# Agentic Commerce - Data Pipelines

This repository contains the data pipelines for the Agentic Commerce project. These pipelines are responsible for ingesting, processing, and enriching product data for use in downstream AI applications.

## Codebase Overview

The core logic of this project is centered around data transformation and loading within the Databricks ecosystem.

### Project Structure

```
agentic_commerce/
├── requirements.txt        # Python dependencies for the project
├── README.md               # This file
├── config/                 #configuration files
├── sql/                    # sql queries
├── src/                    # Source code
│   └── data_pipeline/
│       ├── enrichment/     # Core data enrichment pipelines
│       ├── discovery_data_loader.py # Logic for loading data into Unity Catalog
│       └── ...
```

### Key Components

- **`src/data_pipeline/enrichment/`**: This directory is the heart of the project, containing the Python scripts responsible for the main data enrichment logic. This includes extracting marketing claims, determining product compatibility, and mining reviews.
- **`src/data_pipeline/discovery_data_loader.py`**: This module handles the process of loading the transformed data into Databricks Unity Catalog, ensuring it is available for consumption.

## Getting Started

### Prerequisites

- Python 3.12+
- Conda for environment management

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd agentic_commerce
   ```
2. **Create and activate the Conda environment:**
   ```bash
   conda env create -f environment.yml
   conda activate dbconnect_312
   ```
3. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

### Environment Variables & Databricks Connection

This project can be run both locally and directly on Databricks, and the connection to the Spark cluster is managed automatically. The `src/data_pipeline/enrichment/utils.py` file contains a `get_spark_session` function that handles this logic:

- **When running on a Databricks job cluster**, it uses the native Spark session available in the environment.
- **When running locally**, it uses Databricks Connect to connect to a remote cluster defined in your `.env` file.

1. **Create the `.env` file:**

   ```bash
   cp .env.example .env
   ```
2. **Fill in your credentials** for local development:

   ```env
   # Databricks
   DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
   DATABRICKS_TOKEN=your-personal-access-token
   DATABRICKS_CLUSTER_ID=your-cluster-id
   ```

### Configuration Files (`.yml`)

The project uses `.yml` files for various configuration purposes:


- **`config/general.yml`**: The main configuration file for the pipelines. It defines the source and output tables in dicovery_data_loader and enrichment scripts that the jobs will use.
- **`config/claims_config.yml`**: Contains specific rules and regex patterns for the `claims` enrichment pipeline, used to extract structured marketing claims from unstructured text.
- **`resources/agentic_commerce_data_pipeline.yml`**: Defines the Databricks Asset Bundle (DAB) configuration. This specifies the workflow orchestration, job clusters, and the sequence of enrichment tasks.



## Usage

The data pipelines can be executed as Python scripts. They will automatically connect to Databricks using the method described above.

### discovery_data_loader

Pivots product attributes to create category-specific tables.

```bash
python src/data_pipeline/discovery_data_loader.py
```

### Example enrichment: Claims Enrichment

Extracts structured marketing claims from product data.

```bash
python src/data_pipeline/enrichment/claims.py
```

---

*Recent Major Updates:* 
* DAB Setup
* Implemented Row Hashing(change detection) for final table merge

---

*Author: Venkat Neelraj Nitta*

*Last Updated: April 28, 2026*