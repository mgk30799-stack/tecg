import time
import logging

logger = logging.getLogger(__name__)
from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window


def parse_bool(value: str) -> bool:
    return str(value).strip().lower() in {"1", "true", "t", "yes", "y"}


# CDC errors that indicate a stale or incompatible checkpoint and require
# a checkpoint reset + stream restart to recover.
_CDC_RECOVERABLE_ERRORS = (
    "DELTA_INVALID_CDC_RANGE",     # checkpoint version no longer exists (post full_refresh)
    "DELTA_MISSING_CHANGE_DATA",   # checkpoint version predates when CDF was enabled
)


def _get_cdf_start_version(spark, table_name: str) -> str:
    """
    Find the earliest Delta version at which CDF data is actually available.

    CDF data is only written for operations that occur AFTER
    delta.enableChangeDataFeed is set to true. This function locates the
    SET TBLPROPERTIES event that enabled CDF, then returns the version of
    the first subsequent write operation — i.e. the earliest version from
    which a CDF stream can successfully start.

    Falls back to 'latest' when the history cannot be parsed.
    """
    try:
        history_df = spark.sql(f"DESCRIBE HISTORY {table_name}") \
            .select("version", "operation", "operationParameters")

        # Identify the version where CDF was switched on
        cdf_enabled_at = (
            history_df
            .filter(F.to_json(F.col("operationParameters")).contains("enableChangeDataFeed"))
            .agg(F.min("version"))
            .first()[0]
        )

        if cdf_enabled_at is None:
            return "latest"

        # The first write AFTER that version is the earliest readable CDF version
        write_ops = (
            "WRITE", "MERGE", "UPDATE", "DELETE",
            "CREATE OR REPLACE TABLE AS SELECT",
            "CREATE TABLE AS SELECT", "COPY INTO",
        )
        first_write = (
            history_df
            .filter(F.col("version") >= cdf_enabled_at)
            .filter(F.col("operation").isin(*write_ops))
            .orderBy("version")
            .first()
        )
        if first_write:
            version = str(first_write["version"])
            print(f"[stream] First CDF-available version of {table_name}: {version} "
                  f"(CDF enabled at v{cdf_enabled_at})")
            return version

    except Exception as exc:
        logger.warning(f"[stream] Could not determine CDF start version for {table_name}: {exc}")

    return "latest"


def _exception_text(e) -> str:
    """
    All the text an exception carries. In some Databricks runtimes
    StreamingQueryException.str() is a short wrapper that omits the Java error
    code, so collect every attribute and the cause chain.
    """
    parts = [str(e), repr(e)]
    for attr in ("cause", "message", "desc", "stackTrace", "errorClass"):
        val = getattr(e, attr, None)
        if val:
            parts.append(str(val))
    inner = getattr(e, "__cause__", None) or getattr(e, "__context__", None)
    if inner:
        parts.extend([str(inner), repr(inner)])
    return " ".join(parts)


# A schema-tracked stream stops ONCE after every schema change on its source
# (column added, dropped, renamed, or a widened type) with this error, after
# recording the new schema. Restarting from the SAME checkpoint continues.
# The pipeline's own schema validation layer causes exactly these changes on
# product_master_enriched_t, so the restart is part of normal operation.
_SCHEMA_EVOLUTION_STOP = "DELTA_STREAMING_METADATA_EVOLUTION"


def start_stream_with_cdc_recovery(
    spark,
    dbutils,
    source_table: str,
    checkpoint_path: str,
    process_batch_fn,
    timeout_seconds: int = 3600,
    starting_version: str = "latest",
    allow_source_column_drop: bool = False,
    allow_source_column_type_change: bool = False,
    max_schema_restarts: int = 10,
) -> None:
    """
    Start a foreachBatch stream with automatic recovery from stale CDC
    checkpoints and from source schema changes.

    Recovers from two CDC error types that both require a checkpoint reset:
    - DELTA_INVALID_CDC_RANGE: checkpoint version no longer exists (e.g. after
      a full_refresh drop/recreate of the source table).
    - DELTA_MISSING_CHANGE_DATA: checkpoint version predates when CDF was enabled
      on the source table (CDF enabled after the first write, or table recreated
      without CDF and later enabled). On restart, the stream is anchored to the
      first version that actually has CDF data to avoid the same error recurring.
    In both cases the checkpoint is cleared and the stream restarts once.

    Also restarts, KEEPING the checkpoint, when the stream stops with
    DELTA_STREAMING_METADATA_EVOLUTION — the expected stop after a schema
    change on the source. Each schema change in the source history stops the
    stream once, so this can repeat; it is capped at max_schema_restarts.
    A type change that is not a widening (e.g. ARRAY -> STRUCT) cannot be
    continued from the checkpoint and still fails the job.

    Args:
        spark: Active SparkSession.
        dbutils: Databricks dbutils object.
        source_table: Fully-qualified source Delta table to stream from.
        checkpoint_path: Path to the streaming checkpoint location.
        process_batch_fn: foreachBatch callable (batch_df, batch_id) -> None.
        timeout_seconds: awaitTermination timeout (default: 3600s).
        starting_version: startingVersion for a fresh checkpoint.
        allow_source_column_drop: Continue past DROP COLUMN in the source
            history instead of failing with
            DELTA_STREAMING_CANNOT_CONTINUE_PROCESSING_POST_SCHEMA_EVOLUTION.
            Enable only when the sink does not depend on the dropped columns.
        allow_source_column_type_change: Continue past a type WIDENING in the
            source history (e.g. INT -> BIGINT). Enable only when the sink's
            projection tolerates the wider type.
        max_schema_restarts: Cap on schema-change restarts in one run.
    """
    def _build_stream(sv):
        reader = (
            spark.readStream
            .option("readChangeFeed", "true")
            .option("startingVersion", sv)
            .option("schemaTrackingLocation", f"{checkpoint_path}/_schema_tracking")
        )
        if allow_source_column_drop:
            reader = reader.option("allowSourceColumnDrop", "always")
        if allow_source_column_type_change:
            reader = reader.option("allowSourceColumnTypeChange", "always")
        return (
            reader
            .table(source_table)
            .writeStream
            .foreachBatch(process_batch_fn)
            .option("checkpointLocation", checkpoint_path)
            .trigger(availableNow=True)
            .start()
        )

    def _discard(stream):
        try:
            stream.stop()
        except Exception:
            pass
        # Reset terminated stream registry so Databricks notebook runtime
        # does not flag the failed stream after the recovery stream succeeds.
        try:
            spark.streams.resetTerminated()
        except Exception:
            pass

    stream_version = starting_version
    checkpoint_reset_done = False
    schema_restarts = 0
    while True:
        stream = _build_stream(stream_version)
        try:
            if not stream.awaitTermination(timeout_seconds):
                raise TimeoutError(
                    f"Streaming job did not complete within {timeout_seconds}s. "
                    f"Check for source table locks, checkpoint corruption, or vector index issues."
                )
            if checkpoint_reset_done:
                print("[stream] Stream completed successfully after checkpoint reset.")
            return
        except Exception as e:
            err_text = _exception_text(e)

            if _SCHEMA_EVOLUTION_STOP in err_text and schema_restarts < max_schema_restarts:
                schema_restarts += 1
                print(
                    f"[stream] Source schema changed ({_SCHEMA_EVOLUTION_STOP}). "
                    f"Restarting from the same checkpoint "
                    f"({schema_restarts}/{max_schema_restarts})..."
                )
                _discard(stream)
                continue

            matched_error = next(
                (code for code in _CDC_RECOVERABLE_ERRORS if code in err_text), None
            )
            if not matched_error or checkpoint_reset_done:
                raise

            print(
                f"[stream] Stale checkpoint detected ({matched_error}). "
                f"Clearing checkpoint at {checkpoint_path} and restarting stream..."
            )
            _discard(stream)
            try:
                dbutils.fs.rm(checkpoint_path, True)
                print(f"[stream] Checkpoint cleared: {checkpoint_path}")
            except Exception as rm_exc:
                print(f"[stream] Warning: could not clear checkpoint: {rm_exc}")

            # For DELTA_MISSING_CHANGE_DATA the original startingVersion may itself
            # predate CDF enablement, so resolve the true first CDF-available version
            # before restarting to prevent the same error from recurring.
            if matched_error == "DELTA_MISSING_CHANGE_DATA":
                stream_version = _get_cdf_start_version(spark, source_table)
            checkpoint_reset_done = True


def upsert_preserving_embeddings(
    target,
    upsert_df: DataFrame,
    merge_condition: str,
    text_col: str,
    emb_col: str,
) -> None:
    """
    MERGE `upsert_df` into `target`, keeping a row's existing embedding when
    the text it was computed from has not changed.

    upsert_df carries emb_col = NULL for every row (backfill_embeddings fills
    NULLs later). A plain whenMatchedUpdateAll therefore wiped the embedding of
    every row the change feed touched, even when only an unrelated column
    changed — and a schema migration of the source touches every row, which
    meant re-embedding the whole catalog. Now:
      - matched, same text, embedding present -> update every column EXCEPT
        the embedding
      - matched, text changed (or no embedding yet) -> update all; the
        embedding becomes NULL and is re-computed
      - not matched -> insert
    """
    keep_embedding = {c: f"s.`{c}`" for c in upsert_df.columns if c != emb_col}
    (
        target.alias("t").merge(upsert_df.alias("s"), merge_condition)
        .whenMatchedUpdate(
            condition=f"t.`{text_col}` <=> s.`{text_col}` AND t.`{emb_col}` IS NOT NULL",
            set=keep_embedding,
        )
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )


def get_smart_latest_version(spark, table_name: str) -> str:
    """
    Reads the Delta history and returns the version number of the 
    most recent actual data change, ignoring OPTIMIZE and VACUUM.
    """
    history_df = spark.sql(f"DESCRIBE HISTORY {table_name}")
    
    # latest_valid_version
    valid_ops = (
        "'WRITE', 'MERGE', 'UPDATE', 'DELETE', "
        "'CREATE OR REPLACE TABLE', 'CREATE OR REPLACE TABLE AS SELECT', "
        "'CREATE TABLE AS SELECT', 'COPY INTO', 'RESTORE', 'CLONE'"
    )
    
    latest_row = (
        history_df
        .filter(f"operation IN ({valid_ops})")
        .orderBy(F.col("version").desc())
        .select("version")
        .first()
    )
    
    # Default to "latest" to prevent Change Data Feed (CDF) crashes on version 0
    if latest_row is None:
        print(f"⚠️ Warning: No explicit data operations found in {table_name}. Defaulting to 'latest'.")
        return "latest"
        
    latest_valid_version = latest_row[0]

    # Guard: if the latest data write predates CDF enablement the stream will
    # immediately fail with DELTA_MISSING_CHANGE_DATA. Use the first
    # CDF-available version instead so the stream starts in a valid range.
    cdf_version_str = _get_cdf_start_version(spark, table_name)
    if cdf_version_str not in ("latest", None):
        try:
            cdf_version_int = int(cdf_version_str)
            if latest_valid_version < cdf_version_int:
                print(
                    f"  Latest data write (v{latest_valid_version}) predates CDF start "
                    f"(v{cdf_version_int}). Using CDF start version instead."
                )
                return cdf_version_str
        except (ValueError, TypeError):
            pass

    print(f"Smart Latest for {table_name} is Version {latest_valid_version}")
    return str(latest_valid_version)
    
def keep_latest_change_per_key(input_df, key_columns):
    """
    Deduplicate CDF (Change Data Feed) records to keep only the latest change per key.

    Priority order within the same commit version:
    1. insert/update_postimage (highest - final state)
    2. update_preimage (middle - intermediate state)
    3. delete (lowest - only wins if it's truly the final operation)

    This ensures that in overwrite scenarios (where delete + insert occur in the same commit),
    the insert record wins, preventing mass deletions.
    """
    order_columns = []
    if "_commit_version" in input_df.columns:
        order_columns.append(F.col("_commit_version").desc())
    if "_commit_timestamp" in input_df.columns:
        order_columns.append(F.col("_commit_timestamp").desc())
    if "_change_type" in input_df.columns:
        order_columns.append(
            F.when(F.col("_change_type").isin("update_postimage", "insert"), F.lit(3))
            .when(F.col("_change_type") == "update_preimage", F.lit(2))
            .when(F.col("_change_type") == "delete", F.lit(1))
            .otherwise(F.lit(0))
            .desc()
        )

    if not order_columns:
        return input_df.dropDuplicates(key_columns)

    latest_record_window = Window.partitionBy(*key_columns).orderBy(*order_columns)
    return (
        input_df.withColumn(
            "_latest_row_num", F.row_number().over(latest_record_window)
        )
        .filter(F.col("_latest_row_num") == 1)
        .drop("_latest_row_num")
    )


def backfill_embeddings(
    spark,
    table_path: str,
    pk_col: str,
    text_col: str,
    emb_col: str,
    embedding_endpoint: str,
    embedding_batch_size: int,
    max_batches: int = 50,
    return_type: str = "ARRAY<FLOAT>",
    concurrency_cap: int = 20,
    max_retries: int = 5,
    retry_base_wait_seconds: int = 10,
) -> None:
    """
    Backfill NULL embedding vectors in an index source table using ai_query().

    Iterates in batches, merging pre-computed embeddings back into the table
    until all rows have a non-NULL embedding or max_batches is reached.

    Concurrency control:
        Each batch's ai_query() calls are capped to `concurrency_cap` parallel
        tasks via a REPARTITION hint, to avoid bursting past the serving
        endpoint's QPM/TPM rate limits. Without this, Spark schedules as many
        concurrent ai_query() HTTP calls as there are partitions/tasks, which
        can blow through endpoint rate limits almost instantly and cause
        RpcTimeoutException / stage failures when throttled tasks stall past
        spark.rpc.askTimeout.

    Retry/backoff:
        If a batch's MERGE fails with a rate-limit or RPC-timeout-flavored
        error, it is retried with exponential backoff up to `max_retries`
        times before giving up.

    Args:
        spark: Active SparkSession.
        table_path: Fully-qualified Delta table name (catalog.schema.table).
        pk_col: Primary key column used in the MERGE ON condition.
        text_col: Source text column passed to ai_query().
        emb_col: Embedding vector column to populate (ARRAY<FLOAT>).
        embedding_endpoint: Databricks model serving endpoint name.
        embedding_batch_size: Maximum number of rows to embed per batch.
            NOTE: keep this modest (e.g. 5,000-20,000). A very large value
            (e.g. 1,000,000) defeats the purpose of batching since Spark
            will still try to process the whole batch in one job; use
            `concurrency_cap` and `max_batches` to control total throughput
            and coverage instead of inflating this number.
        max_batches: Safety cap to prevent infinite loops (default: 50).
        return_type: ai_query() return type for the embedding vector (default: 'ARRAY<FLOAT>').
        concurrency_cap: Max parallel tasks (and therefore max concurrent
            ai_query() HTTP calls) per batch. Tune based on observed
            per-call latency and the endpoint's QPM limit, e.g.:
                concurrency_cap ~= (target_QPM / 60) * expected_latency_seconds
            Start conservative (e.g. 15-25) and increase only if endpoint
            metrics show headroom.
        max_retries: Number of retry attempts for a failed batch before
            raising.
        retry_base_wait_seconds: Base wait time for exponential backoff
            between retries (actual wait = base * 2**attempt).
    """
    batch_num = 0
    total_embedded = 0
    start_time = time.time()

    print(
        f"[embed] Starting backfill | table={table_path} | emb_col={emb_col} "
        f"| batch_size={embedding_batch_size} | max_batches={max_batches} "
        f"| concurrency_cap={concurrency_cap}"
    )

    # Errors that indicate rate limiting / throttling / stalled RPCs and are
    # worth retrying with backoff, as opposed to real data/schema errors.
    _RETRYABLE_ERROR_SIGNATURES = (
        "429",
        "RESOURCE_EXHAUSTED",
        "RpcTimeoutException",
        "rate limit",
        "RATE_LIMIT",
        "throttl",
        "TOO_MANY_REQUESTS",
        "askTimeout",
    )

    def _is_retryable(exc: Exception) -> bool:
        text = str(exc)
        return any(sig.lower() in text.lower() for sig in _RETRYABLE_ERROR_SIGNATURES)

    def _run_merge_with_retry(merge_sql: str) -> None:
        for attempt in range(max_retries + 1):
            try:
                spark.sql(merge_sql)
                return
            except Exception as exc:
                if attempt < max_retries and _is_retryable(exc):
                    wait = retry_base_wait_seconds * (2 ** attempt)
                    print(
                        f"[embed] Retryable error on attempt {attempt + 1}/{max_retries + 1} "
                        f"({exc.__class__.__name__}). Backing off {wait}s before retry..."
                    )
                    time.sleep(wait)
                    continue
                raise

    while True:
        remaining = spark.sql(
            f"SELECT count(*) FROM {table_path} WHERE {emb_col} IS NULL"
        ).first()[0]

        if remaining == 0:
            print(
                f"[embed] Complete | total_embedded={total_embedded} "
                f"| elapsed={time.time() - start_time:.1f}s"
            )
            break

        batch_num += 1
        if batch_num > max_batches:
            print(
                f"[embed] STOPPED | hit max_batches={max_batches} | remaining={remaining}"
            )
            break

        batch_start = time.time()
        print(
            f"[embed] Batch {batch_num}/{max_batches} | remaining={remaining} "
            f"| processing up to {embedding_batch_size} rows "
            f"| concurrency_cap={concurrency_cap}..."
        )

        rows_before = remaining

        merge_sql = f"""
            MERGE INTO {table_path} t
            USING (
                SELECT /*+ REPARTITION({concurrency_cap}) */
                       {pk_col},
                       ai_query('{embedding_endpoint}', {text_col}, returnType => '{return_type}') AS emb
                FROM (
                    SELECT {pk_col}, {text_col}
                    FROM {table_path}
                    WHERE {emb_col} IS NULL
                    LIMIT {embedding_batch_size}
                )
            ) s
            ON t.{pk_col} = s.{pk_col}
            WHEN MATCHED THEN UPDATE SET
                t.{emb_col} = s.emb,
                t.updated_at = current_timestamp()
        """

        _run_merge_with_retry(merge_sql)

        rows_after = spark.sql(
            f"SELECT count(*) FROM {table_path} WHERE {emb_col} IS NULL"
        ).first()[0]

        rows_embedded = rows_before - rows_after
        total_embedded += rows_embedded
        batch_elapsed = time.time() - batch_start

        print(
            f"[embed] Batch {batch_num} done | embedded={rows_embedded} "
            f"| batch_time={batch_elapsed:.1f}s | total_embedded={total_embedded}"
        )

        if rows_embedded == 0:
            print(
                f"[embed] WARNING | no progress made this batch "
                f"| {rows_after} rows may have invalid {text_col}"
            )
            break

    final_null = spark.sql(
        f"SELECT count(*) FROM {table_path} WHERE {emb_col} IS NULL"
    ).first()[0]
    print(f"[embed] Final NULL count: {final_null}")


def infer_embedding_dimension(spark, table_path: str, emb_col: str) -> int:
    """
    Infer the embedding vector dimension from an existing non-NULL row.

    Args:
        spark: Active SparkSession.
        table_path: Fully-qualified Delta table name (catalog.schema.table).
        emb_col: Embedding vector column (ARRAY<FLOAT>).

    Returns:
        Integer dimension of the embedding vector.
    """
    dimension = spark.sql(f"""
        SELECT size({emb_col}) FROM {table_path}
        WHERE {emb_col} IS NOT NULL LIMIT 1
    """).first()[0]
    print(f"Embedding dimension: {dimension}")
    return dimension

def reconcile_orphans(
    spark,
    target_table: str,
    target_key_col: str,
    source_table: str,
    source_key_col: str,
) -> int:
    """
    Remove orphaned rows from target table that no longer exist in the source table.

    Handles items that slipped through CDC gaps (e.g. checkpoint was past delete events,
    or full_refresh on source didn't propagate all deletes via CDF).

    Should be called AFTER the CDC stream completes and BEFORE embedding backfill/index sync.

    Args:
        spark: Active SparkSession.
        target_table: Fully-qualified target table to clean (e.g. VS index source table).
        target_key_col: Primary key column in target table (e.g. "product_id").
        source_table: Fully-qualified source-of-truth table (e.g. product_master_enriched_t).
        source_key_col: Primary key column in source table (e.g. "item_id").

    Returns:
        Number of orphaned rows removed.
    """
    orphan_df = spark.sql(f"""
        SELECT DISTINCT t.{target_key_col}
        FROM {target_table} t
        LEFT ANTI JOIN {source_table} s
            ON t.{target_key_col} = s.{source_key_col}
    """).cache()

    orphan_count = orphan_df.count()

    if orphan_count == 0:
        logger.info(f"[reconcile] No orphaned rows found in {target_table}.")
        orphan_df.unpersist()
        return 0

    logger.info(f"[reconcile] Found {orphan_count} orphaned rows in {target_table}. Removing...")
    target_dt = DeltaTable.forName(spark, target_table)
    target_dt.alias("t").merge(
        orphan_df.alias("orphans"),
        f"t.{target_key_col} = orphans.{target_key_col}",
    ).whenMatchedDelete().execute()

    orphan_df.unpersist()
    logger.info(f"[reconcile] {orphan_count} orphan rows removed from {target_table}.")
    return orphan_count