# Common notebook modules.
