# Databricks notebook source
# MAGIC %pip install --disable-pip-version-check mlflow==3.15.2 databricks-sdk==0.133.0 databricks-vectorsearch==0.75
# MAGIC %restart_python

# COMMAND ----------

import json

from databricks.vector_search.client import VectorSearchClient
from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

# COMMAND ----------

import sys
import os
import yaml

# Add paths for shared utilities
_cwd = os.getcwd()
_common_path = os.path.join(_cwd, "common")
if _common_path not in sys.path:
    sys.path.insert(0, _common_path)

sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode, validate_before_write
from shared import keep_latest_change_per_key, backfill_embeddings, infer_embedding_dimension, start_stream_with_cdc_recovery, get_smart_latest_version, reconcile_orphans, upsert_preserving_embeddings

_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_documents_index"]

dbutils.widgets.text("checkpoint_base_path", defaultValue=sync_config["checkpoint_base_path"])
checkpoint_base_path = dbutils.widgets.get("checkpoint_base_path")

# ---------------------------------------------------------------------------
# Tables & vector search settings from config
# ---------------------------------------------------------------------------
product_docs_table_path = sync_config["tables"]["source_table"]
vs_index_source_table_path = sync_config["tables"]["vs_index_source_table"]

vs_endpoint_name = sync_config["vectorsearch"]["endpoint_name"]
vs_index_path = sync_config["vectorsearch"]["index_name"]
embedding_endpoint = sync_config["vectorsearch"]["embedding_endpoint"]
embedding_batch_size = sync_config["vectorsearch"]["embedding_batch_size"]
checkpoint_path = f"{checkpoint_base_path}/sync_product_documents_index"
permissions_groups = sync_config["permissions_groups"]

# ---------------------------------------------------------------------------
# Ensure checkpoint volume exists
# ---------------------------------------------------------------------------
_volume_parts = checkpoint_base_path.strip("/").split("/")
if len(_volume_parts) >= 4 and _volume_parts[0].lower() == "volumes":
    _vol_catalog = _volume_parts[1]
    _vol_schema = _volume_parts[2]
    _vol_name = _volume_parts[3]
    spark.sql(
        f"CREATE VOLUME IF NOT EXISTS {_vol_catalog}.{_vol_schema}.{_vol_name}"
    )
    print(f"Ensured volume exists: {_vol_catalog}.{_vol_schema}.{_vol_name}")

# ---------------------------------------------------------------------------
# Runtime parameters (only full_refresh remains as a widget)
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
full_refresh = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_docs_table_path}")
print(f"Index source: {vs_index_source_table_path}")
print(f"Vector index: {vs_index_path}")
print(f"Checkpoint: {checkpoint_path}")
print(f"Embedding Batch Size: {embedding_batch_size}")
print(f"Full refresh: {full_refresh}")

if full_refresh:
    print(
        "Full refresh requested: deleting checkpoint, source table, and vector index."
    )
    try:
        dbutils.fs.rm(checkpoint_path, True)
    except Exception as exc:
        print(f"Skipping checkpoint cleanup at {checkpoint_path}: {exc}")
    spark.sql(f"DROP TABLE IF EXISTS {vs_index_source_table_path}")
    try:
        vsc_for_delete = VectorSearchClient(disable_notice=True)
        try:
            vsc_for_delete.delete_index(
                endpoint_name=vs_endpoint_name, index_name=vs_index_path
            )
            print(f"✓ Vector index deleted: {vs_index_path}")
        except TypeError:
            vsc_for_delete.delete_index(vs_endpoint_name, vs_index_path)
            print(f"✓ Vector index deleted: {vs_index_path}")
    except Exception as exc:
        if "does not exist" in str(exc).lower():
            print(f"ℹ️ Vector index not found in UC catalog (may not exist or already deleted): {vs_index_path}")
        else:
            print(f"⚠️ WARNING: Failed to delete vector index {vs_index_path}: {exc}")
            print("   The index may still exist. Check Vector Search UI and delete manually if needed.")


@F.udf(T.ArrayType(T.StringType()))
def clean_and_chunk_data(json_str):
    if not json_str:
        return []
    try:
        data = json.loads(json_str)
        elements = data.get("document", {}).get("elements", [])
        if not elements:
            return []

        seen_content_pos = set()
        unique_elements = []
        for el in elements:
            content = str(el.get("content", "")).strip()
            if not content:
                continue
            bbox = el.get("bbox", [])
            if bbox and isinstance(bbox, list) and len(bbox) > 0:
                coord = bbox[0].get("coord", [0, 0, 0, 0])
                y_pos = (
                    round(coord[1], -1)
                    if isinstance(coord, list) and len(coord) > 1
                    else 0
                )
                pos_sig = (content, y_pos)
            else:
                pos_sig = (content, 0)
            if pos_sig not in seen_content_pos:
                unique_elements.append(el)
                seen_content_pos.add(pos_sig)

        excluded_types = {"page_footer", "page_header", "page_number"}
        header_types = {"section_header", "title"}

        chunks = []
        current_buffer = []
        active_header = "General Information"
        current_len = 0
        max_chunk_size = 2000

        for el in unique_elements:
            e_type = el.get("type")
            content = str(el.get("content", "")).strip()
            if e_type in excluded_types:
                continue

            if e_type in header_types:
                if current_buffer:
                    chunks.append("\n".join(current_buffer))
                    current_buffer = []
                    current_len = 0
                active_header = content
                current_buffer.append(f"SECTION: {active_header}")
                current_len = len(active_header)
                continue

            if current_len + len(content) > max_chunk_size and current_buffer:
                chunks.append("\n".join(current_buffer))
                current_buffer = [f"SECTION: {active_header} (continued)"]
                current_len = len(current_buffer[0])

            current_buffer.append(content)
            current_len += len(content)

        if current_buffer:
            chunks.append("\n".join(current_buffer))

        return chunks
    except Exception:
        return []


def build_document_id_expr(input_df: DataFrame):
    cols = set(input_df.columns)
    document_id_candidates = [
        "document_id",
        "doc_id",
        "source_document_id",
        "source_doc_id",
        "document_url",
        "url",
    ]
    document_expr = None
    for candidate in document_id_candidates:
        if candidate in cols:
            expr = F.col(candidate).cast("string")
            document_expr = (
                expr if document_expr is None else F.coalesce(document_expr, expr)
            )

    if document_expr is None:
        document_expr = F.lit("")

    return F.sha2(
        F.concat_ws(
            "||",
            F.coalesce(F.col("item_id").cast("string"), F.lit("")),
            F.coalesce(document_expr, F.lit("")),
        ),
        256,
    )


def build_document_index_projection(input_df: DataFrame):
    return (
        input_df.filter(F.col("download_status") == "Success")
        .withColumn("document_id", build_document_id_expr(input_df))
        .withColumn("chunks", clean_and_chunk_data(F.to_json(F.col("parsed_data"))))
        .select(
            F.col("item_id").alias("product_id"),
            F.col("document_id"),
            F.col("url"),
            F.col("doc_type").cast("string").alias("doc_type"),
            F.posexplode(F.col("chunks")).alias("chunk_index_zero_based", "chunk_text"),
        )
        .withColumn("chunk_index", F.col("chunk_index_zero_based") + F.lit(1))
        .drop("chunk_index_zero_based")
        .withColumn(
            "chunk_id",
            F.md5(
                F.concat_ws(
                    "||",
                    F.col("product_id").cast("string"),
                    F.col("document_id").cast("string"),
                    F.col("chunk_index").cast("string"),
                )
            ),
        )
        .select(
            F.col("chunk_id"),
            F.col("product_id"),
            F.col("document_id"),
            F.col("url"),
            F.col("doc_type"),
            F.col("chunk_text"),
            F.col("chunk_index"),
        )
        .where(F.col("product_id").isNotNull())
        .where(F.length(F.trim(F.col("chunk_text"))) > 0)
    )


def build_upsert_frame(input_df: DataFrame):
    """
    The exact rows written to the index table: projection + embedding slot +
    timestamps. The initial load, process_batch and the schema validation
    all use this, so the declared shape can never drift from what is written.
    """
    return build_document_index_projection(input_df).withColumns({
        "chunk_text_emb": F.lit(None).cast("array<float>"),
        "created_at": F.current_timestamp(),
        "updated_at": F.current_timestamp(),
    })


source_table_initialized = False
if not spark.catalog.tableExists(vs_index_source_table_path):
    # Capture absolute latest version before reading snapshot
    source_history_df = spark.sql(f"DESCRIBE HISTORY {product_docs_table_path} LIMIT 1")
    starting_version = str(source_history_df.collect()[0]["version"])
    print(f"Initial load: captured source at version {starting_version}")

    (
        build_upsert_frame(spark.table(product_docs_table_path))
        .write.mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(vs_index_source_table_path)
    )
    source_table_initialized = True

if source_table_initialized:
    for group_name in permissions_groups:
        spark.sql(
            f"GRANT MANAGE ON TABLE {vs_index_source_table_path} TO `{group_name}`"
        )

    # Delete checkpoint when schema is rebuilt to prevent mismatch
    print(f"Schema was rebuilt. Deleting checkpoint at {checkpoint_path} to avoid schema mismatch.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
        print(f"✓ Checkpoint deleted successfully")
    except Exception as e:
        print(f"Warning: Could not delete checkpoint: {e}")

spark.sql(
    f"ALTER TABLE {vs_index_source_table_path} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
)


def process_batch(batch_df: DataFrame, batch_id: int):
    print(f"Processing batch_id={batch_id}")

    latest_changes_df = batch_df.where(F.col("item_id").isNotNull())
    latest_changes_df = latest_changes_df.withColumn(
        "document_id", build_document_id_expr(latest_changes_df)
    )
    latest_changes_df = keep_latest_change_per_key(
        latest_changes_df,
        ["item_id", "document_id"]
    )

    changed_docs_df = latest_changes_df.select(
        F.col("item_id").alias("product_id"),
        F.col("document_id"),
    ).dropDuplicates(["product_id", "document_id"])

    upsert_df = build_upsert_frame(
        latest_changes_df.filter(
            F.col("_change_type").isin("insert", "update_postimage")
        )
    ).dropDuplicates(["chunk_id"])

    upsert_count = upsert_df.count()
    changed_docs_count = changed_docs_df.count()

    print(f"batch_id={batch_id}: changed_docs={changed_docs_count}, upsert_chunks={upsert_count}")

    target = DeltaTable.forName(spark, vs_index_source_table_path)

    # Only delete chunks for documents that have NEW chunk data to replace them
    # This prevents data loss if a document's content becomes empty
    if upsert_count > 0:
        # Get distinct documents from upsert_df (these have new chunk data)
        docs_to_delete = upsert_df.select(
            F.col("product_id"), F.col("document_id")
        ).dropDuplicates(["product_id", "document_id"])

        # Delete only the STALE chunks of those documents — rows whose
        # chunk_id is not in the new data. Chunks that are still present stay,
        # so the MERGE below can keep their embedding when the text is
        # unchanged. The end state is the same as delete-all-then-insert.
        stale_chunks = (
            spark.table(vs_index_source_table_path)
            .select("chunk_id", "product_id", "document_id")
            .join(docs_to_delete, ["product_id", "document_id"], "left_semi")
            .join(upsert_df.select("chunk_id"), "chunk_id", "left_anti")
            .select("chunk_id")
        )
        target.alias("t").merge(
            stale_chunks.alias("d"),
            "t.chunk_id = d.chunk_id",
        ).whenMatchedDelete().execute()

        # Insert new chunks; keep embeddings whose chunk_text is unchanged
        upsert_preserving_embeddings(
            target, upsert_df, "t.chunk_id = s.chunk_id",
            text_col="chunk_text", emb_col="chunk_text_emb",
        )

        print(f"batch_id={batch_id}: Deleted old chunks and inserted/updated {upsert_count} chunk rows")
    else:
        print(f"batch_id={batch_id}: No chunks to upsert (empty documents or no insert/update changes)")

# === CHOOSE THE CORRECT STARTING VERSION ===
if source_table_initialized:
    final_stream_version = starting_version 
    print(f"Using Anchor Version for stream: {final_stream_version}")
else:
    final_stream_version = get_smart_latest_version(spark, product_docs_table_path)

# === SCHEMA VALIDATION (first, once, before the stream) ===
# Schema-only: limit(0) reads no rows. Evolve never drops an index column.
validate_before_write(
    spark, vs_index_source_table_path,
    build_upsert_frame(spark.table(product_docs_table_path).limit(0)).schema,
)

start_stream_with_cdc_recovery(
    spark=spark,
    dbutils=dbutils,
    source_table=product_docs_table_path,
    checkpoint_path=checkpoint_path,
    process_batch_fn=process_batch,
    starting_version=final_stream_version,
)

# ---------------------------------------------------------------------------
# Reconcile orphans: remove chunks for products no longer in source
# ---------------------------------------------------------------------------
reconcile_orphans(
    spark=spark,
    target_table=vs_index_source_table_path,
    target_key_col="product_id",
    source_table=product_docs_table_path,
    source_key_col="item_id",
)


# COMMAND ----------

# ---------------------------------------------------------------------------
# Validation: Confirm source and index source are in sync (Distinct Products)
# 
# NOTE: This is a WARNING validation, not a blocker. Sync gaps can occur due to:
#   1. Documents with empty/null content (expected - nothing to chunk/index)
#   2. Streaming lag (chunks arrive shortly after documents change)
#   3. Products deleted from source (orphan cleanup handles these)
# 
# Use full_refresh if gaps exceed 5% of total products
# ---------------------------------------------------------------------------

# Use the exact projection to accurately count products that ACTUALLY have chunks
expected_product_count = (
    build_document_index_projection(spark.table(product_docs_table_path))
    .select(F.countDistinct("product_id"))
    .collect()[0][0]
)

actual_product_count = (
    spark.table(vs_index_source_table_path)
    .select(F.countDistinct("product_id"))
    .collect()[0][0]
)

# Total products in source
total_source_products = spark.table(product_docs_table_path).select(
    F.countDistinct("item_id")
).collect()[0][0]

# Products completely missing from documents index
missing_products = spark.sql(f"""
    SELECT COUNT(DISTINCT s.item_id) as missing_count
    FROM {product_docs_table_path} s
    LEFT JOIN {vs_index_source_table_path} t ON s.item_id = t.product_id
    WHERE t.product_id IS NULL
""").collect()[0][0]

# Products with empty documents
products_without_chunks = total_source_products - expected_product_count

# Calculate sync percentage
sync_percentage = (actual_product_count / total_source_products * 100) if total_source_products > 0 else 0

print(f"\n{'='*70}")
print(f"VALIDATION SUMMARY: Product Documents Index Sync")
print(f"{'='*70}")
print(f"Total products in source table:        {total_source_products:>10}")
print(f"Products with chunks:                  {expected_product_count:>10}")
print(f"Products synced to documents index:    {actual_product_count:>10}")
print(f"Products missing (no chunks):          {products_without_chunks:>10}")
print(f"Products missing from index:           {missing_products:>10}")
print(f"Sync percentage:                       {sync_percentage:>9.1f}%")
print(f"{'='*70}\n")

if expected_product_count > actual_product_count:
    gap = expected_product_count - actual_product_count
    print(f"⚠️  SYNC GAP DETECTED: {gap} products with chunks are not in the documents index")
    print(f"   Action: This is typically resolved by full_refresh or subsequent streaming batches")
    if gap / expected_product_count > 0.05:  # > 5% gap
        print(f"   WARNING: Gap exceeds 5% - consider running full_refresh")
elif expected_product_count < actual_product_count:
    print(f"✓  Validation passed: All products with chunk data are synced")
else:
    print(f"✓  Validation passed: Expected products ({expected_product_count}) == index products ({actual_product_count})")

# COMMAND ----------

# ---------------------------------------------------------------------------
# Backfill embeddings for new/changed rows (NULL -> vector)
# ---------------------------------------------------------------------------
# NOTE: Spark RPC timeout must be configured at cluster creation time (Advanced Options)
backfill_embeddings(
    spark=spark,
    table_path=vs_index_source_table_path,
    pk_col="chunk_id",
    text_col="chunk_text",
    emb_col="chunk_text_emb",
    embedding_endpoint=embedding_endpoint,
    embedding_batch_size=embedding_batch_size,
    concurrency_cap=8,  # Low due to large dataset size
    max_retries=5,
    retry_base_wait_seconds=10,
)

# COMMAND ----------

# ---------------------------------------------------------------------------
# Infer embedding dimension from data
# ---------------------------------------------------------------------------
embedding_dimension = infer_embedding_dimension(
    spark=spark,
    table_path=vs_index_source_table_path,
    emb_col="chunk_text_emb",
)

vsc = VectorSearchClient(disable_notice=True)
try:
    vsc.get_endpoint(vs_endpoint_name)
    print("Endpoint already exists")
except Exception:
    vsc.create_endpoint_and_wait(name=vs_endpoint_name, endpoint_type="STANDARD")
    print("Endpoint created")

import time

def wait_for_deletion(timeout_attempts=24, interval=10):
    for attempt in range(timeout_attempts):
        try:
            vsc.get_index(vs_endpoint_name, vs_index_path)
            print(f"Waiting for index deletion... ({attempt + 1})")
            time.sleep(interval)
        except Exception:
            print("Index fully deleted.")
            return
    raise Exception(f"Timed out waiting for index {vs_index_path} to be deleted.")

def delete_index_if_exists():
    try:
        vsc.get_index(vs_endpoint_name, vs_index_path)
        print(f"Deleting index {vs_index_path}...")
        vsc.delete_index(endpoint_name=vs_endpoint_name, index_name=vs_index_path)
        wait_for_deletion()
    except Exception as e:
        if "pending deletion" in str(e).lower():
            print("Index already pending deletion, waiting...")
            wait_for_deletion()
        elif "does not exist" in str(e).lower() or "not found" in str(e).lower():
            print("Index already gone.")
        else:
            raise

def create_index():
    print("Creating Index..")
    vsc.create_delta_sync_index_and_wait(
        endpoint_name=vs_endpoint_name,
        index_name=vs_index_path,
        primary_key="chunk_id",
        source_table_name=vs_index_source_table_path,
        pipeline_type="TRIGGERED",
        embedding_vector_column="chunk_text_emb",
        embedding_dimension=embedding_dimension,
        columns_to_sync=[
            "chunk_id",
            "product_id",
            "document_id",
            "url",
            "doc_type",
            "chunk_text",
            "chunk_text_emb",
            "chunk_index"
        ]
    )
    print("Index created")
    for group_name in permissions_groups:
        spark.sql(f"GRANT MANAGE ON TABLE {vs_index_path} TO `{group_name}`")

index_exists = True
try:
    index = vsc.get_index(vs_endpoint_name, vs_index_path)
    print("Index already exists -> syncing")
except Exception:
    index_exists = False

def sync_index(index, retries=6, interval=30):
    for attempt in range(1, retries + 1):
        try:
            index.sync()
            print("Sync triggered successfully")
            return
        except Exception as e:
            if "not ready" in str(e).lower():
                print(f"Index not ready, retrying in {interval}s... ({attempt}/{retries})")
                time.sleep(interval)
            else:
                raise
    raise Exception(f"Index {vs_index_path} was not ready after {retries} retries.")

if index_exists:
    try:
        index.wait_until_ready()
    except Exception as e:
        if "offline" in str(e).lower():
            print(f"Index {vs_index_path} is offline, recreating...")
            delete_index_if_exists()
            create_index()
        else:
            raise
    else:
        sync_index(index)
else:
    create_index()