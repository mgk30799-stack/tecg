# Databricks notebook source
# MAGIC %pip install --disable-pip-version-check mlflow==3.15.2 databricks-sdk==0.133.0 databricks-ai-search==0.78
# MAGIC %restart_python

# COMMAND ----------

from databricks.ai_search.client import VectorSearchClient
from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType
from pyspark.sql.window import Window

import sys
import os
import yaml
import time

# Add paths for shared utilities
_cwd = os.getcwd()
_common_path = os.path.join(_cwd, "common")
if _common_path not in sys.path:
    sys.path.insert(0, _common_path)

sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode, validate_before_write
from shared import keep_latest_change_per_key, backfill_embeddings, infer_embedding_dimension, start_stream_with_cdc_recovery,reconcile_orphans,get_smart_latest_version, upsert_preserving_embeddings

# COMMAND ----------

_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_detail_index"]

dbutils.widgets.text("checkpoint_base_path", defaultValue=sync_config["checkpoint_base_path"])
checkpoint_base_path = dbutils.widgets.get("checkpoint_base_path")

# ---------------------------------------------------------------------------
# Tables & vector search settings from config
# ---------------------------------------------------------------------------
product_dim_table_path = sync_config["tables"]["source_table"]
vs_index_source_table_path = sync_config["tables"]["vs_index_source_table"]

vs_endpoint_name = sync_config["vectorsearch"]["endpoint_name"]
vs_index_path = sync_config["vectorsearch"]["index_name"]
embedding_endpoint = sync_config["vectorsearch"]["embedding_endpoint"]
embedding_batch_size = sync_config["vectorsearch"]["embedding_batch_size"]
checkpoint_path = f"{checkpoint_base_path}/sync_product_detail_index"
permissions_groups = sync_config["permissions_groups"]

# Minimum faq_summary_json answer_score an answer needs to reach the index.
# FAQ_TAGGING_RULES scores 3-4 as "Referral only" — "contact support", "see the
# manual", "I don't know". Flattened to text those rank exactly like a direct
# answer, so they are dropped here rather than after retrieval. 4 keeps the top
# of that band, which still carries some matchable text; 3 and below does not.
_MIN_INDEXED_ANSWER_SCORE = 4

# ---------------------------------------------------------------------------
# Ensure checkpoint volume exists
# ---------------------------------------------------------------------------
_volume_parts = checkpoint_base_path.strip("/").split("/")
if len(_volume_parts) >= 4 and _volume_parts[0].lower() == "volumes":
    _vol_catalog = _volume_parts[1]
    _vol_schema = _volume_parts[2]
    _vol_name = _volume_parts[3]
    spark.sql(
        f"CREATE VOLUME IF NOT EXISTS {_vol_catalog}.{_vol_schema}.{_vol_name}"
    )
    print(f"Ensured volume exists: {_vol_catalog}.{_vol_schema}.{_vol_name}")

# ---------------------------------------------------------------------------
# Runtime parameters (only full_refresh remains as a widget)
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
full_refresh = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_dim_table_path}")
print(f"Index source: {vs_index_source_table_path}")
print(f"Vector index: {vs_index_path}")
print(f"Checkpoint: {checkpoint_path}")
print(f"Embedding Batch Size: {embedding_batch_size}")
print(f"Full refresh: {full_refresh}")

if full_refresh:
    print(
        "Full refresh requested: deleting checkpoint, source table, and vector index."
    )
    try:
        dbutils.fs.rm(checkpoint_path, True)
    except Exception as exc:
        print(f"Skipping checkpoint cleanup at {checkpoint_path}: {exc}")
    spark.sql(f"DROP TABLE IF EXISTS {vs_index_source_table_path}")
    try:
        vsc_for_delete = VectorSearchClient(disable_notice=True)
        try:
            vsc_for_delete.delete_index(
                endpoint_name=vs_endpoint_name, index_name=vs_index_path
            )
            print(f"✓ Vector index deleted: {vs_index_path}")
        except TypeError:
            vsc_for_delete.delete_index(vs_endpoint_name, vs_index_path)
            print(f"✓ Vector index deleted: {vs_index_path}")
    except Exception as exc:
        if "does not exist" in str(exc).lower():
            print(f"ℹ️ Vector index not found in UC catalog (may not exist or already deleted): {vs_index_path}")
        else:
            print(f"⚠️ WARNING: Failed to delete vector index {vs_index_path}: {exc}")
            print("   The index may still exist. Check Vector Search UI and delete manually if needed.")


# ---------------------------------------------------------------------------
# faq_summary_json schema guards
#
# product_master_enriched_t's faq_summary_json struct is frozen by the
# `CREATE TABLE IF NOT EXISTS ... WHERE 1 = 0` in
# sql/merge_product_enrichment_fields.sql — it is derived once, at table
# creation, and never re-derived. A field added upstream lands here only after
# that merge has evolved the schema, which can lag by a run.
#
# Until it catches up, F.col("faq_summary.<new_field>") raises AnalysisException
# at PLAN time. That is not catchable per-column and it does not fail just the
# FAQ rows — build_product_detail_projection returns one unioned DataFrame, so
# it takes spec, bullets, reviews, claims, highlights and issue signals down
# with it. Resolve against the actual schema instead and degrade to a typed
# NULL, which every consumer below already handles via coalesce.
# ---------------------------------------------------------------------------
def _struct_fields(input_df: DataFrame, column: str, *nested: str) -> set:
    """Field names inside an ARRAY<STRUCT<...>> column, following `nested` down.

    Returns an empty set if the column, or any struct on the path, is absent —
    which makes every _faq_col/_answer_col lookup below fall back to NULL.
    """
    try:
        dtype = input_df.schema[column].dataType
        for name in (None, *nested):
            if isinstance(dtype, ArrayType):
                dtype = dtype.elementType
            if name is not None:
                dtype = dtype[name].dataType
                if isinstance(dtype, ArrayType):
                    dtype = dtype.elementType
        return {f.name for f in dtype.fields}
    except Exception:
        return set()


def _faq_col(present: set, name: str, dtype: str):
    """faq_summary.<name>, or a typed NULL when the frozen struct predates it."""
    if name in present:
        return F.col(f"faq_summary.{name}")
    return F.lit(None).cast(dtype)


def _answer_col(present: set, answer, name: str, dtype: str):
    """answers[].<name>, or a typed NULL. `answer` is the lambda's element."""
    if name in present:
        return answer[name]
    return F.lit(None).cast(dtype)


def build_product_detail_projection(input_df: DataFrame):
    faq_fields = _struct_fields(input_df, "faq_summary_json")
    answer_fields = _struct_fields(input_df, "faq_summary_json", "answers")

    _expected = {"question_tags", "conflict_flag"} - faq_fields
    _expected |= {"answer_tags", "answer_score"} - answer_fields
    if _expected:
        print(
            f"⚠️ faq_summary_json is missing LLM field(s) {sorted(_expected)} — "
            "indexing them as NULL. The enrichment merge has not evolved "
            "product_master_enriched_t yet; see the MERGE WITH SCHEMA EVOLUTION "
            "block at the end of sql/merge_product_enrichment_fields.sql."
        )

    base_df = input_df.select(
        F.col("item_id").alias("product_id"),
        F.col("spec_json"),
        F.col("bullets_json"),
        F.col("reviews"),
        F.col("q_and_a"),
        F.col("extracted_claims_json"),
        F.col("highlights_json"),
        F.col("issue_signals_json"),
        F.col("issue_summary_json"),
        F.col("faq_summary_json"),
    )
    spec_df = base_df.select(
        "product_id", F.explode_outer("spec_json").alias("spec")
    ).select(
        "product_id",
        F.lit("spec").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("spec.attribute_group_nm"),
            F.col("spec.attribute_nm"),
            F.col("spec.attribute_value_txt"),
        ).alias("detail_text"),
    )
    bullets_df = base_df.select(
        "product_id", F.explode_outer("bullets_json").alias("bullet")
    ).select(
        "product_id",
        F.lit("bullet").alias("detail_type"),
        F.col("bullet").cast("string").alias("detail_text"),
    )
    reviews_df = base_df.select(
        "product_id", F.explode_outer("reviews").alias("review")
    ).select(
        "product_id",
        F.lit("review").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("review.title").cast("string"),
            F.col("review.content").cast("string"),
        ).alias("detail_text"),
    )
    qa_df = base_df.select("product_id", F.explode_outer("q_and_a").alias("qa")).select(
        "product_id",
        F.lit("faq").alias("detail_type"),
        F.concat_ws(
            " | ", F.col("qa.q").cast("string"), F.array_join(F.col("qa.a"), " ")
        ).alias("detail_text"),
    )
    claims_df = base_df.select(
        "product_id", F.explode_outer("extracted_claims_json").alias("claim")
    ).select(
        "product_id",
        F.lit("claim").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("claim.claim_type").cast("string"),
            F.col("claim.text").cast("string"),
            F.col("claim.source_text").cast("string"),
            F.col("claim.pattern").cast("string"),
            F.col("claim.value").cast("string"),
            F.col("claim.unit").cast("string"),
        ).alias("detail_text"),
    )
    highlights_df = base_df.select(
        "product_id",
        F.explode_outer("highlights_json").alias("highlight_key", "highlight_value"),
    ).select(
        "product_id",
        F.lit("highlight").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("highlight_key").cast("string"),
            F.col("highlight_value").cast("string"),
        ).alias("detail_text"),
    )
    # issue_signals_json — the 11 fields review_mining._SIGNALS_SCHEMA publishes.
    #
    # This projection used to read issue_title, review_id, qa_id, rating and
    # review_create_dt, none of which survived the LLM migration: issue_title was
    # a YAML lookup the model does not need, review_id/qa_id are unified into
    # source_id with `source` saying which, and rating was never carried. Every
    # one of them indexed as an empty string.
    issue_signals_df = base_df.select(
        "product_id", F.explode_outer("issue_signals_json").alias("issue_signal")
    ).select(
        "product_id",
        F.lit("issue_signal").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("issue_signal.issue_key").cast("string"),
            F.concat(
                F.lit("issue_key="), F.col("issue_signal.issue_key").cast("string")
            ),
            F.concat(
                F.lit("issue_tags="),
                F.array_join(F.col("issue_signal.issue_tags"), ", "),
            ),
            F.concat(
                F.lit("affected_component="),
                F.col("issue_signal.affected_component").cast("string"),
            ),
            F.concat(F.lit("severity="), F.col("issue_signal.severity").cast("string")),
            F.concat(
                F.lit("confidence="), F.col("issue_signal.confidence").cast("string")
            ),
            F.concat(
                F.lit("sentiment_score="),
                F.col("issue_signal.sentiment_score").cast("string"),
            ),
            F.concat(
                F.lit("root_cause="), F.col("issue_signal.root_cause").cast("string")
            ),
            F.concat(F.lit("source="), F.col("issue_signal.source").cast("string")),
            F.concat(
                F.lit("source_id="), F.col("issue_signal.source_id").cast("string")
            ),
            F.concat(
                F.lit("matched_terms="),
                F.array_join(F.col("issue_signal.matched_terms"), ", "),
            ),
            F.concat(
                F.lit("source_create_dt="),
                F.col("issue_signal.source_create_dt").cast("string"),
            ),
        ).alias("detail_text"),
    )

    def _recency_str(recency_col):
        # None when the caller's schema guard found no recency struct at all —
        # the four bucket reads below would raise on a missing field.
        if recency_col is None:
            return F.lit("")
        return F.concat_ws(
            ",",
            F.concat(F.lit("under_30="), recency_col["under_30_days"].cast("string")),
            F.concat(
                F.lit("30_to_60="),
                recency_col["30_to_60_days"].cast("string"),
            ),
            F.concat(
                F.lit("60_to_90="),
                recency_col["60_to_90_days"].cast("string"),
            ),
            F.concat(F.lit("over_90="), recency_col["over_90_days"].cast("string")),
        )

    # issue_summary_json is now a STRUCT with a header, not a bare ARRAY, so the
    # explode is over its `issues` member. The old projection read issue_name,
    # frequency and recency — all three renamed (issue_key, mention_count,
    # recency_buckets) and all three indexing as empty strings until now.
    #
    # The header is indexed as its own row rather than repeated onto every issue:
    # "does this product have known problems" is one fact about the product, and
    # it is the field an agent reads before it reads anything else.
    issue_header_df = base_df.select(
        "product_id",
        F.lit("issue_overview").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.concat(
                F.lit("distinct_issues_found="),
                F.col("issue_summary_json.distinct_issues_found").cast("string"),
            ),
            F.concat(
                F.lit("max_severity="),
                F.col("issue_summary_json.max_severity").cast("string"),
            ),
            F.concat(
                F.lit("total_reviews="),
                F.col("issue_summary_json.total_reviews").cast("string"),
            ),
            F.concat(
                F.lit("overall_sentiment_avg="),
                F.col("issue_summary_json.overall_sentiment_avg").cast("string"),
            ),
        ).alias("detail_text"),
    ).filter(F.col("issue_summary_json").isNotNull())

    # explode (not explode_outer) + NOT NULL: a NULL/empty array or NULL
    # element would otherwise survive as the bare placeholder "recency=",
    # since _recency_str's concat_ws never returns NULL.
    issue_summary_df = (
        base_df.select(
            "product_id", F.explode("issue_summary_json.issues").alias("issue_summary")
        )
        .where(F.col("issue_summary").isNotNull())
    ).select(
        "product_id",
        F.lit("issue_summary").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.col("issue_summary.issue_key").cast("string"),
            F.concat(
                F.lit("mention_count="),
                F.col("issue_summary.mention_count").cast("string"),
            ),
            F.concat(
                F.lit("mention_rate="),
                F.col("issue_summary.mention_rate").cast("string"),
            ),
            F.concat(
                F.lit("severity="), F.col("issue_summary.severity").cast("string")
            ),
            F.concat(
                F.lit("issue_tags="),
                F.array_join(F.col("issue_summary.issue_tags"), ", "),
            ),
            F.concat(
                F.lit("top_components="),
                F.array_join(F.col("issue_summary.top_components"), ", "),
            ),
            F.concat(
                F.lit("top_root_causes="),
                F.array_join(F.col("issue_summary.top_root_causes"), ", "),
            ),
            F.concat(
                F.lit("representative_quote="),
                F.col("issue_summary.representative_quote").cast("string"),
            ),
            F.concat(
                F.lit("conflict_flag="),
                F.col("issue_summary.conflict_flag").cast("string"),
            ),
            F.concat(F.lit("trend="), F.col("issue_summary.trend").cast("string")),
            F.concat(
                F.lit("first_seen="), F.col("issue_summary.first_seen").cast("string")
            ),
            F.concat(
                F.lit("last_seen="), F.col("issue_summary.last_seen").cast("string")
            ),
            F.concat(
                F.lit("recency="),
                _recency_str(F.col("issue_summary.recency_buckets")),
            ),
        ).alias("detail_text"),
    )

    # explode (not explode_outer) + NOT NULL: otherwise products with no FAQ
    # emit "question_tags= | question_recency= | conflict_flag=" rows.
    faq_summary_exploded = base_df.select(
        "product_id", F.explode("faq_summary_json").alias("faq_summary")
    ).where(F.col("faq_summary").isNotNull())

    if "answers" not in faq_fields:
        _answers_str = F.lit("")
    else:
        _answers_str = F.array_join(
            F.transform(
                # Referrals and non-answers are dropped before the string
                # is built, not after retrieval.
                #
                # The coalesce is load-bearing: answer_score is
                # legitimately NULL whenever the LLM gave no opinion —
                # tagging disabled, endpoint down, response unparseable —
                # and comparing NULL yields NULL, not False. Without it,
                # a degraded tagging run would drop EVERY answer and turn
                # an unranked index into an empty one. Defaulting to the
                # threshold keeps unscored answers in. The same coalesce
                # covers the case where answer_score is absent from the
                # struct entirely (schema not yet evolved) — every answer
                # is kept rather than every answer dropped.
                F.filter(
                    F.col("faq_summary.answers"),
                    lambda a: F.coalesce(
                        _answer_col(answer_fields, a, "answer_score", "int"),
                        F.lit(_MIN_INDEXED_ANSWER_SCORE),
                    )
                    >= F.lit(_MIN_INDEXED_ANSWER_SCORE),
                ),
                lambda a: F.concat_ws(
                    ",",
                    F.concat(
                        F.lit("kw="),
                        _answer_col(
                            answer_fields, a, "answer_keyword", "string"
                        ).cast("string"),
                    ),
                    F.concat(
                        F.lit("tags="),
                        # answer_tags is ARRAY<STRING> and may be NULL for
                        # an untagged answer; join it and coalesce so the
                        # segment stays well-formed either way.
                        F.coalesce(
                            F.array_join(
                                _answer_col(
                                    answer_fields, a, "answer_tags", "array<string>"
                                ),
                                "/",
                            ),
                            F.lit(""),
                        ),
                    ),
                    # Recency-adjusted 0-10 usefulness. NULL when the LLM
                    # gave no opinion; coalesced to "" rather than cast,
                    # which would render the string "null".
                    F.concat(
                        F.lit("score="),
                        F.coalesce(
                            _answer_col(
                                answer_fields, a, "answer_score", "int"
                            ).cast("string"),
                            F.lit(""),
                        ),
                    ),
                    F.concat(
                        F.lit("freq="),
                        _answer_col(
                            answer_fields, a, "answer_frequency", "int"
                        ).cast("string"),
                    ),
                    F.concat(
                        F.lit("recency="),
                        _recency_str(
                            a["answer_recency"]
                            if "answer_recency" in answer_fields
                            else None
                        ),
                    ),
                ),
            ),
            " || ",
        )

    faq_summary_df = faq_summary_exploded.select(
        "product_id",
        F.lit("faq_summary").alias("detail_type"),
        F.concat_ws(
            " | ",
            F.concat(
                F.lit("question_keyword="),
                _faq_col(faq_fields, "question_keyword", "string").cast("string"),
            ),
            F.concat(
                F.lit("question_tags="),
                # question_tags is ARRAY<STRING>; cast("string") on an array
                # renders Spark's internal form, so join it explicitly.
                F.coalesce(
                    F.array_join(
                        _faq_col(faq_fields, "question_tags", "array<string>"), ","
                    ),
                    F.lit(""),
                ),
            ),
            F.concat(
                F.lit("question_frequency="),
                _faq_col(faq_fields, "question_frequency", "int").cast("string"),
            ),
            F.concat(
                F.lit("question_recency="),
                _recency_str(
                    F.col("faq_summary.question_recency")
                    if "question_recency" in faq_fields
                    else None
                ),
            ),
            # Two of this question's answers directly contradict each other.
            # Never NULL by contract — _build_faq_summary emits False for
            # "no verdict" rather than carrying the tri-state out.
            F.concat(
                F.lit("conflict_flag="),
                F.coalesce(
                    _faq_col(faq_fields, "conflict_flag", "boolean").cast("string"),
                    F.lit(""),
                ),
            ),
            F.concat(F.lit("answers="), _answers_str),
        ).alias("detail_text"),
    )

    return (
        spec_df.unionByName(bullets_df)
        .unionByName(reviews_df)
        .unionByName(qa_df)
        .unionByName(claims_df)
        .unionByName(highlights_df)
        .unionByName(issue_signals_df)
        .unionByName(issue_header_df)
        .unionByName(issue_summary_df)
        .unionByName(faq_summary_df)
        .where(F.col("product_id").isNotNull())
        .where(F.length(F.trim(F.col("detail_text"))) > 0)
        .withColumn(
            "detail_id",
            F.md5(
                F.concat_ws(
                    "||",
                    F.col("product_id").cast("string"),
                    F.col("detail_type").cast("string"),
                    F.col("detail_text").cast("string"),
                )
            ),
        )
        .select("detail_id", "product_id", "detail_type", "detail_text")
        .dropDuplicates(["detail_id"])
    )


def build_upsert_frame(input_df: DataFrame):
    """
    The exact rows written to the index table: projection + embedding slot +
    timestamps. The initial load, process_batch and the schema validation
    all use this, so the declared shape can never drift from what is written.
    """
    return (
        build_product_detail_projection(input_df)
        .withColumn("detail_text_emb", F.lit(None).cast("array<float>"))
        .withColumn("created_at", F.current_timestamp())
        .withColumn("updated_at", F.current_timestamp())
    )


source_table_initialized = False
if not spark.catalog.tableExists(vs_index_source_table_path):
    # Capture absolute latest version before reading snapshot
    source_history_df = spark.sql(f"DESCRIBE HISTORY {product_dim_table_path} LIMIT 1")
    starting_version = str(source_history_df.collect()[0]["version"])
    print(f"Initial load: captured source at version {starting_version}")

    (
        build_upsert_frame(spark.table(product_dim_table_path))
        .write.mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(vs_index_source_table_path)
    )
    source_table_initialized = True

if source_table_initialized:
    for group_name in permissions_groups:
        spark.sql(
            f"GRANT MANAGE ON TABLE {vs_index_source_table_path} TO `{group_name}`"
        )

    # Delete checkpoint when schema is rebuilt to prevent mismatch
    print(f"Schema was rebuilt. Deleting checkpoint at {checkpoint_path} to avoid schema mismatch.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
        print(f"✓ Checkpoint deleted successfully")
    except Exception as e:
        print(f"Warning: Could not delete checkpoint: {e}")

spark.sql(
    f"ALTER TABLE {vs_index_source_table_path} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
)


def process_batch(batch_df: DataFrame, batch_id: int):
    print(f"Processing batch_id={batch_id}")

    latest_changes_df = keep_latest_change_per_key(
        batch_df.where(F.col("item_id").isNotNull()),
        ["item_id"]
    )

    changed_products_df = latest_changes_df.select(
        F.col("item_id").alias("product_id")
    ).dropDuplicates(["product_id"])
    upsert_source_df = latest_changes_df.filter(
        F.col("_change_type").isin("insert", "update_postimage")
    )

    upsert_df = build_upsert_frame(upsert_source_df)

    # Rebuilding all details for a changed product must not discard embeddings
    # for detail rows whose deterministic detail_id is unchanged. Only new
    # detail_ids should remain NULL and be sent to the embedding endpoint.
    existing_embeddings_df = spark.table(vs_index_source_table_path).select(
        "detail_id", "detail_text_emb"
    ).withColumnRenamed("detail_text_emb", "existing_detail_text_emb")
    upsert_df = (
        upsert_df.join(existing_embeddings_df, on="detail_id", how="left")
        .withColumn(
            "detail_text_emb",
            F.coalesce(
                F.col("existing_detail_text_emb"), F.col("detail_text_emb")
            ),
        )
        .drop("existing_detail_text_emb")
    )

    upsert_count = upsert_df.count()
    changed_count = changed_products_df.count()

    print(f"batch_id={batch_id}: changed_products={changed_count}, upserts={upsert_count}")

    target = DeltaTable.forName(spark, vs_index_source_table_path)

    # Only delete details for products that have NEW detail data to replace them
    # This prevents data loss if a product's arrays become empty
    if upsert_count > 0:
        # Get distinct products from upsert_df (these have new detail data)
        products_to_delete = upsert_df.select("product_id").dropDuplicates(["product_id"])

        # Delete only the STALE details of those products — rows whose
        # detail_id is not in the new data. Rows that are still present stay,
        # so the MERGE below can keep their embedding when the text is
        # unchanged. The end state is the same as delete-all-then-insert.
        stale_details = (
            spark.table(vs_index_source_table_path)
            .select("detail_id", "product_id")
            .join(products_to_delete, "product_id", "left_semi")
            .join(upsert_df.select("detail_id"), "detail_id", "left_anti")
            .select("detail_id")
        )
        target.alias("t").merge(
            stale_details.alias("d"),
            "t.detail_id = d.detail_id",
        ).whenMatchedDelete().execute()

        # Insert-only: detail_id is md5(product_id||detail_type||detail_text),
        # so a matched row is already identical. Updating it only rewrote the
        # timestamps, which churned millions of rows into the index's change
        # feed per run and stalled the triggered sync.
        (
            target.alias("t").merge(upsert_df.alias("s"), "t.detail_id = s.detail_id")
            .whenNotMatchedInsertAll()
            .execute()
        )

        print(f"batch_id={batch_id}: Deleted old details and inserted/updated {upsert_count} detail rows")
    else:
        print(f"batch_id={batch_id}: No details to upsert (empty arrays or no insert/update changes)")


# === CHOOSE THE CORRECT STARTING VERSION ===
if source_table_initialized:
    final_stream_version = starting_version 
    print(f"Using Anchor Version for stream: {final_stream_version}")
else:
    final_stream_version = get_smart_latest_version(spark, product_dim_table_path)

# === SCHEMA VALIDATION (first, once, before the stream) ===
# Schema-only: limit(0) reads no rows. Evolve never drops an index column.
validate_before_write(
    spark, vs_index_source_table_path,
    build_upsert_frame(spark.table(product_dim_table_path).limit(0)).schema,
)

start_stream_with_cdc_recovery(
    spark=spark,
    dbutils=dbutils,
    source_table=product_dim_table_path,
    checkpoint_path=checkpoint_path,
    process_batch_fn=process_batch,
    starting_version=final_stream_version,
    # Continue past a type widening (e.g. INT -> BIGINT) on the source.
    # Column drops still fail the stream: this projection reads
    # issue_summary_json / faq_summary_json directly.
    allow_source_column_type_change=True,
)

# ---------------------------------------------------------------------------
# Reconciliation: Remove orphaned product_ids not in source master table
# ---------------------------------------------------------------------------
reconcile_orphans(
    spark=spark,
    target_table=vs_index_source_table_path,
    target_key_col="product_id",
    source_table=product_dim_table_path,
    source_key_col="item_id",
)

# COMMAND ----------

# ---------------------------------------------------------------------------
# Validation: Confirm source and index source are in sync (Distinct Products)
# 
# NOTE: This is a WARNING validation, not a blocker. Sync gaps can occur due to:
#   1. Products with all empty/null detail arrays (expected - nothing to index)
#   2. Streaming lag (details arrive shortly after)
#   3. Products deleted from source (orphan cleanup handles these)
# 
# Use full_refresh if gaps exceed 5% of total products
# ---------------------------------------------------------------------------

# Count distinct products that SHOULD have details (have non-empty arrays)
expected_product_count = (
    build_product_detail_projection(spark.table(product_dim_table_path))
    .select(F.countDistinct("product_id"))
    .collect()[0][0]
)

# Count distinct products actually synced to detail table
actual_product_count = (
    spark.table(vs_index_source_table_path)
    .select(F.countDistinct("product_id"))
    .collect()[0][0]
)

# Total products in source
total_source_products = spark.table(product_dim_table_path).select(
    F.countDistinct("item_id")
).collect()[0][0]

# Products completely missing from detail table
missing_products = spark.sql(f"""
    SELECT COUNT(DISTINCT s.item_id) as missing_count
    FROM {product_dim_table_path} s
    LEFT JOIN {vs_index_source_table_path} t ON s.item_id = t.product_id
    WHERE t.product_id IS NULL
""").collect()[0][0]

# Products with empty arrays
products_without_details = total_source_products - expected_product_count

# Calculate sync percentage
sync_percentage = (actual_product_count / total_source_products * 100) if total_source_products > 0 else 0

print(f"\n{'='*70}")
print(f"VALIDATION SUMMARY: Product Detail Index Sync")
print(f"{'='*70}")
print(f"Total products in source table:        {total_source_products:>10}")
print(f"Products with detail data:             {expected_product_count:>10}")
print(f"Products synced to detail table:       {actual_product_count:>10}")
print(f"Products missing (no details):         {products_without_details:>10}")
print(f"Products missing from index:           {missing_products:>10}")
print(f"Sync percentage:                       {sync_percentage:>9.1f}%")
print(f"{'='*70}\n")

if expected_product_count > actual_product_count:
    gap = expected_product_count - actual_product_count
    print(f"⚠️  SYNC GAP DETECTED: {gap} products with details are not in the detail table")
    print(f"   Action: This is typically resolved by full_refresh or subsequent streaming batches")
    if gap / expected_product_count > 0.05:  # > 5% gap
        print(f"   WARNING: Gap exceeds 5% - consider running full_refresh")
elif expected_product_count < actual_product_count:
    print(f"✓  Validation passed: All products with detail data are synced")
else:
    print(f"✓  Validation passed: Expected products ({expected_product_count}) == detail products ({actual_product_count})")

# COMMAND ----------

# ---------------------------------------------------------------------------
# Backfill embeddings for new/changed rows (NULL -> vector)
# ---------------------------------------------------------------------------
# NOTE: Spark RPC timeout must be configured at cluster creation time (Advanced Options)
if embedding_batch_size <= 0:
    raise ValueError(
        f"embedding_batch_size must be greater than zero, got {embedding_batch_size}"
    )

missing_embedding_rows = spark.sql(
    f"""
    SELECT COUNT(*)
    FROM {vs_index_source_table_path}
    WHERE detail_text_emb IS NULL
    """
).first()[0]

embedding_batch_count = (
    (missing_embedding_rows + embedding_batch_size - 1) // embedding_batch_size
    if missing_embedding_rows
    else 0
)

print(
    f"Embedding backfill: {missing_embedding_rows} missing rows across "
    f"{embedding_batch_count} batch(es) of up to {embedding_batch_size}"
)

backfill_embeddings(
    spark=spark,
    table_path=vs_index_source_table_path,
    pk_col="detail_id",
    text_col="detail_text",
    emb_col="detail_text_emb",
    embedding_endpoint=embedding_endpoint,
    embedding_batch_size=embedding_batch_size,
    max_batches=embedding_batch_count,
    return_type="ARRAY<DOUBLE>",  #can be removed when do full refresh
    concurrency_cap=8,  # Low due to large dataset size
    max_retries=5,
    retry_base_wait_seconds=10,
)

# COMMAND ----------

# find embedding dimension
embedding_dimension = infer_embedding_dimension(
    spark=spark,
    table_path=vs_index_source_table_path,
    emb_col="detail_text_emb",
)
print(f"Vector Index: {vs_index_path}")


vsc = VectorSearchClient(disable_notice=True)
try:
    vsc.get_endpoint(vs_endpoint_name)
except Exception:
    vsc.create_endpoint_and_wait(name=vs_endpoint_name, endpoint_type="STANDARD")

def wait_for_deletion(timeout_attempts=24, interval=10):
    for attempt in range(timeout_attempts):
        try:
            vsc.get_index(vs_endpoint_name, vs_index_path)
            print(f"Waiting for index deletion... ({attempt + 1})")
            time.sleep(interval)
        except Exception:
            print("Index fully deleted.")
            return
    raise Exception(f"Timed out waiting for index {vs_index_path} to be deleted.")

def delete_index_if_exists():
    try:
        vsc.get_index(vs_endpoint_name, vs_index_path)
        print(f"Deleting index {vs_index_path}...")
        vsc.delete_index(endpoint_name=vs_endpoint_name, index_name=vs_index_path)
        wait_for_deletion()
    except Exception as e:
        if "pending deletion" in str(e).lower():
            print("Index already pending deletion, waiting...")
            wait_for_deletion()
        elif "does not exist" in str(e).lower() or "not found" in str(e).lower():
            print("Index already gone.")
        else:
            raise

def create_index():
    vsc.create_delta_sync_index_and_wait(
        endpoint_name=vs_endpoint_name,
        index_name=vs_index_path,
        primary_key="detail_id",
        source_table_name=vs_index_source_table_path,
        pipeline_type="TRIGGERED",
        embedding_vector_column="detail_text_emb",
        embedding_dimension=embedding_dimension,
        columns_to_sync=[
            "detail_id",
            "product_id",
            "detail_type",
            "detail_text",
            "detail_text_emb"
        ]
    )
    print("Index created")
    for group_name in permissions_groups:
        spark.sql(f"GRANT MANAGE ON TABLE {vs_index_path} TO `{group_name}`")

index_exists = True
try:
    index = vsc.get_index(vs_endpoint_name, vs_index_path)
    print("Index already exists -> syncing")
except Exception:
    index_exists = False

def sync_index(index, retries=6, interval=30):
    for attempt in range(1, retries + 1):
        try:
            index.sync()
            print("Sync triggered successfully")
            return
        except Exception as e:
            if "not ready" in str(e).lower():
                print(f"Index not ready, retrying in {interval}s... ({attempt}/{retries})")
                time.sleep(interval)
            else:
                raise
    raise Exception(f"Index {vs_index_path} was not ready after {retries} retries.")

if index_exists:
    try:
        index.wait_until_ready()
    except Exception as e:
        if "offline" in str(e).lower():
            print(f"Index {vs_index_path} is offline, recreating...")
            delete_index_if_exists()
            create_index()
        else:
            raise
    else:
        sync_index(index)
else:
    create_index()