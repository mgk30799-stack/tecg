# Databricks notebook source
# MAGIC %pip install neo4j
# MAGIC %restart_python

# COMMAND ----------

import json
import sys
from datetime import date
from datetime import datetime
from decimal import Decimal

from neo4j import GraphDatabase
from pyspark.sql import DataFrame
from pyspark.sql import functions as F

context = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
notebook_path = context.notebookPath().get()
common_path = "/Workspace" + notebook_path.rsplit("/", 1)[0] + "/common"
if common_path not in sys.path:
    sys.path.append(common_path)

from shared import keep_latest_change_per_key, start_stream_with_cdc_recovery, get_smart_latest_version
from shared import parse_bool

# COMMAND ----------

import sys
import os
import yaml
sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode
_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_graph"]

dbutils.widgets.text("checkpoint_base_path", defaultValue=sync_config["checkpoint_base_path"])
checkpoint_base_path = dbutils.widgets.get("checkpoint_base_path")

# ---------------------------------------------------------------------------
# Tables & Neo4j settings from config
# ---------------------------------------------------------------------------
product_dim_table_path = sync_config["tables"]["source_table"]

dbutils.widgets.text("neo4j_uri", defaultValue=sync_config["neo4j"][run_mode]["uri"])
neo4j_uri = dbutils.widgets.get("neo4j_uri")

neo4j_database = sync_config["neo4j"]["database"]

dbutils.widgets.text("neo4j_write_chunk_size", defaultValue=str(sync_config["neo4j"]["write_chunk_size"]))
try:
    neo4j_write_chunk_size = int(dbutils.widgets.get("neo4j_write_chunk_size"))
except Exception:
    neo4j_write_chunk_size = sync_config["neo4j"]["write_chunk_size"]

neo4j_secret_scope = sync_config["neo4j"]["secret_scope"]
neo4j_user_secret_key = sync_config["neo4j"]["user_secret_key"]
neo4j_password_secret_key = sync_config["neo4j"]["password_secret_key"]

checkpoint_path = f"{checkpoint_base_path}/sync_product_graph"

# ---------------------------------------------------------------------------
# Ensure checkpoint volume exists
# ---------------------------------------------------------------------------
_volume_parts = checkpoint_base_path.strip("/").split("/")
if len(_volume_parts) >= 4 and _volume_parts[0].lower() == "volumes":
    _vol_catalog = _volume_parts[1]
    _vol_schema = _volume_parts[2]
    _vol_name = _volume_parts[3]
    spark.sql(
        f"CREATE VOLUME IF NOT EXISTS {_vol_catalog}.{_vol_schema}.{_vol_name}"
    )
    print(f"Ensured volume exists: {_vol_catalog}.{_vol_schema}.{_vol_name}")

# ---------------------------------------------------------------------------
# Runtime parameters (only full_refresh remains as a widget)
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_dim_table_path}")
print(f"Neo4j URI: {neo4j_uri}")
print(f"Neo4j database: {neo4j_database}")
print(f"Checkpoint: {checkpoint_path}")

GRAPH_CONSTRAINT_QUERIES = [
    (
        "product_product_id_unique",
        "CREATE CONSTRAINT product_product_id_unique IF NOT EXISTS "
        "FOR (p:Product) REQUIRE p.product_id IS UNIQUE",
    ),
    (
        "category_id_name_level_unique",
        "CREATE CONSTRAINT category_id_name_level_unique IF NOT EXISTS "
        "FOR (c:Category) REQUIRE (c.id, c.name, c.level) IS UNIQUE",
    ),
    (
        "brand_name_unique",
        "CREATE CONSTRAINT brand_name_unique IF NOT EXISTS "
        "FOR (b:Brand) REQUIRE b.name IS UNIQUE",
    ),
    (
        "manufacturer_name_unique",
        "CREATE CONSTRAINT manufacturer_name_unique IF NOT EXISTS "
        "FOR (m:Manufacturer) REQUIRE m.name IS UNIQUE",
    ),
    (
        "group_group_id_unique",
        "CREATE CONSTRAINT group_group_id_unique IF NOT EXISTS "
        "FOR (g:Group) REQUIRE g.group_id IS UNIQUE",
    ),
    (
        "room_context_tags_unique",
        "CREATE CONSTRAINT room_context_tags_unique IF NOT EXISTS "
        "FOR (r:RoomContext) REQUIRE r.tag IS UNIQUE",
    ),
    (
        "audience_context_tags_unique",
        "CREATE CONSTRAINT audience_context_tags_unique IF NOT EXISTS "
        "FOR (a:Audience) REQUIRE a.tag IS UNIQUE",
    ),
    (
        "usecase_tags_unique",
        "CREATE CONSTRAINT usecase_tags_unique IF NOT EXISTS "
        "FOR (u:UseCase) REQUIRE u.tag IS UNIQUE"
    )
]

MERGE_QUERY = """
UNWIND $rows AS row
MERGE (p:Product {product_id: row.product.product_id})
SET p = row.product
CALL (p) {
  OPTIONAL MATCH (p)-[oldRel:IN_SUPERCATEGORY|IN_DEPARTMENT|IN_CATEGORY|IN_CLASS|BRANDED_BY|MANUFACTURED_BY|IN_PRODUCT_GROUP|COMPATIBLE_WITH|SUBSTITUTE_OF|BOUGHT_WITH|HAS_USE_CASE|HAS_ROOM_CONTEXT|HAS_AUDIENCE]->()
  DELETE oldRel
}
WITH p, row
FOREACH (cat IN row.categories |
  MERGE (:Category {id: cat.id, name: cat.name, level: cat.level})
)
FOREACH (edge IN row.category_edges |
  FOREACH (_ IN CASE WHEN edge.rel_type = 'IN_SUPERCATEGORY' THEN [1] ELSE [] END |
    MERGE (c:Category {id: edge.id, name: edge.name, level: edge.level})
    MERGE (p)-[:IN_SUPERCATEGORY]->(c)
  )
  FOREACH (_ IN CASE WHEN edge.rel_type = 'IN_DEPARTMENT' THEN [1] ELSE [] END |
    MERGE (c:Category {id: edge.id, name: edge.name, level: edge.level})
    MERGE (p)-[:IN_DEPARTMENT]->(c)
  )
  FOREACH (_ IN CASE WHEN edge.rel_type = 'IN_CATEGORY' THEN [1] ELSE [] END |
    MERGE (c:Category {id: edge.id, name: edge.name, level: edge.level})
    MERGE (p)-[:IN_CATEGORY]->(c)
  )
  FOREACH (_ IN CASE WHEN edge.rel_type = 'IN_CLASS' THEN [1] ELSE [] END |
    MERGE (c:Category {id: edge.id, name: edge.name, level: edge.level})
    MERGE (p)-[:IN_CLASS]->(c)
  )
)
FOREACH (rel IN row.category_hierarchy |
  MERGE (child:Category {id: rel.child_id, name: rel.child_name, level: rel.child_level})
  MERGE (parent:Category {id: rel.parent_id, name: rel.parent_name, level: rel.parent_level})
  MERGE (child)-[:CHILD_OF]->(parent)
)
FOREACH (_ IN CASE WHEN row.brand.name IS NULL OR row.brand.name = '' THEN [] ELSE [1] END |
  MERGE (b:Brand {name: row.brand.name})
  SET b.is_owned_brand = row.brand.is_owned_brand
  MERGE (p)-[:BRANDED_BY]->(b)
)
FOREACH (_ IN CASE WHEN row.manufacturer.name IS NULL OR row.manufacturer.name = '' THEN [] ELSE [1] END |
  MERGE (m:Manufacturer {name: row.manufacturer.name})
  MERGE (p)-[:MANUFACTURED_BY]->(m)
)
FOREACH (_ IN CASE WHEN row.group.group_id IS NULL OR row.group.group_id = '' THEN [] ELSE [1] END |
  MERGE (g:Group {group_id: row.group.group_id})
  MERGE (p)-[:IN_PRODUCT_GROUP]->(g)
)
FOREACH (relp IN row.related_products |
  FOREACH (_ IN CASE WHEN relp.relationship_type = 'compatible' THEN [1] ELSE [] END |
    MERGE (rp:Product {product_id: relp.related_product_id})
    MERGE (p)-[compat:COMPATIBLE_WITH]->(rp)
    SET compat.source = relp.source,
        compat.confidence = relp.confidence,
        compat.compatibility_json = relp.compatibility_json
  )
  FOREACH (_ IN CASE WHEN relp.relationship_type = 'substitute' THEN [1] ELSE [] END |
    MERGE (rp:Product {product_id: relp.related_product_id})
    MERGE (p)-[sub:SUBSTITUTE_OF]->(rp)
    SET sub.source = relp.source,
        sub.confidence = relp.confidence,
        sub.compatibility_json = relp.compatibility_json
  )
)
FOREACH (bwp IN row.bought_with_products |
  MERGE (bp:Product {product_id: bwp.related_product_id})
  MERGE (p)-[:BOUGHT_WITH]->(bp)
)
FOREACH (tag IN row.use_case_tags |
  MERGE (uc:UseCase {name: tag})
  MERGE (p)-[:HAS_USE_CASE]->(uc)
)
FOREACH (tag IN row.room_context_tags |
  MERGE (rc:RoomContext {name: tag})
  MERGE (p)-[:HAS_ROOM_CONTEXT]->(rc)
)
FOREACH (tag IN row.unique_audience_tags |
  MERGE (au:Audience {name: tag})
  MERGE (p)-[:HAS_AUDIENCE]->(au)
)
"""

DELETE_QUERY = """
UNWIND $rows AS row
MATCH (p:Product {product_id: row.product_id})
DETACH DELETE p
"""


def ensure_graph_constraints() -> None:
    driver = GraphDatabase.driver(
        neo4j_uri,
        auth=(neo4j_user, neo4j_password),
        max_connection_lifetime=30,
        connection_timeout=10,
        max_connection_pool_size=10,
    )
    try:
        with driver.session(database=neo4j_database) as session:
            for constraint_name, query in GRAPH_CONSTRAINT_QUERIES:
                try:
                    session.run(query).consume()
                    print(f"Constraint ensured: {constraint_name}")
                except Exception as exc:
                    raise RuntimeError(
                        f"Failed to create/validate Neo4j constraint '{constraint_name}'. "
                        "Clean duplicates for that label/key pair, then rerun."
                    ) from exc
    finally:
        driver.close()


def clear_all_graph_nodes() -> None:
    driver = GraphDatabase.driver(
        neo4j_uri,
        auth=(neo4j_user, neo4j_password),
        max_connection_lifetime=30,
        connection_timeout=10,
        max_connection_pool_size=10,
    )
    try:
        with driver.session(database=neo4j_database) as session:
            while True:
                result = session.run(
                    "MATCH (n) WITH n LIMIT 10000 DETACH DELETE n RETURN count(*) AS deleted"
                ).single()
                if result["deleted"] == 0:
                    break
    finally:
        driver.close()


def normalize_text(value) -> str:
    return " ".join(str(value).split()).strip()


def normalize_optional_text(value):
    if value is None:
        return None
    normalized = normalize_text(value)
    if not normalized or normalized.lower() == "none":
        return None
    return normalized


def bool_from_y_flag(value):
    return str(value).strip().upper() == "Y"


def to_float_or_none(value):
    if value is None:
        return None
    raw = str(value).strip()
    if raw == "":
        return None
    try:
        return float(raw)
    except Exception:
        return None


def to_int_or_none(value):
    if value is None:
        return None
    raw = str(value).strip()
    if raw == "":
        return None
    try:
        return int(float(raw))
    except Exception:
        return None


def to_bool_or_none(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    raw = str(value).strip().lower()
    if raw in {"true", "t", "1", "yes", "y"}:
        return True
    if raw in {"false", "f", "0", "no", "n"}:
        return False
    return None


def dedupe_dict_list(values, key_fields):
    seen = set()
    deduped = []
    for value in values:
        key = tuple(value.get(field) for field in key_fields)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(value)
    return deduped


def normalize_for_neo4j(value):
    if value is None:
        return None
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: normalize_for_neo4j(v) for k, v in value.items()}
    if isinstance(value, list):
        return [normalize_for_neo4j(v) for v in value]
    if isinstance(value, tuple):
        return [normalize_for_neo4j(v) for v in value]
    return value


def parse_related_products(
    related_product_id,
    relationship_type,
    source,
    confidence,
    compatibility_json,
):
    if related_product_id is None:
        return []
    rels = []
    related_ids = [x.strip() for x in str(related_product_id).split(",") if x.strip()]
    rel_type = (relationship_type or "").strip().lower()
    rel_type_aliases = {
        "compatible_with": "compatible",
        "compat": "compatible",
        "substitute_of": "substitute",
        "sub_of": "substitute",
        "sub": "substitute",
    }
    rel_type = rel_type_aliases.get(rel_type, rel_type)
    source_value = normalize_text(source)
    confidence_value = None
    try:
        if confidence is not None and str(confidence).strip() != "":
            confidence_value = float(confidence)
    except Exception:
        confidence_value = None
    compatibility_json_value = None
    if compatibility_json is not None:
        compatibility_json_value = (
            compatibility_json
            if isinstance(compatibility_json, str)
            else json.dumps(compatibility_json)
        )
    for rid in related_ids:
        if rel_type in {"compatible", "substitute"}:
            rels.append(
                {
                    "related_product_id": rid,
                    "relationship_type": rel_type,
                    "source": source_value or None,
                    "confidence": confidence_value,
                    "compatibility_json": compatibility_json_value,
                }
            )
    return rels


def parse_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        tokens = [str(x).strip() for x in value if str(x).strip()]
        return tokens
    raw = str(value).strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return [str(x).strip() for x in parsed if str(x).strip()]
    except Exception:
        pass
    return [x.strip() for x in raw.split(",") if x.strip()]


def build_graph_row_payload(row):
    product_id = normalize_optional_text(row.get("item_id"))
    if not product_id:
        return {}

    categories = []
    category_edges = []
    tax_columns = [
        ("SUPER", row.get("web_supercategory_id"), row.get("web_supercategory_nm"), "IN_SUPERCATEGORY"),
        ("CATEGORY", row.get("web_category_id"), row.get("web_category_nm"), "IN_CATEGORY"),
        ("DEPARTMENT", row.get("web_department_id"), row.get("web_department_nm"), "IN_DEPARTMENT"),
        ("CLASS", row.get("web_class_id"), row.get("web_class_nm"), "IN_CLASS"),
    ]
    for level, id, name, rel_type in tax_columns:
        if (name and id):
            normalized_name = normalize_text(name)
            if not normalized_name:
                continue
            categories.append({"id": id, "name": normalized_name, "level": level})
            category_edges.append(
                {"id": id, "name": normalized_name, "level": level, "rel_type": rel_type}
            )
    categories = dedupe_dict_list(categories, ["id", "name", "level"])
    category_edges = dedupe_dict_list(category_edges, ["id", "name", "level", "rel_type"])

    id_lookup: dict[tuple[str, str], str] = {
        (cat["name"], cat["level"]): cat["id"]
        for cat in categories
    }

    hierarchy = []
    hierarchy_pairs = [
        ("CLASS", row.get("web_class_nm"), "DEPARTMENT", row.get("web_department_nm")),
        (
            "DEPARTMENT",
            row.get("web_department_nm"),
            "CATEGORY",
            row.get("web_category_nm"),
        ),
        (
            "CATEGORY",
            row.get("web_category_nm"),
            "SUPER",
            row.get("web_supercategory_nm"),
        ),
    ]
    for child_level, child_name, parent_level, parent_name in hierarchy_pairs:
        if child_name and parent_name:
            child_name_norm = normalize_text(child_name)
            parent_name_norm = normalize_text(parent_name)
            if not child_name_norm or not parent_name_norm:
                continue
            hierarchy.append(
                {
                    "child_name":  child_name_norm,
                    "child_level": child_level,
                    "child_id":    id_lookup.get((child_name_norm, child_level)),
                    "parent_name": parent_name_norm,
                    "parent_level": parent_level,
                    "parent_id":   id_lookup.get((parent_name_norm, parent_level)),
                }
            )
    hierarchy = dedupe_dict_list(
        hierarchy, ["child_id", "child_name", "child_level", "parent_id", "parent_name", "parent_level"]
    )
    related_products = [
        {
            "related_product_id": normalize_text(pid),
            "relationship_type": "compatible",
            "source": None,
            "confidence": None,
            "compatibility_json": None,
        }
        for pid in parse_list(row.get("compatible_item_ids"))
        if normalize_text(pid) and normalize_text(pid) != product_id
    ] + [
        {
            "related_product_id": normalize_text(pid),
            "relationship_type": "substitute",
            "source": None,
            "confidence": None,
            "compatibility_json": None,
        }
        for pid in parse_list(row.get("similar_item_ids"))
        if normalize_text(pid) and normalize_text(pid) != product_id
    ]
    related_products = dedupe_dict_list(
        related_products, ["related_product_id", "relationship_type"]
    )
    bought_with_products = [
        {"related_product_id": normalize_text(pid)}
        for pid in parse_list(row.get("related_product_id"))
        if normalize_text(pid) and normalize_text(pid) != product_id
    ]
    bought_with_products = dedupe_dict_list(
        bought_with_products, ["related_product_id"]
    )
    group_id = normalize_optional_text(row.get("group_id"))
    use_case_tags = parse_list(row.get("use_case_tags"))
    room_context_tags = parse_list(row.get("room_context_tags"))
    unique_audience_tags = parse_list(row.get("audience_tags"))

    payload = {
        "product": {
            "product_id": product_id,
            "brand": normalize_optional_text(row.get("brand")),
            "manufacturer": normalize_optional_text(row.get("manufacturer")),
            "own_brand_ind": bool_from_y_flag(row.get("own_brand_ind")),
            "web_class_nm": normalize_optional_text(row.get("web_class_nm")),
            "web_department_nm": normalize_optional_text(row.get("web_department_nm")),
            "web_category_nm": normalize_optional_text(row.get("web_category_nm")),
            "web_supercategory_nm": normalize_optional_text(
                row.get("web_supercategory_nm")
            ),
            "lifecycle_status": normalize_optional_text(row.get("lifecycle_status")),
            "eco_feature_ind": bool_from_y_flag(row.get("eco_feature_ind")),
            "eco_energy_star_certified_ind": bool_from_y_flag(
                row.get("eco_energy_star_certified_ind")
            ),
            "eco_recycled_ind": bool_from_y_flag(row.get("eco_recycled_ind")),
        },
        "brand": {
            "name": row.get("brand"),
            "is_owned_brand": row.get("own_brand_ind"),
        },
        "manufacturer": {"name": row.get("manufacturer")},
        "group": {"group_id": group_id if group_id and group_id != "None" else None},
        "categories": categories,
        "category_edges": category_edges,
        "category_hierarchy": hierarchy,
        "related_products": related_products,
        "bought_with_products": bought_with_products,
        "use_case_tags": use_case_tags,
        "room_context_tags": room_context_tags,
        "unique_audience_tags": unique_audience_tags
    }
    return normalize_for_neo4j(payload)


def execute_graph_cypher_stream(driver, query: str, row_iter, timeout_seconds=1800):
    row_chunk = []
    total_rows = 0
    tx_config = {"timeout": timeout_seconds}  # 30 minutes default
    with driver.session(database=neo4j_database) as session:
        for row in row_iter:
            if not row:
                continue
            row_chunk.append(row)
            if len(row_chunk) >= neo4j_write_chunk_size:
                session.execute_write(
                    lambda tx: tx.run(query, rows=row_chunk, **tx_config).consume()
                )
                total_rows += len(row_chunk)
                row_chunk = []
        if row_chunk:
            session.execute_write(
                lambda tx: tx.run(query, rows=row_chunk, **tx_config).consume()
            )
            total_rows += len(row_chunk)
    return total_rows


def process_batch(batch_df: DataFrame, batch_id: int):
    print(f"Processing batch_id={batch_id}")

    if "_change_type" in batch_df.columns:
        latest_changes_df = keep_latest_change_per_key(
            batch_df.where(F.col("item_id").isNotNull()),
            ["item_id"],
        )
        upsert_df = latest_changes_df.filter(
            F.col("_change_type").isin("insert", "update_postimage")
        )
        delete_df = latest_changes_df.filter(
            F.col("_change_type") == "delete"
        ).dropDuplicates(["item_id"])
    else:
        upsert_df = batch_df
        delete_df = spark.createDataFrame([], "product_id string")

    driver = GraphDatabase.driver(
        neo4j_uri,
        auth=(neo4j_user, neo4j_password),
        max_connection_lifetime=30,
        connection_timeout=10,
        max_connection_pool_size=50,
    )
    try:
        # Materialize rows with collect() before external Neo4j I/O to avoid
        # Spark Connect cursor timeout during blocking I/O operations
        upsert_rows = [
            build_graph_row_payload(row.asDict(recursive=True))
            for row in upsert_df.repartition(50).collect()
        ]
        upsert_count = execute_graph_cypher_stream(
            driver,
            MERGE_QUERY,
            iter(upsert_rows),
        )

        delete_id_col = "item_id" if "item_id" in delete_df.columns else "product_id"
        delete_rows = [
            {"product_id": str(row["product_id"])}
            for row in delete_df.select(
                F.col(delete_id_col).alias("product_id")
            ).repartition(20).collect()
            if row["product_id"] is not None
        ]
        delete_count = execute_graph_cypher_stream(
            driver,
            DELETE_QUERY,
            iter(delete_rows),
        )
    finally:
        driver.close()

    print(
        f"batch_id={batch_id}: merged_products={upsert_count}, deleted_products={delete_count}, write_chunk_size={neo4j_write_chunk_size}"
    )

try:
    neo4j_user = dbutils.secrets.get(neo4j_secret_scope, neo4j_user_secret_key)
    neo4j_password = dbutils.secrets.get(neo4j_secret_scope, neo4j_password_secret_key)
except Exception as exc:
    raise ValueError(
        "Unable to read Neo4j credentials from Databricks secrets: "
        f"scope='{neo4j_secret_scope}', keys='{neo4j_user_secret_key}' and '{neo4j_password_secret_key}'."
    ) from exc

if not neo4j_user or not neo4j_password:
    raise ValueError(
        "Neo4j credentials are empty in scope='agentic_commerce' "
        f"(keys: '{neo4j_user_secret_key}', '{neo4j_password_secret_key}')."
    )

ensure_graph_constraints()

full_refresh = parse_bool(full_refresh_raw)
if full_refresh:
    print("Full refresh requested: deleting checkpoint and clearing Neo4j graph.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
    except Exception as exc:
        print(f"Skipping checkpoint cleanup at {checkpoint_path}: {exc}")
    clear_all_graph_nodes()
    process_batch(spark.table(product_dim_table_path), 0)
else:
    start_stream_with_cdc_recovery(
        spark=spark,
        dbutils=dbutils,
        source_table=product_dim_table_path,
        checkpoint_path=checkpoint_path,
        process_batch_fn=process_batch,
        starting_version=get_smart_latest_version(spark, product_dim_table_path),
        # issue_summary_json / issue_signals_json were dropped and re-added on
        # the source; the graph reads neither, so the drop is safe to pass.
        allow_source_column_drop=True,
        allow_source_column_type_change=True,
    )