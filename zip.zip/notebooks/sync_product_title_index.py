# Databricks notebook source
# MAGIC %pip install mlflow databricks-sdk databricks-vectorsearch
# MAGIC %restart_python

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient
from delta.tables import DeltaTable
from pyspark.sql import functions as F

import sys
import os
import time

_cwd = os.getcwd()
_common_path = os.path.join(_cwd, "common")
if _common_path not in sys.path:
    sys.path.insert(0, _common_path)

sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode, validate_before_write
from shared import backfill_embeddings, infer_embedding_dimension, reconcile_orphans

# COMMAND ----------

_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_title_index"]

# ---------------------------------------------------------------------------
# Tables & vector search settings from config
# ---------------------------------------------------------------------------
product_dim_table_path = sync_config["tables"]["source_table"]
vs_index_source_table_path = sync_config["tables"]["vs_index_source_table"]

vs_endpoint_name = sync_config["vectorsearch"]["endpoint_name"]
vs_index_path = sync_config["vectorsearch"]["index_name"]
embedding_endpoint = sync_config["vectorsearch"]["embedding_endpoint"]
embedding_batch_size = sync_config["vectorsearch"].get("embedding_batch_size", 150)
permissions_groups = sync_config["permissions_groups"]

# ---------------------------------------------------------------------------
# Runtime parameters
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
full_refresh = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_dim_table_path}")
print(f"Index source: {vs_index_source_table_path}")
print(f"Vector index: {vs_index_path}")
print(f"Embedding Batch Size: {embedding_batch_size}")
print(f"Full refresh: {full_refresh}")

if full_refresh:
    print(
        "Full refresh requested: dropping source table and vector index."
    )
    spark.sql(f"DROP TABLE IF EXISTS {vs_index_source_table_path}")
    try:
        vsc_for_delete = VectorSearchClient(disable_notice=True)
        try:
            vsc_for_delete.delete_index(
                endpoint_name=vs_endpoint_name, index_name=vs_index_path
            )
            print(f"Vector index deleted: {vs_index_path}")
        except TypeError:
            vsc_for_delete.delete_index(vs_endpoint_name, vs_index_path)
            print(f"Vector index deleted: {vs_index_path}")
    except Exception as exc:
        if "does not exist" in str(exc).lower() or "not found" in str(exc).lower():
            print(f"Index already gone: {exc}")
        else:
            raise

# COMMAND ----------

# ---------------------------------------------------------------------------
# Batch snapshot-diff sync
#
# product_discovery_data is rebuilt daily via CREATE OR REPLACE TABLE AS SELECT.
# CTAS never produces CDF (Change Data Feed) records, so CDF streaming will
# always raise DELTA_MISSING_CHANGE_DATA regardless of checkpoint state.
#
# Instead we do a pure-batch diff:
#   1. Read the full current snapshot of the source.
#   2. On first run: write it directly as the target table.
#   3. On subsequent runs: MERGE changed/new rows into the target, then
#      remove rows no longer present in the source (reconcile_orphans handles
#      the delete pass below).
# ---------------------------------------------------------------------------

source_df = spark.table(product_dim_table_path).select("item_id", "title")

# The exact shape of the index table: the initial load writes this, and the
# MERGE below sets exactly these columns.
index_df = source_df.withColumns({
    "title_emb": F.lit(None).cast("array<double>"),
    "created_at": F.current_timestamp(),
    "updated_at": F.current_timestamp(),
})

# === SCHEMA VALIDATION (first, before any write) ===
validate_before_write(spark, vs_index_source_table_path, index_df.schema)

if not spark.catalog.tableExists(vs_index_source_table_path):
    print(f"[initial load] Target does not exist — writing full snapshot...")
    (
        index_df
        .write.format("delta")
        .option("delta.enableChangeDataFeed", "true")
        .saveAsTable(vs_index_source_table_path)
    )
    print(f"[initial load] Created {vs_index_source_table_path} with {source_df.count()} rows.")
else:
    print(f"[incremental] Target exists — computing diff and merging changes...")
    target_df = spark.table(vs_index_source_table_path).select("item_id", "title")

    # Rows that are new in source or whose title has changed
    changed_df = (
        source_df.alias("s")
        .join(target_df.alias("t"), on="item_id", how="left")
        .filter(
            F.col("t.item_id").isNull()                      # new item
            | (F.col("s.title") != F.col("t.title"))         # title changed
        )
        .select(
            F.col("s.item_id"),
            F.col("s.title"),
        )
    )

    changed_count = changed_df.count()
    if changed_count == 0:
        print("[incremental] No changes detected — skipping MERGE.")
    else:
        print(f"[incremental] Merging {changed_count} changed/new rows...")
        DeltaTable.forName(spark, vs_index_source_table_path).alias("t").merge(
            changed_df.alias("s"), "t.item_id = s.item_id"
        ).whenMatchedUpdate(
            set={
                "title": "s.title",
                "title_emb": F.lit(None).cast("array<double>"),
                "updated_at": F.current_timestamp(),
            }
        ).whenNotMatchedInsert(
            values={
                "item_id": "s.item_id",
                "title": "s.title",
                "title_emb": F.lit(None).cast("array<double>"),
                "created_at": F.current_timestamp(),
                "updated_at": F.current_timestamp(),
            }
        ).execute()
        print(f"[incremental] MERGE complete.")

# ---------------------------------------------------------------------------
# Reconcile orphans: remove items no longer in source
# ---------------------------------------------------------------------------
reconcile_orphans(
    spark=spark,
    target_table=vs_index_source_table_path,
    target_key_col="item_id",
    source_table=product_dim_table_path,
    source_key_col="item_id",
)

# ---------------------------------------------------------------------------
# Validation: Confirm source and index source are in sync
# 
# NOTE: This is a WARNING validation, not a blocker. Sync gaps can occur due to:
#   1. Streaming lag (new products arrive shortly after)
#   2. Products deleted from source (orphan cleanup handles these)
#   3. CDC change data not yet processed
# 
# Use full_refresh if gaps exceed 5% of total products
# ---------------------------------------------------------------------------
expected_count = (
    spark.table(product_dim_table_path)
    .where(F.col("item_id").isNotNull())
    .select(F.countDistinct("item_id"))
    .collect()[0][0]
)

actual_count = (
    spark.table(vs_index_source_table_path)
    .select(F.countDistinct("item_id"))
    .collect()[0][0]
)

# Products completely missing from title index
missing_products = spark.sql(f"""
    SELECT COUNT(DISTINCT s.item_id) as missing_count
    FROM {product_dim_table_path} s
    LEFT JOIN {vs_index_source_table_path} t ON s.item_id = t.item_id
    WHERE s.item_id IS NOT NULL AND t.item_id IS NULL
""").collect()[0][0]

# Calculate sync percentage
sync_percentage = (actual_count / expected_count * 100) if expected_count > 0 else 0

print(f"\n{'='*70}")
print(f"VALIDATION SUMMARY: Product Title Index Sync")
print(f"{'='*70}")
print(f"Total products in source table:        {expected_count:>10}")
print(f"Products synced to title index:        {actual_count:>10}")
print(f"Products missing from index:           {missing_products:>10}")
print(f"Sync percentage:                       {sync_percentage:>9.1f}%")
print(f"{'='*70}\n")

if expected_count > actual_count:
    gap = expected_count - actual_count
    print(f"⚠️  SYNC GAP DETECTED: {gap} products are not in the title index")
    print(f"   Action: This is typically resolved by subsequent streaming batches or full_refresh")
    if gap / expected_count > 0.05:  # > 5% gap
        print(f"   WARNING: Gap exceeds 5% - consider running full_refresh")
elif expected_count < actual_count:
    print(f"ℹ️  Index has more products than source (may include orphaned/pending cleanup)")
else:
    print(f"✓  Validation passed: expected items ({expected_count}) == index items ({actual_count})")


# COMMAND ----------

# ---------------------------------------------------------------------------
# Remove rows with NULL titles (ai_query cannot process nulls)
# ---------------------------------------------------------------------------
null_count = spark.sql(
    f"SELECT count(*) FROM {vs_index_source_table_path} WHERE title IS NULL"
).first()[0]
if null_count > 0:
    print(f"[cleanup] Removing {null_count} rows with NULL titles...")
    spark.sql(f"DELETE FROM {vs_index_source_table_path} WHERE title IS NULL")

# ---------------------------------------------------------------------------
# Backfill embeddings for new/changed rows (NULL -> vector)
# ---------------------------------------------------------------------------
# NOTE: Spark RPC timeout must be configured at cluster creation time (Advanced Options)
backfill_embeddings(
    spark=spark,
    table_path=vs_index_source_table_path,
    pk_col="item_id",
    text_col="title",
    emb_col="title_emb",
    embedding_endpoint=embedding_endpoint,
    embedding_batch_size=embedding_batch_size,
    concurrency_cap=12,  # Moderate concurrency for medium-sized dataset
    max_retries=5,
    retry_base_wait_seconds=10,
)

# COMMAND ----------

# find embedding dimension
embedding_dimension = infer_embedding_dimension(
    spark=spark,
    table_path=vs_index_source_table_path,
    emb_col="title_emb",
)
print(f"Vector Index: {vs_index_path}")

vsc = VectorSearchClient(disable_notice=True)
try:
    vsc.get_endpoint(vs_endpoint_name)
except Exception:
    vsc.create_endpoint_and_wait(name=vs_endpoint_name, endpoint_type="STANDARD")


def wait_for_deletion(timeout_attempts=24, interval=10):
    for attempt in range(timeout_attempts):
        try:
            vsc.get_index(vs_endpoint_name, vs_index_path)
            print(f"Waiting for index deletion... ({attempt + 1})")
            time.sleep(interval)
        except Exception:
            print("Index fully deleted.")
            return
    raise Exception(f"Timed out waiting for index {vs_index_path} to be deleted.")


def delete_index_if_exists():
    try:
        vsc.get_index(vs_endpoint_name, vs_index_path)
        print(f"Deleting index {vs_index_path}...")
        vsc.delete_index(endpoint_name=vs_endpoint_name, index_name=vs_index_path)
        wait_for_deletion()
    except Exception as e:
        if "pending deletion" in str(e).lower():
            print("Index already pending deletion, waiting...")
            wait_for_deletion()
        elif "does not exist" in str(e).lower() or "not found" in str(e).lower():
            print("Index already gone.")
        else:
            raise


def create_index():
    vsc.create_delta_sync_index_and_wait(
        endpoint_name=vs_endpoint_name,
        index_name=vs_index_path,
        primary_key="item_id",
        source_table_name=vs_index_source_table_path,
        pipeline_type="TRIGGERED",
        embedding_vector_column="title_emb",
        embedding_dimension=embedding_dimension,
        columns_to_sync=[
            "item_id",
            "title",
            "title_emb",
        ],
    )
    print("Index created")
    for group_name in permissions_groups:
        spark.sql(f"GRANT MANAGE ON TABLE {vs_index_path} TO `{group_name}`")


index_exists = True
try:
    index = vsc.get_index(vs_endpoint_name, vs_index_path)
    print("Index already exists -> syncing")
except Exception:
    index_exists = False


def sync_index(index, retries=6, interval=30):
    for attempt in range(1, retries + 1):
        try:
            index.sync()
            print("Sync triggered successfully")
            return
        except Exception as e:
            if "not ready" in str(e).lower():
                print(f"Index not ready, retrying in {interval}s... ({attempt}/{retries})")
                time.sleep(interval)
            else:
                raise
    raise Exception(f"Index {vs_index_path} was not ready after {retries} retries.")


if index_exists:
    try:
        index.wait_until_ready()
    except Exception as e:
        if "offline" in str(e).lower():
            print(f"Index {vs_index_path} is offline, recreating...")
            delete_index_if_exists()
            create_index()
        else:
            raise
    else:
        sync_index(index)
else:
    create_index()