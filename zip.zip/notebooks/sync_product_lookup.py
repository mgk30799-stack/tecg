# Databricks notebook source
# MAGIC %pip install pyyaml
# MAGIC %restart_python

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Cell 3

import sys
import os
import yaml

# Add paths for shared utilities
_cwd = os.getcwd()
_common_path = os.path.join(_cwd, "common")
if _common_path not in sys.path:
    sys.path.insert(0, _common_path)

sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode, validate_before_write
from shared import keep_latest_change_per_key, start_stream_with_cdc_recovery, reconcile_orphans,get_smart_latest_version

_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_lookup"]

dbutils.widgets.text("checkpoint_base_path", defaultValue=sync_config["checkpoint_base_path"])
checkpoint_base_path = dbutils.widgets.get("checkpoint_base_path")

# ---------------------------------------------------------------------------
# Tables from config
# ---------------------------------------------------------------------------
product_dim_table_path = sync_config["tables"]["source_table"]
product_lookup_table_path = sync_config["tables"]["output_table"]

checkpoint_path = f"{checkpoint_base_path}/sync_product_lookup"
permissions_groups = sync_config["permissions_groups"]

# ---------------------------------------------------------------------------
# Ensure checkpoint volume exists
# ---------------------------------------------------------------------------
_volume_parts = checkpoint_base_path.strip("/").split("/")
if len(_volume_parts) >= 4 and _volume_parts[0].lower() == "volumes":
    _vol_catalog = _volume_parts[1]
    _vol_schema = _volume_parts[2]
    _vol_name = _volume_parts[3]
    spark.sql(
        f"CREATE VOLUME IF NOT EXISTS {_vol_catalog}.{_vol_schema}.{_vol_name}"
    )
    print(f"Ensured volume exists: {_vol_catalog}.{_vol_schema}.{_vol_name}")

# ---------------------------------------------------------------------------
# Runtime parameters (only full_refresh remains as a widget)
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
full_refresh = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_dim_table_path}")
print(f"Lookup table: {product_lookup_table_path}")
print(f"Checkpoint: {checkpoint_path}")
print(f"Full refresh: {full_refresh}")

if full_refresh:
    print("Full refresh requested: deleting checkpoint and lookup table.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
    except Exception as exc:
        print(f"Skipping checkpoint cleanup at {checkpoint_path}: {exc}")
    spark.sql(f"DROP TABLE IF EXISTS {product_lookup_table_path}")


def build_lookup_projection(input_df: DataFrame):
    support_schema = "array<struct<channel:string,availability:array<struct<days:string,hours:string>>,details:struct<email:string,phone:string>>>"
    support_raw_col = (
        F.from_json(F.col("support_channel_json"), support_schema)
        if dict(input_df.dtypes).get("support_channel_json") == "string"
        else F.col("support_channel_json").cast(support_schema)
    )
    # A change-feed batch from before the sell_unit_ columns were added has only the plain
    # names, which hold the same package size
    sell_unit = {
        measure: F.col("sell_unit_" + measure) if "sell_unit_" + measure in input_df.columns else F.col(measure)
        for measure in ("length", "width", "height", "weight")
    }
    # A change-feed batch from before capacity_info was added has only the plain capacity_value
    # and capacity_unit columns, which hold the same values
    capacity = {
        key: F.get_json_object(F.col("capacity_info"), "$." + key) if "capacity_info" in input_df.columns
        else F.col("capacity_" + key).cast("string")
        for key in ("value", "unit")
    }

    return input_df.select(
        # ============================================================
        # Core Product
        # ============================================================
        F.col("item_id").alias("product_id"),
        F.col("upc").alias("upc"),
        F.col("ean").alias("ean"),
        F.col("gtin").alias("gtin"),
        F.col("mpn").alias("mpn"),
        F.col("model_number").alias("model_number"),
        F.col("title").alias("title"),
        F.col("description").alias("description"),
        F.col("url").alias("url"),
        F.col("image_url").alias("image_url"),
        F.col("additional_image_urls").alias("additional_image_urls"),
        # =====================================
        # Physical Packaging
        # =====================================
        F.col("multipack").alias("multipack"),
        F.concat(F.col("length"), F.lit(" "), F.col("dimension_unit")).alias("length"),
        F.concat(F.col("width"), F.lit(" "), F.col("dimension_unit")).alias("width"),
        F.concat(F.col("height"), F.lit(" "), F.col("dimension_unit")).alias("height"),
        F.concat(F.col("weight"), F.lit(" "), F.col("weight_unit")).alias("weight"),
        # The same package (sell unit) size under the names that replace the four above
        F.concat(sell_unit["length"], F.lit(" "), F.col("dimension_unit")).alias("sell_unit_length"),
        F.concat(sell_unit["width"], F.lit(" "), F.col("dimension_unit")).alias("sell_unit_width"),
        F.concat(sell_unit["height"], F.lit(" "), F.col("dimension_unit")).alias("sell_unit_height"),
        F.concat(sell_unit["weight"], F.lit(" "), F.col("weight_unit")).alias("sell_unit_weight"),
        capacity["value"].alias("capacity_value"),
        capacity["unit"].alias("capacity_unit"),
        F.col("color").alias("color"),
        F.col("material").alias("material"),
        F.col("pattern").alias("pattern"),
        F.col("finish").alias("finish"),
        F.col("collection_name").alias("collection_name"),
        # =======================
        # Fulfillment
        # =======================
        F.col("store_name").alias("store_name"),
        F.col("store_country").alias("store_country"),
        F.when(F.col("bopis_eligible") == "Y", True)
        .otherwise(False)
        .alias("bopis_eligible"),
        F.when(F.col("dropship_dotcom_ind") == "Y", True)
        .otherwise(False)
        .alias("dropship_dotcom_ind"),
        F.when(F.col("ship_from_store_ind") == "Y", True)
        .otherwise(False)
        .alias("ship_from_store_ind"),
        F.when(F.col("auto_restock_ind") == "Y", True)
        .otherwise(False)
        .alias("auto_restock_ind"),
        F.col("return_window").alias("return_window"),
        F.col("lifecycle_status").alias("lifecycle_status"),
        F.col("sales_velocity").cast("double").alias("sales_velocity"),
        F.col("sales_amt_lt_30days").cast("double").alias("sales_amt_lt_30days"),
        # ==========================================
        # Audience
        # ==========================================
        F.col("gender").alias("gender"),
        F.col("age_group").alias("age_group"),
        F.col("age_restriction").alias("age_restriction"),
        F.array_distinct(
            F.transform(
                F.filter(
                    F.col("room_context_tags").cast("array<string>"),
                    lambda x: x.isNotNull() & (F.length(F.trim(x)) > 0),
                ),
                lambda x: F.trim(x),
            )
        ).alias("room_context_tags"),
        F.col("use_case_tags").cast("array<string>").alias("use_case_tags"),
        F.col("audience_tags").cast("array<string>").alias("audience_tags"),
        # ======================================================
        # Quality, Maintenance, Support
        # ======================================================
        # Master has both(review_count, star_rating); using store_* here aliased to those names.
        F.col("store_review_count").cast("long").alias("review_count"),
        F.col("store_star_rating").cast("double").alias("star_rating"),
        F.col("review_overall_summary").alias("review_overall_summary"),
        F.array_distinct(
            F.transform(
                F.filter(
                    F.from_json(
                        (
                            F.col("compliance_tags_json")
                            if "compliance_tags_json" in input_df.columns
                            else (
                                F.col("complaience_tags_json")
                                if "complaience_tags_json" in input_df.columns
                                else F.lit(None)
                            )
                        ).cast("string"),
                        "array<struct<name:string,source:string,confidence:double>>",
                    ),
                    lambda x: x["name"].isNotNull()
                    & (F.length(F.trim(x["name"])) > 0)
                    & (F.coalesce(x["confidence"], F.lit(0.0)) > F.lit(0.8)),
                ),
                lambda x: F.trim(x["name"]),
            )
        ).alias("compliance_tags_json"),
        F.col("warranty_json").alias("warranty"),
        F.col("support_warranty_duration_months").alias(
            "support_warranty_duration_months"
        ),
        F.col("warning").alias("warning"),
        F.transform(
            F.filter(
                support_raw_col,
                lambda x: x["channel"].isNotNull()
                & (F.length(F.trim(x["channel"])) > 0),
            ),
            lambda x: F.struct(
                F.trim(x["channel"]).alias("channel"),
                F.array_distinct(
                    F.transform(
                        F.filter(
                            x["availability"],
                            lambda a: a["days"].isNotNull()
                            & (F.length(F.trim(a["days"])) > 0)
                            & a["hours"].isNotNull()
                            & (F.length(F.trim(a["hours"])) > 0),
                        ),
                        lambda a: F.concat(
                            F.trim(a["days"]), F.lit(": "), F.trim(a["hours"])
                        ),
                    )
                ).alias("availability"),
                F.trim(x["details"]["email"]).alias("email"),
                F.trim(x["details"]["phone"]).alias("phone"),
            ),
        ).alias("support"),
    )

# ===INITIAL LOAD (table doesn't exist yet) ===
lookup_table_initialized = False

if not spark.catalog.tableExists(product_lookup_table_path):
    (
        build_lookup_projection(spark.table(product_dim_table_path))
        .where(F.col("product_id").isNotNull())
        .dropDuplicates(["product_id"])
        .write.mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(product_lookup_table_path)
    )
    lookup_table_initialized = True

if lookup_table_initialized:
    for group_name in permissions_groups:
        spark.sql(
            f"GRANT MANAGE ON TABLE {product_lookup_table_path} TO `{group_name}`"
        )

    # Delete checkpoint when schema is rebuilt to prevent mismatch
    print(f"Schema was rebuilt. Deleting checkpoint at {checkpoint_path} to avoid schema mismatch.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
        print(f"✓ Checkpoint deleted successfully")
    except Exception as e:
        print(f"Warning: Could not delete checkpoint: {e}")

    spark.sql(
        f"ALTER TABLE {product_lookup_table_path} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
    )


def process_batch(batch_df: DataFrame, batch_id: int):
    print(f"Processing batch_id={batch_id}")
    latest_changes_df = keep_latest_change_per_key(
        batch_df.where(F.col("item_id").isNotNull()),
        ["item_id"]
    )

    upsert_df = (
        build_lookup_projection(
            latest_changes_df.filter(
                F.col("_change_type").isin("insert", "update_postimage")
            )
        )
        .where(F.col("product_id").isNotNull())
        .dropDuplicates(["product_id"])
    )
    delete_df = (
        latest_changes_df.filter(F.col("_change_type") == "delete")
        .select(F.col("item_id").alias("product_id"))
        .where(F.col("product_id").isNotNull())
        .dropDuplicates(["product_id"])
    )

    target = DeltaTable.forName(spark, product_lookup_table_path)
    target.alias("t").merge(
        upsert_df.alias("s"),
        "t.product_id = s.product_id",
    ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    target.alias("t").merge(
        delete_df.alias("d"),
        "t.product_id = d.product_id",
    ).whenMatchedDelete().execute()
    print(
        f"batch_id={batch_id}: upserts={upsert_df.count()}, deletes={delete_df.count()}"
    )


# === RESOLVE STREAM STARTING VERSION ===
if lookup_table_initialized:
    # The initial load already bulk-loaded all existing source rows into the
    # target table. Starting from the source table's history version 0 would
    # fail with DELTA_MISSING_CHANGE_DATA because CREATE TABLE AS SELECT does
    # not write CDF change-data files even when CDF is enabled as a table
    # property. Use "latest" so the stream only picks up future changes.
    final_stream_version = "latest"
    print("Stream starting version: latest (initial load captured existing data)")
else:
    final_stream_version = get_smart_latest_version(spark, product_dim_table_path)
    print(f"Stream starting version: {final_stream_version}")

# === SCHEMA VALIDATION (first, once, before the stream) ===
# build_lookup_projection is exactly what process_batch writes. Schema-only:
# limit(0) reads no rows. Evolve never drops a lookup column.
validate_before_write(
    spark, product_lookup_table_path,
    build_lookup_projection(spark.table(product_dim_table_path).limit(0)).schema,
)

# === PASS THE VERSION TO THE STREAM ===
start_stream_with_cdc_recovery(
    spark=spark,
    dbutils=dbutils,
    source_table=product_dim_table_path,
    checkpoint_path=checkpoint_path,
    process_batch_fn=process_batch,
    starting_version=final_stream_version,
    # issue_summary_json / issue_signals_json were dropped and re-added on the
    # source; this projection reads neither, so the drop is safe to pass.
    allow_source_column_drop=True,
    allow_source_column_type_change=True,
)
# ---------------------------------------------------------------------------
# Reconciliation: Remove orphaned product_ids not in source master table
# ---------------------------------------------------------------------------
reconcile_orphans(
    spark=spark,
    target_table=product_lookup_table_path,
    target_key_col="product_id",
    source_table=product_dim_table_path,
    source_key_col="item_id",
)



# COMMAND ----------

source_count = (
    spark.table(product_dim_table_path)
    .where(F.col("item_id").isNotNull())
    .select(F.countDistinct("item_id"))
    .collect()[0][0]
)

lookup_count = spark.table(product_lookup_table_path).count()

# After reconcile_orphans: orphans=0, so any diff = missing items
if source_count != lookup_count:
    # Find exactly which items are missing
    missing_df = spark.sql(f"""
        SELECT s.item_id
        FROM {product_dim_table_path} s
        LEFT ANTI JOIN {product_lookup_table_path} t
            ON s.item_id = t.product_id
        WHERE s.item_id IS NOT NULL
    """)
    missing_count = missing_df.count()

    raise AssertionError(
        f"VALIDATION FAILED: source={source_count}, lookup={lookup_count}. "
        f"{missing_count} items in source not synced to lookup (CDC gap)."
    )

print(f"✓ Validation passed: source ({source_count}) == lookup ({lookup_count})")