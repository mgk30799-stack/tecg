# Databricks notebook source
# MAGIC %pip install mlflow databricks-sdk databricks-vectorsearch
# MAGIC %restart_python

# COMMAND ----------

# DBTITLE 1,Cell 2
from databricks.vector_search.client import VectorSearchClient
from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

import sys
import os
import yaml

# Add paths for shared utilities
_cwd = os.getcwd()
_common_path = os.path.join(_cwd, "common")
if _common_path not in sys.path:
    sys.path.insert(0, _common_path)

sys.path.append(os.path.join("..", "src", "data_pipeline", "enrichment"))
from utils import save_data, get_spark_session, read_config, ENVS, CATALOG, get_run_mode, validate_before_write
from shared import keep_latest_change_per_key, backfill_embeddings, infer_embedding_dimension, start_stream_with_cdc_recovery, reconcile_orphans, get_smart_latest_version, upsert_preserving_embeddings

_cwd = os.getcwd()
if os.path.exists(os.path.join(_cwd, "config", "general.yml")):
    PROJECT_ROOT = _cwd
else:
    PROJECT_ROOT = os.path.abspath(os.path.join(_cwd, ".."))
    if not os.path.exists(os.path.join(PROJECT_ROOT, "config", "general.yml")):
        raise FileNotFoundError(
            f"Cannot locate config/general.yml from {_cwd}"
        )

dbutils.widgets.text("catalog", defaultValue="mld01_ml_de")
dbutils.widgets.text("schema", defaultValue="product")

catalog = dbutils.widgets.get("catalog")
schema = dbutils.widgets.get("schema")

run_mode = get_run_mode(catalog=catalog)

config = read_config(os.path.join(PROJECT_ROOT, "config", "general.yml"), run_mode=run_mode)
sync_config = config["sync_product_discovery_index"]

dbutils.widgets.text("checkpoint_base_path", defaultValue=sync_config["checkpoint_base_path"])
checkpoint_base_path = dbutils.widgets.get("checkpoint_base_path")

# ---------------------------------------------------------------------------
# Tables & vector search settings from config
# ---------------------------------------------------------------------------
product_dim_table_path = sync_config["tables"]["source_table"]
vs_index_source_table_path = sync_config["tables"]["vs_index_source_table"]

vs_endpoint_name = sync_config["vectorsearch"]["endpoint_name"]
vs_index_path = sync_config["vectorsearch"]["index_name"]
embedding_endpoint = sync_config["vectorsearch"]["embedding_endpoint"]
embedding_batch_size = sync_config["vectorsearch"]["embedding_batch_size"]
checkpoint_path = f"{checkpoint_base_path}/sync_product_discovery_index"
permissions_groups = sync_config["permissions_groups"]

# ---------------------------------------------------------------------------
# Ensure checkpoint volume exists
# ---------------------------------------------------------------------------
_volume_parts = checkpoint_base_path.strip("/").split("/")
if len(_volume_parts) >= 4 and _volume_parts[0].lower() == "volumes":
    _vol_catalog = _volume_parts[1]
    _vol_schema = _volume_parts[2]
    _vol_name = _volume_parts[3]
    spark.sql(
        f"CREATE VOLUME IF NOT EXISTS {_vol_catalog}.{_vol_schema}.{_vol_name}"
    )
    print(f"Ensured volume exists: {_vol_catalog}.{_vol_schema}.{_vol_name}")

# ---------------------------------------------------------------------------
# Runtime parameters (only full_refresh remains as a widget)
# ---------------------------------------------------------------------------
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
full_refresh = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

print(f"Environment: {run_mode} | Catalog: {catalog}")
print(f"Source table: {product_dim_table_path}")
print(f"Index source: {vs_index_source_table_path}")
print(f"Vector index: {vs_index_path}")
print(f"Checkpoint: {checkpoint_path}")
print(f"Embedding Batch Size: {embedding_batch_size}")
print(f"Full refresh: {full_refresh}")

embedding_stopwords = F.array(
    *[
        F.lit(x)
        for x in [
            "a",
            "an",
            "and",
            "are",
            "as",
            "at",
            "be",
            "by",
            "for",
            "from",
            "in",
            "into",
            "is",
            "it",
            "its",
            "of",
            "on",
            "or",
            "that",
            "the",
            "their",
            "this",
            "to",
            "was",
            "with",
            "your",
            "you",
            "our",
            "we",
            "they",
            "them",
            "can",
            "may",
            "might",
            "will",
            "would",
            "should",
            "could",
            "about",
            "over",
            "under",
            "through",
            "up",
            "down",
            "out",
            "off",
            "more",
            "most",
            "very",
            "also",
            "just",
            "than",
            "then",
            "so",
            "if",
            "when",
            "while",
            "where",
            "which",
        ]
    ]
)

if full_refresh:
    print(
        "Full refresh requested: deleting checkpoint, source table, and vector index."
    )
    try:
        dbutils.fs.rm(checkpoint_path, True)
    except Exception as exc:
        print(f"Skipping checkpoint cleanup at {checkpoint_path}: {exc}")
    spark.sql(f"DROP TABLE IF EXISTS {vs_index_source_table_path}")
    try:
        vsc_for_delete = VectorSearchClient(disable_notice=True)
        try:
            vsc_for_delete.delete_index(
                endpoint_name=vs_endpoint_name, index_name=vs_index_path
            )
            print(f"✓ Vector index deleted: {vs_index_path}")
        except TypeError:
            vsc_for_delete.delete_index(vs_endpoint_name, vs_index_path)
            print(f"✓ Vector index deleted: {vs_index_path}")
    except Exception as exc:
        if "does not exist" in str(exc).lower():
            print(f"ℹ️ Vector index not found in UC catalog (may not exist or already deleted): {vs_index_path}")
        else:
            print(f"⚠️ WARNING: Failed to delete vector index {vs_index_path}: {exc}")
            print("   The index may still exist. Check Vector Search UI and delete manually if needed.")


def build_product_index_projection(input_df: DataFrame):
    # Deduplicate by item_id BEFORE expensive projection
    # Removes duplicate products before unique_tokens window aggregation
    deduped_df = (
        input_df
        .where(F.col("item_id").isNotNull())
        .dropDuplicates(["item_id"])
    )    
    # Helper function to safely get array columns
    cols = set(deduped_df.columns)

    def _array_col_or_empty(name):
        if name in cols:
            return F.col(name).cast("array<string>")
        return F.array().cast("array<string>")

    room_context_tags_col = _array_col_or_empty("room_context_tags")
    use_case_tags_col = _array_col_or_empty("use_case_tags")
    audience_tags_col = _array_col_or_empty("audience_tags")
    spec_text_expr = F.array_join(
        F.transform(
            F.col("spec_json"),
            lambda x: F.concat_ws(
                " ", x.attribute_group_nm, x.attribute_nm, x.attribute_value_txt
            ),
        ),
        " | ",
    )
    bullets_text_expr = F.array_join(F.col("bullets_json"), " | ")
    review_aspects_text_expr = F.to_json(F.col("review_aspects"))
    discovery_profile_raw = F.concat_ws(
        " | ",
        F.col("brand"),
        F.col("manufacturer"),
        F.when(F.upper(F.trim(F.col("own_brand_ind"))) == "Y", "Own Brand").otherwise(
            ""
        ),
        F.col("title"),
        F.col("description"),
        F.col("web_supercategory_nm"),
        F.col("web_department_nm"),
        F.col("web_category_nm"),
        F.col("web_class_nm"),
        spec_text_expr,
        bullets_text_expr,
        review_aspects_text_expr,
        F.col("review_overall_summary"),
        F.array_join(room_context_tags_col, " "),
        F.array_join(use_case_tags_col, " "),
        F.array_join(audience_tags_col, " "),
        F.concat_ws(
            " ",
            F.when(
                F.upper(F.trim(F.col("eco_energy_star_certified_ind"))) == "Y",
                "Energy Star Certified",
            ).otherwise(""),
            F.when(
                F.upper(F.trim(F.col("eco_recycled_ind"))) == "Y", "Recycled"
            ).otherwise(""),
            F.when(
                F.upper(F.trim(F.col("eco_feature_ind"))) == "Y", "Eco Feature"
            ).otherwise(""),
        ),
    )
    cleaned = F.trim(
        F.regexp_replace(
            F.regexp_replace(
                F.regexp_replace(
                    F.regexp_replace(
                        F.coalesce(discovery_profile_raw.cast("string"), F.lit("")),
                        r"https?://\S+",
                        " ",
                    ),
                    r"[\r\n\t]+",
                    " ",
                ),
                r"[^A-Za-z0-9\s\|\-\._/:]",
                " ",
            ),
            r"\s+",
            " ",
        )
    )
    segments = F.array_distinct(
        F.filter(
            F.transform(F.split(cleaned, r"\|"), lambda x: F.trim(x)), lambda x: x != ""
        )
    )
    segment_text = F.array_join(segments, " | ")
    tokens = F.filter(
        F.transform(F.split(F.lower(segment_text), r"\s+"), lambda x: F.trim(x)),
        lambda x: (x != "")
        & (~F.array_contains(embedding_stopwords, x))
        & (F.length(x) > F.lit(1)),
    )
    unique_tokens = F.aggregate(
        tokens,
        F.expr("CAST(array() AS array<string>)"),
        lambda acc, x: F.when(F.array_contains(acc, x), acc).otherwise(
            F.concat(acc, F.array(x))
        ),
    )
    return (
        deduped_df.select(
            F.col("item_id").alias("product_id"),
            F.col("brand").cast("string").alias("brand"),
            F.col("manufacturer").cast("string").alias("manufacturer"),
            (F.upper(F.trim(F.col("own_brand_ind"))) == "Y").alias("own_brand_ind"),
            F.col("web_class_nm").cast("string").alias("web_class_nm"),
            F.col("web_department_nm").cast("string").alias("web_department_nm"),
            F.col("web_category_nm").cast("string").alias("web_category_nm"),
            F.col("web_supercategory_nm").cast("string").alias("web_supercategory_nm"),
            #F.col("cache_list_price").cast("double").alias("list_price"),
            F.split(F.col("pm_price"), " ").getItem(0).cast("double").alias("sale_price"),
            # F.col("lifecycle_status").cast("string").alias("lifecycle_status"),
            (F.upper(F.trim(F.col("eco_feature_ind"))) == "Y").alias("eco_feature_ind"),
            (F.upper(F.trim(F.col("eco_energy_star_certified_ind"))) == "Y").alias(
                "eco_energy_star_certified_ind"
            ),
            (F.upper(F.trim(F.col("eco_recycled_ind"))) == "Y").alias(
                "eco_recycled_ind"
            ),
            room_context_tags_col.alias("room_context_tags"),
            use_case_tags_col.alias("use_case_tags"),
            audience_tags_col.alias("audience_tags"),
            F.array_join(unique_tokens, " ").alias("discovery_profile"),
        )
        # dropDuplicates already done before projection
    )


def build_upsert_frame(input_df: DataFrame):
    """
    The exact rows written to the index table: projection + embedding slot +
    timestamps. The initial load, process_batch and the schema validation
    all use this, so the declared shape can never drift from what is written.
    """
    return (
        build_product_index_projection(input_df)
        .withColumn("discovery_profile_emb", F.lit(None).cast("array<float>"))
        .withColumn("created_at", F.current_timestamp())
        .withColumn("updated_at", F.current_timestamp())
    )


# === INITIAL LOAD (table doesn't exist yet) ===
source_table_initialized = False

if not spark.catalog.tableExists(vs_index_source_table_path):
    (
        build_upsert_frame(spark.table(product_dim_table_path))
        .write.mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(vs_index_source_table_path)
    )
    source_table_initialized = True

if source_table_initialized:
    for group_name in permissions_groups:
        spark.sql(
            f"GRANT MANAGE ON TABLE {vs_index_source_table_path} TO `{group_name}`"
        )

    print(f"Schema was rebuilt. Deleting checkpoint at {checkpoint_path} to avoid schema mismatch.")
    try:
        dbutils.fs.rm(checkpoint_path, True)
        print(f"✓ Checkpoint deleted successfully")
    except Exception as e:
        print(f"Warning: Could not delete checkpoint: {e}")

spark.sql(
    f"ALTER TABLE {vs_index_source_table_path} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
)


def process_batch(batch_df: DataFrame, batch_id: int):
    print(f"Processing batch_id={batch_id}")
    latest_changes_df = keep_latest_change_per_key(
        batch_df.where(F.col("item_id").isNotNull()),
        ["item_id"]
    )

    upsert_df = build_upsert_frame(
        latest_changes_df.filter(
            F.col("_change_type").isin("insert", "update_postimage")
        )
    )
    delete_df = (
        latest_changes_df.filter(F.col("_change_type") == "delete")
        .select(F.col("item_id").alias("product_id"))
        .dropDuplicates(["product_id"])
    )

    target = DeltaTable.forName(spark, vs_index_source_table_path)
    # Keeps the embedding of a product whose discovery_profile is unchanged.
    upsert_preserving_embeddings(
        target, upsert_df, "t.product_id = s.product_id",
        text_col="discovery_profile", emb_col="discovery_profile_emb",
    )
    target.alias("t").merge(
        delete_df.alias("d"),
        "t.product_id = d.product_id",
    ).whenMatchedDelete().execute()
    print(
        f"batch_id={batch_id}: upserts={upsert_df.count()}, deletes={delete_df.count()}"
    )


# === RESOLVE STREAM STARTING VERSION ===
if source_table_initialized:
    # The initial load already bulk-loaded all existing source rows into the
    # target table. Starting from the source table's history version 0 would
    # fail with DELTA_MISSING_CHANGE_DATA because CREATE TABLE AS SELECT does
    # not write CDF change-data files even when CDF is enabled as a table
    # property. Use "latest" so the stream only picks up future changes.
    final_stream_version = "latest"
    print("Stream starting version: latest (skipping history — initial load already captured existing data)")
else:
    final_stream_version = get_smart_latest_version(spark, product_dim_table_path)
    print(f"Stream starting version: {final_stream_version}")

# === SCHEMA VALIDATION (first, once, before the stream) ===
# Schema-only: limit(0) reads no rows. Evolve never drops an index column.
validate_before_write(
    spark, vs_index_source_table_path,
    build_upsert_frame(spark.table(product_dim_table_path).limit(0)).schema,
)

# === PASS THE VERSION TO THE STREAM ===
start_stream_with_cdc_recovery(
    spark=spark,
    dbutils=dbutils,
    source_table=product_dim_table_path,
    checkpoint_path=checkpoint_path,
    process_batch_fn=process_batch,
    starting_version=final_stream_version,
    # issue_summary_json / issue_signals_json were dropped and re-added on the
    # source; this projection reads neither, so the drop is safe to pass.
    allow_source_column_drop=True,
    allow_source_column_type_change=True,
)

# ---------------------------------------------------------------------------
# Reconciliation: Remove orphaned product_ids not in source master table
# ---------------------------------------------------------------------------
reconcile_orphans(
    spark=spark,
    target_table=vs_index_source_table_path,
    target_key_col="product_id",
    source_table=product_dim_table_path,
    source_key_col="item_id",
)

# ---------------------------------------------------------------------------
# Backfill embeddings for new/changed rows (NULL -> vector)
# ---------------------------------------------------------------------------
# NOTE: Spark RPC timeout must be configured at cluster creation time (Advanced Options)
backfill_embeddings(
    spark=spark,
    table_path=vs_index_source_table_path,
    pk_col="product_id",
    text_col="discovery_profile",
    emb_col="discovery_profile_emb",
    embedding_endpoint=embedding_endpoint,
    embedding_batch_size=embedding_batch_size,
    concurrency_cap=15,  # Higher concurrency for smaller dataset
    max_retries=5,
    retry_base_wait_seconds=10,
)

# COMMAND ----------

# DBTITLE 1,Validation: Confirm source and index source are in sync
# ---------------------------------------------------------------------------
# Validation: Confirm source and index source are in sync
# 
# NOTE: This is a WARNING validation, not a blocker. Sync gaps can occur due to:
#   1. Streaming lag (new products arrive shortly after)
#   2. Products deleted from source (orphan cleanup handles these)
#   3. CDC change data not yet processed
# 
# Use full_refresh if gaps exceed 5% of total products
# ---------------------------------------------------------------------------

source_count = (
    spark.table(product_dim_table_path)
    .where(F.col("item_id").isNotNull())
    .select(F.countDistinct("item_id"))
    .collect()[0][0]
)

index_source_count = (
    spark.table(vs_index_source_table_path)
    .select(F.countDistinct("product_id"))
    .collect()[0][0]
)

# Products completely missing from discovery index
missing_products = spark.sql(f"""
    SELECT COUNT(DISTINCT s.item_id) as missing_count
    FROM {product_dim_table_path} s
    LEFT JOIN {vs_index_source_table_path} t ON s.item_id = t.product_id
    WHERE s.item_id IS NOT NULL AND t.product_id IS NULL
""").collect()[0][0]

# Calculate sync percentage
sync_percentage = (index_source_count / source_count * 100) if source_count > 0 else 0

print(f"\n{'='*70}")
print(f"VALIDATION SUMMARY: Product Discovery Index Sync")
print(f"{'='*70}")
print(f"Total products in source table:        {source_count:>10}")
print(f"Products synced to discovery index:    {index_source_count:>10}")
print(f"Products missing from index:           {missing_products:>10}")
print(f"Sync percentage:                       {sync_percentage:>9.1f}%")
print(f"{'='*70}\n")

if source_count > index_source_count:
    gap = source_count - index_source_count
    print(f"⚠️  SYNC GAP DETECTED: {gap} products are not in the discovery index")
    print(f"   Action: This is typically resolved by subsequent streaming batches or full_refresh")
    if gap / source_count > 0.05:  # > 5% gap
        print(f"   WARNING: Gap exceeds 5% - consider running full_refresh")
elif source_count < index_source_count:
    print(f"ℹ️  Index has more products than source (may include orphaned/pending cleanup)")
else:
    print(f"✓  Validation passed: source ({source_count}) == index_source ({index_source_count})")

# COMMAND ----------

# find embedding dimension
embedding_dimension = infer_embedding_dimension(
    spark=spark,
    table_path=vs_index_source_table_path,
    emb_col="discovery_profile_emb",
)
print(f"Vector Index: {vs_index_path}")

# COMMAND ----------

vsc = VectorSearchClient(disable_notice=True)
try:
    vsc.get_endpoint(vs_endpoint_name)
except Exception:
    vsc.create_endpoint_and_wait(name=vs_endpoint_name, endpoint_type="STANDARD")

import time

def wait_for_deletion(timeout_attempts=24, interval=10):
    for attempt in range(timeout_attempts):
        try:
            vsc.get_index(vs_endpoint_name, vs_index_path)
            print(f"Waiting for index deletion... ({attempt + 1})")
            time.sleep(interval)
        except Exception:
            print("Index fully deleted.")
            return
    raise Exception(f"Timed out waiting for index {vs_index_path} to be deleted.")

def delete_index_if_exists():
    try:
        vsc.get_index(vs_endpoint_name, vs_index_path)
        print(f"Deleting index {vs_index_path}...")
        vsc.delete_index(endpoint_name=vs_endpoint_name, index_name=vs_index_path)
        wait_for_deletion()
    except Exception as e:
        if "pending deletion" in str(e).lower():
            print("Index already pending deletion, waiting...")
            wait_for_deletion()
        elif "does not exist" in str(e).lower() or "not found" in str(e).lower():
            print("Index already gone.")
        else:
            raise

def create_index():
    vsc.create_delta_sync_index_and_wait(
        endpoint_name=vs_endpoint_name,
        index_name=vs_index_path,
        primary_key="product_id",
        source_table_name=vs_index_source_table_path,
        pipeline_type="TRIGGERED",
        embedding_vector_column="discovery_profile_emb",
        embedding_dimension=embedding_dimension,
        columns_to_sync=[
            "product_id",
            "brand",
            "manufacturer",
            "own_brand_ind",
            "web_class_nm",
            "web_department_nm",
            "web_category_nm",
            "web_supercategory_nm",
            #"list_price",
            "sale_price",
            "eco_feature_ind",
            "eco_energy_star_certified_ind",
            "eco_recycled_ind",
            "room_context_tags",
            "use_case_tags",
            "audience_tags",
            "discovery_profile",
            "discovery_profile_emb",
        ]
    )
    print("Index created")
    for group_name in permissions_groups:
        spark.sql(f"GRANT MANAGE ON TABLE {vs_index_path} TO `{group_name}`")

index_exists = True
try:
    index = vsc.get_index(vs_endpoint_name, vs_index_path)
    print("Index already exists -> syncing")
except Exception:
    index_exists = False

def sync_index(index, retries=6, interval=30):
    for attempt in range(1, retries + 1):
        try:
            index.sync()
            print("Sync triggered successfully")
            return
        except Exception as e:
            if "not ready" in str(e).lower():
                print(f"Index not ready, retrying in {interval}s... ({attempt}/{retries})")
                time.sleep(interval)
            else:
                raise
    raise Exception(f"Index {vs_index_path} was not ready after {retries} retries.")

if index_exists:
    try:
        index.wait_until_ready()
    except Exception as e:
        if "offline" in str(e).lower():
            print(f"Index {vs_index_path} is offline, recreating...")
            delete_index_if_exists()
            create_index()
        else:
            raise
    else:
        sync_index(index)
else:
    create_index()
