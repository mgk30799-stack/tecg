"""
Extracts product document URLs (SDS, PROP 65, tech specs, etc.) from Unity Catalog
and saves them to the configured output table (config/general.yml).
"""
import os
import sys

# Ensure `data_pipeline` package is importable when executed directly.
# CWD on serverless = this file's directory; go up 2 levels to reach src/.
sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), "..", "..")))

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, lower, coalesce, regexp_extract, when, trim, expr
from pyspark.sql.types import StringType

from data_pipeline.utils import get_spark_session, read_config, save_data


def _resolve_config():
    """Load general.yml and return resolved config dict."""
    project_root = os.path.abspath(os.path.join(os.getcwd(), "..", "..", ".."))
    config_path = os.path.join(project_root, "config", "general.yml")
    return read_config(config_path)


# Regex pattern to extract a bare PDF URL from an HTML bullet string.
# Mirrors: regexp_substr(bullet_txt, 'https?://[^"]+\.pdf')
_PDF_URL_PATTERN = r'https?://[^"]+\.pdf'

# Regex to extract P65 URL from warning text.
# Matches: https://www.prop65.ca.gov or www.prop65.ca.gov or prop65.ca.gov
# Handles query params, fragments, and common URL variations.
# Excludes trailing punctuation: periods, quotes, angle brackets.
_P65_URL_PATTERN = r'(?i)((?:https?://)?(?:www\.)?(?:prop65\.)?(?:p65\.)?[a-z0-9.-]+\.(?:ca\.)?gov[a-z0-9\-._~:/?#\[\]@!$&\'()*+,;=%]*)'


def _extract_and_validate_prop65_url(warning_text: str) -> str:
    """
    Extract P65 URL from warning text with fallbacks and validation.

    Args:
        warning_text: Raw warning text that may contain P65 URL.

    Returns:
        Valid URL string with https:// protocol, or None if no URL found.
    """
    import re

    if not warning_text:
        return None

    # Try pattern match
    match = re.search(_P65_URL_PATTERN, str(warning_text), re.IGNORECASE)
    if match:
        url = match.group(1).strip()
        if url:
            # Ensure protocol
            if not url.startswith('http'):
                url = 'https://' + url
            # Remove trailing punctuation
            url = re.sub(r'[,.\'")\]]+$', '', url)
            return url if url.startswith('http') else None

    # Fallback: look for exact domain matches
    common_p65_domains = [
        'prop65.ca.gov',
        'p65warnings.ca.gov',
        'www.prop65.ca.gov',
    ]
    for domain in common_p65_domains:
        if domain.lower() in warning_text.lower():
            return f'https://{domain}'

    return None


def _nullif_empty(column_expr, pattern: str, group: int = 1):
    """
    PySpark equivalent of SQL NULLIF(regexp_extract(col, pattern, group), '').
    Returns the captured group, or None when the capture is an empty string.
    """
    extracted = regexp_extract(column_expr, pattern, group)
    return when(extracted != "", extracted).otherwise(lit(None))


def _classify_doc_type_from_url(url_col):
    """
    Last-resort fallback: classify doc_type from keywords in product_doc_url.
    Only used when all p1–p7 HTML label extraction patterns return NULL.
    Returns a string literal or NULL if no keyword matches.
    """
    url_lower = lower(url_col)
    return (
        when(url_lower.rlike(r"chemical.?disclos|chemicaldisclos|dislcosure"), lit("Chemical Disclosure"))
        .when(url_lower.rlike(r"msds"), lit("Material Safety Data Sheet"))
        .when(url_lower.rlike(r"instruction|instrucrion"), lit("Product Instructions"))
        .when(url_lower.rlike(r"guide.?datasheet|datasheet|data-sheet"), lit("Guide Datasheet"))
        .when(url_lower.rlike(r"reformatting|guide"), lit("Reformatting Guide"))
        .when(url_lower.rlike(r"terms|protection"), lit("Terms & Conditions"))
        .when(url_lower.rlike(r"warranty"), lit("Warranty"))
        .when(url_lower.rlike(r"template"), lit("Template"))
        .when(url_lower.rlike(r"brochure|manual"), lit("Product Manual"))
        .when(url_lower.rlike(r"assembly"), lit("Assembly Instructions"))
        .otherwise(lit(None))
    )


def _normalize_doc_type(doc_type_col):
    dt_lower = lower(trim(doc_type_col))

    return (
        when(dt_lower.rlike(r"click here.*template"), "PDF Template")
        .when(dt_lower.rlike(r"click here.*product instruction"), "Product Instructions")
        .when(dt_lower.rlike(r"click here.*instructional wall chart"), "Instructional Wall Chart")
        .when(dt_lower.contains("click here"), "Datasheet")
        .otherwise(trim(doc_type_col))
    )


def build_document_url_query(
    spark: SparkSession,
    product_master_table: str,
    product_web_bullets_table: str,
) -> DataFrame:
    """
    Build a DataFrame of document URLs extracted from product data.

    Args:
        spark: Active SparkSession.
        product_master_table: Fully qualified product_master table name.
        product_web_bullets_table: Fully qualified product_web_bullets table name.

    Returns:
        DataFrame with columns: item_id, product_doc_url, doc_type.
    """
    # Register PROP 65 extraction UDF
    spark.udf.register("extract_prop65_url", _extract_and_validate_prop65_url, StringType())

    pm = spark.table(product_master_table)
    bullets = spark.table(product_web_bullets_table)

    # ------------------------------------------------------------------
    # CTE 1 — all_data
    # Left-join product_master with product_web_bullets; keep only rows
    # that are live on dotcom AND have at least one document URL or a
    # bullet that references a PDF.
    # Cache to prevent plan duplication across union branches.
    # ------------------------------------------------------------------
    all_data = (
        pm.alias("pm")
        .join(
            bullets.alias("b"),
            on=col("pm.PRODUCT_ID") == col("b.PRODUCT_ID"),
            how="left",
        )
        .filter(
            (col("pm.web_live_on_dotcom_ind") == "Y")
            & (col("pm.intent_to_sell_dotcom_ind") == "Y")
            & (
                col("pm.WEB_SAFETY_DATA_SHEET_URL").isNotNull()
                | col("pm.WEB_PROP65_WARNING_TXT").isNotNull()
                | col("pm.WEB_SECONDARY_LABEL_URL").isNotNull()
                | col("pm.web_technical_data_sheet_url").isNotNull()
                | col("pm.WEB_TOY_SAFETY_DATA_SHEET_URL").isNotNull()
                # iLIKE '%.pdf%'  →  lower(col).contains(".pdf")
                | lower(col("b.bullet_txt")).contains(".pdf")
            )
        )
        .select(
            col("pm.PRODUCT_ID"),
            col("pm.WEB_SAFETY_DATA_SHEET_URL"),
            col("pm.WEB_PROP65_WARNING_TXT"),
            col("pm.WEB_SECONDARY_LABEL_URL").alias("WEB_SEC_LABEL_URL"),
            col("pm.web_technical_data_sheet_url"),
            col("pm.WEB_TOY_SAFETY_DATA_SHEET_URL"),
            col("b.bullet_txt"),
        )
    ).cache()

    # ------------------------------------------------------------------
    # CTE 2 — split_bullets
    # From bullet rows that contain a PDF reference, extract:
    #   • the raw PDF URL  (group 0 = full match of the URL pattern)
    #   • up to seven candidate link-label patterns (p1–p7)
    #   • p6/p7 are catch-all fallbacks for HTML variations missed by p1–p5
    # ------------------------------------------------------------------
    split_bullets = (
        all_data.filter(
            col("bullet_txt").isNotNull()
            & lower(col("bullet_txt")).contains(".pdf")
        )
        .select(
            col("PRODUCT_ID"),
            col("bullet_txt"),
            # regexp_substr → regexp_extract with group=0 (full match)
            regexp_extract(col("bullet_txt"), _PDF_URL_PATTERN, 0).alias("url"),
            # NULLIF(regexp_extract(..., pattern, 1), '')
            _nullif_empty(col("bullet_txt"), r'target="new">([^<]+)</a>').alias("p1"),
            _nullif_empty(
                col("bullet_txt"),
                r'target\s*=\s*["\u201c]_blank["\u201d]\s*>\s*([^<]+)\s*</a>',
            ).alias("p2"),
            _nullif_empty(
                col("bullet_txt"),
                r'target\s*=\s*["\u201c]_blank["\u201d]<gt/>([^&]+?)<lt/>',
            ).alias("p3"),
            _nullif_empty(
                col("bullet_txt"), r'target="new"<gt/>([^&]+?)<lt/>'
            ).alias("p4"),
            _nullif_empty(
                col("bullet_txt"),
                r'target\s*=\s*["\u201c]_blank["\u201d]>([^&]+)<',
            ).alias("p5"),
            # p6: catch-all for any <a> tag link text (fallback for missed target= variations)
            _nullif_empty(col("bullet_txt"), r'>\s*([^<]{2,}?)\s*</a>').alias("p6"),
            # p7: catch-all for encoded HTML <gt/>text<lt/> without specific target format
            _nullif_empty(col("bullet_txt"), r'<gt/>\s*([^<]{2,}?)\s*<lt/>').alias("p7"),
        )
        .distinct()
    )

    # ------------------------------------------------------------------
    # Six UNION ALL branches  →  six DataFrames unioned together.
    # Each branch selects (PRODUCT_ID, URL, DOC_TYPE).
    # ------------------------------------------------------------------

    # Branch 1 — Safety Data Sheet
    sds = (
        all_data.filter(
            col("WEB_SAFETY_DATA_SHEET_URL").isNotNull()
            & lower(col("WEB_SAFETY_DATA_SHEET_URL")).contains(".pdf")
        )
        .select(
            col("PRODUCT_ID").alias("item_id"),
            col("WEB_SAFETY_DATA_SHEET_URL").alias("product_doc_url"),
            lit("Safety Data Sheet").alias("doc_type"),
        )
        .distinct()
    )

    # Branch 2 — PROP 65: extract URL from warning text using robust validation
    # Using custom UDF for better error handling and fallbacks
    prop65 = (
        all_data.filter(col("WEB_PROP65_WARNING_TXT").isNotNull())
        .select(
            col("PRODUCT_ID").alias("item_id"),
            expr("extract_prop65_url(WEB_PROP65_WARNING_TXT)").alias("product_doc_url"),
            lit("PROP 65").alias("doc_type"),
        )
        .filter(col("product_doc_url").isNotNull())  # Only keep rows with extracted URL
        .distinct()
    )

    # Branch 3 — Secondary / Sec Label
    sec_label = (
        all_data.filter(
            col("WEB_SEC_LABEL_URL").isNotNull()
            & lower(col("WEB_SEC_LABEL_URL")).contains(".pdf")
        )
        .select(
            col("PRODUCT_ID").alias("item_id"),
            col("WEB_SEC_LABEL_URL").alias("product_doc_url"),
            lit("Sec Label").alias("doc_type"),
        )
        .distinct()
    )

    # Branch 4 — Technical Data Sheet
    tech_sheet = (
        all_data.filter(
            col("web_technical_data_sheet_url").isNotNull()
            & lower(col("web_technical_data_sheet_url")).contains(".pdf")
        )
        .select(
            col("PRODUCT_ID").alias("item_id"),
            col("web_technical_data_sheet_url").alias("product_doc_url"),
            lit("Tech Data Sheet").alias("doc_type"),
        )
        .distinct()
    )

    # Branch 5 — Toy Safety Certificate (no .pdf filter in original SQL)
    toy_safety = (
        all_data.filter(col("WEB_TOY_SAFETY_DATA_SHEET_URL").isNotNull())
        .select(
            col("PRODUCT_ID").alias("item_id"),
            col("WEB_TOY_SAFETY_DATA_SHEET_URL").alias("product_doc_url"),
            lit("Toy Safety Certificate").alias("doc_type"),
        )
        .distinct()
    )

    # Branch 6 — PDF URLs extracted from bullet_txt
    # Priority chain:
    #   1. p1–p5 (specific HTML target= patterns)
    #   2. p6–p7 (catch-all HTML >text</a>)
    #   3. _classify_doc_type_from_url (URL keyword fallback)
    #   4. _normalize_doc_type (clean up "Click here..." labels)
    bullets_urls = split_bullets.select(
        col("PRODUCT_ID").alias("item_id"),
        col("url").alias("product_doc_url"),
        _normalize_doc_type(
            coalesce(
                col("p1"), col("p2"), col("p3"), col("p4"), col("p5"),
                col("p6"), col("p7"),
                _classify_doc_type_from_url(col("url"))
            )
        ).alias("doc_type"),
    )

    return (
        sds
        .union(prop65)
        .union(sec_label)
        .union(tech_sheet)
        .union(toy_safety)
        .union(bullets_urls)
    )


def run_ingestion(limit: int = None, mode: str = "overwrite"):
    """
    Run the full document URL ingestion pipeline.

    1. Reads source tables from config (product_discovery_data.tables)
    2. Executes extraction query
    3. Writes results to unstructed_data.url_data table

    Args:
        limit: Optional row limit for testing
        mode: Write mode ('overwrite' or 'append')
    """
    config = _resolve_config()
    spark = get_spark_session()

    # Source tables from config
    tables = config["product_discovery_data"]["tables"]
    product_master_table = tables["product_master"]
    product_web_bullets_table = tables["product_web_bullets"]

    # Output table from config
    output_fqn = config["unstructured_data"]["tables"]["url_data"]



    print(f"Source: {product_master_table}")
    print(f"Source: {product_web_bullets_table}")
    print(f"Output: {output_fqn}")

    # Build DataFrame using PySpark API
    print("Building document URL DataFrame...")
    df = build_document_url_query(spark, product_master_table, product_web_bullets_table)
    if limit:
        df = df.limit(limit)
    row_count = df.count()
    print(f"Extracted {row_count:,} document URL records")

    if row_count == 0:
        print("No records found. Skipping write.")
        return

    save_data(df, spark, table=output_fqn, mode=mode)

    final_count = spark.table(output_fqn).count()
    print(f"Successfully saved {final_count:,} rows to {output_fqn}")


if __name__ == "__main__":
    run_ingestion()
