"""
Product Document Ingestion Pipeline

Extracts, downloads, and parses product document URLs (PDFs) into structured text.

Serverless-compatible: downloads on driver (FUSE not available on workers),
parses via binaryFile reader + ai_parse_document.

Config-driven: reads source/target table names from config/general.yml.
"""
import os
import sys
import time
import logging
import requests as http_requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.exceptions import RequestException, Timeout, ConnectionError

# Configure logging
logging.basicConfig(
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def check_ai_parse_document_availability(spark):
    """
    Check if ai_parse_document function is available on this cluster.

    Returns:
        bool: True if available, False otherwise
    """
    try:
        logger.info("Checking ai_parse_document availability...")
        test_sql = "SELECT ai_parse_document(unhex('255044'))"
        spark.sql(test_sql).collect()
        logger.info("✓ ai_parse_document is available")
        return True
    except Exception as e:
        logger.warning(f"✗ ai_parse_document not available: {e}")
        logger.warning("  Requirements: Databricks Runtime ML 14.0+, AI features enabled")
        return False


sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), "..", "..")))

from data_pipeline.utils import get_spark_session, read_config, get_run_mode, CATALOG, validate_before_write

from pyspark.sql.functions import (
    col, expr, lit, current_timestamp, monotonically_increasing_id,
    when, lower, regexp_replace, trim, concat, row_number, count,
    regexp_extract
)
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.window import Window
from pyspark.dbutils import DBUtils


# --- Configuration from general.yml ---
def _resolve_config():
    project_root = os.path.abspath(os.path.join(os.getcwd(), "..", "..", ".."))
    config_path = os.path.join(project_root, "config", "general.yml")
    return read_config(config_path)

config = _resolve_config()
run_mode = get_run_mode()
catalog_name = CATALOG[run_mode]

SOURCE_TABLE = config["unstructured_data"]["tables"]["url_data"]
TARGET_TABLE = config["unstructured_data"]["tables"]["documents"]
DOWNLOAD_STATUS_TABLE = config["unstructured_data"]["tables"]["download_status"]

# Column mappings (as they exist in source table)
URL_COLUMN = "product_doc_url"
ID_COLUMN = "item_id"

# Download params
DOWNLOAD_WORKERS = config["unstructured_data"]["download"].get("batch_size", 16)
CONNECT_TIMEOUT = config["unstructured_data"]["download"].get("connect_timeout_seconds", 5)
READ_TIMEOUT = config["unstructured_data"]["download"].get(
    "read_timeout_seconds",
    config["unstructured_data"]["download"].get("timeout_seconds", 30)
)
MAX_RETRIES = config["unstructured_data"]["download"].get("max_retries", 2)

# Parse params
PARSE_BATCH_SIZE = config["unstructured_data"]["parsing"].get("batch_size", 500)
AI_PARSE_ENABLED = config["unstructured_data"]["parsing"].get("ai_parse_enabled", True)
REPARTITION_FACTOR = config["unstructured_data"]["parsing"].get("repartition_factor", 32)

VOLUME_PATH = f"/Volumes/{catalog_name}/product/documents/"

# Initialize Spark and DBUtils
spark = get_spark_session()
dbutils = DBUtils(spark)

# --- Runtime Parameters (widgets) ---
dbutils.widgets.text("full_refresh", defaultValue="false")
full_refresh_raw = dbutils.widgets.get("full_refresh")
FULL_REFRESH = str(full_refresh_raw).strip().lower() in {"1", "true", "t", "yes", "y"}

dbutils.widgets.text("test_limit", defaultValue="")
test_limit_raw = dbutils.widgets.get("test_limit")
TEST_LIMIT = int(test_limit_raw) if test_limit_raw and test_limit_raw.strip().isdigit() else None

logger.info(f"Environment: {run_mode} | Catalog: {catalog_name}")
logger.info(f"Source: {SOURCE_TABLE}")
logger.info(f"Target: {TARGET_TABLE}")
logger.info(f"Status: {DOWNLOAD_STATUS_TABLE}")
logger.info(f"Volume: {VOLUME_PATH}")
logger.info(f"Download: {DOWNLOAD_WORKERS} workers | Timeout: ({CONNECT_TIMEOUT}s connect, {READ_TIMEOUT}s read) | Max retries: {MAX_RETRIES}")
logger.info(f"Parse: batch_size={PARSE_BATCH_SIZE} | repartition={REPARTITION_FACTOR} | enabled={AI_PARSE_ENABLED}")
logger.info(f"Full refresh: {FULL_REFRESH}")
logger.info(f"Test limit: {TEST_LIMIT if TEST_LIMIT else 'None (full run)'}")

if FULL_REFRESH:
    logger.warning("=" * 70)
    logger.warning("⚠️  FULL_REFRESH MODE ENABLED")
    logger.warning("=" * 70)
    logger.warning("This will DELETE all downloaded files and reset pipeline state:")
    logger.warning(f"  - Dropping table: {DOWNLOAD_STATUS_TABLE}")
    logger.warning(f"  - Dropping table: {TARGET_TABLE}")
    logger.warning(f"  - Clearing volume: {VOLUME_PATH}")
    logger.warning("=" * 70)

    spark.sql(f"DROP TABLE IF EXISTS `{DOWNLOAD_STATUS_TABLE}`")
    spark.sql(f"DROP TABLE IF EXISTS `{TARGET_TABLE}`")
    dbutils.fs.rm(VOLUME_PATH, recurse=True)
    dbutils.fs.mkdirs(VOLUME_PATH)
    logger.info("Reset complete. Starting fresh.")


# --- Step 1: Read URLs from source table ---
url_df = spark.table(SOURCE_TABLE).select(
    col(ID_COLUMN).alias("item_id"),
    col(URL_COLUMN).alias("product_doc_url")
).filter(col(URL_COLUMN).isNotNull()).distinct()

if TEST_LIMIT:
    url_df = url_df.limit(TEST_LIMIT)

# Clean and normalize URLs
url_df = url_df.withColumn("corrected_url",
    regexp_replace(
        regexp_replace(
            regexp_replace(trim(col("product_doc_url")), r"\s+target=.*$", ""),
            r"^(https?):/(?!/)", "$1://"
        ),
        r"[\s/]+$", ""
    )
)

# Generate unique filenames
window_spec = Window.partitionBy("item_id").orderBy("corrected_url")
url_df = url_df.withColumn("url_index", row_number().over(window_spec))
url_df = url_df.withColumn("url_count", count("item_id").over(Window.partitionBy("item_id")))
url_df = url_df.withColumn("file_name",
    when(col("url_count") > 1, concat(col("item_id"), lit("_"), col("url_index"), lit(".pdf")))
    .otherwise(concat(col("item_id"), lit(".pdf")))
)

# Classify URL types
url_df = url_df.withColumn("url_type",
    when(col("corrected_url").isNull() | (col("corrected_url") == ""), "nourl")
    .when(col("corrected_url").contains(","), "multi_url")
    .when(lower(col("corrected_url")).endswith(".pdf"), "pdfurl")
    .when(lower(col("corrected_url")).contains("youtube") | lower(col("corrected_url")).contains("vimeo"), "video")
    .when(lower(col("corrected_url")).contains("/image/"), "imageurl")
    .otherwise("other")
)

total_links = url_df.count()
logger.info(f"Processing {total_links} URLs")
url_df.groupBy("url_type").count().show()

# Add batch ID for tracking
url_df = url_df.withColumn("batch_id", (monotonically_increasing_id() / DOWNLOAD_WORKERS).cast("int"))
url_df.select("item_id", "corrected_url", "url_type", "file_name").show(truncate=False)


# --- Step 2: Download Phase (driver-side, parallel via ThreadPoolExecutor) ---
logger.info("\n--- DOWNLOAD PHASE (driver-side, threaded) ---")

download_candidates = url_df.filter(col("url_type").isin("pdfurl", "imageurl")) \
    .select("item_id", "corrected_url", "url_type", "file_name", "batch_id") \
    .collect()

skipped_df = url_df.filter(~col("url_type").isin("pdfurl", "imageurl")) \
    .select("item_id", "corrected_url", "url_type", "file_name", "batch_id")

logger.info(f"Downloadable URLs: {len(download_candidates)}")
logger.info(f"Skipped (non-PDF/image): {skipped_df.count()}")

# Skip already-downloaded
if spark.catalog.tableExists(DOWNLOAD_STATUS_TABLE):
    existing = spark.table(DOWNLOAD_STATUS_TABLE).filter(
        col("download_status") == "Success"
    ).select("item_id", "corrected_url").collect()
    existing_set = {(r.item_id, r.corrected_url) for r in existing}
    download_candidates = [r for r in download_candidates if (r.item_id, r.corrected_url) not in existing_set]
    logger.info(f"After skipping already-downloaded: {len(download_candidates)} remaining")


def download_single(row, max_retries=MAX_RETRIES):
    """
    Download a single file to the Volume with retry logic.

    Features:
    - Exponential backoff on network failures
    - Atomic write: download to .tmp first, then rename
    - Size validation against Content-Length header
    - Tuple timeout: (connect, read) for fail-fast + slow-CDN tolerance
    """
    item_id = row.item_id
    url = row.corrected_url
    file_name = row.file_name
    dest_dir = f"{VOLUME_PATH}{item_id}"
    dest_path = f"{dest_dir}/{file_name}"
    temp_path = f"{dest_path}.tmp"

    # Skip if file already exists with content
    if os.path.isfile(dest_path):
        try:
            file_size = os.path.getsize(dest_path)
            if file_size > 0:
                logger.debug(f"[{item_id}] File already exists ({file_size} bytes)")
                return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                        "Success", dest_path, None)
            else:
                os.remove(dest_path)
                logger.warning(f"[{item_id}] Found empty file, re-downloading")
        except OSError:
            logger.warning(f"[{item_id}] Error checking existing file")

    for attempt in range(1, max_retries + 1):
        try:
            os.makedirs(dest_dir, exist_ok=True)

            logger.debug(f"[{item_id}] Attempt {attempt}/{max_retries}: GET {url[:60]}...")
            resp = http_requests.get(url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), stream=True)
            resp.raise_for_status()

            expected_size = resp.headers.get('Content-Length')
            if expected_size:
                try:
                    expected_size = int(expected_size)
                except (ValueError, TypeError):
                    expected_size = None

            downloaded_size = 0
            with open(temp_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)

            if expected_size and downloaded_size != expected_size:
                logger.warning(f"[{item_id}] Incomplete: {downloaded_size}/{expected_size} bytes")
                os.remove(temp_path)

                if attempt < max_retries:
                    backoff = 2 ** attempt
                    logger.info(f"[{item_id}] Retrying in {backoff}s ({attempt}/{max_retries})")
                    time.sleep(backoff)
                    continue
                else:
                    return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                            "Failed", None, f"Incomplete: {downloaded_size}/{expected_size} bytes")

            os.rename(temp_path, dest_path)
            logger.info(f"[{item_id}] Downloaded {downloaded_size} bytes ({attempt} attempt(s))")
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Success", dest_path, None)

        except Timeout:
            logger.warning(f"[{item_id}] Timeout on attempt {attempt}/{max_retries}")
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            if attempt < max_retries:
                time.sleep(2 ** attempt)
                continue
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Failed", None, f"Timeout after {max_retries} retries")

        except ConnectionError as e:
            logger.warning(f"[{item_id}] Connection error {attempt}/{max_retries}: {e}")
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            if attempt < max_retries:
                time.sleep(2 ** attempt)
                continue
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Failed", None, f"Connection failed after {max_retries} retries")

        except RequestException as e:
            logger.error(f"[{item_id}] HTTP error: {e}")
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Failed", None, f"HTTP error: {str(e)[:100]}")

        except OSError as e:
            logger.error(f"[{item_id}] I/O error: {e}")
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Failed", None, f"I/O error: {str(e)[:100]}")

        except Exception as e:
            logger.error(f"[{item_id}] Unexpected error: {type(e).__name__}: {e}")
            if os.path.exists(temp_path):
                try: os.remove(temp_path)
                except OSError: pass
            return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
                    "Failed", None, f"Unexpected error: {type(e).__name__}")

    return (item_id, url, row.url_type, row.file_name, str(row.batch_id),
            "Failed", None, "Unknown error")


# Parallel download via ThreadPoolExecutor
results = []
if download_candidates:
    download_start = time.time()
    logger.info(f"Downloading {len(download_candidates)} files with {DOWNLOAD_WORKERS} workers...")

    with ThreadPoolExecutor(max_workers=DOWNLOAD_WORKERS) as pool:
        futures = {pool.submit(download_single, row): row for row in download_candidates}
        for i, fut in enumerate(as_completed(futures), 1):
            results.append(fut.result())
            if i % 100 == 0 or i == len(download_candidates):
                logger.info(f"  Progress: {i}/{len(download_candidates)}")

    elapsed = time.time() - download_start
    success_count = sum(1 for r in results if r[5] == "Success")
    failed_count = sum(1 for r in results if r[5] == "Failed")
    logger.info(f"\nDownloaded {success_count} files, {failed_count} failed ({elapsed:.1f}s)")

    failures = [r for r in results if r[5] == "Failed"]
    for f in failures[:5]:
        logger.warning(f"  FAILED: {f[0]} → {f[7]}")

# Save download status
status_schema = StructType([
    StructField("item_id", StringType()),
    StructField("corrected_url", StringType()),
    StructField("url_type", StringType()),
    StructField("file_name", StringType()),
    StructField("batch_id", StringType()),
    StructField("download_status", StringType()),
    StructField("file_path", StringType()),
    StructField("error_message", StringType()),
])

validate_before_write(spark, DOWNLOAD_STATUS_TABLE, status_schema)

if results:
    status_df = spark.createDataFrame(results, schema=status_schema)
    status_df.write.format("delta").mode("append").saveAsTable(DOWNLOAD_STATUS_TABLE)

skipped_status = skipped_df.withColumn("download_status", lit("Skipped")) \
    .withColumn("file_path", lit(None).cast("string")) \
    .withColumn("error_message", lit(None).cast("string")) \
    .select("item_id", "corrected_url", "url_type", "file_name",
            col("batch_id").cast("string"), "download_status", "file_path", "error_message")
skipped_status.write.format("delta").mode("append").saveAsTable(DOWNLOAD_STATUS_TABLE)

logger.info("\nDownload Report:")
spark.table(DOWNLOAD_STATUS_TABLE).groupBy("download_status").count().show()


# --- Step 3: Parse Phase ---
logger.info("\n--- PARSE PHASE ---")

if not spark.catalog.tableExists(DOWNLOAD_STATUS_TABLE):
    logger.info("No downloads found. Nothing to parse.")
elif not AI_PARSE_ENABLED:
    logger.warning("⚠️  SKIPPING PARSE PHASE: ai_parse_enabled=false in config")
    logger.warning(f"  Downloaded files preserved in {VOLUME_PATH}")
else:
    ai_parse_available = check_ai_parse_document_availability(spark)

    if not ai_parse_available:
        logger.warning("⚠️  SKIPPING PARSE PHASE: ai_parse_document not available on cluster")
        logger.warning(f"  Downloaded files preserved in {VOLUME_PATH}")
    else:
        downloaded_df = spark.table(DOWNLOAD_STATUS_TABLE).filter(col("download_status") == "Success")

        if spark.catalog.tableExists(TARGET_TABLE):
            processed_df = spark.table(TARGET_TABLE).select(
                col("item_id"), col("url").alias("corrected_url")
            )
            pending_df = downloaded_df.join(processed_df, ["item_id", "corrected_url"], "left_anti")
        else:
            pending_df = downloaded_df

        pending_count = pending_df.count()
        logger.info(f"Found {pending_count} items to parse")

        if pending_count == 0:
            logger.info("Nothing to parse. Done!")
        else:
            # Read PDFs from volume via binaryFile reader
            logger.info("Reading downloaded files from volume...")
            binary_df = spark.read.format("binaryFile") \
                .option("pathGlobFilter", "*.pdf") \
                .option("recursiveFileLookup", "true") \
                .load(VOLUME_PATH)

            # Extract item_id and file_name from path
            binary_df = binary_df.withColumn(
                "extracted_item_id",
                regexp_extract(col("path"), r"/documents/([^/]+)/", 1)
            ).withColumn(
                "extracted_file_name",
                regexp_extract(col("path"), r"/([^/]+\.pdf)$", 1)
            )

            parse_df = pending_df.join(
                binary_df.select(
                    col("extracted_item_id").alias("item_id"),
                    col("extracted_file_name").alias("file_name"),
                    col("content").alias("file_content"),
                    col("path").alias("volume_path")
                ),
                ["item_id", "file_name"],
                "inner"
            )

            actual_parse_count = parse_df.count()
            logger.info(f"Matched {actual_parse_count} files for parsing")

            if actual_parse_count == 0:
                logger.warning("No files matched for parsing. Check volume contents.")
            else:
                # Deterministic batching (handles retries correctly)
                parse_df_numbered = parse_df.withColumn(
                    "row_num", row_number().over(Window.orderBy("item_id"))
                )

                total_batches = (actual_parse_count + PARSE_BATCH_SIZE - 1) // PARSE_BATCH_SIZE
                processed_count = 0

                for batch_number in range(total_batches):
                    batch_start = time.time()
                    batch_min = batch_number * PARSE_BATCH_SIZE + 1
                    batch_max = (batch_number + 1) * PARSE_BATCH_SIZE

                    # repartition gives ai_parse_document parallel executors per batch
                    batch_df = (parse_df_numbered
                        .filter((col("row_num") >= batch_min) & (col("row_num") <= batch_max))
                        .drop("row_num")
                        .repartition(REPARTITION_FACTOR))

                    item_count = batch_df.count()
                    if item_count == 0:
                        logger.warning(f"Batch {batch_number+1}: 0 rows. Skipping.")
                        continue

                    logger.info(f"[Batch {batch_number+1}/{total_batches}] Parsing {item_count} items (row_num {batch_min}-{batch_max})...")

                    try:
                        parsed_batch = (batch_df
                            .withColumn("parsed_data",
                                when(col("file_content").isNotNull(),
                                     expr("ai_parse_document(file_content)"))
                                .otherwise(None))
                            .withColumn("html_content", expr("""
                                concat_ws('\\n\\n',
                                    transform(
                                        try_cast(parsed_data:document:elements AS ARRAY<VARIANT>),
                                        element -> try_cast(element:content AS STRING)
                                    )
                                )
                            """))
                            .withColumn("processed_at", current_timestamp())
                            .select(
                                col("item_id"),
                                col("corrected_url").alias("url"),
                                col("html_content").cast("string").alias("html_content"),
                                "parsed_data", "url_type", "processed_at", "batch_id",
                                col("volume_path").alias("file_path"),
                                "download_status", "error_message"
                            ))

                        # Per batch; after the first it is one metadata read.
                        validate_before_write(spark, TARGET_TABLE, parsed_batch.schema)
                        (parsed_batch.write.format("delta")
                            .mode("append")
                            .option("mergeSchema", "true")
                            .saveAsTable(TARGET_TABLE))

                        processed_count += item_count
                        batch_elapsed = time.time() - batch_start
                        logger.info(f"  Batch {batch_number+1} complete: {item_count} items in {batch_elapsed:.1f}s")

                    except Exception as e:
                        logger.error(f"Batch {batch_number+1} failed: {e}")
                        logger.error(f"  Rows {batch_min}-{batch_max} will be retried via left_anti join")
                        raise

                logger.info(f"\nPipeline complete! Parsed {processed_count} documents")
                logger.info(f"Results in {TARGET_TABLE}")
                spark.table(TARGET_TABLE).select("item_id", "url", "url_type").limit(10).show(truncate=False)