"""
prompt_store.py - the one place prompt TEXT is read from.

Every prompt this pipeline sends to an LLM lives as text in ``config/prompts/*.yaml``.
Python keeps only the *assembly*: SQL building and escaping, truncation, empty-field
markers and the numeric contracts the replies are parsed against. To change what a model
is told, edit the YAML; to change how it is stitched together, edit the module.

    config/prompts/issue_tagging.yaml   review issue extraction + conflict pass
    config/prompts/faq_tagging.yaml     FAQ question + answer tagging
    config/prompts/product_tagging.yaml class profiling + per-product tagging

Failure is loud and early. A missing file, a missing key or blank text raises
``PromptConfigError`` at import of the consuming module, i.e. when the job starts - not
halfway through a 200k-row run with a weaker prompt. ``check_placeholders`` does the same
for ``str.format`` templates: a dropped or misspelt ``{placeholder}`` fails at import.

Usage:
    import prompt_store

    P = prompt_store.load("faq_tagging")             # whole file, cached
    text = prompt_store.get("issue_tagging", "tagging", "system_instruction")
    prompt_store.check_placeholders(P["rules_template"], {"keyword_min_words",
                                    "keyword_max_words"}, "faq_tagging.rules_template")

    python src/data_pipeline/prompts/prompt_store.py   # list every prompt, version, fingerprint

This file lives alone in src/data_pipeline/prompts/ so that directory can go on sys.path without
shadowing the flat-imported ``utils`` modules (src/data_pipeline/utils.py vs enrichment/utils.py).

Directory resolution, in order:
    1. $PROMPTS_CONFIG_DIR
    2. <project root>/config/prompts
"""

from __future__ import annotations

import hashlib
import os
import string
import sys
from functools import lru_cache
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

import yaml

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
    _PROJECT_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
except NameError:  # Databricks notebooks/jobs without __file__
    _HERE = os.getcwd()
    _PROJECT_ROOT = _HERE if os.path.exists(os.path.join(_HERE, "config")) else os.path.abspath(
        os.path.join(_HERE, "..", "..", ".."))

PROMPTS_DIR_ENV_VAR = "PROMPTS_CONFIG_DIR"


class PromptConfigError(RuntimeError):
    """Raised when a prompt file is missing, unparseable, or has blank/absent text."""


def prompts_dir() -> str:
    return os.environ.get(PROMPTS_DIR_ENV_VAR) or os.path.join(_PROJECT_ROOT, "config", "prompts")


def _walk_strings(node: Any, path: str = "") -> Iterator[Tuple[str, str]]:
    if isinstance(node, dict):
        for key, value in node.items():
            yield from _walk_strings(value, f"{path}.{key}" if path else str(key))
    elif isinstance(node, str):
        yield path, node


@lru_cache(maxsize=None)
def load(name: str) -> Dict[str, Any]:
    """Parse and validate ``<prompts_dir>/<name>.yaml``. Cached; callers must not mutate it."""
    path = os.path.join(prompts_dir(), f"{name}.yaml")
    if not os.path.exists(path):
        raise PromptConfigError(
            f"prompt file not found: {path}. Every prompt lives in config/prompts/; set "
            f"${PROMPTS_DIR_ENV_VAR} if the directory has moved."
        )
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except yaml.YAMLError as e:
        raise PromptConfigError(f"{path}: not valid YAML: {e}") from e
    if not isinstance(data, dict):
        raise PromptConfigError(f"{path}: top level must be a mapping")
    for key_path, text in _walk_strings(data):
        if not text.strip():
            raise PromptConfigError(f"{name}.{key_path}: prompt text must not be blank")
    return data


def get(name: str, *keys: str) -> Any:
    """``get("issue_tagging", "tagging", "version")`` - a value by key path, or a clear error."""
    node: Any = load(name)
    walked: List[str] = []
    for key in keys:
        walked.append(key)
        if not isinstance(node, dict) or key not in node:
            raise PromptConfigError(f"{name}.yaml has no key '{'.'.join(walked)}'")
        node = node[key]
    return node


def placeholders(template: str) -> set:
    """The set of ``{named}`` fields a ``str.format`` template uses."""
    return {field for _, field, _, _ in string.Formatter().parse(template) if field}


def check_placeholders(template: str, expected: Iterable[str], label: str) -> str:
    """
    Fail unless ``template`` uses exactly the ``expected`` placeholders; returns it unchanged.

    A dropped placeholder silently removes a bound from the prompt; an extra or misspelt one
    raises KeyError on the first render. Either way it should be caught at start-up.
    """
    expected = set(expected)
    found = placeholders(template)
    if found != expected:
        missing, extra = sorted(expected - found), sorted(found - expected)
        raise PromptConfigError(
            f"{label}: placeholders differ from what the code fills in "
            f"(missing: {missing or 'none'}, unexpected: {extra or 'none'})"
        )
    return template


def fingerprint(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:10]


def catalog() -> List[Dict[str, str]]:
    """One row per prompt text: file, key path, fingerprint, size. For review and audit."""
    rows: List[Dict[str, str]] = []
    base = prompts_dir()
    for fn in sorted(os.listdir(base)):
        if not fn.endswith(".yaml"):
            continue
        name = fn[:-5]
        data = load(name)
        for key_path, text in _walk_strings(data):
            rows.append({"file": name, "key": key_path, "sha": fingerprint(text),
                         "chars": str(len(text))})
    return rows


def versions() -> Dict[str, str]:
    """``{"file": "v1", "issue_tagging.tagging": "v3", ...}`` - every ``version`` key found."""
    out: Dict[str, str] = {}

    def walk(node: Any, path: str) -> None:
        if not isinstance(node, dict):
            return
        if "version" in node:
            out[path] = str(node["version"])
        for key, value in node.items():
            walk(value, f"{path}.{key}")

    for fn in sorted(os.listdir(prompts_dir())):
        if fn.endswith(".yaml"):
            walk(load(fn[:-5]), fn[:-5])
    return out


def main(argv: Optional[List[str]] = None) -> int:
    rows = catalog()
    width = max(len(f"{r['file']}.{r['key']}") for r in rows)
    print(f"prompts dir: {prompts_dir()}")
    for r in rows:
        print(f"  {r['file'] + '.' + r['key']:<{width}}  {r['sha']}  {r['chars']:>6} chars")
    print("\nversions:")
    for k, v in versions().items():
        print(f"  {k} = {v}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
