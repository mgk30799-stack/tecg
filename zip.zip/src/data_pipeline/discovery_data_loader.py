"""
Unity Catalog Data Loader - Step 1: Raw Data Extraction

This module provides utilities for loading data from Databricks Unity Catalog
using Databricks Connect. This is the first step in the data enrichment pipeline that
feeds into the knowledge graph construction.
Need to config spark in the databricks cluster: spark.jars.packages mysql:mysql-connector-java:8.0.33

Pipeline Stage: Raw Data Extraction
Input: Unity Catalog tables (Snowflake EDH)
Output: PySpark DataFrames with product data
"""
# Windows compatibility fix - must be before databricks imports
import sys
if sys.platform == 'win32':
    import socketserver
    if not hasattr(socketserver, 'UnixStreamServer'):
        class UnixStreamServer:
            def __init__(self, *args, **kwargs):
                raise NotImplementedError("UnixStreamServer not available on Windows")
        socketserver.UnixStreamServer = UnixStreamServer
        socketserver.UnixDatagramServer = UnixStreamServer

import os
from typing import Dict, List, Optional
from databricks.connect import DatabricksSession
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
import yaml

from enrichment.utils import (
    ENVS, read_config, get_run_mode, CATALOG, ALL_BU_PRODUCT_COLUMNS, ALL_BU_DOTCOM_ONLY_COLUMNS,
    ALL_BU_DOTCOM_COLUMNS, ALL_BU_HIERARCHY_LEVELS, dotcom_names_in_all_bu,
)

# ---------------------------------------------------------------------------
# All-BU product list: product_discovery_data_all
# ---------------------------------------------------------------------------
# The product list for every site: the Staples.com products of load_product_master plus every
# product live on Staples Business. It is built first; product_discovery_data is then written as
# its Staples.com slice under the old column names, so existing readers see no change and can
# move to the all-BU table one at a time.
# Its column lists live in enrichment/utils.py, shared with the tasks that read the table.

# Staples Business is the "contract" channel in the source data: its live flags, price, URL,
# hierarchy (STAPLESADVANTAGE) and review site all carry that name.
CONTRACT_SITE_ID = "STAPLESADVANTAGE"
LIVE_DOTCOM = "(s.intent_to_sell_dotcom_ind = 'Y' AND s.web_live_on_dotcom_ind = 'Y')"
LIVE_CONTRACT = "(s.intent_to_sell_contract_ind = 'Y' AND s.web_live_on_contract_ind = 'Y')"

ALL_BU_TABLE_COMMENT = (
    "Product list for every site: the Staples.com products (in_product_discovery_data) plus every "
    "product live on Staples Business (the contract channel in the source data). Columns that "
    "differ by site end in _dotcom or _contract. product_discovery_data is written daily as the "
    "Staples.com slice of this table, under its old column names.")


def all_bu_column_comments(columns: List[str]) -> Dict[str, str]:
    """Column descriptions for the all-BU table (only for columns it has)."""
    notes = {
        "in_product_discovery_data": "True for the Staples.com products of product_discovery_data; "
                                     "their columns hold exactly the values in that table",
        "is_live_dotcom": "Live on Staples.com: intent to sell and live",
        "is_live_contract": "Live on Staples Business (the contract channel): intent to sell and live",
        "review_count": "Reviews with text, all sites",
        "star_rating": "Average rating of reviews with text, all sites",
    }
    for src, dst in ALL_BU_DOTCOM_COLUMNS.items():
        notes[dst] = "Staples.com: {} in product_discovery_data".format(src)
    for level in ALL_BU_HIERARCHY_LEVELS:
        notes["web_{}_dotcom".format(level)] = "Staples.com category (STAPLESDOTCOM hierarchy)"
        notes["web_{}_contract".format(level)] = "Staples Business category (STAPLESADVANTAGE hierarchy)"
    for column in ALL_BU_DOTCOM_ONLY_COLUMNS:
        notes[column] = "Staples.com only, from product_discovery_data; empty for Staples Business only products"
    for measure in ("length", "width", "height", "weight"):
        notes["sell_unit_" + measure] = "Package (sell unit) {}, from product_master.sell_unit_{}_amt".format(measure, measure)
    notes["sell_unit_dimensions"] = "Package (sell unit) length x width x height"
    for column in columns:
        if column.endswith("_contract") and column not in notes:
            notes[column] = "Staples Business (the contract channel)"
    return {c: t for c, t in notes.items() if c in columns}


class UnityCatalogLoader:
    """Loader for accessing Unity Catalog tables via Databricks Connect."""
    
    def __init__(self, spark: Optional[DatabricksSession] = None):
        """
        Initialize Unity Catalog Loader.
        
        Args:
            spark: Existing DatabricksSession. If None, will create a new session.
        """
        self.spark = spark or self._create_spark_session()
        run_mode = get_run_mode()
        catalog_name = CATALOG[run_mode]
    
        # Load general configuration to get output table name
        try:
            CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
            PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
        except NameError:
            CURRENT_DIR = os.getcwd()
            if os.path.exists(os.path.join(CURRENT_DIR, "config")):
              PROJECT_ROOT = CURRENT_DIR
            else:
              PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
    
        GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
        _general_config = read_config(GENERAL_CONFIG_PATH)
        self.config = _general_config
        # Get output table from config (with {env} placeholder replaced)
        default_output_table_full = self.config["product_discovery_data"]["tables"]["output_table"]
        # Extract just the table name from full path (e.g., "product_discovery_data_dev")
        default_table_name = default_output_table_full.split('.')[-1]

        
        # Parse from config's fully qualified table name
        output_fqn =self.config['product_discovery_data']['tables']['output_table']
        parts = output_fqn.split('.')
        self.output_catalog = parts[0]  # mld01_ml_{env}
        self.output_schema = parts[1]   # product
        self.output_table = parts[2]    # product_discovery_data
        self.all_bu_output_table = self.config['product_discovery_data']['tables'].get('all_bu_output_table')
        self._all_bu_source = None


    # def _create_spark_session(self) -> DatabricksSession:
    #     """Create a Databricks session using Databricks Connect."""
    #     databricks_host = os.getenv('DATABRICKS_HOST', '').rstrip('/')
    #     databricks_token = os.getenv('DATABRICKS_TOKEN', '')
    #     cluster_id = os.getenv('DATABRICKS_CLUSTER_ID', '')
        
        
    #     if not databricks_host or not databricks_token:
    #         raise ValueError("DATABRICKS_HOST and DATABRICKS_TOKEN must be set")
        
    #     # Use DatabricksSession for Databricks Connect
    #     spark = (DatabricksSession.builder
    #             .remote(
    #                 host=databricks_host,
    #                 token=databricks_token,
    #                 cluster_id=cluster_id if cluster_id else None
    #             )
    #             .getOrCreate())
        
    #     return spark

    @property
    def catalog_name(self):
        return CATALOG[get_run_mode()]
    
    def _create_spark_session(self) -> DatabricksSession:
        """
        Dynamically create a Spark session.
        - Uses native Spark context if running on a Databricks cluster (e.g., Job).
        - Uses Databricks Connect with .env credentials if running locally.
        """
        # Databricks clusters always have this environment variable defined
        if os.getenv("DATABRICKS_RUNTIME_VERSION"):
            print("Running on Databricks cluster. Using native Spark session.")
            return DatabricksSession.builder.getOrCreate()
        else:
            print("Running locally. Using Databricks Connect.")
            from dotenv import load_dotenv
            load_dotenv()
            
            databricks_host = os.getenv('DATABRICKS_HOST', '').rstrip('/')
            databricks_token = os.getenv('DATABRICKS_TOKEN', '')
            cluster_id = os.getenv('DATABRICKS_CLUSTER_ID', '')
            
            if not databricks_host or not databricks_token:
                raise ValueError("DATABRICKS_HOST and DATABRICKS_TOKEN must be set in .env for local development.")

            spark = (DatabricksSession.builder
                .remote(host=databricks_host, token=databricks_token, cluster_id=cluster_id if cluster_id else None)
                .getOrCreate())
            return spark
        
    def load_product_master(
        self,
        departments: Optional[list] = None,
        classes: Optional[list] = None,
        web_live_only: bool = True,
        limit: Optional[int] = None
    ) -> DataFrame:
        """
        Load comprehensive product discovery data from Unity Catalog.

        This query provides rich product information for AI-powered product discovery:
        - Core product attributes (SKU, name, description, brand, category)
        - Product identifiers (UPC, EAN, GTIN, MPN) with automatic derivation
        - Physical dimensions and weight
        - Images and media URLs
        - Price and availability
        - Inventory status from multiple warehouses
        - Customer reviews (aggregated and detailed)
        - Product Q&A
        - Related products (customers bought together)
        - Variant/group information
        - Fulfillment and seller information
        - Return policies (mapped from return_rules_highlighted)
        - Support channel information (chat, email, phone with availability)

        Identifier Derivation Logic:
        - EAN-13: UPC-12 with '0' prefix (e.g., 718103448055 → 0718103448055)
        - GTIN-14: UPC-12 with '00' prefix (e.g., 718103448055 → 00718103448055)
        - MPN: Manufacturer Part Number from MODEL_DELIVERY_NUM

        Support Channel Schema:
        - support_channel_json: Array of support channels with:
          - channel: "Chat with a Staples Expert" | "Email a Staples Expert" | "Call a Staples Expert"
          - availability: Array of {days, hours} for channel operating hours
          - details: {email, phone} contact information

        Args:
            departments: List of department IDs to filter.
                        Defaults to ['10', '24', '32', '43', '50', '51', '52', '53', '55', '59', '68', '84', '98']
            classes: List of class IDs to filter. Defaults to ['545','745']
            web_live_only: Only include products live on dotcom
            intent_to_sell_dotcom_ind: Only include products with intent to sell on dotcom
            limit: Maximum number of rows to return. None for all rows.

        Returns:
            PySpark DataFrame with comprehensive product discovery data optimized
            for AI search and recommendation systems.
        """

        #catalog_name = CATALOG[get_run_mode()]
        # Comprehensive product discovery query
        print("preparing query")
        query = f"""
        WITH sku_src AS (
            SELECT
                pm.sku_num,
                pm.product_id,
                pm.product_key,
                pm.UPC_DELIVERY_CD AS upc,
                pm.hierarchy_web_dotcom_product_hierarchy_key,
                pm.MODEL_DELIVERY_NUM,
                pm.MODEL_EDI_NUM,
                pm.MODEL_RETAIL_NUM,
                ph.class_id as corp_class_id,
                ph.class_nm as corp_class_nm,
                ph.department_id as corp_department_id,
                ph.department_nm as corp_department_nm,
                ph.division_id as corp_division_id,
                ph.division_nm as corp_division_nm,
                attr.super_category_nm AS SUPERCATEGORY,
                pm.brand_nm AS BRAND,
                pm.OWN_BRAND_IND,
                pm.MANUFACTURER_NM AS MANUFACTURER,
                pm.PRODUCT_WEB_DSCR,
                pm.PRODUCT_SHORT_DSCR,
                pm.PRODUCT_AS400_DELIVERY_DSCR,
                -- Physical dimensions
                pm.sell_unit_height_amt as height,
                pm.sell_unit_length_amt as length,
                pm.sell_unit_weight_amt as weight,
                pm.sell_unit_width_amt as width,
                pm.PRICE_REGULAR_AMT,
                -- Images
                pm.image_url,
                pm.IMAGE_SECONDARY_1_URL,
                pm.IMAGE_SECONDARY_2_URL,
                pm.IMAGE_SECONDARY_3_URL,
                pm.IMAGE_SECONDARY_4_URL,
                pm.IMAGE_SECONDARY_5_URL,
                pm.IMAGE_SECONDARY_6_URL,
                pm.IMAGE_SECONDARY_7_URL,
                pm.IMAGE_SECONDARY_8_URL,
                -- URLs and inventory
                pm.web_dotcom_url,
                -- channel indicators
                --- pm.WEB_LIVE_ON_DOTCOM_IND,
                --- pm.intent_to_sell_dotcom_ind,
                -- Variant
                pm.skuset_dotcom_id,
                pm.VIRTUAL_PARENT_DOTCOM_CD,
                -- Lifecycle dates
                pm.WEB_FIRST_ON_DOTCOM_DT,
                pm.PRODUCT_CREATE_DT,
                -- Buy online pickup in store(Y/U)
                pm.BOPIS_ELIGIBLE_IND,
                -- eco features
                pm.ECO_FEATURE_IND,
                pm.ECO_ENERGY_STAR_CERTIFIED_IND,
                pm.ECO_RECYCLED_IND,
                -- fulfillment flags
                pm.DROPSHIP_DOTCOM_IND,
                pm.SHIP_FROM_STORE_IND,
                pm.AUTO_RESTOCK_IND,
                -- Headliner statement
                pm.web_headliner_statement_txt,
                ph2.class_id as web_class_id,
                ph2.class_nm as web_class_nm,
                ph2.department_id as web_department_id,
                ph2.department_nm as web_department_nm,
                ph2.category_id as web_category_id,
                ph2.category_nm as web_category_nm,
                ph2.supercategory_id as web_supercategory_id,
                ph2.supercategory_nm as web_supercategory_nm
            FROM snowflake_edh.product.product_master pm
            LEFT JOIN snowflake_edh.product.product_hierarchy ph
                ON pm.hierarchy_corp_product_hierarchy_key = ph.product_hierarchy_key AND ph.hierarchy_source_cd = 'MERCH'
            LEFT JOIN snowflake_edh.PRODUCT.PRODUCT_CLASS_ATTRIBUTES attr
                ON pm.hierarchy_corp_product_hierarchy_key = attr.PRODUCT_HIERARCHY_KEY
            JOIN snowflake_edh.product.product_hierarchy ph2
            	ON pm.hierarchy_web_dotcom_product_hierarchy_key = ph2.product_hierarchy_key AND ph2.hierarchy_source_cd = 'STAPLESDOTCOM'
            WHERE  pm.intent_to_sell_dotcom_ind = 'Y'
            AND  pm.web_live_on_dotcom_ind = 'Y'),
        web_spec AS(
            SELECT 
            product_id,
            COLLECT_LIST(bullet_txt) as bullets_json
            FROM snowflake_edh.product.product_web_bullets
            WHERE row_status_cd='ACTIVE'
            GROUP BY product_id),
        att AS (
            SELECT
                product_id,
                SORT_ARRAY(
                    COLLECT_LIST(
                        STRUCT(
                            attribute_group_nm,
                            attribute_nm,
                            attribute_value_txt
                        )
                    )
                ) AS spec_json,
            max(row_update_tms) as specs_last_updated_at
            FROM snowflake_edh.Product.PRODUCT_SPECIFICATIONS
            WHERE row_status_cd='ACTIVE'
            GROUP BY product_id),
        filtered_reviews_dotcom AS (
            SELECT
                product_id,
                review_title_txt,
                review_detail_txt,
                review_rating_rt,
                REVIEW_CREATE_DT,
                ROW_NUMBER() OVER (
                    PARTITION BY product_id
                    -- WEB_REVIEW_ID breaks same-day ties, so every run picks the same 50
                    ORDER BY REVIEW_CREATE_DT DESC, WEB_REVIEW_ID DESC
                ) AS rn
            FROM snowflake_edh.product.PRODUCT_WEB_REVIEW
            WHERE site_id = 'STAPLESUS'
                AND review_detail_txt IS NOT NULL
                AND LENGTH(TRIM(review_detail_txt)) >= 10
        ),
        -- only pick up the top 50 most recent reviews per product to avoid hitting payload limits for downstream LLM applications
        review_agg_dotcom AS (
            SELECT
                product_id,
                COLLECT_LIST(
                    NAMED_STRUCT(
                        'title', review_title_txt,
                        'content', review_detail_txt,
                        'minRating', 1,
                        'maxRating', 5,
                        'rating', review_rating_rt
                    )
                ) AS reviews
            FROM filtered_reviews_dotcom
            WHERE rn <= 50
            GROUP BY product_id
        ),
        -- product master has the avg rating, and count, can we use them directly
        review_all AS (
            SELECT
                product_id,
                COUNT(DISTINCT(WEB_REVIEW_ID)) AS cnt,
                ROUND(AVG(review_rating_rt), 2) AS avg_review_rating
            FROM snowflake_edh.product.PRODUCT_WEB_REVIEW
            where REVIEW_DETAIL_TXT is not null
            GROUP BY product_id
        ),
        review_dotcomm AS (
            SELECT
                product_id,
                COUNT(*) AS cnt,
                ROUND(AVG(review_rating_rt), 2) AS avg_review_rating
            FROM snowflake_edh.product.PRODUCT_WEB_REVIEW
            WHERE site_id = 'STAPLESUS'
            GROUP BY product_id
        ),
        adobe_base AS (
             SELECT
                data_providers_v184,
                recommending_product_v16,
                sku_data_provider,
                products,
                SPLIT_PART(recommending_product_v16, '|',1) AS product_id,
                src_row_tms,
                -- Tag which relationship type each row belongs to
                CASE
                    WHEN data_providers_v184 iLIKE '%bought together%' THEN 'cbt'
                    WHEN data_providers_v184 iLIKE '%bought with%' THEN 'cbt'
                    WHEN data_providers_v184 iLIKE '%also bought%' THEN 'cbt'
                    WHEN data_providers_v184 iLIKE '%similar%' THEN 'similar'
                END AS rel_type
            FROM snowflake_cap.PRD_USD_OPV.ADOBE_WEB_FILTERED_IMPRESSIONS_DOTCOM_V
            JOIN sku_src on sku_src.product_id=SPLIT_PART(recommending_product_v16, '|',1)
            WHERE (data_providers_v184 iLIKE '%bought together%' 
                    OR data_providers_v184 iLIKE '%bought with%' 
                    OR data_providers_v184 iLIKE '%also bought%' 
                    OR data_providers_v184 iLIKE '%similar%' 
            )
            AND date(src_row_tms) >= (
                SELECT MAX(date(src_row_tms))-7
                FROM snowflake_cap.PRD_USD_OPV.ADOBE_WEB_FILTERED_IMPRESSIONS_DOTCOM_V
                WHERE data_providers_v184 iLIKE '%bought together%' 
                    OR data_providers_v184 iLIKE '%bought with%' 
                    OR data_providers_v184 iLIKE '%also bought%' 
                    OR data_providers_v184 iLIKE '%similar%' 
            ) 
            AND recommending_product_v16 IS NOT NULL
        ),
        cbt AS (
            SELECT DISTINCT
                products,
                product_id
                --src_row_tms
            FROM adobe_base
            WHERE rel_type = 'cbt'
            --ORDER BY src_row_tms desc
        ),
        cbt_agg AS (
            SELECT
                product_id,
                COLLECT_SET(products) AS related_product_id
                --MAX(src_row_tms)      AS cbt_last_updated_at
            FROM cbt
            WHERE products != product_id
            AND products IN (SELECT product_id FROM sku_src)  -- only valid IDs
            GROUP BY product_id
        ),
        similar_raw AS (
            SELECT DISTINCT
                product_id,
                products
                --src_row_tms
            FROM adobe_base
            WHERE rel_type = 'similar'
            AND product_id IS NOT NULL
            AND product_id != ''
            --ORDER BY src_row_tms desc
        ),
        similar_agg AS (
            SELECT
                product_id,
                COLLECT_SET(products) AS similar_item_ids -- unique ids
                --ARRAY_DISTINCT(COLLECT_LIST(similar_product_id)) AS similar_item_ids,
                --MAX(src_row_tms) AS similar_last_updated_at
            FROM similar_raw
            WHERE products != product_id   -- exclude self-references
            AND products IN (SELECT product_id FROM sku_src)  -- only valid IDs
            GROUP BY product_id
        ),
        answers_per_question AS (
            SELECT
                q.product_id,
                q.question_id,
                 nvl(q.question_details_txt,q.question_summary_txt) AS question,
                COLLECT_LIST(a.answer_txt) AS answers
            FROM snowflake_edh.product.product_web_question q
            LEFT JOIN snowflake_edh.product.product_web_answer a
                ON q.product_id = a.product_id
                AND q.question_id = a.question_id
            WHERE q.site_id = 'STAPLESUS'
            GROUP BY
                q.product_id,
                q.question_id,
                question
        ),
        f_a_q AS (
            SELECT
                product_id,
                COLLECT_LIST(
                    NAMED_STRUCT(
                        'q', question,
                        'a', answers
                    )
                ) AS q_and_a
            FROM answers_per_question
            GROUP BY product_id
        ),
        return_rules AS (
            SELECT
                subdepartment,
                class,
                FIRST(RETUNPOLICY) AS RETUNPOLICY
            FROM {self.catalog_name}.product.return_rules_highlighted
            GROUP BY subdepartment, class
        ),
        sales as(
               SELECT
                sls.order_product_id,
                SUM(CASE 
                        WHEN bill_date >= (CURRENT_DATE - INTERVAL '7' DAY) 
                        THEN sales_quantity 
                        ELSE 0 
                    END) AS sales_qty_7d,
                SUM(CASE 
                        WHEN bill_date >= (CURRENT_DATE - INTERVAL '30' DAY)
                        THEN sales_quantity 
                        ELSE 0 
                    END) AS sales_qty_30d,
                SUM(CASE 
                        WHEN bill_date >= (CURRENT_DATE - INTERVAL '90' DAY)
                        THEN sales_quantity 
                        ELSE 0 
                    END) AS sales_qty_90d,
                SUM(CASE 
                        WHEN bill_date >= (CURRENT_DATE - INTERVAL '30' DAY)
                        THEN sales_amt 
                        ELSE 0 
                    END) AS sales_amt_30d
                FROM snowflake_edh.finance.DOTCOM_HITOUCH_SALES_FACT_V sls,
                snowflake_edh.product.product_master pm
                WHERE pm.product_id=order_product_id
                AND BUSINESS_UNIT_CD IN ('52', '55')
                  AND invoice_type_cd = 'SHIPMENT'
                  AND pm.web_live_on_dotcom_ind = 'Y'
                  AND pm.intent_to_sell_dotcom_ind = 'Y'
                  AND sls.bill_date >= (CURRENT_DATE - INTERVAL '90' DAY)
                GROUP BY order_product_id
    ),
        review_summary_data AS (
    SELECT 
        rr.item_id,
        TRANSFORM(
            FLATTEN(COLLECT_LIST(rs.aspect_summaries)),
            x -> NAMED_STRUCT('aspect', x.aspect, 'aspect_summary', x.summary)
        ) AS aspect_sum,
        FIRST(rs.overall_summary,true) AS overall_summary
    FROM {self.catalog_name}.product.review_summary rs
    INNER JOIN (
        SELECT DISTINCT
            PRODUCT_ID AS item_id,
            CASE
                WHEN VIRTUAL_PARENT_DOTCOM_CD IS NOT NULL THEN VIRTUAL_PARENT_DOTCOM_CD
                WHEN SKUSET_DOTCOM_ID IS NOT NULL THEN SKUSET_DOTCOM_ID
                ELSE PRODUCT_ID
            END AS SKUSET
        FROM {self.catalog_name}.product.review_raw
    ) rr ON rs.skuset = rr.SKUSET 
    GROUP BY rr.item_id
    ),
    product_sizes AS (
    SELECT distinct 
        product_id,
        web_class_nm,
        width,
        height,
        weight,
        width * height * weight AS size
    FROM sku_src
    WHERE width IS NOT NULL
        AND height IS NOT NULL
        AND weight IS NOT NULL
        AND web_supercategory_nm in (
                'Audio','Bags, Backpacks & Luggage',
                'Cleaning Supplies','Facilities',
                'Furniture','Gift Shop',
                'Hard Drives & Data Storage','Ink & Toner',
                'Kitchen Tools & Appliances','Laboratory & Scientific Supplies',
                'Networking & WiFi','Office Decor, Homewares & Appliances',
                'Party Supplies','Phones, Cameras & Electronics','Printers & Scanners',
                'Restaurant & Foodservice Supplies',
                'Retail Store Supplies',
                'Safety Supplies',
                'Shipping, Packing & Mailing Supplies',
                'Shredders, Projectors & Office Machines',
                'Smart Home & Security',
                'TV & Streaming Media',
                'Tablets & iPads',
                'Tools, Parts & Supplies',
                'Wearable Technology')
    AND LOWER(web_class_nm) NOT LIKE '%accessory%'
    AND LOWER(web_class_nm) NOT LIKE '%&%'
    ),
    median_calc AS (
    SELECT web_class_nm,
        PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY size) AS median_size
    FROM product_sizes
    group by web_class_nm
    ),
    size_cat AS (
        SELECT
        p.product_id,
        m.median_size,
        CASE
            WHEN p.size > m.median_size * 1.33 THEN 'Large'
            WHEN p.size < m.median_size * 0.67 THEN 'Small'
            ELSE 'Medium'
        END AS size_category
        FROM product_sizes p
        JOIN median_calc m ON p.web_class_nm=m.web_class_nm
    ),
    -- Final deduplication to ensure one row per product
        final_data AS (
        SELECT
            -- Basic Product Data
            src.product_id AS item_id,
            src.upc,
            src.corp_class_id,
            src.corp_class_nm,
            src.corp_department_id,
            src.corp_department_nm,
            src.corp_division_id,
            src.corp_division_nm,
            src.web_class_id,
            src.web_class_nm,
            src.web_department_id,
            src.web_department_nm,
            src.web_category_id,
            src.web_category_nm,
            src.web_supercategory_id,
            src.web_supercategory_nm,
            -- Derive EAN from UPC
            CASE 
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 12 THEN CONCAT('0', TRIM(src.upc))  -- UPC-12 → EAN-13
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 13 THEN TRIM(src.upc)              -- Already EAN-13
                ELSE NULL 
            END AS ean,
            -- Derive GTIN from UPC
            CASE 
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 12 THEN CONCAT('00', TRIM(src.upc)) -- UPC-12 → GTIN-14
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 13 THEN CONCAT('0', TRIM(src.upc))  -- EAN-13 → GTIN-14
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 14 THEN TRIM(src.upc)              -- Already GTIN-14
                ELSE NULL 
            END AS gtin,
            src.MODEL_DELIVERY_NUM as model_number,
            COALESCE(
                src.MODEL_EDI_NUM,
                src.MODEL_DELIVERY_NUM,
                src.MODEL_RETAIL_NUM
            ) AS mpn,
            src.brand,
            src.OWN_BRAND_IND,
            src.manufacturer,
            src.PRODUCT_WEB_DSCR AS title,
            src.PRODUCT_SHORT_DSCR AS description,
            COALESCE(NULLIF(TRIM(src.web_dotcom_url), ''), CONCAT('https://www.staples.com/product_', CAST(src.product_id AS STRING))) AS url,
            -- Item Information
            'new' AS CONDITION,
            -- Physical dimensions
            concat(
               round(src.length, 2), 'x',
                round(src.width, 2), 'x',
                round(src.height, 2), ' '
            ) AS dimensions,
            round(src.length, 2) AS length,
            round(src.width, 2) AS width,
            round(src.height, 2) AS height,
            CAST(ROUND(src.weight, 2) AS DOUBLE) AS weight,
            'in' AS dimension_unit,
            'lb' AS weight_unit,
            --- Specifications and Attributes (aggregated as JSON)
            att.spec_json,
            att.specs_last_updated_at,
            web_spec.bullets_json,
            --- Media
            src.IMAGE_URL AS image_url,
            ARRAY_JOIN(
                FILTER(
                    ARRAY(
                        src.IMAGE_SECONDARY_1_URL,
                        src.IMAGE_SECONDARY_2_URL,
                        src.IMAGE_SECONDARY_3_URL,
                        src.IMAGE_SECONDARY_4_URL,
                        src.IMAGE_SECONDARY_5_URL,
                        src.IMAGE_SECONDARY_6_URL,
                        src.IMAGE_SECONDARY_7_URL,
                        src.IMAGE_SECONDARY_8_URL
                    ),
                    x -> x IS NOT NULL
                ),
                ','
            ) AS additional_image_urls,
            -- Price & Promotion
            round(src.PRICE_REGULAR_AMT, 2) || ' USD' AS pm_price,
            ---src.WEB_LIVE_ON_DOTCOM_IND AS web_live_on_dotcom,
            ---src.intent_to_sell_dotcom_ind AS intent_to_sell_dotcom,
            -- Lifecycle dates (for VIG-001: lifecycle_status derivation)
            src.WEB_FIRST_ON_DOTCOM_DT AS web_first_published_date,
            src.PRODUCT_CREATE_DT AS product_create_date,
            -- Variants
            --src.skuset_dotcom_id AS group_id,
            nvl(src.VIRTUAL_PARENT_DOTCOM_CD, src.skuset_dotcom_id) AS group_id,
            CASE WHEN src.skuset_dotcom_id IS NOT NULL THEN 'true' ELSE 'false' END AS listing_has_variations,
            -- Merchant Info
            'Staples Inc.' AS store_name,
            'http://Staples.com' AS seller_url,
            'https://www.staples.com/hc?id=dbb94c10-973c-478b-a078-00e58f66ba32' AS seller_privacy_policy,
            'https://www.staples.com/hc?topicId=9' AS seller_tos,
            -- Returns (fixed typo: RETUNPOLICYy -> RETUNPOLICY)
            'https://www.staples.com/hc?topicId=8' AS return_policy,
            COALESCE(rr_dept.RETUNPOLICY, rr_class.RETUNPOLICY, 'missing') as return_window,
            -- Reviews and Q&A
            review_all.cnt AS review_count,
            review_all.avg_review_rating AS star_rating,
            review_dotcomm.cnt AS store_review_count,
            review_dotcomm.avg_review_rating AS store_star_rating,
            review_summary_data.aspect_sum as review_aspects,
            review_summary_data.overall_summary as review_overall_summary,
            f_a_q.q_and_a,
            review_agg_dotcom.reviews,
            -- Geo Tagging
            'US' AS target_countries,
            'US' AS store_country,
            -- Related Products
            cbt_agg.related_product_id,
            similar_agg.similar_item_ids,
            CASE WHEN cbt_agg.related_product_id IS NOT NULL THEN 'often_bought_with' ELSE NULL END AS relationship_type,
           -- eco features
            src.ECO_FEATURE_IND,
            src.ECO_ENERGY_STAR_CERTIFIED_IND,
            src.ECO_RECYCLED_IND,
           -- fulfillment flags
            src.BOPIS_ELIGIBLE_IND AS bopis_eligible,
            src.DROPSHIP_DOTCOM_IND,
            src.SHIP_FROM_STORE_IND,
            src.AUTO_RESTOCK_IND,
           -- Eligibility flags
            true AS is_eligible_search,
            false AS is_eligible_checkout,
            -- calculate velocity
            (0.5 * (sales.sales_qty_7d/7) + 0.3 * (sales.sales_qty_30d/30) +0.2 * (sales.sales_qty_90d/90)) as sales_velocity,
            sales.sales_amt_30d as sales_amt_lt_30days,
            -- size classification
            -- Headliner statement
            src.web_headliner_statement_txt,
            size_cat.median_size,
            size_cat.size_category,
            -- Add row_number for deduplication
            ROW_NUMBER() OVER (PARTITION BY src.product_id ORDER BY src.hierarchy_web_dotcom_product_hierarchy_key) AS rn
        FROM sku_src src
        LEFT JOIN att ON att.product_id=src.product_id
        LEFT JOIN review_all ON src.product_id = review_all.product_id
        LEFT JOIN review_dotcomm ON src.product_id = review_dotcomm.product_id
        LEFT JOIN cbt_agg ON cbt_agg.product_id = src.product_id
        LEFT JOIN similar_agg ON similar_agg.product_id = src.product_id
        LEFT JOIN f_a_q ON f_a_q.product_id = src.product_id
        LEFT JOIN review_agg_dotcom ON src.product_id = review_agg_dotcom.product_id
        LEFT JOIN web_spec ON src.product_id = web_spec.product_id
        LEFT JOIN return_rules rr_dept ON rr_dept.subdepartment = src.corp_department_id
        LEFT JOIN return_rules rr_class ON rr_class.class = src.corp_class_id
        LEFT JOIN review_summary_data ON review_summary_data.item_id = src.product_id
        LEFT JOIN sales ON sales.order_product_id = src.product_id
        LEFT JOIN size_cat ON size_cat.product_id = src.product_id
        )
        SELECT
            item_id,
            upc,
            corp_class_id,
            corp_class_nm,
            corp_department_id,
            corp_department_nm,
            corp_division_id,
            corp_division_nm,
            ean,
            gtin,
            mpn,
            brand,
            OWN_BRAND_IND as own_brand_ind,
            manufacturer,
            model_number,
            title,
            description,
            url,
            --CONDITION as condition,
            web_class_id,
            web_class_nm,
            web_department_id,
            web_department_nm,
            web_category_id,
            web_category_nm,
            web_supercategory_id,
            web_supercategory_nm,
            dimensions,
            length,
            width,
            height,
            weight,
            dimension_unit,
            weight_unit,
            -- The same package (sell unit) size under its sell_unit_ names, which replace the plain ones
            dimensions AS sell_unit_dimensions,
            length AS sell_unit_length,
            width AS sell_unit_width,
            height AS sell_unit_height,
            weight AS sell_unit_weight,
            spec_json,
            bullets_json,
            image_url,
            additional_image_urls,
            pm_price,
            --- web_live_on_dotcom,
            --- intent_to_sell_dotcom,
            web_first_published_date,
            product_create_date,
            group_id,
            listing_has_variations,
            store_name,
            seller_url,
            seller_privacy_policy,
            seller_tos,
            return_policy,
            return_window,
            review_count,
            star_rating,
            store_review_count,
            store_star_rating,
            q_and_a,
            reviews,
            review_aspects,
            review_overall_summary,
            --target_countries,
            store_country,
            related_product_id,
            similar_item_ids,
            relationship_type,
            ECO_FEATURE_IND as eco_feature_ind,
            ECO_ENERGY_STAR_CERTIFIED_IND as eco_energy_star_certified_ind,
            ECO_RECYCLED_IND as eco_recycled_ind,
            bopis_eligible,
            DROPSHIP_DOTCOM_IND as dropship_dotcom_ind,
            SHIP_FROM_STORE_IND as ship_from_store_ind,
            AUTO_RESTOCK_IND as auto_restock_ind,
            is_eligible_search,
            is_eligible_checkout,
            -- Support Channel Information (static for all products)
            ARRAY(
                NAMED_STRUCT(
                    'channel', 'Chat with a Staples Expert',
                    'availability', ARRAY(
                        NAMED_STRUCT('days', 'Mon - Fri', 'hours', '8 am - 8 pm ET'),
                        NAMED_STRUCT('days', 'Sat - Sun', 'hours', '10 am - 7 pm ET')
                    ),
                    'details', CAST(NULL AS STRUCT<email: STRING, phone: STRING>)
                ),
                NAMED_STRUCT(
                    'channel', 'Email a Staples Expert',
                    'availability', CAST(NULL AS ARRAY<STRUCT<days: STRING, hours: STRING>>),
                    'details', NAMED_STRUCT('email', 'help@staples.com', 'phone', CAST(NULL AS STRING))
                ),
                NAMED_STRUCT(
                    'channel', 'Call a Staples Expert',
                    'availability', ARRAY(
                        NAMED_STRUCT('days', 'Mon - Fri', 'hours', '8 am - 10 pm ET'),
                        NAMED_STRUCT('days', 'Sat - Sun', 'hours', '9 am - 8 pm ET')
                    ),
                    'details', NAMED_STRUCT('email', CAST(NULL AS STRING), 'phone', '1 (800) 333-3330')
                )
            ) AS support_channel_json,
            size_category,
            sales_velocity,
            sales_amt_lt_30days,
            web_headliner_statement_txt
        FROM final_data
        WHERE rn = 1
        """
      
        if limit:
            query += f"\n        LIMIT {limit}"
        
        return self.spark.sql(query)

    # ------------------------------------------------------------------
    # All-BU product list (product_discovery_data_all)
    # ------------------------------------------------------------------
    @staticmethod
    def _all_bu_source_sql() -> str:
        """One row per product live on Staples.com or Staples Business, with the product master
        columns the all-BU table needs. All three hierarchies are LEFT joins, so a product on one
        site only keeps its row; duplicates are resolved the way load_product_master does."""
        images = ",\n                    ".join(
            "pm.IMAGE_SECONDARY_{}_URL".format(i) for i in range(1, 9))
        levels = [("class_id", "class_id"), ("class_nm", "class_nm"),
                  ("department_id", "department_id"), ("department_nm", "department_nm"),
                  ("category_id", "category_id"), ("category_nm", "category_nm"),
                  ("supercategory_id", "supercategory_id"), ("supercategory_nm", "supercategory_nm")]
        dotcom_hier = ",\n                    ".join(
            "ph2.{} AS web_{}".format(src, dst) for src, dst in levels)
        contract_hier = ",\n                    ".join(
            "ph3.{} AS contract_{}".format(src, dst) for src, dst in levels)
        return f"""
        SELECT * EXCEPT (rn) FROM (
            SELECT base.*,
                   ROW_NUMBER() OVER (
                       PARTITION BY base.product_id
                       ORDER BY base.hierarchy_web_dotcom_product_hierarchy_key
                   ) AS rn
            FROM (
                SELECT
                    pm.product_id,
                    pm.UPC_DELIVERY_CD AS upc,
                    pm.hierarchy_web_dotcom_product_hierarchy_key,
                    pm.MODEL_DELIVERY_NUM,
                    pm.MODEL_EDI_NUM,
                    pm.MODEL_RETAIL_NUM,
                    ph.class_id AS corp_class_id,
                    ph.class_nm AS corp_class_nm,
                    ph.department_id AS corp_department_id,
                    ph.department_nm AS corp_department_nm,
                    ph.division_id AS corp_division_id,
                    ph.division_nm AS corp_division_nm,
                    pm.brand_nm AS brand,
                    pm.OWN_BRAND_IND,
                    pm.MANUFACTURER_NM AS manufacturer,
                    pm.PRODUCT_WEB_DSCR,
                    pm.PRODUCT_SHORT_DSCR,
                    pm.sell_unit_height_amt AS height,
                    pm.sell_unit_length_amt AS length,
                    pm.sell_unit_weight_amt AS weight,
                    pm.sell_unit_width_amt AS width,
                    pm.PRICE_REGULAR_CONTRACT_AMT,
                    pm.image_url,
                    {images},
                    pm.web_contract_url,
                    pm.intent_to_sell_dotcom_ind,
                    pm.web_live_on_dotcom_ind,
                    pm.intent_to_sell_contract_ind,
                    pm.web_live_on_contract_ind,
                    pm.skuset_contract_id,
                    pm.VIRTUAL_PARENT_CONTRACT_CD,
                    pm.PRODUCT_CREATE_DT,
                    pm.DISCONTINUED_ALTERNATE_IND,
                    pm.DISCONTINUED_ALTERNATE_PRODUCT_ID,
                    pm.DISCONTINUED_BY_MANUFACTURER_DT,
                    pm.DISCONTINUED_BY_MANUFACTURER_IND,
                    pm.DISCONTINUED_CONTRACT_CD,
                    pm.BOPIS_ELIGIBLE_IND,
                    pm.ECO_FEATURE_IND,
                    pm.ECO_ENERGY_STAR_CERTIFIED_IND,
                    pm.ECO_RECYCLED_IND,
                    pm.DROPSHIP_CONTRACT_IND,
                    pm.SHIP_FROM_STORE_IND,
                    pm.AUTO_RESTOCK_IND,
                    pm.VIRTUAL_BUNDLE_DOTCOM_IND,
                    pm.VIRTUAL_CARTON_DOTCOM_IND,
                    pm.VIRTUAL_BUNDLE_CONTRACT_IND,
                    pm.VIRTUAL_CARTON_CONTRACT_IND,
                    pm.web_headliner_statement_txt,
                    {dotcom_hier},
                    {contract_hier}
                FROM snowflake_edh.product.product_master pm
                LEFT JOIN snowflake_edh.product.product_hierarchy ph
                    ON pm.hierarchy_corp_product_hierarchy_key = ph.product_hierarchy_key
                    AND ph.hierarchy_source_cd = 'MERCH'
                LEFT JOIN snowflake_edh.product.product_hierarchy ph2
                    ON pm.hierarchy_web_dotcom_product_hierarchy_key = ph2.product_hierarchy_key
                    AND ph2.hierarchy_source_cd = 'STAPLESDOTCOM'
                LEFT JOIN snowflake_edh.product.product_hierarchy ph3
                    ON pm.hierarchy_web_contract_product_hierarchy_key = ph3.product_hierarchy_key
                    AND ph3.hierarchy_source_cd = 'STAPLESADVANTAGE'
                WHERE (pm.intent_to_sell_dotcom_ind = 'Y' AND pm.web_live_on_dotcom_ind = 'Y')
                   OR (pm.intent_to_sell_contract_ind = 'Y' AND pm.web_live_on_contract_ind = 'Y')
            ) base
        ) WHERE rn = 1
        """

    @staticmethod
    def _all_bu_specs_sql(ids: str) -> str:
        """spec_json, built as in load_product_master, for the products in `ids`."""
        return f"""
        SELECT
            product_id,
            SORT_ARRAY(
                COLLECT_LIST(STRUCT(attribute_group_nm, attribute_nm, attribute_value_txt))
            ) AS spec_json
        FROM snowflake_edh.Product.PRODUCT_SPECIFICATIONS
        WHERE row_status_cd = 'ACTIVE'
          AND product_id IN (SELECT product_id FROM {ids})
        GROUP BY product_id
        """

    @staticmethod
    def _all_bu_bullets_sql(ids: str) -> str:
        """bullets_json, built as in load_product_master, for the products in `ids`."""
        return f"""
        SELECT
            product_id,
            COLLECT_LIST(bullet_txt) AS bullets_json
        FROM snowflake_edh.product.product_web_bullets
        WHERE row_status_cd = 'ACTIVE'
          AND product_id IN (SELECT product_id FROM {ids})
        GROUP BY product_id
        """

    @staticmethod
    def _all_bu_all_site_reviews_sql(ids: str) -> str:
        """review_count and star_rating over every site, as in load_product_master."""
        return f"""
        SELECT
            product_id,
            COUNT(DISTINCT(WEB_REVIEW_ID)) AS cnt,
            ROUND(AVG(review_rating_rt), 2) AS avg_review_rating
        FROM snowflake_edh.product.PRODUCT_WEB_REVIEW
        WHERE REVIEW_DETAIL_TXT IS NOT NULL
          AND product_id IN (SELECT product_id FROM {ids})
        GROUP BY product_id
        """

    @staticmethod
    def _all_bu_site_reviews_sql(ids: str, site_id: str) -> str:
        """One site's review count and average over all its reviews, plus the 50 newest reviews
        with at least 10 characters of text: the same rules as the Staples.com columns."""
        return f"""
        SELECT
            product_id,
            COUNT(*) AS cnt,
            ROUND(AVG(review_rating_rt), 2) AS avg_review_rating,
            CASE WHEN SUM(CASE WHEN is_valid THEN 1 ELSE 0 END) > 0 THEN
                COLLECT_LIST(
                    CASE WHEN is_valid AND rn <= 50 THEN
                        NAMED_STRUCT(
                            'title', review_title_txt,
                            'content', review_detail_txt,
                            'minRating', 1,
                            'maxRating', 5,
                            'rating', review_rating_rt
                        )
                    END
                )
            END AS reviews
        FROM (
            SELECT v.*,
                   ROW_NUMBER() OVER (
                       PARTITION BY v.product_id, v.is_valid
                       -- WEB_REVIEW_ID breaks same-day ties, so every run picks the same 50
                       ORDER BY v.REVIEW_CREATE_DT DESC, v.WEB_REVIEW_ID DESC
                   ) AS rn
            FROM (
                SELECT
                    r.product_id,
                    r.review_title_txt,
                    r.review_detail_txt,
                    r.review_rating_rt,
                    r.REVIEW_CREATE_DT,
                    r.WEB_REVIEW_ID,
                    (r.review_detail_txt IS NOT NULL AND LENGTH(TRIM(r.review_detail_txt)) >= 10) AS is_valid
                FROM snowflake_edh.product.PRODUCT_WEB_REVIEW r
                WHERE r.site_id = '{site_id}'
                  AND r.product_id IN (SELECT product_id FROM {ids})
            ) v
        )
        GROUP BY product_id
        """

    @staticmethod
    def _all_bu_site_qa_sql(ids: str, site_id: str) -> str:
        """One site's questions with their answers, as in load_product_master."""
        return f"""
        SELECT
            product_id,
            COLLECT_LIST(NAMED_STRUCT('q', question, 'a', answers)) AS q_and_a
        FROM (
            SELECT
                q.product_id,
                q.question_id,
                NVL(q.question_details_txt, q.question_summary_txt) AS question,
                COLLECT_LIST(a.answer_txt) AS answers
            FROM snowflake_edh.product.product_web_question q
            LEFT JOIN snowflake_edh.product.product_web_answer a
                ON q.product_id = a.product_id
                AND q.question_id = a.question_id
            WHERE q.site_id = '{site_id}'
              AND q.product_id IN (SELECT product_id FROM {ids})
            GROUP BY
                q.product_id,
                q.question_id,
                NVL(q.question_details_txt, q.question_summary_txt)
        )
        GROUP BY product_id
        """

    @staticmethod
    def _all_bu_contract_sales_sql(ids: str) -> str:
        """Staples Business shipments over 90 days, from the contract sales mart. The join from
        SKU_NUMBER to product_id is taken over from feature/all_bu_design and still needs
        confirming with its author. Both sides are compared as text: with ANSI mode on, comparing
        a numeric SKU_NUMBER with product ids such as 'AVE79805' would fail the query."""
        return f"""
        SELECT
            s.product_id AS product_id,
            SUM(CASE WHEN a12.CLD_DT >= (CURRENT_DATE - INTERVAL '7' DAY)  THEN a11.to_ship_qty ELSE 0 END) AS sales_qty_7d,
            SUM(CASE WHEN a12.CLD_DT >= (CURRENT_DATE - INTERVAL '30' DAY) THEN a11.to_ship_qty ELSE 0 END) AS sales_qty_30d,
            SUM(CASE WHEN a12.CLD_DT >= (CURRENT_DATE - INTERVAL '90' DAY) THEN a11.to_ship_qty ELSE 0 END) AS sales_qty_90d,
            ROUND(SUM(CASE WHEN a12.CLD_DT >= (CURRENT_DATE - INTERVAL '30' DAY)
                           THEN (a11.EXTD_PRC_AMT + a11.CUST_TOT_RBT_AMT) ELSE 0 END), 2) AS sales_amt_30d
        FROM snowflake_cap.PRD_CONTR_DMV.F_SHIP_LN_ALL_V a11
        JOIN snowflake_cap.PRD_CONTR_DMV.D_CONTR_TM_DY_V a12
            ON a11.END_OF_DAY_POSTD_TM_KY = a12.TM_KY
        JOIN snowflake_cap.PRD_CONTR_DMV.D_US_CONTR_PDT_A_V a14
            ON a11.ACT_SHIP_PDT_KY = a14.pdt_ky
        JOIN {ids} s
            ON CAST(a11.SKU_NUMBER AS STRING) = CAST(s.product_id AS STRING)
            AND a14.sku_number = a11.sku_number
        WHERE a11.STD_FINL_FILTER_IND = 'N'
          AND a11.SRC_SYS_CD IN ('08')
          AND a12.CLD_DT >= (CURRENT_DATE - INTERVAL '90' DAY)
        GROUP BY s.product_id
        """

    @staticmethod
    def _all_bu_extra_product_sql(extra: str, specs: str, bullets: str, all_reviews: str) -> str:
        """The product columns for products only on Staples Business, with the same expressions
        as load_product_master (and in ALL_BU_PRODUCT_COLUMNS order)."""
        images = ",\n                        ".join(
            "src.IMAGE_SECONDARY_{}_URL".format(i) for i in range(1, 9))
        return f"""
        SELECT
            src.product_id AS item_id,
            src.upc,
            src.corp_class_id,
            src.corp_class_nm,
            src.corp_department_id,
            src.corp_department_nm,
            src.corp_division_id,
            src.corp_division_nm,
            CASE
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 12 THEN CONCAT('0', TRIM(src.upc))
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 13 THEN TRIM(src.upc)
                ELSE NULL
            END AS ean,
            CASE
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 12 THEN CONCAT('00', TRIM(src.upc))
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 13 THEN CONCAT('0', TRIM(src.upc))
                WHEN src.upc IS NOT NULL AND LENGTH(TRIM(src.upc)) = 14 THEN TRIM(src.upc)
                ELSE NULL
            END AS gtin,
            COALESCE(src.MODEL_EDI_NUM, src.MODEL_DELIVERY_NUM, src.MODEL_RETAIL_NUM) AS mpn,
            src.brand,
            src.OWN_BRAND_IND AS own_brand_ind,
            src.manufacturer,
            src.MODEL_DELIVERY_NUM AS model_number,
            src.PRODUCT_WEB_DSCR AS title,
            src.PRODUCT_SHORT_DSCR AS description,
            concat(
                round(src.length, 2), 'x',
                round(src.width, 2), 'x',
                round(src.height, 2), ' '
            ) AS dimensions,
            round(src.length, 2) AS length,
            round(src.width, 2) AS width,
            round(src.height, 2) AS height,
            CAST(ROUND(src.weight, 2) AS DOUBLE) AS weight,
            'in' AS dimension_unit,
            'lb' AS weight_unit,
            concat(
                round(src.length, 2), 'x',
                round(src.width, 2), 'x',
                round(src.height, 2), ' '
            ) AS sell_unit_dimensions,
            round(src.length, 2) AS sell_unit_length,
            round(src.width, 2) AS sell_unit_width,
            round(src.height, 2) AS sell_unit_height,
            CAST(ROUND(src.weight, 2) AS DOUBLE) AS sell_unit_weight,
            att.spec_json,
            web_spec.bullets_json,
            src.IMAGE_URL AS image_url,
            ARRAY_JOIN(
                FILTER(
                    ARRAY(
                        {images}
                    ),
                    x -> x IS NOT NULL
                ),
                ','
            ) AS additional_image_urls,
            src.PRODUCT_CREATE_DT AS product_create_date,
            ra.cnt AS review_count,
            ra.avg_review_rating AS star_rating,
            src.ECO_FEATURE_IND AS eco_feature_ind,
            src.ECO_ENERGY_STAR_CERTIFIED_IND AS eco_energy_star_certified_ind,
            src.ECO_RECYCLED_IND AS eco_recycled_ind,
            src.BOPIS_ELIGIBLE_IND AS bopis_eligible,
            src.SHIP_FROM_STORE_IND AS ship_from_store_ind,
            src.AUTO_RESTOCK_IND AS auto_restock_ind,
            true AS is_eligible_search,
            false AS is_eligible_checkout,
            src.web_headliner_statement_txt
        FROM {extra} src
        LEFT JOIN {specs} att ON att.product_id = src.product_id
        LEFT JOIN {bullets} web_spec ON web_spec.product_id = src.product_id
        LEFT JOIN {all_reviews} ra ON ra.product_id = src.product_id
        """

    @staticmethod
    def _all_bu_final_sql(dotcom_columns: List[str], v: Dict[str, str]) -> str:
        """Assemble the all-BU table: one row per product in the Staples.com slice or live on
        Staples Business. A Staples.com product carries exactly its slice values."""
        known = ({"item_id"} | set(ALL_BU_PRODUCT_COLUMNS) | set(ALL_BU_DOTCOM_ONLY_COLUMNS)
                 | set(ALL_BU_DOTCOM_COLUMNS) | {"web_" + lv for lv in ALL_BU_HIERARCHY_LEVELS})
        missing = sorted(known - set(dotcom_columns))
        if missing:
            raise ValueError("load_product_master no longer returns {}; update the ALL_BU_* "
                             "column lists".format(", ".join(missing)))
        # A column added to load_product_master later is carried over under its own name.
        carried = [c for c in dotcom_columns if c not in known]
        if carried:
            print("⚠ carrying new product_discovery_data columns unchanged: " + ", ".join(carried))

        in_dotcom = "p.item_id IS NOT NULL"
        cols = [
            "ids.item_id",
            f"{in_dotcom} AS in_product_discovery_data",
            f"CASE WHEN {in_dotcom} THEN true ELSE coalesce({LIVE_DOTCOM}, false) END AS is_live_dotcom",
            f"coalesce({LIVE_CONTRACT}, false) AS is_live_contract",
        ]
        cols += [f"CASE WHEN {in_dotcom} THEN p.{c} ELSE e.{c} END AS {c}"
                 for c in ALL_BU_PRODUCT_COLUMNS]
        cols += [f"CASE WHEN {in_dotcom} THEN p.web_{lv} ELSE s.web_{lv} END AS web_{lv}_dotcom"
                 for lv in ALL_BU_HIERARCHY_LEVELS]
        cols += [f"CASE WHEN {LIVE_CONTRACT} THEN s.contract_{lv} END AS web_{lv}_contract"
                 for lv in ALL_BU_HIERARCHY_LEVELS]
        cols += [f"p.{src} AS {dst}" for src, dst in ALL_BU_DOTCOM_COLUMNS.items()]
        cols += [
            f"CASE WHEN {LIVE_CONTRACT} THEN s.web_contract_url END AS url_contract",
            f"CASE WHEN {LIVE_CONTRACT} THEN round(s.PRICE_REGULAR_CONTRACT_AMT, 2) || ' USD' END AS price_contract",
            f"CASE WHEN {LIVE_CONTRACT} THEN nvl(s.VIRTUAL_PARENT_CONTRACT_CD, s.skuset_contract_id) END AS group_id_contract",
            f"CASE WHEN {LIVE_CONTRACT} THEN CASE WHEN s.skuset_contract_id IS NOT NULL THEN 'true' ELSE 'false' END END"
            " AS listing_has_variations_contract",
            "rv.cnt AS review_count_contract",
            "rv.avg_review_rating AS star_rating_contract",
            "qa.q_and_a AS q_and_a_contract",
            "rv.reviews AS reviews_contract",
            f"CASE WHEN {LIVE_CONTRACT} THEN s.DROPSHIP_CONTRACT_IND END AS dropship_ind_contract",
            "(0.5 * (sc.sales_qty_7d/7) + 0.3 * (sc.sales_qty_30d/30) + 0.2 * (sc.sales_qty_90d/90))"
            " AS sales_velocity_contract",
            "sc.sales_amt_30d AS sales_amt_lt_30days_contract",
            f"CASE WHEN {in_dotcom} OR {LIVE_DOTCOM} THEN s.VIRTUAL_BUNDLE_DOTCOM_IND END AS virtual_bundle_ind_dotcom",
            f"CASE WHEN {LIVE_CONTRACT} THEN s.VIRTUAL_BUNDLE_CONTRACT_IND END AS virtual_bundle_ind_contract",
            f"CASE WHEN {in_dotcom} OR {LIVE_DOTCOM} THEN s.VIRTUAL_CARTON_DOTCOM_IND END AS virtual_carton_ind_dotcom",
            f"CASE WHEN {LIVE_CONTRACT} THEN s.VIRTUAL_CARTON_CONTRACT_IND END AS virtual_carton_ind_contract",
            f"CASE WHEN {LIVE_CONTRACT} THEN s.DISCONTINUED_CONTRACT_CD END AS discontinued_cd_contract",
            "s.DISCONTINUED_ALTERNATE_IND AS discontinued_alternate_ind",
            "s.DISCONTINUED_ALTERNATE_PRODUCT_ID AS discontinued_alternate_product_id",
            "s.DISCONTINUED_BY_MANUFACTURER_DT AS discontinued_by_manufacturer_dt",
            "s.DISCONTINUED_BY_MANUFACTURER_IND AS discontinued_by_manufacturer_ind",
        ]
        cols += [f"p.{c}" for c in ALL_BU_DOTCOM_ONLY_COLUMNS + carried]
        select = ",\n            ".join(cols)
        return f"""
        WITH ids AS (
            SELECT item_id FROM {v['dotcom']}
            UNION
            SELECT product_id AS item_id FROM {v['contract']}
        )
        SELECT
            {select}
        FROM ids
        LEFT JOIN {v['dotcom']} p ON p.item_id = ids.item_id
        LEFT JOIN {v['source']} s ON s.product_id = ids.item_id
        LEFT JOIN {v['extra_product']} e ON e.item_id = ids.item_id
        LEFT JOIN {v['reviews_contract']} rv ON rv.product_id = ids.item_id
        LEFT JOIN {v['qa_contract']} qa ON qa.product_id = ids.item_id
        LEFT JOIN {v['sales_contract']} sc ON sc.product_id = ids.item_id
        """

    def build_all_bu(self, dotcom_df: DataFrame) -> DataFrame:
        """The all-BU product list, from load_product_master's Staples.com products plus every
        product live on Staples Business. Register-only: nothing runs until the result is written.
        """
        views = {"dotcom": "all_bu_dotcom", "source": "all_bu_source", "contract": "all_bu_contract",
                 "extra": "all_bu_extra"}
        dotcom_df.createOrReplaceTempView(views["dotcom"])
        # The product master scan is shared by every step below, so it is computed once.
        self._all_bu_source = self.spark.sql(self._all_bu_source_sql()).cache()
        self._all_bu_source.createOrReplaceTempView(views["source"])
        self.spark.sql(
            f"SELECT * FROM {views['source']} s WHERE {LIVE_CONTRACT}"
        ).createOrReplaceTempView(views["contract"])
        self.spark.sql(
            f"SELECT c.* FROM {views['contract']} c "
            f"LEFT ANTI JOIN {views['dotcom']} p ON p.item_id = c.product_id"
        ).createOrReplaceTempView(views["extra"])

        steps = {
            "specs": self._all_bu_specs_sql(views["extra"]),
            "bullets": self._all_bu_bullets_sql(views["extra"]),
            "all_reviews": self._all_bu_all_site_reviews_sql(views["extra"]),
            "reviews_contract": self._all_bu_site_reviews_sql(views["contract"], CONTRACT_SITE_ID),
            "qa_contract": self._all_bu_site_qa_sql(views["contract"], CONTRACT_SITE_ID),
            "sales_contract": self._all_bu_contract_sales_sql(views["contract"]),
        }
        for name, sql in steps.items():
            views[name] = "all_bu_" + name
            self.spark.sql(sql).createOrReplaceTempView(views[name])
        views["extra_product"] = "all_bu_extra_product"
        self.spark.sql(self._all_bu_extra_product_sql(
            views["extra"], views["specs"], views["bullets"], views["all_reviews"]
        )).createOrReplaceTempView(views["extra_product"])
        return self.spark.sql(self._all_bu_final_sql(dotcom_df.columns, views))

    @staticmethod
    def dotcom_slice_of_all_bu(all_bu: DataFrame, dotcom_columns: List[str]) -> DataFrame:
        """product_discovery_data as the Staples.com slice of the all-BU table: the same rows,
        columns, column order and names that load_product_master produces."""
        name_in_all_bu = dotcom_names_in_all_bu()
        return (all_bu.filter(F.col("in_product_discovery_data"))
                .select(*[F.col(name_in_all_bu.get(c, c)).alias(c) for c in dotcom_columns]))

    def save_all_bu_data(self, df: DataFrame) -> None:
        """Write the all-BU table, replacing its schema, and describe its columns."""
        table = self.all_bu_output_table
        print(f"Saving data to {table}...")
        df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table)
        def quoted(text: str) -> str:
            return "'" + text.replace("\\", "\\\\").replace("'", "\\'") + "'"

        self.spark.sql(f"COMMENT ON TABLE {table} IS {quoted(ALL_BU_TABLE_COMMENT)}")
        for column, text in all_bu_column_comments(df.columns).items():
            self.spark.sql(f"ALTER TABLE {table} ALTER COLUMN {column} COMMENT {quoted(text)}")
        row_count = self.spark.table(table).count()
        print(f"✓ Successfully saved {row_count:,} rows to {table}")

    def save_product_list(self, dotcom_df: DataFrame) -> None:
        """Write product_discovery_data_all, then product_discovery_data as its Staples.com slice.

        Without all_bu_output_table in general.yml, product_discovery_data is written as before.
        """
        if not self.all_bu_output_table:
            self.save_product_data(dotcom_df, mode='overwrite')
            return
        dotcom_df = dotcom_df.cache()
        try:
            self.save_all_bu_data(self.build_all_bu(dotcom_df))
            all_bu = self.spark.table(self.all_bu_output_table)
            self.save_product_data(self.dotcom_slice_of_all_bu(all_bu, dotcom_df.columns), mode='overwrite')
        finally:
            dotcom_df.unpersist()
            if self._all_bu_source is not None:
                self._all_bu_source.unpersist()
                self._all_bu_source = None

    def load_table(self, catalog: str, schema: str, table: str) -> DataFrame:
        """
        Load any Unity Catalog table.
        
        Args:
            catalog: Catalog name (e.g., 'snowflake_edh')
            schema: Schema name (e.g., 'product')
            table: Table name (e.g., 'product_master')
        
        Returns:
            PySpark DataFrame
        """
        full_table_name = f"{catalog}.{schema}.{table}"
        return self.spark.table(full_table_name)
    
    def execute_query(self, query: str) -> DataFrame:
        """
        Execute a custom SQL query against Unity Catalog.
        
        Args:
            query: SQL query string
        
        Returns:
            PySpark DataFrame with query results
        """

        query = query.format(catalog_name=self.catalog_name)
        return self.spark.sql(query)
    
    def save_to_catalog(
        self,
        df: DataFrame,
        catalog: str,
        schema: str,
        table: str,
        mode: str = "overwrite",
        create_schema: bool = True
    ) -> None:
        """
        Save DataFrame to Unity Catalog as a Delta table.
        
        Args:
            df: DataFrame to save
            catalog: Catalog name (e.g., 'mld01_ml_de')
            schema: Schema name (e.g., 'agent_demo')
            table: Table name (e.g., 'product_discovery_data')
            mode: Write mode - 'overwrite', 'append', 'error', 'ignore'
            create_schema: Whether to create schema if it doesn't exist
        
        Example:
            loader = UnityCatalogLoader()
            df = loader.load_product_master(limit=100)
            loader.save_to_catalog(
                df=df,
                catalog='mld01_ml_de',
                schema='product',
                table='product_discovery_data',
                mode='overwrite'
            )
        """
        full_table_name = f"{catalog}.{schema}.{table}"
        
        # Create schema if needed
        if create_schema:
            try:
                self.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
                print(f"✓ Schema {catalog}.{schema} ready")
            except Exception as e:
                print(f"⚠ Warning: Could not create schema: {str(e)}")
        
        # Save as Delta table with schema merge
        try:
            print(f"Saving data to {full_table_name}...")
            df.write \
                .format("delta") \
                .mode(mode) \
                .option("mergeSchema", "true") \
                .saveAsTable(full_table_name)
            
            # Get row count
            row_count = self.spark.table(full_table_name).count()
            print(f"✓ Successfully saved {row_count:,} rows to {full_table_name}")
            
        except Exception as e:
            print(f"✗ Failed to save data: {str(e)}")
            raise
    
    def save_product_data(
        self,
        df: DataFrame,
        mode: str = "overwrite"
    ) -> None:
        """
        Save product data to the configured Unity Catalog location.
        
        
        Args:
            df: DataFrame to save
            mode: Write mode - 'overwrite', 'append', 'error', 'ignore'
        
        Example:
            loader = UnityCatalogLoader()
            df = loader.load_product_master()
            loader.save_product_data(df)  # Uses config from .env
        """
        self.save_to_catalog(
            df=df,
            catalog=self.output_catalog,
            schema=self.output_schema,
            table=self.output_table,
            mode=mode,
            create_schema=True
        )
    
    def get_output_table_name(self) -> str:
        """
        Get the full output table name from configuration.
        
        Returns:
            Full table name (e.g., 'mld01_ml_de.agent_demo.product_discovery_data')
        """
        return f"{self.output_catalog}.{self.output_schema}.{self.output_table}"
    
    def close(self):
        """Stop the Spark session."""
        if self.spark:
            self.spark.stop()


# Example usage
if __name__ == "__main__":
    # from dotenv import load_dotenv
    
    # load_dotenv()
    
    # Initialize loader
    loader = UnityCatalogLoader()
    
    try:
        print("=" * 60)
        print("Unity Catalog Loader - Example Usage")
        print("=" * 60)
        
        # Show configuration
        print(f"\nOutput Configuration:")
        print(f"  Target Table: {loader.get_output_table_name()}")
        
        # Load product master data
        print("\nLoading product master data...")
        df = loader.load_product_master()
        
        print(f"✓ Loaded {df.count()} rows")
        df.show(5)
        
        # Save to configured location
        if os.getenv("DATABRICKS_RUNTIME_VERSION"):
            loader.save_product_list(df)
        else:
            save_choice = input("\nSave to Unity Catalog? (y/n): ")
            if save_choice.lower() == 'y':
                loader.save_product_list(df)
                print(f"✓ Data saved to {loader.get_output_table_name()}")
        
    finally:
        # Only close Spark session when running locally via Databricks Connect
        # On Databricks cluster, let Databricks manage the session lifecycle
        if not os.getenv("DATABRICKS_RUNTIME_VERSION"):
            loader.close()
        print("✓ Script completed successfully")
