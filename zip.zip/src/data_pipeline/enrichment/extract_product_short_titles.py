"""Short product titles for every product of both sites (ai_extract).

Runs as the enrichment_short_titles task of the Agentic Commerce Data Pipeline. It reads the
all-sites product list (product_discovery_data_all) and keeps one title per item_id in
product_short_titles. The enrichment_fields task then joins short_title into
product_master_enriched_inclusive_t.

Each run reads the full snapshot. The source_hash comparison decides which products go to
ai_extract, so unchanged products cost nothing. ai_extract is probed first and never skipped:
if it cannot run, the task fails.

Every title is checked before it is saved (check_title): a character count the model wrote after
the title is removed, and a title longer than max_title_chars, with the model's notes in it, or
without real words is saved as NULL with the reason in short_title_issue. Each run also re-checks
the saved titles and sends the NULL ones to a stricter repair prompt, at most max_repair_attempts
times until the product changes.
"""
import hashlib
import json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    # Notebook cell: no __file__ (same fallback as review_mining.py)
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

for _path in (PROJECT_ROOT, os.path.join(PROJECT_ROOT, "src", "data_pipeline", "enrichment")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType, StructField, StructType

from utils import get_spark_session, read_config, read_all_products, validate_before_write

logging.basicConfig(level=logging.INFO)
logging.getLogger("py4j").setLevel(logging.WARNING)  # drop the "Received command c" lines
logger = logging.getLogger(__name__)

GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")

KEY_COLUMN = "item_id"
TAXONOMY_LEVELS = ["web_supercategory_nm", "web_category_nm", "web_department_nm", "web_class_nm"]
# read_all_products gives the Staples.com taxonomy under the plain names and keeps the SB
# taxonomy under *_contract. SB-only products have no Staples.com taxonomy.
SOURCE_COLUMNS = [KEY_COLUMN, "upc", "title"] + TAXONOMY_LEVELS + [f"{c}_contract" for c in TAXONOMY_LEVELS]
OUTPUT_COLUMNS = [KEY_COLUMN, "upc", "title", "merchandising_family", "short_title", "source_hash", "updated_at",
                  "short_title_issue", "short_title_attempts"]
# Table property holding the time of the last run that finished without falling back.
LAST_SUCCESS_PROPERTY = "short_titles.last_success_at"

# Error text that means a temporary problem: retried, and a short outage may fall back.
TRANSIENT_MARKERS = (
    "timeout", "timed out", "429", "too many requests", "rate limit",
    "503", "service unavailable", "temporarily unavailable", "connection reset",
)
PROBE_CONTENT_SQL = "'ORIGINAL TITLE: probe product'"


class TransientAIError(RuntimeError):
    """ai_extract failed with a temporary error after all retries."""


# ---------------------------------------------------------------------------
# Prompt, schema and merchandising families (copied from the earlier notebook)
# ---------------------------------------------------------------------------
FAMILY_PATTERNS = [
    ("GROCERY_CONSUMABLES", r"\b(grocery|food|snack|candy|beverage|coffee|tea|water|juice|nutrition|cookie|cracker|cereal|drink|soda)\b"),
    ("APPAREL", r"\b(apparel|clothing|shirt|jacket|uniform|footwear|shoe|glove|sock|pants|vest|coat|wearable)\b"),
    ("TECHNOLOGY", r"\b(computer|tablet|laptop|monitor|electronics|technology|memory|drive|charger|cable|headset|phone|camera|network|keyboard|mouse|webcam|adapter|router|projector)\b"),
    ("PRINTING_SUPPLIES", r"\b(printer|scanner|copier|fax|ink|toner|cartridge|drum|printhead)\b"),
    ("PAPER_STATIONERY", r"\b(paper|notebook|notepad|label|envelope|cardstock|stationery|index card|receipt roll)\b"),
    ("WRITING_INSTRUMENTS", r"\b(pen|pencil|marker|highlighter|crayon|writing|chalk|eraser|stylus)\b"),
    ("FURNITURE", r"\b(furniture|desk|chair|bookcase|cabinet|table|shelf|workstation|stool|credenza)\b"),
    ("JANITORIAL_CLEANING", r"\b(cleaning|janitorial|sanitation|trash|soap|towel|tissue|disinfect|detergent|cleaner|broom|mop|wipes)\b"),
    ("SHIPPING_PACKAGING", r"\b(shipping|mailing|packaging|carton|packing|bubble wrap|mailer|shipping box|strapping|packing tape)\b"),
    ("EDUCATION", r"\b(school|education|classroom|teacher|student|learning|curriculum|grade)\b"),
    ("TOOLS_SAFETY", r"\b(tool|hardware|safety|industrial|maintenance|electrical|protective|eyewear|hard hat|respirator)\b"),
    ("ORGANIZATION_FILING", r"\b(binder|folder|organizer|portfolio|divider|file jacket|expanding file|document holder)\b"),
    ("PRESENTATION_DISPLAY", r"\b(whiteboard|bulletin board|display board|easel|sign holder|poster frame|dry erase board)\b"),
]

AI_EXTRACT_SCHEMA = {
    "short_title": {
        "type": "string",
        "description": (
            "A concise customer-facing product title. Prefer 40 characters "
            "or fewer and never exceed 65 characters. Put the shortest "
            "accurate generic product type early. Retain the original "
            "manufacturer brand only when differentiating. Retain model, "
            "size, dimensions, capacity, weight, volume, color, compatibility, "
            "or count only when required to identify the purchasable variant."
        ),
    }
}

AI_EXTRACT_INSTRUCTIONS = """
Act as a strategic retail merchandising title editor for a mobile,
visual-first shopping experience.

Generate only the short product title.

TITLE RULES

1. Prefer a title of 40 characters or fewer.
2. Never exceed 65 characters.
3. Put the shortest accurate generic product type early.
4. Keep the original manufacturer's brand only when it materially
   differentiates the product.
5. Never substitute the retailer or merchant name for the manufacturer.
6. Keep a model or product line only when it helps identify the item.
7. Remove repeated nouns, marketing language, redundant adjectives,
   unnecessary punctuation, and internal item codes.
8. Remove size, dimensions, capacity, weight, volume, color, material,
   pack count, and feature tags by default.
9. Retain those attributes only when required to distinguish the
   purchasable product variant.
10. Preserve paper size, shipping-box dimensions, furniture dimensions,
    apparel size, technology capacity or screen size, grocery weight or
    volume, and printing compatibility only when needed for that class.
11. Use only information explicitly supported by the original title.
12. Never invent a brand, product type, model, size, color, capacity,
    feature, compatibility value, or product claim.
13. Do not truncate words.
14. Do not add an explanation to the title.
15. Return only the natural customer-facing short title in short_title.
""".strip()

schema_json = json.dumps(AI_EXTRACT_SCHEMA, ensure_ascii=True, separators=(",", ":"))
schema_check = json.loads(schema_json)
if "type" in schema_check or "properties" in schema_check:
    raise ValueError("Invalid AI_EXTRACT schema wrapper detected. Use direct field mapping.")
for field_name, field_definition in schema_check.items():
    if not isinstance(field_definition, dict):
        raise ValueError(f"Schema field '{field_name}' must map to an object.")
    if field_definition.get("type") != "string":
        raise ValueError(f"Schema field '{field_name}' must use type='string'.")
    if not field_definition.get("description"):
        raise ValueError(f"Schema field '{field_name}' must include a description.")

SCHEMA_SQL = schema_json.replace("'", "''")
INSTRUCTIONS_SQL = AI_EXTRACT_INSTRUCTIONS.replace("'", "''")
# Part of every row's source_hash: a changed prompt or schema refreshes every title.
PROMPT_HASH = hashlib.sha256((schema_json + "\n" + AI_EXTRACT_INSTRUCTIONS).encode("utf-8")).hexdigest()

# ---------------------------------------------------------------------------
# Title check and the repair prompt
# ---------------------------------------------------------------------------
# Longest title the downstream readers accept.
MAX_TITLE_CHARS = 65
# Model answers that mean "no title".
EMPTY_ANSWERS = ("", "null", "none", "n/a", "unknown")
# A character count the model wrote after the title while checking its length, e.g. ' (40 chars)',
# ' (37 chars: "...")' or ' 57 characters'. It is removed and the title before it is kept.
_TRAILING_COUNT = re.compile(r"\s*(?:\(\s*\d+\s*(?:chars?|characters)\b[^)]*\)|\d+\s*(?:chars?|characters))\s*$",
                             re.IGNORECASE)
# The model's own working inside a title: counting, correcting itself, or the prompt's rule text.
_AI_NOTES = re.compile(r"\(\s*\d+\s*(?:chars?|characters)\b|=\s*\d+\s*(?:chars?|characters)\b|let'?s recount"
                       r"|preservation rules|title rules|\bactually, i\b|\bi need to\b", re.IGNORECASE)
# The same word five or more times in a row, e.g. 'Canvas & & & & & &'.
_REPEATED_WORD = re.compile(r"(\S+)(?:\s+\1){4,}")
CHECKED_TITLE_TYPE = StructType([StructField("short_title", StringType()), StructField("issue", StringType())])

# Used only for titles that failed the check, so it is not part of PROMPT_HASH: changing it never
# refreshes the titles that passed.
REPAIR_SCHEMA = {
    "short_title": {
        "type": "string",
        "description": "A customer-facing product title of at most 65 characters, with no notes or explanation.",
    }
}
REPAIR_INSTRUCTIONS = """
Write a short customer-facing product title for a mobile shopping app.

RULES
1. At most 65 characters including spaces; about 40 is ideal.
2. Start with the generic product type; keep the brand when it matters.
3. To make it fit, drop in this order: pack count, color, material, extra sizes, model numbers.
4. Use only facts from the original title. Never add a detail.
5. Return only the title: no character counts, notes, quotes or explanations.

EXAMPLES
Original: Avery EcoFriendly Laser/Inkjet Rectangle Multipurpose Labels, 2-1/4" x 7-3/4", White, 40/Pack
Short title: Avery Laser/Inkjet Multipurpose Labels, 2-1/4" x 7-3/4"
Original: Safavieh Jasmine Cambridge 2'6" x 10' Runner Indoor Area Rug, Tufted, Wool, Silver/Ivory
Short title: Safavieh Jasmine Runner Rug, 2'6" x 10'
Original: Braun MultiServe Plus 10-Cup Automatic Drip Coffee Maker, Stainless Steel (KF9270SI)
Short title: Braun MultiServe 10-Cup Coffee Maker
""".strip()
REPAIR_SCHEMA_SQL = json.dumps(REPAIR_SCHEMA, ensure_ascii=True, separators=(",", ":")).replace("'", "''")
REPAIR_INSTRUCTIONS_SQL = REPAIR_INSTRUCTIONS.replace("'", "''")


def ai_extract_sql(content_sql: str, schema_sql: str = SCHEMA_SQL, instructions_sql: str = INSTRUCTIONS_SQL) -> str:
    """ai_extract over a SQL expression holding the prompt content (the main prompt unless told otherwise)."""
    return (
        f"ai_extract({content_sql}, '{schema_sql}', "
        f"options => map('version', '2.1', 'instructions', '{instructions_sql}'))"
    )


# ---------------------------------------------------------------------------
# Decisions (pure functions, unit-tested)
# ---------------------------------------------------------------------------
def is_transient_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in TRANSIENT_MARKERS)


def fallback_decision(table_exists: bool, days_since_last_success, max_title_age_days: float) -> str:
    """'keep' when the titles of the last successful run may stand in for this run, else 'raise'.

    Keeping is allowed only when the table exists and the last successful run is recent enough.
    Days are counted from the last successful run, not the last row write: a steady catalog
    writes few rows, and that must not look stale.
    """
    if not table_exists or days_since_last_success is None:
        return "raise"
    return "keep" if days_since_last_success <= max_title_age_days else "raise"


def clean_title(text):
    """The model's title with whitespace collapsed, a trailing character count and wrapping quotes removed."""
    if text is None:
        return None
    title = _TRAILING_COUNT.sub("", re.sub(r"\s+", " ", text).strip()).strip()
    if len(title) > 1 and title[0] == title[-1] == '"' and '"' not in title[1:-1]:
        title = title[1:-1].strip()
    return title


def title_issue(title, max_chars: int = MAX_TITLE_CHARS):
    """Why a cleaned title cannot be used ('empty', 'no_words', 'ai_notes', 'junk', 'too_long'), or None."""
    if title is None or title.strip().lower() in EMPTY_ANSWERS:
        return "empty"
    if not re.search(r"[A-Za-z]", title):
        return "no_words"
    if _AI_NOTES.search(title):
        return "ai_notes"
    if _REPEATED_WORD.search(title):
        return "junk"
    if len(title) > max_chars:
        return "too_long"
    return None


def check_title(text, max_chars: int = MAX_TITLE_CHARS):
    """(short_title, issue): the cleaned title when it can be used, else (None, the reason)."""
    title = clean_title(text)
    issue = title_issue(title, max_chars)
    return (None, issue) if issue else (title, None)


# ---------------------------------------------------------------------------
# Probe and source guards
# ---------------------------------------------------------------------------
def probe_ai_extract(spark) -> None:
    """Fail the task now if ai_extract cannot run here. Never skips."""
    try:
        row = spark.sql(f"SELECT to_json({ai_extract_sql(PROBE_CONTENT_SQL)}) AS r").first()
    except Exception as exc:
        raise RuntimeError(f"ai_extract is not usable on this cluster: {exc}") from exc
    if row is None or not row["r"]:
        raise RuntimeError("ai_extract probe returned no result")
    logger.info("ai_extract probe passed")


def check_source_keys(raw_df: DataFrame) -> None:
    """Refuse to write when item_id is missing or repeated in the source."""
    null_keys = raw_df.where(F.col(KEY_COLUMN).isNull()).count()
    if null_keys:
        raise ValueError(f"Source has {null_keys} rows with null {KEY_COLUMN}; refusing to write.")
    total = raw_df.count()
    distinct = raw_df.select(KEY_COLUMN).distinct().count()
    if total != distinct:
        raise ValueError(f"Source has {total - distinct} duplicate rows for {KEY_COLUMN}; refusing to write.")


def check_drop_rate(spark, source_count: int, output_table: str, max_source_drop_rate: float) -> None:
    """Refuse deletions when the source population fell by more than the allowed rate."""
    if not spark.catalog.tableExists(output_table):
        return
    target_count = spark.table(output_table).select(KEY_COLUMN).distinct().count()
    if target_count and source_count < target_count * (1 - max_source_drop_rate):
        drop_rate = 1 - source_count / target_count
        raise ValueError(
            f"Source population dropped by {drop_rate:.2%} ({target_count} to {source_count}), "
            f"above the allowed {max_source_drop_rate:.2%}; refusing source-driven deletion."
        )


# ---------------------------------------------------------------------------
# Transformations
# ---------------------------------------------------------------------------
def clean_source(raw_df: DataFrame) -> DataFrame:
    """One row per item_id with a whitespace-normalised title of 3+ characters.

    Taxonomy: the Staples.com value, else the SB (_contract) value.
    """
    taxonomy = [
        F.coalesce(F.col(level).cast("string"), F.col(f"{level}_contract").cast("string")).alias(level)
        for level in TAXONOMY_LEVELS
    ]
    return (
        raw_df.select(
            KEY_COLUMN,
            "upc",
            F.trim(F.regexp_replace(F.col("title").cast("string"), r"\s+", " ")).alias("title"),
            *taxonomy,
        )
        .where(F.col(KEY_COLUMN).isNotNull() & F.col("title").isNotNull() & (F.length("title") >= 3))
    )


def _family_expr():
    taxonomy_text = F.lower(F.concat_ws(" ", *[F.coalesce(F.col(c), F.lit("")) for c in TAXONOMY_LEVELS]))
    expr = None
    for family_name, pattern in FAMILY_PATTERNS:
        condition = taxonomy_text.rlike(pattern)
        expr = F.when(condition, F.lit(family_name)) if expr is None else expr.when(condition, F.lit(family_name))
    return expr.otherwise(F.lit("GENERAL"))


def build_ai_input(source_df: DataFrame) -> DataFrame:
    """Merchandising family, the prompt content, and source_hash (content, UPC and prompt)."""
    taxonomy_str = F.concat_ws(" > ", *[F.coalesce(F.col(c), F.lit("")) for c in TAXONOMY_LEVELS])
    return (
        source_df.withColumn("merchandising_family", _family_expr())
        .withColumn(
            "ai_extract_content",
            F.concat_ws(
                "\n",
                F.concat(F.lit("ORIGINAL TITLE: "), F.col("title")),
                F.concat(F.lit("TAXONOMY: "), taxonomy_str),
                F.concat(F.lit("MERCHANDISING FAMILY: "), F.col("merchandising_family")),
            ),
        )
        .withColumn(
            "source_hash",
            F.sha2(
                F.concat_ws(
                    "||",
                    F.col("ai_extract_content"),
                    F.coalesce(F.col("upc").cast("string"), F.lit("")),
                    F.lit(PROMPT_HASH),
                ),
                256,
            ),
        )
    )


def _saved_issue(saved: DataFrame):
    """short_title_issue of the saved rows; NULL for a table written before the column existed."""
    return F.col("short_title_issue") if "short_title_issue" in saved.columns else F.lit(None).cast("string")


def _saved_attempts(saved: DataFrame):
    """short_title_attempts of the saved rows, 0 when unset."""
    if "short_title_attempts" in saved.columns:
        return F.coalesce(F.col("short_title_attempts"), F.lit(0))
    return F.lit(0)


def select_rows_needing_title(spark, ai_input_df: DataFrame, output_table: str) -> DataFrame:
    """Products that are new, whose source_hash changed, or without a title and without a recorded reason.

    A title that failed the check has a reason; it goes to the repair prompt instead (select_titles_to_repair).
    """
    if not spark.catalog.tableExists(output_table):
        return ai_input_df
    saved = spark.table(output_table)
    existing = saved.select(
        F.col(KEY_COLUMN).alias("_t_key"),
        F.col("source_hash").alias("_t_hash"),
        F.col("short_title").alias("_t_title"),
        _saved_issue(saved).alias("_t_issue"),
    )
    return (
        ai_input_df.join(existing, F.col(KEY_COLUMN) == F.col("_t_key"), "left")
        .where(
            F.col("_t_key").isNull()
            | ~F.col("source_hash").eqNullSafe(F.col("_t_hash"))
            | (F.col("_t_title").isNull() & F.col("_t_issue").isNull())
        )
        .drop("_t_key", "_t_hash", "_t_title", "_t_issue")
    )


def select_titles_to_repair(spark, ai_input_df: DataFrame, output_table: str, max_repair_attempts: int) -> DataFrame:
    """Saved products whose title failed the check and that have repair attempts left, with their prompt content."""
    saved = spark.table(output_table)
    failed = (
        saved.where(F.col("short_title").isNull() & _saved_issue(saved).isNotNull()
                    & (_saved_attempts(saved) < max_repair_attempts))
        .select(KEY_COLUMN, "upc", "title", "merchandising_family", "short_title", "source_hash",
                _saved_attempts(saved).alias("short_title_attempts"))
    )
    return failed.join(ai_input_df.select(KEY_COLUMN, "ai_extract_content"), KEY_COLUMN)


def log_pending_breakdown(spark, ai_input_df: DataFrame, output_table: str) -> None:
    """LOG ONLY: why each product is (or is not) going to ai_extract. Never stops the run."""
    try:
        total = ai_input_df.count()
        if not spark.catalog.tableExists(output_table):
            logger.info(
                "Short title scope (first run, table not found):\n"
                "  products in source      : %d\n"
                "  new (to ai_extract)     : %d\n"
                "  hash changed            : 0\n"
                "  previous title NULL     : 0\n"
                "  unchanged (skipped)     : 0", total, total)
            return
        saved = spark.table(output_table)
        existing = saved.select(
            F.col(KEY_COLUMN).alias("_t_key"),
            F.col("source_hash").alias("_t_hash"),
            F.col("short_title").alias("_t_title"),
            _saved_issue(saved).alias("_t_issue"),
        )
        joined = ai_input_df.join(existing, F.col(KEY_COLUMN) == F.col("_t_key"), "left")
        is_new = F.col("_t_key").isNull()
        hash_changed = ~is_new & ~F.col("source_hash").eqNullSafe(F.col("_t_hash"))
        title_null = ~is_new & ~hash_changed & F.col("_t_title").isNull() & F.col("_t_issue").isNull()
        stats = joined.agg(
            F.sum(is_new.cast("int")).alias("new"),
            F.sum(hash_changed.cast("int")).alias("changed"),
            F.sum(title_null.cast("int")).alias("null_title"),
        ).first()
        new, changed, null_title = (stats[k] or 0 for k in ("new", "changed", "null_title"))
        logger.info(
            "Short title scope:\n"
            "  products in source      : %d\n"
            "  new (to ai_extract)     : %d\n"
            "  hash changed (to ai)    : %d\n"
            "  previous title NULL     : %d (retried)\n"
            "  unchanged (skipped)     : %d",
            total, new, changed, null_title, total - new - changed - null_title)
    except Exception as error:
        logger.warning("Short title scope summary skipped (%s)", error)


def _ai_title(schema_sql: str = SCHEMA_SQL, instructions_sql: str = INSTRUCTIONS_SQL):
    """The short_title value of an ai_extract call over ai_extract_content."""
    return F.get_json_object(F.to_json(F.expr(ai_extract_sql("ai_extract_content", schema_sql, instructions_sql))),
                             "$.response.short_title.value")


def _with_checked_title(df: DataFrame, raw_title, attempts, max_title_chars: int) -> DataFrame:
    """df with the checked title, its issue, the attempt count and updated_at, in OUTPUT_COLUMNS order."""
    check = F.udf(lambda text: check_title(text, max_title_chars), CHECKED_TITLE_TYPE)
    return (
        df.withColumn("_checked", check(raw_title))
        .withColumn("short_title", F.col("_checked.short_title"))
        .withColumn("short_title_issue", F.col("_checked.issue"))
        .withColumn("short_title_attempts", attempts.cast("int"))
        .withColumn("updated_at", F.current_timestamp())
        .select(*OUTPUT_COLUMNS)
    )


def generate_short_titles(pending_df: DataFrame, max_title_chars: int = MAX_TITLE_CHARS) -> DataFrame:
    """Call ai_extract and check the result; short_title is NULL, with the reason, when it cannot be used."""
    return _with_checked_title(pending_df, _ai_title(), F.lit(0), max_title_chars)


def repair_short_titles(failed_df: DataFrame, max_title_chars: int = MAX_TITLE_CHARS) -> DataFrame:
    """Ask again with the stricter repair prompt; each call counts as one repair attempt."""
    return _with_checked_title(failed_df, _ai_title(REPAIR_SCHEMA_SQL, REPAIR_INSTRUCTIONS_SQL),
                               F.col("short_title_attempts") + 1, max_title_chars)


def recheck_saved_titles(spark, output_table: str, max_title_chars: int = MAX_TITLE_CHARS) -> int:
    """Run the title check over the saved titles, with no AI call, and save what it changes.

    This catches titles saved before the check existed: a trailing character count is removed, and a
    title that still fails is set to NULL with its reason, which sends it to the repair prompt.
    Returns the number of rows changed.
    """
    saved = spark.table(output_table)
    check = F.udf(lambda text: check_title(text, max_title_chars), CHECKED_TITLE_TYPE)
    changed = (
        saved.where(F.col("short_title").isNotNull())
        .withColumn("_checked", check(F.col("short_title")))
        .where(~F.col("_checked.short_title").eqNullSafe(F.col("short_title")))
        .withColumn("short_title", F.col("_checked.short_title"))
        .withColumn("short_title_issue", F.col("_checked.issue"))
        .withColumn("short_title_attempts", _saved_attempts(saved).cast("int"))
        .withColumn("updated_at", F.current_timestamp())
        .select(*OUTPUT_COLUMNS)
    )
    count = changed.count()
    if count:
        validate_before_write(spark, output_table, changed.schema)
        merge_short_titles(spark, changed, output_table)
    return count


# ---------------------------------------------------------------------------
# Writes
# ---------------------------------------------------------------------------
def merge_short_titles(spark, titles_df: DataFrame, output_table: str) -> None:
    from delta.tables import DeltaTable

    (
        DeltaTable.forName(spark, output_table).alias("t")
        .merge(titles_df.alias("s"), f"t.{KEY_COLUMN} = s.{KEY_COLUMN}")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )


def delete_removed_products(spark, source_df: DataFrame, output_table: str) -> None:
    """Delete titles of products no longer in the source (including products whose title became unusable)."""
    from delta.tables import DeltaTable

    (
        DeltaTable.forName(spark, output_table).alias("t")
        .merge(source_df.select(KEY_COLUMN).alias("s"), f"t.{KEY_COLUMN} = s.{KEY_COLUMN}")
        .whenNotMatchedBySourceDelete()
        .execute()
    )


def write_with_retries(spark, pending_df: DataFrame, output_table: str, attempts: int, wait_seconds: float,
                       label: str = "", build=generate_short_titles) -> None:
    """Build the titles (generate_short_titles unless told otherwise) and write them. Transient errors are
    retried; other errors raise at once.

    A MERGE is atomic, so a retry never repeats rows that were already written.
    """
    for attempt in range(1, attempts + 1):
        try:
            titles_df = build(pending_df)
            validate_before_write(spark, output_table, titles_df.schema)
            if spark.catalog.tableExists(output_table):
                logger.info("Merging titles%s into %s", label, output_table)
                merge_short_titles(spark, titles_df, output_table)
                logger.info("Merge complete: %s", output_table)
            else:
                logger.info("Table %s not found - creating it with the titles%s", output_table, label)
                titles_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(output_table)
                logger.info("Table created: %s", output_table)
            return
        except Exception as exc:
            if not is_transient_error(exc):
                raise
            if attempt == attempts:
                raise TransientAIError(f"ai_extract still failing after {attempts} attempts: {exc}") from exc
            logger.warning("Transient ai_extract error (attempt %s of %s), retrying: %s", attempt, attempts, exc)
            time.sleep(wait_seconds * attempt)


def write_in_chunks(spark, pending_df: DataFrame, pending_count: int, output_table: str, chunk_size: int,
                    attempts: int, wait_seconds: float, build=generate_short_titles, stage: str = "ai_extract") -> None:
    """Send the pending products to ai_extract one chunk at a time and save each chunk as it finishes.

    The log shows how many products are done and the estimated time left after every chunk. A failure
    keeps the finished chunks, and the next run only picks up the products still without a title.
    Products are put in chunks by a hash of the key, so a chunk is the same set of products even though
    the pending list shrinks as chunks are written.
    """
    chunk_count = max(1, -(-pending_count // chunk_size))
    started = time.monotonic()
    for index in range(chunk_count):
        chunk_df = pending_df
        if chunk_count > 1:
            chunk_df = pending_df.where(F.pmod(F.xxhash64(F.col(KEY_COLUMN)), F.lit(chunk_count)) == index)
        logger.info("%s chunk %d/%d started", stage, index + 1, chunk_count)
        chunk_started = time.monotonic()
        write_with_retries(spark, chunk_df, output_table, attempts, wait_seconds,
                           label=f" ({stage} chunk {index + 1}/{chunk_count})", build=build)
        elapsed = time.monotonic() - started
        done = min(pending_count, round(pending_count * (index + 1) / chunk_count))
        # Chunks are about equal in size, so the average chunk time gives the estimate.
        eta_minutes = elapsed / (index + 1) * (chunk_count - index - 1) / 60
        logger.info(
            "%s chunk %d/%d saved in %.1f min | %d of %d products done (%.0f%%) | "
            "elapsed %.1f min | estimated remaining %.1f min",
            stage, index + 1, chunk_count, (time.monotonic() - chunk_started) / 60, done, pending_count,
            100.0 * done / pending_count, elapsed / 60, eta_minutes)


def mark_success(spark, output_table: str) -> None:
    """Record the time of this successful run as a table property."""
    stamp = datetime.now(timezone.utc).isoformat()
    spark.sql(f"ALTER TABLE {output_table} SET TBLPROPERTIES ('{LAST_SUCCESS_PROPERTY}' = '{stamp}')")


def days_since_last_success(spark, output_table: str):
    """Days since the last successful run, or None when there is no table or no record."""
    if not spark.catalog.tableExists(output_table):
        return None
    rows = spark.sql(f"SHOW TBLPROPERTIES {output_table} ('{LAST_SUCCESS_PROPERTY}')").collect()
    if not rows:
        return None
    last = datetime.fromisoformat(rows[0]["value"])
    return (datetime.now(timezone.utc) - last).total_seconds() / 86400


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
def run_short_titles_pipeline(spark, source_table: str, output_table: str, transient_retry_attempts: int = 3,
                              max_title_age_days: float = 3, max_source_drop_rate: float = 0.5,
                              retry_wait_seconds: float = 30, chunk_size: int = 10000,
                              max_title_chars: int = MAX_TITLE_CHARS, max_repair_attempts: int = 2) -> None:
    run_started = time.monotonic()
    table_found = spark.catalog.tableExists(output_table)
    run_mode = "INCREMENTAL" if table_found else "FULL (first run)"
    logger.info("Short titles run mode: %s | output table %s %s", run_mode, output_table,
                "found" if table_found else "not found - will be created")
    probe_ai_extract(spark)

    raw_df = read_all_products(spark, source_table, SOURCE_COLUMNS)
    check_source_keys(raw_df)
    source_df = clean_source(raw_df)
    check_drop_rate(spark, source_df.count(), output_table, max_source_drop_rate)

    # The MERGE reads its source more than once; materialising it keeps ai_extract at one call per row.
    spark.conf.set("spark.databricks.delta.merge.materializeSource", "all")

    ai_input_df = build_ai_input(source_df)
    log_pending_breakdown(spark, ai_input_df, output_table)
    pending_df = select_rows_needing_title(spark, ai_input_df, output_table)
    pending_count = pending_df.count()  # no AI call yet
    logger.info("Products sent to ai_extract: %s", pending_count)
    if not pending_count:
        logger.info("No products need a new short title - ai_extract not called")

    repair_count = 0
    try:
        if pending_count:
            write_in_chunks(spark, pending_df, pending_count, output_table, chunk_size,
                            transient_retry_attempts, retry_wait_seconds,
                            build=lambda df: generate_short_titles(df, max_title_chars))
        if spark.catalog.tableExists(output_table):
            rechecked = recheck_saved_titles(spark, output_table, max_title_chars)
            repair_df = select_titles_to_repair(spark, ai_input_df, output_table, max_repair_attempts)
            repair_count = repair_df.count()  # no AI call yet
            logger.info("Saved titles changed by the title check: %s | sent to the repair prompt: %s",
                        rechecked, repair_count)
            if repair_count:
                write_in_chunks(spark, repair_df, repair_count, output_table, chunk_size,
                                transient_retry_attempts, retry_wait_seconds,
                                build=lambda df: repair_short_titles(df, max_title_chars), stage="repair")
        mark_success(spark, output_table)
    except TransientAIError as exc:
        age = days_since_last_success(spark, output_table)
        if fallback_decision(spark.catalog.tableExists(output_table), age, max_title_age_days) == "raise":
            raise
        logger.warning(
            "ai_extract unavailable: keeping existing short titles. Last successful run %.1f days ago "
            "(limit %s). %s products not refreshed. Cause: %s",
            age, max_title_age_days, pending_count, exc,
        )

    if spark.catalog.tableExists(output_table):
        rows_before_delete = spark.table(output_table).count()
        delete_removed_products(spark, source_df, output_table)
        saved = spark.table(output_table)
        summary = saved.agg(
            F.count("*").alias("rows"),
            F.sum(F.col("short_title").isNull().cast("int")).alias("null_titles"),
            F.sum((F.length("short_title") > max_title_chars).cast("int")).alias("over_limit"),
        ).first()
        reasons = (dict(saved.where(F.col("short_title_issue").isNotNull()).groupBy("short_title_issue").count().collect())
                   if "short_title_issue" in saved.columns else {})
        logger.info("Removed products deleted from the table: %s", rows_before_delete - summary["rows"])
        logger.info("Short titles table: rows=%s, NULL=%s (by reason: %s), over %s chars=%s",
                    summary["rows"], summary["null_titles"], reasons or "none", max_title_chars, summary["over_limit"])
        logger.info("Short titles run COMPLETE | mode %s | sent to ai_extract %s | sent to repair %s | table rows %s | "
                    "took %.1f min", run_mode, pending_count, repair_count, summary["rows"],
                    (time.monotonic() - run_started) / 60)


if __name__ == "__main__":
    spark = get_spark_session()
    # os.environ.setdefault("sf_env", "dev")
    config = read_config(GENERAL_CONFIG_PATH)["extract_product_short_titles"]
    run_short_titles_pipeline(
        spark,
        config["tables"]["source_table"],
        config["tables"]["output_table"],
        transient_retry_attempts=config["transient_retry_attempts"],
        max_title_age_days=config["max_title_age_days"],
        max_source_drop_rate=config["max_source_drop_rate"],
        chunk_size=config["chunk_size"],
        max_title_chars=config["max_title_chars"],
        max_repair_attempts=config["max_repair_attempts"],
    )
