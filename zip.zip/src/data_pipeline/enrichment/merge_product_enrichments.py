import os
import re
import sys
import time
import logging

from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, MapType, StructType

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Add project root to sys.path
try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, '..', '..', '..'))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, 'sql')):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, '..', '..', '..'))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from utils import (
    read_config, get_spark_session, align_table_schema, dotcom_names_in_all_bu,
)

GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
SQL_PATH = os.path.join(PROJECT_ROOT, "sql", "merge_product_enrichment_fields.sql")
INCLUSIVE_SQL_PATH = os.path.join(PROJECT_ROOT, "sql", "merge_product_enrichment_fields_inclusive.sql")


def table_config(general_config):
    """The tables the merge reads and writes, under the names the SQL file uses."""
    def output(section):
        return general_config[section]["tables"]["output_table"]

    return {
        "product_discovery_data_table": output("product_discovery_data"),
        "claims_table": output("claims"),
        "compatibility_table": output("compatibility"),
        "universal_attributes_table": output("universal_attributes"),
        "lifecycle_table": output("lifecycle"),
        "review_mining_table": output("review_mining"),
        "capacity_indicator_table": output("capacity_indicator"),
        "product_master_enriched": general_config["product_master_enriched"],
        "product_master_hist": general_config["product_master_hist"],
        "all_products_table": general_config["product_discovery_data"]["tables"]["all_bu_output_table"],
        "tags_table": general_config["tagging_all"]["tables"]["tags_table"],
        "short_titles_table": output("extract_product_short_titles"),
        "product_master_enriched_inclusive": general_config["product_master_enriched_inclusive"],
    }


# Columns of the inclusive table that hold the Staples.com value of a column with an SB
# (_contract) value next to it: product_master_enriched name -> inclusive name. The
# product_discovery_data columns are mapped by dotcom_names_in_all_bu; the rest keep their names.
DOTCOM_ENRICHMENT_NAMES = {
    "lifecycle_status": "lifecycle_status_dotcom",
    "compatible_item_ids": "compatible_item_ids_dotcom",
    "compatibility_json": "compatibility_json_dotcom",
    "faq_json": "faq_json_dotcom",
    "faq_summary_json": "faq_summary_json_dotcom",
    "quality_grade": "quality_grade_dotcom",
    "value_proposition_segment": "value_proposition_segment_dotcom",
}


def dotcom_names_in_inclusive():
    """Every product_master_enriched column name, mapped to its name in the inclusive table."""
    names = dotcom_names_in_all_bu()
    names.update(DOTCOM_ENRICHMENT_NAMES)
    return names


# === Schema drift guard ======================================================
# MERGE WITH SCHEMA EVOLUTION adds a brand-new TOP-LEVEL column to
# product_master_enriched, but the MERGE's explicit UPDATE SET / INSERT lists
# never assign it, so it would read NULL forever with nothing failing or
# warning. Catch that here instead. Nested struct fields are unaffected —
# target.faq_summary_json = source.faq_summary_json carries a new field inside
# the struct on its own, which is why only top-level additions need this.

# The ON clause key. Never appears in UPDATE SET, by design.
_MERGE_KEY = "item_id"


def _strip_sql_comments(text):
    """Drop `--` line comments, so a commented-out column reads as unassigned."""
    return re.sub(r"--[^\n]*", "", text)


def _merge_update_columns(sql_text):
    """Target columns assigned by the MERGE's WHEN MATCHED ... UPDATE SET list."""
    match = re.search(
        r"THEN\s+UPDATE\s+SET(.*?)WHEN\s+NOT\s+MATCHED",
        sql_text, re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return set()
    body = _strip_sql_comments(match.group(1))
    return {m.group(1).lower() for m in re.finditer(r"target\.(\w+)\s*=", body)}


def _merge_insert_column_list(sql_text):
    """Target columns named by the MERGE's WHEN NOT MATCHED THEN INSERT (...) list, in order."""
    match = re.search(
        r"WHEN\s+NOT\s+MATCHED\s+THEN\s+INSERT\s*\((.*?)\)\s*VALUES",
        sql_text, re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return []
    body = _strip_sql_comments(match.group(1))
    return [c.strip().lower() for c in body.split(",") if c.strip()]


def _merge_insert_columns(sql_text):
    """Target columns named by the MERGE's WHEN NOT MATCHED THEN INSERT (...) list."""
    return set(_merge_insert_column_list(sql_text))


def assert_merge_covers_staged(spark, sql_text):
    """
    Fail if enrichment_staged has a column the MERGE never assigns.

    Runs after the view exists but BEFORE the history INSERT — aborting later
    would leave product_master_hist rows describing changes the MERGE never
    applied.
    """
    staged = {c.lower() for c in spark.table("enrichment_staged").columns}
    missing_update = sorted(staged - _merge_update_columns(sql_text) - {_MERGE_KEY})
    missing_insert = sorted(staged - _merge_insert_columns(sql_text))

    if missing_update or missing_insert:
        raise ValueError(
            "enrichment_staged has column(s) the MERGE never assigns, so they "
            "would stay NULL in the target forever. Add them to "
            "sql/merge_product_enrichment_fields.sql.\n"
            f"  missing from UPDATE SET: {missing_update or 'none'}\n"
            f"  missing from INSERT:     {missing_insert or 'none'}"
        )

    logger.info(
        f"✓ Schema drift check passed: all {len(staged)} enrichment_staged "
        "column(s) are assigned by the MERGE."
    )


# === Change detection ========================================================
# A row is rewritten only when a column the MERGE updates really changed. The
# columns themselves are compared, so no change is missed and an unchanged row
# is never rewritten. The order of lists and maps is ignored at every level: the
# loader builds several lists with COLLECT_SET / COLLECT_LIST, whose order differs
# from run to run. Each side is read with its own table's types, so a column or a
# struct field the target does not have yet (MERGE WITH SCHEMA EVOLUTION adds it)
# counts as a change instead of failing the statement.

# Filled by the MERGE itself (CURRENT_TIMESTAMP()), not taken from the staged view.
_MERGE_OWN_COLUMNS = {"row_inserted_at", "row_updated_at"}
# Assigned by the MERGE but not compared: bookkeeping, the old fingerprint, and the time the
# tags last changed (it moves only with the tags, which are compared).
_NOT_COMPARED = {_MERGE_KEY, "row_updated_at", "source_row_hash", "tags_updated_at"}
_GENERATED_MARKERS = ("__HISTORY_STACK__", "__CHANGED_ROWS_T_S__", "__CHANGED_ROWS_TARGET_SOURCE__",
                      "__RUN_TS__", "__UPDATE_SET__", "__INSERT__")
_NESTED = (ArrayType, MapType, StructType)


def _quoted(name):
    """A SQL string literal."""
    return "'" + name.replace("\\", "\\\\").replace("'", "\\'") + "'"


def _normalized(data_type, expr, depth=0, stored=None):
    """SQL for `expr` that is equal exactly when the content is equal, whatever the order
    of its lists, maps and struct fields: arrays and maps become sorted arrays of strings,
    structs JSON with lower-case field names in sorted order, and a struct with nothing in it
    is NULL. A struct field missing on one side compares equal to a NULL one, because to_json
    leaves NULL fields out. `stored` is the target's type, given for a source value: its leaves are cast
    to it first, so the value compares as the MERGE would store it."""
    var = f"x{depth}"
    if isinstance(data_type, ArrayType):
        inner = stored.elementType if isinstance(stored, ArrayType) else None
        element = _as_text(data_type.elementType, var, depth + 1, inner)
        return f"array_sort(transform({expr}, {var} -> {element}))"
    if isinstance(data_type, MapType):
        key_type, value_type = (stored.keyType, stored.valueType) if isinstance(stored, MapType) else (None, None)
        key = _as_text(data_type.keyType, f"{var}.key", depth + 1, key_type)
        value = _as_text(data_type.valueType, f"{var}.value", depth + 1, value_type)
        return (f"array_sort(transform(map_entries({expr}), "
                f"{var} -> to_json(named_struct('k', {key}, 'v', {value}))))")
    if isinstance(data_type, StructType):
        stored_fields = ({f.name.lower(): f.dataType for f in stored.fields}
                         if isinstance(stored, StructType) else {})
        fields = ", ".join(
            f"{_quoted(f.name.lower())}, "
            f"{_as_text(f.dataType, f'{expr}.`{f.name}`', depth + 1, stored_fields.get(f.name.lower()))}"
            for f in sorted(data_type.fields, key=lambda f: f.name.lower())
        )
        # A struct with no non-NULL field counts as NULL: MERGE can store a NULL struct as one.
        return f"CASE WHEN {expr} IS NULL THEN NULL ELSE nullif(to_json(named_struct({fields})), '{{}}') END"
    if _other_scalar(stored, data_type):
        return f"try_cast({expr} AS {stored.simpleString()})"
    return expr


def _as_text(data_type, expr, depth=0, stored=None):
    """_normalized as a string, for use inside a list, map or struct."""
    if isinstance(data_type, (ArrayType, MapType)):
        return f"to_json({_normalized(data_type, expr, depth, stored)})"
    if isinstance(data_type, StructType):
        return _normalized(data_type, expr, depth, stored)
    return f"CAST({_normalized(data_type, expr, depth, stored)} AS STRING)"


def _other_scalar(stored, data_type):
    """True when a scalar is stored in the target with a different scalar type."""
    return (stored is not None and not isinstance(stored, _NESTED)
            and stored.simpleString() != data_type.simpleString())


def _differs(column, target_type, source_type, t, s):
    """NULL-safe: true when `column` differs between rows t and s. target_type is None
    when the target does not have the column yet."""
    t_col, s_col = f"{t}.`{column}`", f"{s}.`{column}`"
    if target_type is None:
        return f"({s_col} IS NOT NULL)"
    if target_type.simpleString() == source_type.simpleString():
        return f"NOT ({_normalized(source_type, t_col)} <=> {_normalized(source_type, s_col)})"
    # Types differ: compare the source value as the MERGE would store it in the target's type.
    return f"NOT ({_as_text(target_type, t_col)} <=> {_as_text(source_type, s_col, 0, target_type)})"


def _as_logged(data_type, expr, stored=None):
    """A value as the history table stores it: JSON for lists, maps and structs."""
    if data_type is None:
        return "CAST(NULL AS STRING)"
    if isinstance(data_type, _NESTED):
        return f"to_json({expr})"
    if _other_scalar(stored, data_type):
        return f"CAST(try_cast({expr} AS {stored.simpleString()}) AS STRING)"
    return f"CAST({expr} AS STRING)"


def run_timestamp():
    """One timestamp for every history row of this run, so a failed run can remove its own."""
    return f"timestamp_micros({time.time_ns() // 1000})"


def add_new_columns(spark, table, staged_schema, columns):
    """Add the columns the MERGE assigns but `table` does not have yet, typed as in the staged
    view, so the history step and the MERGE read them like any other column."""
    existing = {f.name.lower() for f in spark.table(table).schema.fields}
    types = {f.name.lower(): f.dataType for f in staged_schema.fields}
    new = [c for c in columns if c not in existing and c in types]
    if new:
        spark.sql(f"ALTER TABLE {table} ADD COLUMNS ("
                  + ", ".join(f"{_quoted_name(c)} {types[c].simpleString()}" for c in new) + ")")
        logger.info(f"Added column(s) to {table}: {new}")
    return new


def _quoted_name(name):
    """A SQL identifier."""
    return "`" + name.replace("`", "``") + "`"


def generated_sql(spark, staged_view, target_table, assigned, run_ts):
    """The generated SQL of the history step and the MERGE, keyed by marker: the change check
    over the assigned columns, and the UPDATE SET and INSERT lists (for a MERGE that assigns
    every staged column)."""
    staged = spark.table(staged_view).schema
    source = {f.name.lower(): f.dataType for f in staged.fields}
    columns = sorted(set(assigned) - _NOT_COMPARED)
    if not columns:
        raise ValueError("Found no UPDATE SET columns in the MERGE; cannot build the change check")
    missing = [c for c in assigned if c not in source and c not in _MERGE_OWN_COLUMNS]
    if missing:
        raise ValueError(f"UPDATE SET column(s) not in {staged_view}: {missing}")
    new_columns = add_new_columns(spark, target_table, staged, assigned)
    target = {f.name.lower(): f.dataType for f in spark.table(target_table).schema.fields}
    other_types = [c for c in columns
                   if c in target and target[c].simpleString() != source[c].simpleString()]

    def differs(c, t, s):
        return _differs(c, target.get(c), source[c], t, s)

    stack = ",\n      ".join(
        f"{_quoted(c)}, {_as_logged(target.get(c), f't.`{c}`')}, "
        f"{_as_logged(source[c], f's.`{c}`', target.get(c))}, {differs(c, 't', 's')}"
        for c in columns
    )
    logger.info(f"Change detection compares {len(columns)} column(s); added to the target: "
                f"{new_columns or 'none'}; type differs from the target: {other_types or 'none'}")
    return {
        "__HISTORY_STACK__": f"stack({len(columns)},\n      {stack}\n    )",
        "__CHANGED_ROWS_T_S__": "(" + "\n     OR ".join(differs(c, "t", "s") for c in columns) + ")",
        "__CHANGED_ROWS_TARGET_SOURCE__": "(" + "\n     OR ".join(
            differs(c, "target", "source") for c in columns) + ")",
        "__RUN_TS__": run_ts,
        "__UPDATE_SET__": ",\n  ".join(
            [f"target.{_quoted_name(c)} = source.{_quoted_name(c)}" for c in assigned]
            + ["target.row_updated_at = CURRENT_TIMESTAMP()"]),
        "__INSERT__": "({}) VALUES ({})".format(
            ", ".join(_quoted_name(c) for c in [_MERGE_KEY, *assigned, "row_inserted_at", "row_updated_at"]),
            ", ".join([f"source.{_quoted_name(c)}" for c in [_MERGE_KEY, *assigned]]
                      + ["CURRENT_TIMESTAMP()", "CURRENT_TIMESTAMP()"])),
    }


def _creates_view(statement):
    """True for the statement that creates the staged view, whatever comments come first."""
    return _strip_sql_comments(statement).strip().upper().startswith("CREATE OR REPLACE TEMPORARY VIEW")


def execute(spark, statement):
    """Run one statement and log the rows a MERGE or INSERT wrote."""
    logger.info(f'Executing: {statement[:100]}...')
    result_df = spark.sql(statement)
    kind = _strip_sql_comments(statement).strip().upper()
    if kind.startswith('MERGE'):
        metrics = result_df.collect()[0]
        logger.info(f"  → Insertions: {metrics['num_inserted_rows']} | Updates: "
                    f"{metrics['num_updated_rows']} | Deletes: {metrics['num_deleted_rows']}")
    elif kind.startswith('INSERT'):
        metrics = result_df.collect()[0]
        logger.info(f"  → Insertions (history changes logged): {metrics['num_affected_rows']} "
                    "| Updates: 0 | Deletes: 0")
    logger.info('✓ Success')


def merge(spark, sql_content, staged_view, target_table, run_ts, assigned=None, hist_table=None,
          check_drift=False, schema_align_enabled=True):
    """Run a merge SQL file's statements in order.

    The staged view is the first statement. Right after it: one row per item_id, the drift check
    (check_drift: the MERGE's own column lists must cover the view), and the target's column
    types brought in line with the view, all before any history row is written. assigned is the
    columns the MERGE assigns; None means every staged column, through the generated lists. If a
    statement fails, the history rows this run wrote are removed, so the history never describes
    a change the MERGE did not apply.
    """
    generated = {}
    try:
        for statement in sql_content.split(';'):
            statement = statement.strip()
            if not statement:
                continue
            markers = [m for m in _GENERATED_MARKERS if m in statement]
            if markers and not generated:
                columns = assigned or [c.lower() for c in spark.table(staged_view).columns
                                       if c.lower() != _MERGE_KEY]
                generated = generated_sql(spark, staged_view, target_table, columns, run_ts)
            for marker in markers:
                statement = statement.replace(marker, generated[marker])
            try:
                execute(spark, statement)
            except Exception as e:
                logger.error(f'✗ Error: {str(e)}')
                raise

            if _creates_view(statement):
                assert_one_row_per_item(spark, staged_view)
                if check_drift:
                    assert_merge_covers_staged(spark, sql_content)
                # Migrate the target's column types to the staged view's before the MERGE (overlap: staged is a subset).
                align_table_schema(
                    spark,
                    target_table,
                    spark.table(staged_view).schema,
                    mode="overlap",
                    enabled=schema_align_enabled,
                )
    except Exception:
        if hist_table:
            remove_history_rows(spark, hist_table, run_ts)
        raise


def assert_one_row_per_item(spark, staged_view):
    """Fail if an input table repeats a product: the MERGE would insert it twice."""
    repeated = (spark.table(staged_view).groupBy(_MERGE_KEY).count()
                .filter(F.col("count") > 1).limit(5).collect())
    if repeated:
        raise ValueError(f"{staged_view} has more than one row for {_MERGE_KEY} "
                         f"{[r[_MERGE_KEY] for r in repeated]}; an input table repeats a product")


# Filled by the master's MERGE itself, so not taken from the inclusive table.
_MASTER_OWN_COLUMNS = {"source_row_hash"} | _MERGE_OWN_COLUMNS


def build_dotcom_slice(spark, inclusive_table, sql_text, view="dotcom_slice"):
    """The Staples.com rows of the inclusive table under product_master_enriched's column names:
    every column the master's MERGE inserts, apart from the ones it fills itself."""
    names = dotcom_names_in_inclusive()
    columns = [c for c in _merge_insert_column_list(sql_text) if c not in _MASTER_OWN_COLUMNS]
    inclusive = spark.table(inclusive_table)
    have = {c.lower() for c in inclusive.columns}
    missing = [c for c in columns if names.get(c, c).lower() not in have]
    if missing:
        raise ValueError(f"{inclusive_table} has no column for product_master_enriched column(s) {missing}")
    (inclusive.filter(F.col("in_product_discovery_data"))
     .select(*[F.col(names.get(c, c)).alias(c) for c in columns])
     .createOrReplaceTempView(view))
    logger.info(f"{view}: the Staples.com rows of {inclusive_table}, {len(columns)} column(s)")


def remove_history_rows(spark, hist_table, run_ts):
    """Delete the history rows written with run_ts (a run that failed after Step 4)."""
    if spark.catalog.tableExists(hist_table):
        spark.sql(f"DELETE FROM {hist_table} WHERE changed_at = {run_ts}")
        logger.info(f"Removed this run's history rows from {hist_table}")


def check_row_count(spark, source_table, target_table):
    """Fail if the target does not hold exactly the source's number of products."""
    source_count = spark.table(source_table).count()
    target_count = spark.table(target_table).count()
    logger.info(f"  {source_table} row count: {source_count}")
    logger.info(f"  {target_table} row count: {target_count}")
    if source_count != target_count:
        raise ValueError(
            f"Row count mismatch! {source_table} has {source_count} rows "
            f"but {target_table} has {target_count} rows. "
            f"Delta: {target_count - source_count}"
        )


def main(spark=None, tables=None):
    """Merge every product into product_master_enriched_inclusive, then write its Staples.com
    slice into product_master_enriched. `tables` overrides general.yml."""
    general_config = read_config(GENERAL_CONFIG_PATH)
    tables = tables or table_config(general_config)
    # Rewrite a target table when a producer's column type has moved on.
    # Same switch review_mining reads; see utils.align_table_schema.
    schema_align_enabled = bool((general_config.get("schema_align") or {}).get("enabled", True))

    logger.info("Initializing Spark session...")
    spark = spark or get_spark_session()

    logger.info(f'Loading SQL from: {INCLUSIVE_SQL_PATH} and {SQL_PATH}')
    with open(INCLUSIVE_SQL_PATH, 'r') as f:
        inclusive_sql = f.read().format(**tables)
    with open(SQL_PATH, 'r') as f:
        sql_content = f.read().format(**tables)
    run_ts = run_timestamp()

    # 1. Every product of both sites
    merge(spark, inclusive_sql, "inclusive_staged", tables["product_master_enriched_inclusive"], run_ts,
          schema_align_enabled=schema_align_enabled)
    check_row_count(spark, tables["all_products_table"], tables["product_master_enriched_inclusive"])

    # 2. Its Staples.com slice, with the field-level history
    build_dotcom_slice(spark, tables["product_master_enriched_inclusive"], sql_content)
    merge(spark, sql_content, "enrichment_staged", tables["product_master_enriched"], run_ts,
          assigned=sorted(_merge_update_columns(sql_content)), hist_table=tables["product_master_hist"],
          check_drift=True, schema_align_enabled=schema_align_enabled)
    logger.info('\n✓ All-category enrichment fields merged successfully!')

    # === Validation: discovery_data vs product_master_enriched row count ===
    logger.info("Running post-merge validation...")
    check_row_count(spark, tables["product_discovery_data_table"], tables["product_master_enriched"])


if __name__ == "__main__":
    main()
