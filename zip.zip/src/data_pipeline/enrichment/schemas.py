from pyspark.sql.types import (
    ArrayType, DoubleType, IntegerType, MapType, StringType, StructField, StructType,
)


CLAIM_STRUCT_TYPE = ArrayType(StructType([
    StructField("claim_type", StringType(), True),
    StructField("confidence", DoubleType(), True),
    StructField("pattern", StringType(), True),
    StructField("source", StringType(), True),
    StructField("source_text", StringType(), True),
    StructField("text", StringType(), True),
    StructField("unit", StringType(), True),
    StructField("value", StringType(), True),
]))


STRING_MAP_SCHEMA = MapType(StringType(), StringType())


COMPLIANCE_TAGS_SCHEMA = ArrayType(StructType([
    StructField("name", StringType(), True),
    StructField("source", StringType(), True),
    StructField("confidence", IntegerType(), True),
]))


REVIEW_SIGNALS_SCHEMA = ArrayType(StructType([
    StructField("issue_key", StringType()),
    StructField("issue_title", StringType()),
    StructField("severity", StringType()),
    StructField("confidence", DoubleType()),
    StructField("confidence_band", StringType()),
    StructField("matched_terms", ArrayType(StringType())),
    StructField("evidence_spans", ArrayType(StringType())),
    StructField("source", StringType()),
    StructField("review_id", StringType()),
    StructField("rating", DoubleType()),
    StructField("qa_id", StringType()),
    StructField("helpful_votes", DoubleType()),
]))


KNOWN_ISSUES_SCHEMA = ArrayType(StructType([
    StructField("issue_key", StringType()),
    StructField("frequency", IntegerType()),
    StructField("max_confidence", DoubleType()),
    StructField("evidence_spans", ArrayType(StringType())),
]))


# NOTE: unused and stale. The live faq_json schema is review_mining._FAQ_SCHEMA,
# which has more fields and types `answer` as ARRAY<STRING>. Kept only so the
# field names here do not contradict what the pipeline actually writes.
FAQ_SCHEMA = ArrayType(StructType([
    StructField("question", StringType()),
    StructField("answer", StringType()),
    StructField("source", StringType()),
    StructField("question_id", StringType()),
    StructField("submission_date", StringType()),
]))


ISSUE_FREQUENCY_SCHEMA = MapType(StringType(), IntegerType())