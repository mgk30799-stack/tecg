"""
Review & FAQ Mining — issue signals and FAQ summaries (Databricks PySpark).

Mines customer reviews for product issues by keyword / phrase / regex matching
against the taxonomy in config/issue_keywords.yaml, and aggregates the LLM FAQ
tags from product_faq_tags into per-product summaries.

FIELDS PRODUCED
    issue_signals_json  per-product issue detections
    issue_summary_json  aggregation of all issues
    faq_json            per-question LLM tags/keywords/scores, built directly
                        from product_faq_tags
    faq_summary_json    keyword-level aggregated FAQ summary
    reliability_score   0-100
    faq_json_contract, faq_summary_json_contract
                        the same for Staples Business: a copy of the two above when the
                        product has Staples.com questions, else built from its SB questions

Sites:
    Issue fields are per product, from every site's reviews, for every product of
    product_discovery_data_all. The Staples.com FAQ fields come from Staples.com questions only.

Usage:
    from review_mining import run_review_mining_pipeline

    run_review_mining_pipeline(
        spark,
        source_table="mld01_ml_de.product.product_discovery_data_all",
        output_table="review_mining_output",
    )
"""

import os
import re
import sys
import json
import logging
import string
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Optional, Any

import pandas as pd
import yaml
from pyspark.sql import DataFrame, SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    StringType, BooleanType, IntegerType, ArrayType,
    StructType, StructField, DoubleType,
)
# pyrefly: ignore [missing-import]
from utils import (
    save_data, get_spark_session, read_config, incremental_save_data,
    question_id_expr, resolve_question_keys, read_all_products,
    QUESTION_SITE_ID, CONTRACT_QUESTION_SITE_ID,
)
logger = logging.getLogger(__name__)

# =============================================================================
# PROJECT ROOT
# =============================================================================

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))


# =============================================================================
# INCREMENTAL PIPELINE HELPERS
# =============================================================================

def get_cutoff_ts(spark: SparkSession, output_table: str):
    """
    MAX(last_updated_ts) from the output table, or None on the first run.

    Used to filter the source tables so only reviews / Q&A newer than the last run
    are processed.
    """
    try:
        row = (
            spark.table(output_table)
            .agg(F.max("last_updated_ts").alias("cutoff"))
            .collect()[0][0]
        )
        if row is not None:
            logger.info("Cutoff timestamp derived: %s", row)
        else:
            logger.info("Output table exists but last_updated_ts is all NULL — full scan")
        return row
    except Exception:
        logger.info("Output table '%s' not found — first run, full scan", output_table)
        return None


# NOTE: incremental_save_data now lives in utils.py so faq_tagging can reuse it
# without importing this module (which would create an import cycle, since
# run_review_mining_pipeline imports faq_tagging.mine_faq_tags).


# Leading filler stripped before building a fallback keyword. Longest first so
# "do you know" wins over "do". These carry no search value, and taking the
# first two words past them is the difference between "tell me" and
# "how this mounts to the wall".
_FILLER_PREFIXES = (
    "can you please tell me", "i want to know", "does anyone know",
    "do you know if", "can you tell me", "i would like to know",
    "does anybody know", "can someone tell me", "i was wondering",
    "do you know", "does anyone", "does anybody", "can you", "could you",
    "would you", "i need to know", "i need", "please tell me", "tell me",
    "i am wondering", "im wondering", "just wondering",
)


# =============================================================================
# ANSWER SCORE RECENCY DECAY
#
# faq_tagging's answer_score is a TIMELESS content judgement (see reviews_prompts
# for why age is kept out of the prompt). The staleness half is applied here,
# deterministically, from the answer's real submission timestamp — so it
# recomputes for free every run, is reproducible, and is testable without Spark.
# =============================================================================

# Fallbacks used when faq_config.yaml carries no answer_score_decay block, so
# the decay never silently becomes a no-op if the config is missing a key.
#
# Bands mirror _RECENCY_SCHEMA / _bucket_ts exactly — under_30 / 30_to_60 /
# 60_to_90 / over_90 — so a decayed score and the recency histogram sitting next
# to it in faq_summary_json always agree about which bucket an answer is in.
_DEFAULT_SCORE_DECAY = {
    # Floor of -2, not -3: an ordinary answer going stale should slide down the
    # ranking, not fall off it. Only the time_bound tier is allowed to gut a
    # score outright.
    "default":    {"under_30": 0, "30_to_60": -1, "60_to_90": -2, "over_90": -2},
    "evergreen":  {"under_30": 0, "30_to_60": -1, "60_to_90": -1, "over_90": -1},
    "time_bound": {"under_30": 0, "30_to_60": -3, "60_to_90": -4, "over_90": -5},
}

_DEFAULT_EVERGREEN_TAGS = frozenset({
    "dimensions", "specification", "product_specification", "warranty",
    "capacity", "country_of_origin", "compatibility",
})


def _age_days(ts_str, now):
    """
    Whole days between an ISO-8601 timestamp string and `now` (negative clamps to 0),
    or None when unknown. Unknown is not treated as old.
    """
    if not ts_str:
        return None
    try:
        ts = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    try:
        return max(0, (now - ts).days)
    except (TypeError, OverflowError):
        return None


def _decay_tier(age_days: int, tier: dict) -> int:
    """
    Penalty for an age, from one tier's band table.

    Bands are half-open [low, high) and are the SAME cutoffs _bucket_ts uses for the
    recency histogram: <30, 30-59, 60-89, 90+. Keep them in step — an answer counted
    under 60_to_90_days in question_recency must not be scored from a different band.
    """
    if age_days < 30:
        return int(tier.get("under_30", 0))
    if age_days < 60:
        return int(tier.get("30_to_60", 0))
    if age_days < 90:
        return int(tier.get("60_to_90", 0))
    return int(tier.get("over_90", 0))


def decay_answer_score(
    content_score,
    age_days,
    time_bound,
    evergreen,
    decay_cfg=None,
):
    """
    Turn faq_tagging's content score into the recency-adjusted 0-10 score.

    Args:
        content_score: 0-10 from the LLM, or None.
        age_days:      Age of the answer in days, or None (no penalty).
        time_bound:    LLM verdict that the answer's truth expires; wins over evergreen.
        evergreen:     Question asks about a standing fact (specs, warranty, dimensions).
        decay_cfg:     Band tables from faq_config.yaml.

    Returns:
        int in 0-10, or None when content_score is None.
    """
    if content_score is None:
        return None
    try:
        score = int(content_score)
    except (TypeError, ValueError):
        return None

    if age_days is not None:
        cfg = decay_cfg or _DEFAULT_SCORE_DECAY
        if time_bound:
            name = "time_bound"
        elif evergreen:
            name = "evergreen"
        else:
            name = "default"
        tier = cfg.get(name) or _DEFAULT_SCORE_DECAY[name]
        score += _decay_tier(age_days, tier)

    return max(0, min(10, score))


_ANSWERS_META_TYPE = ArrayType(StructType([
    StructField("position", IntegerType()),
    StructField("answer_keyword", StringType()),
    StructField("answer_tags", ArrayType(StringType())),
    StructField("answer_score", IntegerType()),
    # Whether this answer's truth expires — selects the decay table in
    # decay_answer_score. Must stay field-for-field identical to
    # faq_tagging.TAG_TABLE_SCHEMA's answers_meta struct: _attach_question_tags
    # coalesces against this type, and Spark RAISES rather than degrades when a
    # 4-field struct meets a 5-field one.
    StructField("time_bound", BooleanType()),
]))


def _attach_question_tags(
    df: DataFrame, tags_df: Optional[DataFrame] = None
) -> DataFrame:
    """
    Left-join question_tags, question_keyword, conflict_flag and answers_meta on tag_id.
    `tags_df` is this run's mine_faq_tags output; None yields typed NULL columns.
    """
    null_tags = F.lit(None).cast(ArrayType(StringType()))
    null_meta = F.lit(None).cast(_ANSWERS_META_TYPE)
    null_kw = F.lit(None).cast(StringType())
    null_conflict = F.lit(None).cast(BooleanType())

    def _degrade(reason_args=None):
        return (
            df.withColumn("question_tags", null_tags)
              .withColumn("question_keyword", null_kw)
              .withColumn("conflict_flag", null_conflict)
              .withColumn("answers_meta", null_meta)
        )

    if tags_df is None:
        logger.info("No FAQ tags this run — question topics from keywords only")
        return _degrade()

    try:
        # tags_df is this run's output, so a missing column is a real bug: let the select raise.
        faq_tags = tags_df.select(
            "tag_id", "question_tags", "question_keyword",
            "conflict_flag", "answers_meta",
        ).dropDuplicates(["tag_id"])
        return df.join(faq_tags, on="tag_id", how="left")
    except Exception as e:
        logger.warning(
            "Could not join FAQ tags (%s) — question topics from keywords only", e,
        )
        return _degrade()


# QUESTION_SITE_ID lives in utils alongside resolve_question_keys, which is
# the only thing that applies it. Imported above so the references in this
# module still read the one value discovery_data_loader filters on.
#
# The shapes of the maps resolve_question_keys emits (_question_meta_map /
# _answer_meta_map) are owned by utils now — this module only passes the frame
# through to faq_tagging and reads back the resolved columns.


def _resolve_question_keys(
    spark: SparkSession, df: DataFrame, site_id: str = QUESTION_SITE_ID
) -> Optional[DataFrame]:
    """
    Resolve every q_and_a question back to its SOURCE ROW in Snowflake, so faq_json
    can carry the real QUESTION_ID / ANSWER_ID and real submission timestamps.

    Thin wrapper over utils.resolve_question_keys — read that docstring for the text
    match, the site filter, the dedupe order and the duplicate-question-text limit.
    This wrapper supplies review_mining's table config and requests the answers
    table, which only this side wants (faq_tagging resolves question ids alone).

    Returns None whenever the keys cannot be had. Callers MUST treat None as "NULL
    question_id and empty timestamps", never as an error — an unreachable question
    table must not empty faq_json. Nothing is substituted for a missing question_id;
    tag_id in particular is not its fallback.
    """
    try:
        tables = _ensure_table_config()
        questions_table = tables["QUESTIONS_TABLE"]
        answers_table = tables["ANSWERS_TABLE"]
    except Exception as e:
        logger.warning(
            "FAQ key resolution has no table config (%s) — NULL question_id "
            "and empty submission_date in faq_json", e,
        )
        return None

    return resolve_question_keys(
        spark,
        df,
        questions_table=questions_table,
        answers_table=answers_table,
        site_id=site_id,
    )

# =============================================================================
# TABLE REFERENCES (lazy-loaded — importing the module won't crash)
# =============================================================================

# Values are mostly table-name strings, but FAQ_TAGS_OPTS holds a nested dict.
_table_config: Dict[str, Any] = {}


def _ensure_table_config() -> Dict[str, Any]:
    """Load table references from general.yml on first use."""
    if _table_config:
        return _table_config

    config_path = os.path.join(PROJECT_ROOT, "config", "general.yml")
    cfg = read_config(config_path)
    rm = cfg["review_mining"]["tables"]

    _table_config["REVIEW_TABLE"] = rm["REVIEW_TABLE"]
    _table_config["QUESTIONS_TABLE"] = rm["QUESTIONS_TABLE"]
    _table_config["ANSWERS_TABLE"] = rm["ANSWERS_TABLE"]
    _table_config["PRODUCT_CATALOG_TABLE"] = rm["PRODUCT_CATALOG_TABLE"]
    _table_config["SOURCE_TABLE"] = rm["source_table"]
    _table_config["OUTPUT_TABLE"] = rm["output_table"]
    # FAQ LLM tags. No table name here any more: review_mining consumes the
    # DataFrame mine_faq_tags returns and never reads the tag table, so where
    # faq_tagging chooses to persist is entirely its own business.
    # .get() so an un-migrated general.yml degrades to defaults rather than
    # raising KeyError at pipeline start.
    _table_config["FAQ_TAGS_OPTS"] = cfg["review_mining"].get("faq", {}) or {}
    # The union view over the two per-tagger tag tables is retired with them:
    # there is ONE tag table now (review_mining.tables.tag_table), per unit,
    # written by the unified tagger. None makes ensure_tag_union_view a no-op.
    _table_config["TAG_VIEW"] = None
    _table_config["ISSUE_TAGS_TABLE"] = None
    _table_config["FAQ_TAGS_TABLE"] = None
    # full_refresh: true reprocesses the whole catalogue instead of only what
    # changed since the last run — the way to re-tag items the incremental
    # cutoff has already moved past (e.g. a batch whose faq_json came out NULL).
    # Same switch faq_tagging exposes. Defaults False so a scheduled run stays
    # incremental if the key is absent.
    _table_config["FULL_REFRESH"] = bool(
        cfg["review_mining"].get("full_refresh", False)
    )
    # Let the pipeline migrate its own target schema (QA/PROD take no manual ALTER).
    _table_config["SCHEMA_ALIGN"] = bool(
        (cfg.get("schema_align") or {}).get("enabled", True)
    )
    return _table_config


# =============================================================================
# TAG UNION VIEW  (observability — nothing in the pipeline reads it)
# =============================================================================

# The columns the two tag tables genuinely share, in view order. Everything
# type-specific stays in its own table: faq's answers_meta / answer_id and
# issues' severity / confidence / matched_terms are all still one join away on
# (tag_type, tag_id), and hoisting them here would put ~25 permanently-NULL
# columns on every row for no query anyone actually runs.
#
# The two tables CANNOT be one physical table: product_faq_tags is one row per
# QUESTION and product_issue_tags is one row per DETECTED ISSUE, so they share
# no primary key and would need two writers MERGEing on different conditions
# into one target. A view costs nothing and keeps each writer's contract intact.
_TAG_VIEW_SQL = """
CREATE OR REPLACE VIEW {view} AS
SELECT
    'faq'                        AS tag_type,
    item_id,
    tag_id,
    CAST(NULL AS STRING)         AS source,
    question_id                  AS source_id,
    question                     AS source_text,
    question_tags                AS tags,
    question_keyword             AS keyword,
    model_endpoint,
    created_at_ts,
    last_updated_ts
FROM {faq_table}
UNION ALL
SELECT
    'issue'                      AS tag_type,
    item_id,
    tag_id,
    source,
    source_id,
    source_text,
    issue_tags                   AS tags,
    issue_key                    AS keyword,
    model_endpoint,
    created_at_ts,
    last_updated_ts
FROM {issue_table}
"""


def ensure_tag_union_view(spark: SparkSession) -> Optional[str]:
    """
    (Re)create the read-only view unioning product_faq_tags and product_issue_tags.
    Never fatal; returns the view name, or None when it could not be created.
    """
    cfg = _ensure_table_config()
    view = cfg.get("TAG_VIEW")
    faq_table = cfg.get("FAQ_TAGS_TABLE")
    issue_table = cfg.get("ISSUE_TAGS_TABLE")

    if not view:
        logger.debug("No review_mining.tag_view configured — skipping tag union view")
        return None
    if not (faq_table and issue_table):
        logger.info(
            "Tag union view skipped — need both faq_tagging.tables.output_table "
            "(%s) and review_mining.tables.ISSUE_TAGS_TABLE (%s)",
            faq_table, issue_table,
        )
        return None

    missing = [
        t for t in (faq_table, issue_table)
        if not _table_exists(spark, t)
    ]
    if missing:
        logger.info(
            "Tag union view %s skipped — table(s) not created yet: %s. Turn on "
            "faq_tagging.tag_table / review_mining.llm.tag_table and re-run.",
            view, ", ".join(missing),
        )
        return None

    try:
        spark.sql(_TAG_VIEW_SQL.format(
            view=view, faq_table=faq_table, issue_table=issue_table,
        ))
        logger.info("Tag union view ready: %s", view)
        return view
    except Exception as error:
        logger.warning("Could not create tag union view %s (%s)", view, error)
        return None


def _table_exists(spark: SparkSession, table: str) -> bool:
    """tableExists, but a thrown catalog error reads as 'no' rather than failing."""
    try:
        return bool(spark.catalog.tableExists(table))
    except Exception:
        return False


# The fields we produce
ISSUE_SIGNALS_FIELD = "issue_signals_json"
ISSUE_SUMMARY_FIELD = "issue_summary_json"
# Precomputed scalars derived from issue_summary_json. They exist as COLUMNS
# because Databricks Vector Search can only filter on synced columns, so an
# expression evaluated at query time is not a filter. The index sync that
# consumes them is a LATER PHASE and is deliberately not wired up here — see
# the STAGED FOR INDEX PHASE note in add_issue_features_from_llm.
HAS_HIGH_SEVERITY_FIELD = "has_high_severity_issue"
HAS_UNRESOLVED_FIELD = "has_unresolved_issue"
TOP_ISSUE_KEYS_FIELD = "top_issue_keys"
TOP_ISSUE_TAGS_FIELD = "top_issue_tags"
FAQ_TROUBLESHOOTING_FIELD = "faq_json"
FAQ_SUMMARY_FIELD = "faq_summary_json"
# Staples Business FAQ, shaped like the two above
FAQ_CONTRACT_FIELD = "faq_json_contract"
FAQ_SUMMARY_CONTRACT_FIELD = "faq_summary_json_contract"
RELIABILITY_SCORE_FIELD = "reliability_score"
MAINTENANCE_BURDEN_FIELD = "maintenance_burden_score"
SETUP_DIFFICULTY_FIELD = "setup_difficulty_score"


# =============================================================================
# 1.  YAML LOADER
# =============================================================================

def load_issue_keywords(yaml_path: str) -> dict:
    if not os.path.exists(yaml_path):
        raise FileNotFoundError(f"issue_keywords.yaml not found at: {yaml_path}")

    with open(yaml_path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    issue_count = len(data.get("issues", []))
    logger.info("Loaded issue_keywords.yaml: %d issue definitions", issue_count)
    return data


def load_faq_config(faq_yaml_path: str) -> dict:
    if not os.path.exists(faq_yaml_path):
        raise FileNotFoundError(f"faq_config.yaml not found at: {faq_yaml_path}")

    with open(faq_yaml_path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)

    faq_cfg = data.get("faq_troubleshooting", {})
    g_q = len(faq_cfg.get("global_question_keywords", []))
    g_a = len(faq_cfg.get("global_answer_keywords", []))
    n_cats = len(faq_cfg.get("per_category", {}))
    logger.info(
        "Loaded faq_config.yaml: %d global question kw, %d global answer kw, %d categories",
        g_q, g_a, n_cats,
    )
    return data


# =============================================================================
# 2.  TEXT NORMALISATION
# =============================================================================

_PUNCT_TABLE = str.maketrans("", "", string.punctuation)


def normalize_text(text: str) -> str:
    if not text:
        return ""
    text = text.lower()
    text = text.translate(_PUNCT_TABLE)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _is_empty(val) -> bool:
    """
    Safely check if a Pandas UDF value is null / empty.

    Handles None, np.nan, empty strings, empty lists, and numpy arrays (which raise
    ValueError on a bare ``not val``).
    """
    if val is None:
        return True
    try:
        if pd.isna(val):
            return True
    except (ValueError, TypeError):
        # pd.isna() raises ValueError on multi-element numpy arrays
        pass
    if isinstance(val, str) and not val.strip():
        return True
    if isinstance(val, (list, tuple)) and len(val) == 0:
        return True
    return False


# =============================================================================
# 3.  ISSUE DETECTION (per-review)
# =============================================================================

_SUPERCATEGORY_ALIAS = {
    "furniture":                         "Furniture",
    "cleaning supplies":                 "Cleaning Supplies",
    "facilities":                        "Facilities",
    "healthcare supplies":               "Healthcare Supplies",
    "safety supplies":                   "Safety Supplies",
    "batteries & power":                 "Batteries & Power",
    "printers & scanners":               "Printers & Scanners",
    "coffee, water & snacks":            "Coffee, Water & Snacks",
    "party supplies":                    "Party Supplies",
    "kitchen tools & appliances":        "Kitchen Tools & Appliances",
    "restaurant & foodservice supplies": "Restaurant & Foodservice Supplies",
    "bags, backpacks & luggage":         "Bags, Backpacks & Luggage",
}


def _resolve_category(raw_category: str) -> str:
    if not raw_category:
        return ""
    return _SUPERCATEGORY_ALIAS.get(raw_category.lower().strip(), raw_category.strip())


def _sentence_contains_negative(sentence: str,
                                global_negatives: List[str],
                                issue_negatives: List[str]) -> bool:
    all_negatives = global_negatives + issue_negatives
    for neg in all_negatives:
        if neg.lower() in sentence:
            return True
    return False


def detect_issues_in_review(
    review_text: str,
    category: str,
    issues: List[dict],
    scoring_cfg: dict,
    global_cfg: dict,
) -> List[dict]:
    if not review_text:
        return []

    norm_text = normalize_text(review_text)
    if not norm_text:
        return []

    kw_weight = scoring_cfg.get("keyword_weight", 1.0)
    phrase_weight = scoring_cfg.get("phrase_weight", 1.2)
    regex_weight = scoring_cfg.get("regex_weight", 1.5)
    severity_weights = scoring_cfg.get("severity_weight", {})
    global_negatives = global_cfg.get("negative_indicators_global", [])

    detections = []

    for issue in issues:
        applies_to = issue.get("applies_to_categories", [])
        if category and category not in applies_to:
            continue

        issue_key = issue.get("key", "unknown")
        issue_title = issue.get("title", issue_key)
        severity = issue.get("severity_default", "medium")
        issue_negatives = issue.get("negative_indicators", [])
        sev_multiplier = severity_weights.get(severity, 1.0)

        total_score = 0.0
        matched_terms = []

        keywords = issue.get("keywords", [])
        for kw in keywords:
            kw_norm = normalize_text(kw)
            if not kw_norm:
                continue
            idx = norm_text.find(kw_norm)
            while idx != -1:
                sentence_start = max(0, norm_text.rfind(".", 0, idx) + 1)
                sentence_end = norm_text.find(".", idx)
                if sentence_end == -1:
                    sentence_end = len(norm_text)
                sentence = norm_text[sentence_start:sentence_end]

                if _sentence_contains_negative(sentence, global_negatives, issue_negatives):
                    idx = norm_text.find(kw_norm, idx + len(kw_norm))
                    continue

                word_count = len(kw_norm.split())
                weight = phrase_weight if word_count > 1 else kw_weight
                total_score += weight
                matched_terms.append(kw)
                idx = norm_text.find(kw_norm, idx + len(kw_norm))

        regex_patterns = issue.get("regex", [])
        review_lower = review_text.lower() if review_text else ""
        for pattern_str in regex_patterns:
            try:
                for m in re.finditer(pattern_str, review_lower, re.IGNORECASE):
                    sent_start = max(0, review_lower.rfind(".", 0, m.start()) + 1)
                    sent_end = review_lower.find(".", m.end())
                    if sent_end == -1:
                        sent_end = len(review_lower)
                    sentence = review_lower[sent_start:sent_end]

                    if _sentence_contains_negative(sentence, global_negatives, issue_negatives):
                        continue

                    total_score += regex_weight
                    matched_str = m.group(0).strip()
                    if matched_str and matched_str not in matched_terms:
                        matched_terms.append(matched_str)
            except re.error as exc:
                logger.warning("Invalid regex '%s' for issue '%s': %s",
                               pattern_str, issue_key, exc)

        if total_score == 0:
            continue

        _RAW_CONF_CEILING = 5.0
        raw_confidence = total_score * sev_multiplier
        confidence = round(min(raw_confidence / _RAW_CONF_CEILING, 1.0), 4)

        if confidence >= 0.7:
            band = "high"
        elif confidence >= 0.4:
            band = "medium"
        else:
            band = "low"

        unique_matched_terms = list(dict.fromkeys(matched_terms))

        detections.append({
            "issue_key": issue_key,
            "issue_title": issue_title,
            "severity": severity,
            "confidence": confidence,
            "confidence_band": band,
            "matched_terms": unique_matched_terms,
        })

    return detections


# =============================================================================
# 4.  PER-PRODUCT AGGREGATION
# =============================================================================

def aggregate_signals_for_product(all_detections: List[dict]) -> Optional[str]:
    """
    The keyword fallback's issue_signals_json — projected onto _SIGNALS_SCHEMA.

    The detection dicts use the keyword era's own names (review_id / qa_id /
    review_create_dt / issue_title / rating), none of which _SIGNALS_SCHEMA
    carries. Dumped raw they are dropped by from_json without a word, and
    source_id and source_create_dt land NULL on every fallback row. Project
    explicitly instead, so the field list is visible next to the schema it has
    to match.

    issue_tags, affected_component, sentiment_score and root_cause are omitted
    because this path genuinely has none of them; they parse to NULL, which is
    the honest value.
    """
    if not all_detections:
        return None
    signals = sorted(all_detections, key=lambda x: x.get("confidence", 0.0), reverse=True)
    return json.dumps([
        {
            "issue_key":        d.get("issue_key"),
            "severity":         d.get("severity"),
            "confidence":       d.get("confidence"),
            "matched_terms":    d.get("matched_terms"),
            "source":           d.get("source"),
            # review_id and qa_id are one field downstream; `source` says which.
            "source_id":        d.get("review_id") or d.get("qa_id"),
            "source_create_dt": d.get("review_create_dt"),
        }
        for d in signals
    ], sort_keys=False)


# =============================================================================
# 4b. ISSUE SUMMARY
# =============================================================================

def build_issue_summary(
    all_detections: List[dict],
    item_id: Optional[str] = None,
    total_reviews: Optional[int] = None,
) -> Optional[str]:
    """
    Keyword fallback's issue_summary_json, in the same envelope as the LLM path
    (must match _ISSUE_SUMMARY_SCHEMA). Sentiment, root causes and components are
    empty and conflict_flag is False.
    """
    if not all_detections:
        return None

    now = datetime.now(timezone.utc)

    issue_map: Dict[str, dict] = {}

    for det in all_detections:
        key = det.get("issue_key", "unknown")
        review_id = det.get("review_id") or det.get("qa_id") or ""
        confidence = det.get("confidence", 0.0)
        source = det.get("source", "review")
        review_dt = det.get("review_create_dt")

        if key not in issue_map:
            issue_map[key] = {
                "issue_key": key,
                "max_confidence": 0.0,
                "review_ids": set(),
                "qa_ids": set(),
                "review_dates": [],
                "severities": [],
                "quotes": [],
            }

        entry = issue_map[key]
        if confidence > entry["max_confidence"]:
            entry["max_confidence"] = confidence

        severity = det.get("severity")
        if severity in _SEVERITIES:
            entry["severities"].append(severity)

        # Same rule as the LLM path's representative_quote: most confident
        # first, then longest. These spans are keyword matches against the
        # review text, so they are verbatim by construction.
        for term in (det.get("matched_terms") or []):
            if term:
                entry["quotes"].append((confidence, len(str(term)), str(term)))

        if source == "review":
            entry["review_ids"].add(review_id)
            if review_dt:
                entry["review_dates"].append(review_dt)
        else:
            entry["qa_ids"].add(review_id)

    issues: List[dict] = []

    for key, entry in issue_map.items():
        r_count = len(entry["review_ids"])
        q_count = len(entry["qa_ids"])
        freq = max(1, int(round(float(r_count) + 0.5 * float(q_count))))

        under_30 = 0
        btn_30_60 = 0
        btn_60_90 = 0
        over_90 = 0
        parsed_dates = []
        for dt_str in entry["review_dates"]:
            try:
                dt = datetime.strptime(str(dt_str).strip(), "%Y-%m-%d").replace(
                    tzinfo=timezone.utc
                )
                parsed_dates.append(dt)
                delta_days = (now - dt).days
                if delta_days < 30:
                    under_30 += 1
                elif 30 <= delta_days < 60:
                    btn_30_60 += 1
                elif 60 <= delta_days < 90:
                    btn_60_90 += 1
                else:
                    over_90 += 1
            except (ValueError, TypeError):
                over_90 += 1

        dist = {s: entry["severities"].count(s) for s in _SEVERITIES}
        # Modal band, ties broken upward — same rule as the LLM rollup.
        modal = max(
            _SEVERITIES, key=lambda s: (dist[s], _SEV_RANK[s]),
        ) if entry["severities"] else None

        # NULL, not "stable", when neither recent window has anything. Same
        # reasoning as the LLM path: there is no trend to report.
        if under_30 + btn_30_60 == 0:
            trend = None
        elif under_30 > btn_30_60 * _TREND_BAND:
            trend = "increasing"
        elif under_30 * _TREND_BAND < btn_30_60:
            trend = "decreasing"
        else:
            trend = "stable"

        quote = max(entry["quotes"])[2] if entry["quotes"] else None

        issues.append({
            "issue_key": key,
            "issue_tags": [],
            "top_components": [],
            "severity": modal,
            "severity_distribution": dist,
            "mention_count": freq,
            "mention_rate": (
                round(freq / total_reviews, 2) if total_reviews else None
            ),
            "representative_quote": quote,
            "top_root_causes": [],
            "unattributed_count": freq,
            "first_seen": min(parsed_dates).strftime("%Y-%m-%d") if parsed_dates else None,
            "last_seen": max(parsed_dates).strftime("%Y-%m-%d") if parsed_dates else None,
            "trend": trend,
            "recency_buckets": {
                "under_30_days": under_30,
                "30_to_60_days": btn_30_60,
                "60_to_90_days": btn_60_90,
                "over_90_days": over_90,
            },
            "conflict_flag": False,
        })

    if not issues:
        return None

    issues.sort(key=lambda x: x["mention_count"], reverse=True)

    severities_present = [i["severity"] for i in issues if i["severity"]]
    return json.dumps({
        "item_id": item_id,
        "total_reviews": total_reviews,
        "distinct_issues_found": len(issues),
        "max_severity": (
            max(severities_present, key=lambda s: _SEV_RANK[s])
            if severities_present else None
        ),
        # Keyword detections carry no sentiment at all — see the docstring.
        "overall_sentiment_avg": None,
        "issues": issues,
    }, sort_keys=False)


# =============================================================================
# 4d. RELIABILITY SCORING
# =============================================================================

def calculate_reliability_score(all_detections: List[dict], issue_config: dict) -> int:
    if not all_detections:
        return 100

    seen_review_issues = set()
    penalties = 0
    valid_keys = {issue["key"]: issue.get("severity_default", "medium") for issue in issue_config}

    for det in all_detections:
        key = det.get("issue_key")
        r_id = det.get("review_id")
        if not key or not r_id:
            continue
        sig_id = f"{r_id}_{key}"
        if sig_id in seen_review_issues:
            continue
        seen_review_issues.add(sig_id)

        severity = valid_keys.get(key, "medium").lower()
        if severity == "critical":
            penalties += 20
        elif severity in ("high", "major"):
            penalties += 10
        elif severity in ("medium", "minor", "low"):
            penalties += 3

    return max(0, min(100, 100 - penalties))


# =============================================================================
# 5.  SPARK UDF BUILDER
# =============================================================================

def build_issue_signals_udf(yaml_path: str):
    """
    Build a Pandas UDF for per-row issue detection.

    ``source_type`` ("review" | "qa") is passed as a Spark literal column at the call
    site (e.g. ``F.lit("review")``), so one UDF handles both review and Q&A rows
    without loading config twice.
    """
    cfg = load_issue_keywords(yaml_path)
    issues_list = cfg.get("issues", [])
    scoring_cfg = cfg.get("scoring", {})
    global_cfg = cfg.get("global", {})

    logger.info("Built issue detection Pandas UDF with %d issue definitions", len(issues_list))

    @F.pandas_udf(StringType())
    def _detect_pandas_udf(
        review_text: pd.Series,
        category: pd.Series,
        source_id: pd.Series,
        metadata_val: pd.Series,
        review_create_dt_val: pd.Series,
        source_type_col: pd.Series,
    ) -> pd.Series:
        results = []
        for rt, cat, sid, meta, rdt, stype in zip(
            review_text, category, source_id,
            metadata_val, review_create_dt_val, source_type_col,
        ):
            if _is_empty(rt):
                results.append(None)
                continue

            resolved_cat = _resolve_category(cat or "")
            detections = detect_issues_in_review(
                rt, resolved_cat, issues_list, scoring_cfg, global_cfg
            )
            if not detections:
                results.append(None)
                continue

            formatted_detections = []
            for d in detections:
                res = {
                    "issue_key":       d["issue_key"],
                    "issue_title":     d["issue_title"],
                    "severity":        d["severity"],
                    "confidence":      d["confidence"],
                    "confidence_band": d["confidence_band"],
                    "matched_terms":   d["matched_terms"],
                    "source":          stype,
                }
                if stype == "review":
                    res["review_id"] = sid or ""
                    res["rating"] = meta
                    res["review_create_dt"] = rdt
                else:
                    res["qa_id"] = sid or ""
                formatted_detections.append(res)

            results.append(json.dumps(formatted_detections, sort_keys=False))

        return pd.Series(results)

    return _detect_pandas_udf


# =============================================================================
# 6.  MAIN PIPELINE: add_review_mining_features()
# =============================================================================

def add_review_mining_features(spark: SparkSession, df: DataFrame,
                               yaml_path: str) -> DataFrame:
    """
    Apply issue_signals_json and issue_summary enrichment.

    Returns a slim DataFrame: item_id, web_supercategory_nm, issue_signals_json,
    issue_summary_json, reliability_score.

    ``df`` is already filtered to the changed item_ids by the caller in incremental
    mode, so no cutoff filter is needed here.
    """
    tables = _ensure_table_config()
    REVIEW_TABLE = tables["REVIEW_TABLE"]
    QUESTIONS_TABLE = tables["QUESTIONS_TABLE"]

    logger.info("=" * 70)
    logger.info("Reviews & FAQ : Starting issue_signals_json + issue_summary_json enrichment")
    logger.info("=" * 70)

    cfg = load_issue_keywords(yaml_path)
    known_issue_rules = cfg.get("policy_thresholds", {}).get("known_issue_rules", {})
    logger.info("Known-issue rules: %s", known_issue_rules)

    # Step 1: Load ALL reviews (full history for the filtered products)
    logger.info("[1/6] Loading reviews from %s", REVIEW_TABLE)
    reviews_df = spark.table(REVIEW_TABLE).select(
        F.col("PRODUCT_ID").cast("string").alias("review_product_id"),
        F.col("REVIEW_DETAIL_TXT").alias("review_text"),
        F.col("WEB_REVIEW_ID").alias("review_id"),
        F.col("REVIEW_RATING_RT").alias("review_rating"),
        F.col("CONTENT_SYNDICATION_SOURCE_NM").alias("syndication_source"),
        F.col("SITE_ID").alias("site_id"),
        F.col("REVIEW_CREATE_DT").cast("string").alias("review_create_dt"),
    )
    logger.info("Reviews DataFrame loaded")

    # Step 2: Dedup syndicated reviews
    logger.info("[2/6] Deduplicating syndicated reviews")
    reviews_deduped = reviews_df.filter(F.col("syndication_source").isNull())
    logger.info("Syndicated reviews filtered (count skipped for performance)")

    # Step 3: Join reviews with product data for web_supercategory_nm
    logger.info("[3/6] Joining reviews with product catalog for category")
    product_categories = df.select(
        F.col("item_id").cast("string").alias("cat_item_id"),
        F.col("web_supercategory_nm"),
    ).distinct()

    reviews_with_cat = reviews_deduped.join(
        product_categories.hint("broadcast"),
        reviews_deduped["review_product_id"] == product_categories["cat_item_id"],
        "inner",
    ).drop("cat_item_id")
    logger.info("[3/6] Reviews joined with product catalog")

    # Step 4: Apply per-review issue detection Pandas UDF (single UDF for review + Q&A)
    logger.info("[4/6] Running issue detection Pandas UDF on each review")
    detect_udf = build_issue_signals_udf(yaml_path)

    reviews_with_signals = reviews_with_cat.withColumn(
        "review_detections",
        detect_udf(
            F.col("review_text"),
            F.col("web_supercategory_nm"),
            F.col("review_id"),
            F.col("review_rating").cast("double"),
            F.col("review_create_dt"),
            F.lit("review"),
        ),
    )

    reviews_with_detections = (
        reviews_with_signals
        .filter(F.col("review_detections").isNotNull())
        .select(
            F.col("review_product_id").alias("product_id"),
            F.col("review_detections").alias("detections"),
            F.col("web_supercategory_nm"),
        )
        .cache()
    )
    detected_count = reviews_with_detections.count()  # materialises cache
    logger.info("%d reviews had issue detections", detected_count)

    # Step 4b: Q&A issue detection (reuses the same Pandas UDF with source_type="qa")
    logger.info("[4b/6] Running issue detection Pandas UDF on Q&A")
    # Load ALL Q&A (full history for the filtered products)
    questions_df = spark.table(QUESTIONS_TABLE).select(
        F.col("PRODUCT_ID").cast("string").alias("qa_product_id"),
        F.col("QUESTION_DETAILS_TXT").alias("qa_text"),
        F.col("QUESTION_ID").alias("qa_id"),
    )
    qa_with_cat = questions_df.join(
        product_categories.hint("broadcast"),
        questions_df["qa_product_id"] == product_categories["cat_item_id"],
        "inner",
    ).drop("cat_item_id")

    qa_with_signals = qa_with_cat.withColumn(
        "qa_detections",
        detect_udf(
            F.col("qa_text"),
            F.col("web_supercategory_nm"),
            F.col("qa_id"),
            F.lit(0.0).cast("double"),
            F.lit(None).cast("string"),
            F.lit("qa"),
        ),
    )

    qa_with_detections = (
        qa_with_signals
        .filter(F.col("qa_detections").isNotNull())
        .select(
            F.col("qa_product_id").alias("product_id"),
            F.col("qa_detections").alias("detections"),
            F.col("web_supercategory_nm"),
        )
    )
    logger.info("[4b/6] Q&A issue detection complete (count skipped for performance)")

    # Union Review and QA Detections
    combined_detections = reviews_with_detections.unionByName(qa_with_detections)

    # The mention_rate / total_reviews denominator for this path.
    #
    # Counted from the PRE-detection frames, not from combined_detections: the
    # latter is already filtered to rows that matched a keyword, so dividing by
    # it would make every mention_rate ~1.0. Taken before detect_udf is in the
    # lineage, so the count does not re-run detection.
    rows_considered = (
        reviews_with_cat.select(F.col("review_product_id").alias("product_id"))
        .unionByName(qa_with_cat.select(F.col("qa_product_id").alias("product_id")))
        .groupBy("product_id")
        .agg(F.count("*").cast("int").alias("rows_considered"))
    )

    # Step 5: Aggregate per product
    logger.info("[5/6] Aggregating detections per product")
    per_product = (
        combined_detections.groupBy("product_id", "web_supercategory_nm")
        .agg(F.collect_list(F.col("detections")).alias("all_detections_list"))
        .join(rows_considered.hint("broadcast"), on="product_id", how="left")
    )

    _issue_cfg = cfg.get("issues", [])

    @F.pandas_udf(StringType())
    def aggregate_both_pandas_udf(
        detection_jsons: pd.Series,
        product_ids: pd.Series,
        rows_considered_col: pd.Series,
    ) -> pd.Series:
        results = []
        for detection_jsons_list, product_id, n_rows in zip(
            detection_jsons, product_ids, rows_considered_col,
        ):
            if detection_jsons_list is None or (hasattr(detection_jsons_list, '__len__') and len(detection_jsons_list) == 0):
                results.append(None)
                continue
            all_detections = []
            for review_dets_json in detection_jsons_list:
                if _is_empty(review_dets_json):
                    continue
                try:
                    dets = json.loads(review_dets_json)
                    all_detections.extend(dets)
                except (json.JSONDecodeError, TypeError):
                    continue
            if not all_detections:
                results.append(None)
                continue
            signals_json = aggregate_signals_for_product(all_detections)
            issue_summary_json = build_issue_summary(
                all_detections,
                item_id=None if product_id is None else str(product_id),
                # pandas gives NaN, not None, for a missing left-join value, and
                # NaN is truthy — it would sail into the division below.
                total_reviews=(
                    None if n_rows is None or pd.isna(n_rows) else int(n_rows)
                ),
            )
            reliability = calculate_reliability_score(all_detections, _issue_cfg)
            results.append(json.dumps({
                "signals": signals_json,
                "issue_summary_json": issue_summary_json,
                "reliability": reliability,
            }))
        return pd.Series(results)

    product_signals = (
        per_product
        .withColumn("_agg_result", aggregate_both_pandas_udf(
            F.col("all_detections_list"), F.col("product_id"), F.col("rows_considered"),
        ))
        .withColumn(ISSUE_SIGNALS_FIELD, F.get_json_object(F.col("_agg_result"), "$.signals"))
        .withColumn(ISSUE_SUMMARY_FIELD, F.get_json_object(F.col("_agg_result"), "$.issue_summary_json"))
        .withColumn(RELIABILITY_SCORE_FIELD, F.get_json_object(F.col("_agg_result"), "$.reliability").cast("int"))
        .select(
            F.col("product_id").alias("sig_item_id"),
            F.col(ISSUE_SIGNALS_FIELD),
            F.col(ISSUE_SUMMARY_FIELD),
            F.col(RELIABILITY_SCORE_FIELD),
        )
        .cache()  # prevent double execution from two consecutive .count() calls
    )
    product_count = product_signals.count()  # materialises cache once
    logger.info("Generated issue_signals_json / issue_summary_json for %d products", product_count)

    # Left-join back to product list
    product_base = df.select(
        F.col("item_id").cast("string").alias("base_item_id"),
        F.col("web_supercategory_nm"),
    ).distinct()

    result_df = product_base.join(
        product_signals,
        product_base["base_item_id"] == product_signals["sig_item_id"],
        "left",
    ).select(
        F.col("base_item_id").alias("item_id"),
        F.col("web_supercategory_nm"),
        F.col(ISSUE_SIGNALS_FIELD),
        F.col(ISSUE_SUMMARY_FIELD),
        F.col(RELIABILITY_SCORE_FIELD),
    )

    logger.info("Left-join complete; NULL issue_signals_json check skipped for performance")

    logger.info("=" * 70)
    logger.info("Reviews & FAQ : issue_signals + issue_summary enrichment COMPLETE")
    logger.info("=" * 70)

    return result_df

# =============================================================================
# 6a. LLM ISSUE ROLLUP  (issues_tagging.py -> issue_signals_json/issue_summary_json)
# =============================================================================

# Severity vocabulary, shared by the histogram and the representative pick.
_SEVERITIES = ("critical", "high", "medium", "low")
# Severity tie-break rank and per-occurrence reliability penalty.
_SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1}
_SEV_PENALTY = {"critical": 20, "high": 10, "medium": 3, "low": 3}
_TREND_BAND = 1.2   # see the trend column below

# Sentiment polarity cut-offs on the configured 1-5 scale, used ONLY by the
# no-LLM conflict fallback (issues_tagging.sentiment_conflict_fallback).
#
# 3 is excluded from both sides deliberately: issues_tagging._clamp_sentiment
# returns the midpoint when the model's value is missing or unparseable, so a 3
# cannot be told apart from a parse failure. Counting it on either side would
# build the flag on noise.
_SENT_POS_MIN = 4   # >= this is a clearly positive mention
_SENT_NEG_MAX = 2   # <= this is a clearly negative one


def _top_n_by_count(col_name: str, n: int):
    """
    Top-N distinct non-NULL values of a column by frequency (ties alphabetical),
    via native array functions.
    """
    values = F.collect_list(F.col(col_name))
    ranked = F.array_sort(F.transform(
        F.array_distinct(values),
        lambda v: F.struct(
            (-F.size(F.filter(values, lambda x: x == v))).alias("neg_count"),
            v.alias("value"),
        ),
    ))
    return F.slice(F.transform(ranked, lambda x: x["value"]), 1, n)


def add_issue_features_from_llm(
    spark: SparkSession,
    df: DataFrame,
    issues_df: DataFrame,
    rows_considered_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    Aggregate issues_tagging's per-issue records into per-product fields (no LLM call).
    conflict_flag arrives per group from issues_tagging; gaps are filled here.

    Args:
        spark:              Active SparkSession.
        df:                 Product catalog rows (item_id, web_supercategory_nm).
        issues_df:          One row per detected issue, from issues_tagging.mine_issue_tags.
        rows_considered_df: product_id, rows_considered (denominator for total_reviews
                            and mention_rate); None leaves both NULL.

    Returns:
        item_id, issue_signals_json, issue_summary_json, reliability_score,
        has_high_severity_issue, has_unresolved_issue, top_issue_keys, top_issue_tags.
    """
    logger.info("=" * 70)
    logger.info("Reviews & FAQ : LLM issue rollup (no model calls in this step)")
    logger.info("=" * 70)

    # Function-scoped, same reason as the mine_issue_tags import in the pipeline
    # entry point: a broken issues_tagging deploy must not take review_mining
    # down at import time.
    # pyrefly: ignore [missing-import]
    from issues_tagging import sentiment_conflict_fallback

    sig = issues_df.withColumn(
        "age_days",
        F.datediff(F.current_date(), F.to_date(F.col("source_create_dt"))),
    ).cache()

    # A run where conflict detection was off, failed, or ran against an older
    # issues_tagging leaves no such column. Materialise it as NULL so every
    # expression below is written one way — NULL is already the value that means
    # "no verdict", so the fallback fires exactly as it should.
    if "conflict_flag" not in sig.columns:
        sig = sig.withColumn("conflict_flag", F.lit(None).cast(BooleanType()))

    # ---- issue_signals_json: one entry per detected mention -----------------
    # severity_reason, confidence_band, resolution_status and time_bound stay on product_issue_tags only.
    signals_df = (
        sig.groupBy("product_id")
        .agg(F.collect_list(F.struct(
            "issue_key", "issue_tags", "affected_component", "severity",
            "confidence", "sentiment_score", "root_cause", "matched_terms",
            "source", "source_id", "source_create_dt",
        )).alias("_signals"))
        .select("product_id", F.to_json("_signals").alias(ISSUE_SIGNALS_FIELD))
    )

    # ---- the mention_rate / total_reviews denominator -----------------------
    #
    # An empty frame rather than a None branch when the caller supplies nothing:
    # the left joins below then produce NULL everywhere by construction, and the
    # two code paths stay one code path. A NULL denominator is the honest
    # outcome — a mention_rate over an invented total is worse than none.
    _counts_schema = StructType([
        StructField("product_id", StringType()),
        StructField("total_reviews_considered", IntegerType()),
    ])
    if rows_considered_df is not None:
        counts_df = rows_considered_df.select(
            F.col("product_id").cast("string").alias("product_id"),
            F.col("rows_considered").cast("int").alias("total_reviews_considered"),
        )
    else:
        logger.warning(
            "No rows_considered frame supplied — total_reviews, "
            "total_reviews_considered and mention_rate will be NULL."
        )
        counts_df = spark.createDataFrame([], _counts_schema)

    # ---- per (product, issue_key) rollup ------------------------------------
    per_key = (
        sig.groupBy("product_id", "issue_key")
        .agg(
            F.count("*").alias("frequency"),
            F.array_distinct(F.flatten(F.collect_list("issue_tags"))).alias("issue_tags"),
            *[
                F.sum(F.when(F.col("severity") == s, 1).otherwise(0)).alias("sev_" + s)
                for s in _SEVERITIES
            ],
            F.sum(F.when(F.col("age_days") < 30, 1).otherwise(0)).alias("under_30_days"),
            F.sum(F.when((F.col("age_days") >= 30) & (F.col("age_days") < 60), 1)
                   .otherwise(0)).alias("30_to_60_days"),
            F.sum(F.when((F.col("age_days") >= 60) & (F.col("age_days") < 90), 1)
                   .otherwise(0)).alias("60_to_90_days"),
            # NULL age (Q&A carries no timestamp) lands here rather than being
            # dropped, so SUM(recency) still equals frequency.
            F.sum(F.when(F.col("age_days").isNull() | (F.col("age_days") >= 90), 1)
                   .otherwise(0)).alias("over_90_days"),
            F.sum(F.when(F.col("resolution_status") == "unresolved", 1)
                   .otherwise(0)).alias("_n_unresolved"),
            F.sum(F.when(F.col("resolution_status") == "resolved_by_manufacturer", 1)
                   .otherwise(0)).alias("_n_mfr"),
            F.countDistinct(F.concat_ws("|", "source_id", "issue_key")).alias("_distinct_mentions"),
            _top_n_by_count("affected_component", 3).alias("top_components"),
            _top_n_by_count("root_cause", 3).alias("top_root_causes"),
            # The model's per-group conflict verdict. Every row of a group
            # carries the same value, so max() just reads it back; it returns
            # NULL only when the whole group went unjudged, which is precisely
            # when the fallback below should fire.
            F.max("conflict_flag").alias("_llm_conflict"),
            # Polarity counts — inputs to that fallback, and to nothing else.
            F.sum(F.when(F.col("sentiment_score") >= _SENT_POS_MIN, 1)
                   .otherwise(0)).alias("_n_pos"),
            F.sum(F.when(F.col("sentiment_score") <= _SENT_NEG_MAX, 1)
                   .otherwise(0)).alias("_n_neg"),
            # Sum and count, NOT avg. overall_sentiment_avg is a per-PRODUCT
            # figure, and averaging these per-key averages would weight a key
            # with one mention the same as a key with forty.
            F.sum("sentiment_score").alias("_sent_sum"),
            F.count("sentiment_score").alias("_sent_n"),
            # A mention the model could not tie to a specific part. Useful as a
            # confidence signal on top_components: three components and nine
            # unattributed mentions means the component list is thin evidence.
            F.sum(F.when(F.col("affected_component").isNull(), 1)
                   .otherwise(0)).alias("unattributed_count"),
            # Normalised to yyyy-MM-dd rather than passed through: source_create_dt
            # is a raw string and Q&A rows carry none at all, so min/max over the
            # parsed date is the only form that both ignores NULLs and returns a
            # comparable value.
            F.date_format(F.min(F.to_date(F.col("source_create_dt"))), "yyyy-MM-dd")
             .alias("first_seen"),
            F.date_format(F.max(F.to_date(F.col("source_create_dt"))), "yyyy-MM-dd")
             .alias("last_seen"),
            # representative_quote: the most-confident, then longest, grounded
            # span in the group. Same (sort key first) sort_array idiom as
            # _top_n_by_count — the inner transform pairs every span of a
            # mention with that mention's confidence, flatten collapses the
            # per-row arrays, and a descending sort puts the winner at 1.
            #
            # Safe to surface verbatim: issues_tagging._ground_terms rejects any
            # entry whose matched_terms are not substrings of the source text,
            # so these are customer words, not model words.
            # F.get, not F.element_at: a group whose every mention had NULL
            # matched_terms collapses to an EMPTY array here, and element_at on
            # an empty array raises INVALID_ARRAY_INDEX under ANSI mode instead
            # of returning NULL. F.get is out-of-bounds-safe by definition.
            F.get(
                F.transform(
                    F.sort_array(
                        F.flatten(F.collect_list(
                            F.transform(
                                F.col("matched_terms"),
                                lambda term: F.struct(
                                    F.col("confidence").alias("conf"),
                                    F.length(term).alias("len"),
                                    term.alias("term"),
                                ),
                            )
                        )),
                        False,
                    ),
                    lambda x: x["term"],
                ),
                F.lit(0),
            ).alias("representative_quote"),
        )
        .withColumn(
            # Representative severity: most frequent band, ties broken UPWARD.
            # sort_array descending over (count, rank) gives exactly that in one
            # pass — no window, no second shuffle.
            "severity",
            F.element_at(F.transform(
                F.sort_array(F.array(*[
                    F.struct(
                        F.col("sev_" + s).alias("c"),
                        F.lit(_SEV_RANK[s]).alias("r"),
                        F.lit(s).alias("name"),
                    )
                    for s in _SEVERITIES
                ]), False),
                lambda x: x["name"],
            ), 1),
        )
        .withColumn("severity_distribution", F.struct(
            *[F.col("sev_" + s).alias(s) for s in _SEVERITIES]
        ))
        .withColumn(
            # Model verdict wins (including False); the sentiment heuristic only fills gaps.
            "conflict_flag",
            F.coalesce(
                F.col("_llm_conflict"),
                sentiment_conflict_fallback(),
                F.lit(False),
            ),
        )
        .withColumn(
            # _3.md specifies "under_30 rate vs 30_to_60 rate" without a
            # threshold. A bare > flips the label on a single report, so a 20%
            # band is required for it to mean anything.
            #
            # NULL, not "stable", when both recent windows are empty. An issue
            # last mentioned two years ago is not trending stably — there is no
            # trend to report, and saying "stable" is a claim about data that
            # does not exist.
            "trend",
            F.when(F.col("under_30_days") + F.col("30_to_60_days") == 0, F.lit(None))
             .when(F.col("under_30_days") > F.col("30_to_60_days") * _TREND_BAND, "increasing")
             .when(F.col("under_30_days") * _TREND_BAND < F.col("30_to_60_days"), "decreasing")
             .otherwise("stable"),
        )
        .withColumn("recency_buckets", F.struct(
            "under_30_days", "30_to_60_days", "60_to_90_days", "over_90_days",
        ))
        .withColumn(
            "_penalty",
            F.col("_distinct_mentions") * F.coalesce(
                F.element_at(
                    F.create_map(*[
                        x for s in _SEVERITIES
                        for x in (F.lit(s), F.lit(_SEV_PENALTY[s]))
                    ]),
                    F.col("severity"),
                ),
                F.lit(3),
            ),
        )
        # ---- the mention_rate denominator -----------------------------------
        #
        # Left join, and NOT coalesced to zero: a product whose count is missing
        # keeps a NULL total_reviews_considered and mention_rate divides to NULL
        # with it. Substituting a zero or a guess here would publish a rate that
        # looks authoritative and is not.
        #
        # Joined inside this chain, before the cache, so there is exactly one
        # materialised per_key to unpersist at the end.
        .join(counts_df.hint("broadcast"), on="product_id", how="left")
        .withColumn(
            # NULL denominator -> NULL rate, with no guard needed. A ZERO
            # denominator cannot arise: counts_df comes from a groupBy().count(),
            # so a product either has a row with a count of 1 or more, or has no
            # row at all and lands here NULL from the left join. That matters
            # because under ANSI mode a division by zero raises rather than
            # returning NULL.
            "mention_rate",
            F.round(F.col("frequency") / F.col("total_reviews_considered"), 2),
        )
        .withColumn("mention_count", F.col("frequency").cast(IntegerType()))
        .cache()
    )

    # ---- per-product summary + the precomputed scalars ----------------------
    #
    # STAGED FOR INDEX PHASE: has_high_severity_issue, has_unresolved_issue,
    # top_issue_keys and top_issue_tags are computed and written to the enriched
    # table here, but NOTHING consumes them yet. product_detail_index and
    # product_discovery_index are explicitly out of scope for this phase, so
    # neither sync notebook has been touched and neither index syncs these
    # columns. They are produced now so the index phase is a sync-config change
    # rather than a backfill.
    _sev_name_by_rank = F.create_map(*[
        x for s in _SEVERITIES for x in (F.lit(_SEV_RANK[s]), F.lit(s))
    ])
    _sev_rank_by_name = F.create_map(*[
        x for s in _SEVERITIES for x in (F.lit(s), F.lit(_SEV_RANK[s]))
    ])

    summary_df = (
        per_key.groupBy("product_id")
        .agg(
            # Field order here IS the published order of issue_summary_json.issues[].
            F.collect_list(F.struct(
                "issue_key", "issue_tags", "top_components", "severity",
                "severity_distribution", "mention_count",
                "mention_rate", "representative_quote",
                "top_root_causes", "unattributed_count", "first_seen", "last_seen",
                "trend", "recency_buckets", "conflict_flag",
            )).alias("issues"),
            F.max(F.when((F.col("sev_critical") > 0) | (F.col("sev_high") > 0), True)
                   .otherwise(False)).alias(HAS_HIGH_SEVERITY_FIELD),
            # Unresolved: more unresolved reports than manufacturer fixes.
            F.max(F.when(
                F.col("_n_unresolved") > F.col("_n_mfr"), True,
            ).otherwise(False)).alias(HAS_UNRESOLVED_FIELD),
            F.slice(F.transform(F.sort_array(F.collect_list(F.struct(
                F.col("frequency").alias("c"), F.col("issue_key"),
            )), False), lambda x: x["issue_key"]), 1, 5).alias(TOP_ISSUE_KEYS_FIELD),
            F.array_distinct(F.flatten(F.collect_list("issue_tags")))
             .alias(TOP_ISSUE_TAGS_FIELD),
            # Same 100-minus-penalties shape as the keyword era, clamped [0,100].
            F.greatest(F.lit(0), F.least(F.lit(100), F.lit(100) - F.sum("_penalty")))
             .cast("int").alias(RELIABILITY_SCORE_FIELD),
            # --- header inputs ---
            F.max(F.element_at(_sev_rank_by_name, F.col("severity")))
             .alias("_max_sev_rank"),
            F.max("total_reviews_considered").alias("total_reviews"),
            F.sum("_sent_sum").alias("_sent_sum"),
            F.sum("_sent_n").alias("_sent_n"),
        )
        .withColumn("distinct_issues_found", F.size("issues"))
        .withColumn("max_severity", F.element_at(_sev_name_by_rank, F.col("_max_sev_rank")))
        .withColumn(
            "overall_sentiment_avg",
            F.when(F.col("_sent_n") > 0,
                   F.round(F.col("_sent_sum") / F.col("_sent_n"), 2)),
        )
        .select(
            "product_id",
            F.to_json(F.struct(
                F.col("product_id").alias("item_id"),
                F.col("total_reviews"),
                F.col("distinct_issues_found"),
                F.col("max_severity"),
                F.col("overall_sentiment_avg"),
                F.col("issues"),
            )).alias(ISSUE_SUMMARY_FIELD),
            HAS_HIGH_SEVERITY_FIELD, HAS_UNRESOLVED_FIELD,
            TOP_ISSUE_KEYS_FIELD, TOP_ISSUE_TAGS_FIELD, RELIABILITY_SCORE_FIELD,
        )
    )

    # LEFT from the catalog: a product with no issues at all must still emit a
    # row, with reliability_score 100 rather than NULL. An inner join here would
    # silently drop every clean product from the output.
    catalog = (
        df.select(F.col("item_id").cast("string").alias("item_id"))
          .dropDuplicates(["item_id"])
    )

    # NO empty envelope for a product with nothing detected. Both JSON columns
    # are left NULL by the two left joins below, and deliberately so.
    #
    # THE INVARIANT THIS BUYS. signals_df and summary_df are both built from
    # `sig` — signals_df groups it by product_id, summary_df groups per_key,
    # which is the same frame grouped one level finer. Neither applies a filter,
    # so a product appears in BOTH or in NEITHER. Leaving the joins to speak for
    # themselves therefore makes the two columns carry identical non-null counts
    # by construction, which is the property this file now guarantees.
    #
    # An envelope on the summary side alone broke that: issue_signals_json read
    # NULL while issue_summary_json read {"distinct_issues_found":0,"issues":[]},
    # so the two columns disagreed on every clean product and a COUNT could not
    # tell "no issues found" apart from "not tagged".
    #
    # This also matches the keyword fallback, where build_issue_summary already
    # returns None for an empty detection list.
    #
    # The scalars below still coalesce, and are NOT part of this change:
    # reliability_score 100, has_high_severity_issue false and two empty arrays
    # are real statements about a clean product rather than absences, and none
    # of them needed the envelope to be readable.
    result_df = (
        catalog
        .join(signals_df.withColumnRenamed("product_id", "item_id"), on="item_id", how="left")
        .join(summary_df.withColumnRenamed("product_id", "item_id"), on="item_id", how="left")
        .withColumn(RELIABILITY_SCORE_FIELD,
                    F.coalesce(F.col(RELIABILITY_SCORE_FIELD), F.lit(100)))
        .withColumn(HAS_HIGH_SEVERITY_FIELD,
                    F.coalesce(F.col(HAS_HIGH_SEVERITY_FIELD), F.lit(False)))
        .withColumn(HAS_UNRESOLVED_FIELD,
                    F.coalesce(F.col(HAS_UNRESOLVED_FIELD), F.lit(False)))
        .withColumn(TOP_ISSUE_KEYS_FIELD,
                    F.coalesce(F.col(TOP_ISSUE_KEYS_FIELD), F.array().cast("array<string>")))
        .withColumn(TOP_ISSUE_TAGS_FIELD,
                    F.coalesce(F.col(TOP_ISSUE_TAGS_FIELD), F.array().cast("array<string>")))
    )

    # Materialise before releasing the upstream caches: issues_df still carries
    # the model-call lineage, and leaving this lazy over evicted caches risks
    # re-issuing paid calls during the write.
    result_df = result_df.cache()
    result_df.count()
    per_key.unpersist()
    sig.unpersist()

    logger.info("Reviews & FAQ : LLM issue rollup COMPLETE")
    logger.info("=" * 70)
    return result_df


# =============================================================================
# 6b. FAQ TROUBLESHOOTING PIPELINE
# =============================================================================

def add_faq_troubleshooting_features(
    spark: SparkSession,
    df: DataFrame,
    faq_config_path: str,
    tags_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    Build faq_json directly from product_faq_tags (this run's `tags_df` from
    faq_tagging.mine_faq_tags) — no LLM call here, no re-derivation from q_and_a.

    One entry per tagged question, in original q_and_a array order, capped at
    max_results_per_product.

    tags_df is None, or an item has no tagged rows -> faq_json is NULL for that
    item, never an error. An item whose q_and_a is NULL or empty is also NULL:
    faq_json is derived from q_and_a, so it cannot outlive it.
    """
    logger.info("=" * 70)
    logger.info("FAQ Troubleshooting : Starting faq_json enrichment (from product_faq_tags)")
    logger.info("=" * 70)

    cfg = load_faq_config(faq_config_path)
    max_results = cfg.get("faq_troubleshooting", {}).get("max_results_per_product", 10)

    # has_qa is the contract: faq_json is derived from q_and_a, so an item with
    # no questions must carry NULL even if a stale tag row exists for it. The
    # size() > 0 half matches faq_tagging.explode_questions, which has always
    # required a non-empty array.
    base_items = df.select(
        F.col("item_id").cast("string").alias("item_id"),
        (F.col("q_and_a").isNotNull() & (F.size(F.col("q_and_a")) > 0))
        .alias("_has_qa"),
    ).groupBy("item_id").agg(F.max("_has_qa").alias("_has_qa"))

    if tags_df is None:
        logger.info("No FAQ tags this run — faq_json will be NULL")
        return base_items.drop("_has_qa").withColumn(
            FAQ_TROUBLESHOOTING_FIELD, F.lit(None).cast(StringType()),
        )

    per_question = tags_df.select(
        F.col("item_id").cast("string").alias("item_id"),
        "tag_id", "question_tags", "question_keyword", "conflict_flag",
        F.transform(
            F.coalesce(F.col("answers_meta"), F.array().cast(_ANSWERS_META_TYPE)),
            lambda a: F.struct(
                a["position"].alias("position"),
                a["answer_keyword"].alias("answer_keyword"),
                a["answer_tags"].alias("answer_tags"),
                a["answer_score"].alias("answer_score"),
            ),
        ).alias("answers"),
        # tag_id is "{item_id}_{n}", NOT zero-padded (utils.question_id_expr),
        # so a lexical sort would put "..._10" before "..._2". n is always the
        # last "_"-separated token regardless of underscores in item_id.
        F.element_at(F.split(F.col("tag_id"), "_"), -1).cast("int").alias("_pos"),
    )

    per_item = (
        per_question
        .groupBy("item_id")
        .agg(
            F.sort_array(
                F.collect_list(
                    F.struct(
                        "_pos", "question_tags", "question_keyword",
                        "conflict_flag", "answers",
                    )
                )
            ).alias("_sorted"),
        )
        .withColumn(
            FAQ_TROUBLESHOOTING_FIELD,
            F.to_json(
                F.slice(
                    F.transform(
                        F.col("_sorted"),
                        lambda s: F.struct(
                            s["question_tags"].alias("question_tags"),
                            s["question_keyword"].alias("question_keyword"),
                            s["conflict_flag"].alias("conflict_flag"),
                            s["answers"].alias("answers"),
                        ),
                    ),
                    1, max_results,
                )
            ),
        )
        .select("item_id", FAQ_TROUBLESHOOTING_FIELD)
    )

    result_df = (
        base_items.join(per_item, on="item_id", how="left")
        .withColumn(
            FAQ_TROUBLESHOOTING_FIELD,
            F.when(F.col("_has_qa"), F.col(FAQ_TROUBLESHOOTING_FIELD)),
        )
        .drop("_has_qa")
    )

    logger.info("=" * 70)
    logger.info("FAQ Troubleshooting : faq_json enrichment COMPLETE")
    logger.info("=" * 70)

    return result_df


# =============================================================================
# 6b-ii. FAQ SUMMARY PIPELINE
# =============================================================================

def add_faq_summary_features(
    spark: SparkSession,
    df: DataFrame,
    faq_config_path: str,
    tags_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    Build faq_summary_json (keyword-level FAQ summary with recency bucketing).

    `tags_df` is this run's mine_faq_tags output (None degrades to keyword topics);
    `df` is already narrowed to items with changed Q&A.

    Returns:
        item_id, faq_summary_json.
    """
    tables = _ensure_table_config()
    QUESTIONS_TABLE = tables["QUESTIONS_TABLE"]
    ANSWERS_TABLE = tables["ANSWERS_TABLE"]

    logger.info("=" * 70)
    logger.info("FAQ Summary : Starting faq_summary_json enrichment")
    logger.info("=" * 70)

    cfg = load_faq_config(faq_config_path)
    faq_cfg = cfg.get("faq_troubleshooting", {})
    max_results = faq_cfg.get("max_results_per_product", 10)

    # Summary grouping + keyword shape. Clamped so a bad config value cannot
    # produce one-word keywords or a threshold that merges everything.
    keyword_min_words = max(1, int(faq_cfg.get("keyword_min_words", 2)))
    keyword_max_words = max(keyword_min_words, int(faq_cfg.get("keyword_max_words", 7)))
    q_min_shared_tags = max(1, int(faq_cfg.get("question_cluster_min_shared_tags", 2)))
    a_min_shared_tags = max(1, int(faq_cfg.get("answer_cluster_min_shared_tags", 2)))

    # answer_score recency decay. Per-tier fallback, not whole-block fallback:
    # a config that defines only `time_bound` still gets sane default/evergreen
    # tables rather than silently disabling decay for the other two.
    decay_raw: dict = faq_cfg.get("answer_score_decay") or {}
    score_decay_cfg = {
        name: {**bands, **(decay_raw.get(name) or {})}
        for name, bands in _DEFAULT_SCORE_DECAY.items()
    }
    evergreen_tags = {
        str(t).lower()
        for t in (faq_cfg.get("evergreen_question_tags") or _DEFAULT_EVERGREEN_TAGS)
    }
    logger.info(
        "Answer score decay: %d tiers, %d evergreen tags",
        len(score_decay_cfg), len(evergreen_tags),
    )

    global_q_kws = faq_cfg.get("global_question_keywords", [])
    global_a_kws = faq_cfg.get("global_answer_keywords", [])
    global_q_set = set(kw.lower() for kw in global_q_kws)
    global_a_set = set(kw.lower() for kw in global_a_kws)

    per_category_cfg: dict = faq_cfg.get("per_category", {})
    per_category_q: dict = {
        cat: set(kw.lower() for kw in vals.get("question_keywords", []))
        for cat, vals in per_category_cfg.items()
    }
    per_category_a: dict = {
        cat: set(kw.lower() for kw in vals.get("answer_keywords", []))
        for cat, vals in per_category_cfg.items()
    }

    topic_mapping_raw: dict = faq_cfg.get("topic_mapping", {})
    topic_mapping: dict = {
        topic: [kw.lower() for kw in triggers]
        for topic, triggers in topic_mapping_raw.items()
        if triggers
    }

    stopwords_list = faq_cfg.get("stopwords", [])
    stopwords_set = set(w.lower() for w in stopwords_list)

    logger.info("Topic mapping: %d topics loaded", len(topic_mapping))

    # Step 1: Load timestamps
    #
    # Both scans are explicitly .alias()'d, and QUESTION_ID is renamed to a
    # unique name (q_question_id / a_question_id) the moment it's selected.
    # If QUESTIONS_TABLE and ANSWERS_TABLE ever resolve to the same underlying
    # table/view (e.g. a combined sample view in a dev config), scanning it
    # twice and then joining the two DataFrames is the classic Spark
    # self-join scenario that produces AMBIGUOUS_REFERENCE on a bare
    # "QUESTION_ID" — Catalyst can lose track of which scan it came from once
    # the two sides are joined. Aliasing the scan + renaming the column at
    # selection time means no bare "QUESTION_ID" ever survives into that join
    # scope, so the ambiguity has nothing to attach to regardless of whether
    # the two tables are physically distinct or not.
    logger.info("Loading timestamps from Snowflake tables...")
    q_timestamps = spark.table(QUESTIONS_TABLE).alias("qt").select(
        F.col("qt.PRODUCT_ID").cast("string").alias("q_product_id"),
        F.col("qt.QUESTION_ID").alias("q_question_id"),
        F.col("qt.QUESTION_DETAILS_TXT").alias("q_text_for_match"),
        F.col("qt.SUBMISSION_TMS").cast("string").alias("q_submission_ts"),
    )
    a_timestamps = spark.table(ANSWERS_TABLE).alias("at").select(
        F.col("at.QUESTION_ID").alias("a_question_id"),
        F.col("at.ANSWER_TXT").alias("a_text_for_match"),
        F.col("at.SUBMISSION_TMS").cast("string").alias("a_submission_ts"),
    )
    # Full history is loaded — the caller has already narrowed df to changed item_ids

    # Step 2: Explode q_and_a, join timestamps
    logger.info("Exploding q_and_a and joining timestamps...")
    # Same contract as faq_json in add_faq_troubleshooting_features: an item with
    # no questions produces no summary, so it falls out here and the caller's
    # left join leaves faq_summary_json NULL. size() > 0 matches
    # faq_tagging.explode_questions rather than relying on posexplode happening to
    # drop an empty array.
    catalog_qa = df.select(
        F.col("item_id").cast("string"),
        F.col("q_and_a"),
        F.col("web_supercategory_nm"),
    ).filter(F.col("q_and_a").isNotNull() & (F.size(F.col("q_and_a")) > 0))

    exploded_qa = catalog_qa.select(
        "item_id", "web_supercategory_nm",
        F.posexplode("q_and_a").alias("q_idx", "qa_item"),
    ).select(
        "item_id", "web_supercategory_nm", "q_idx",
        F.col("qa_item.q").alias("question_text"),
        F.col("qa_item.a").alias("answer_texts"),
    )

    # Attach LLM question_tags at the per-question grain, BEFORE aggregation.
    # A pandas UDF cannot query a table, so the tags have to arrive as data and
    # ride into _build_faq_summary inside the qa_rows structs. Joining on tag_id
    # alone is enough — it already embeds item_id.
    #
    # q_idx (from posexplode above) IS the question's position in the raw
    # q_and_a array — this function does no ranking/reordering, so the
    # position captured here already matches faq_tagging.explode_questions
    # with no extra bookkeeping needed.
    #
    # THIS FUNCTION KEYS ON tag_id, NOT question_id, and that is what keeps
    # faq_summary_json's output unchanged by the id split. tag_id is always
    # present, so every question still reaches _build_faq_summary and still
    # groups the same way. Keying on the real question_id would drop every
    # unresolved question here, because _build_faq_summary skips a NULL id —
    # silently shrinking this field rather than erroring.
    #
    # faq_summary_json has no question_id of its own (see _FAQ_SUMMARY_SCHEMA),
    # so nothing downstream of here observes the difference.
    exploded_qa = exploded_qa.withColumn(
        "tag_id", question_id_expr(F.col("item_id"), F.col("q_idx")),
    )
    exploded_qa = _attach_question_tags(exploded_qa, tags_df)

    with_q_ts = exploded_qa.join(
        q_timestamps,
        (exploded_qa["item_id"] == q_timestamps["q_product_id"]) &
        (exploded_qa["question_text"] == q_timestamps["q_text_for_match"]),
        "left",
    ).drop("q_product_id", "q_text_for_match")

    # NOTE: question_tags must appear in BOTH this projection and the struct
    # below. Either omission drops it silently — the UDF then sees None and
    # every keyword falls back to its keyword-derived topic, which looks like
    # normal output rather than a bug.
    # Pick THIS answer's entry out of answers_meta by position.
    # F.get(..., 0) rather than [0]/getItem/element_at: those honor
    # spark.sql.ansi.enabled and RAISE INVALID_ARRAY_INDEX on this cluster
    # (ANSI is on), instead of degrading to NULL as intended. F.get is
    # documented to always return NULL on an out-of-bounds index regardless of
    # ANSI mode, so a question whose answers_meta is NULL, short (answers were
    # capped), or stale degrades to NULL rather than failing the job.
    _this_answer_meta = F.get(
        F.filter(
            F.coalesce(F.col("answers_meta"), F.array().cast(_ANSWERS_META_TYPE)),
            lambda x: x["position"] == F.col("a_idx"),
        ),
        0,
    )

    with_answers = with_q_ts.select(
        "item_id", "web_supercategory_nm", "question_text", "question_tags",
        # tag_id keys the summary entries — one entry per QUESTION. Without
        # it the UDF has to key on matched config keywords, which is what made
        # one question fragment into up to five entries.
        "tag_id", "question_keyword", "conflict_flag",
        "answers_meta", "q_submission_ts", "q_question_id",
        # posexplode_outer, not explode_outer: a_idx is the answer's index in
        # answer_texts, which is what answers_meta.position aligns to.
        F.posexplode_outer("answer_texts").alias("a_idx", "answer_text"),
    ).withColumn(
        "answer_tags", _this_answer_meta["answer_tags"],
    ).withColumn(
        # The LLM's per-answer phrase
        "answer_keyword", _this_answer_meta["answer_keyword"],
    ).withColumn(
        # The LLM's TIMELESS content score. decay_answer_score turns it into the
        # recency-adjusted score that reaches faq_summary_json; it is NOT used
        # raw. NULL = no LLM opinion, which stays NULL through the decay.
        "answer_score", _this_answer_meta["answer_score"],
    ).withColumn(
        # Selects which decay table that answer gets.
        "time_bound", _this_answer_meta["time_bound"],
    ).drop("answers_meta")

    # Join answers on question_id only — avoids expensive full-text string equality join
    with_a_ts = with_answers.join(
        a_timestamps,
        with_answers["q_question_id"] == a_timestamps["a_question_id"],
        "left",
    ).drop("a_question_id", "a_text_for_match", "q_question_id")

    # NOTE: every field here must ALSO appear in the with_answers projection
    # above. Dropping one is silent — the UDF sees None and falls back, which
    # looks like ordinary output rather than a bug.
    per_product = with_a_ts.groupBy("item_id", "web_supercategory_nm").agg(
        F.collect_list(
            F.struct(
                "tag_id", "question_text", "answer_text",
                "q_submission_ts", "a_submission_ts",
                "question_tags", "answer_tags",
                "question_keyword", "answer_keyword",
                "conflict_flag", "answer_score", "time_bound",
            )
        ).alias("qa_rows")
    )

    logger.info("Per-product aggregation complete, applying UDF...")
    _now = datetime.now(timezone.utc)  # pre-compute once; closed over by _build_faq_summary

    def _build_faq_summary(qa_rows, web_supercategory_nm: Optional[str]) -> Optional[str]:
        if _is_empty(qa_rows):
            return None

        now = _now

        eff_q_kws = set(global_q_set)
        eff_a_kws = set(global_a_set)
        if web_supercategory_nm and web_supercategory_nm in per_category_q:
            eff_q_kws |= per_category_q[web_supercategory_nm]
        if web_supercategory_nm and web_supercategory_nm in per_category_a:
            eff_a_kws |= per_category_a[web_supercategory_nm]

        def _bucket_ts(ts_str):
            if not ts_str:
                return "over_90_days"
            try:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                delta = (now - ts).days
                if delta < 30: return "under_30_days"
                elif delta < 60: return "30_to_60_days"
                elif delta < 90: return "60_to_90_days"
                else: return "over_90_days"
            except (ValueError, TypeError):
                return "over_90_days"

        def _normalize(text):
            if not text: return ""
            t = text.lower()
            t = t.translate(_PUNCT_TABLE)
            return " ".join(t.split())

        def _get_context_words(text_normalized, kw):
            words = text_normalized.split()
            kw_words = kw.split()
            kw_len = len(kw_words)
            for i in range(len(words) - kw_len + 1):
                if words[i:i + kw_len] == kw_words:
                    for j in range(i - 1, -1, -1):
                        if words[j] not in stopwords_set and len(words[j]) > 1:
                            return words[j] + " " + kw
                    for j in range(i + kw_len, len(words)):
                        if words[j] not in stopwords_set and len(words[j]) > 1:
                            return kw + " " + words[j]
                    return kw
            return kw

        def _extract_keywords(text, keyword_set):
            norm = _normalize(text)
            if not norm: return []
            matched = []
            for kw in keyword_set:
                if kw in norm:
                    contextual_kw = _get_context_words(norm, kw)
                    matched.append((contextual_kw, kw))
            return matched

        def _classify_topic(config_root_kw):
            """
            Keyword-derived topic, used as the question_type fallback when no question behind
            a keyword carries LLM tags.

            Lowercased so it shares one casing convention with the LLM tags it sits
            alongside, rather than mixing ["setup"] and ["SETUP"].
            """
            root_lower = config_root_kw.lower()
            for topic, triggers in topic_mapping.items():
                for trigger in triggers:
                    if trigger in root_lower or root_lower in trigger:
                        return topic.lower()
            return "general"

        def _fallback_keyword(text, max_words=None):
            """
            Keyword built from the text alone, for when there is no LLM keyword.

            Leading filler is dropped first, since it carries no search value: that is what
            turns "can you tell me how this mounts to the wall" into "how this mounts to the
            wall" rather than "tell me".
            """
            norm = _normalize(text)
            if not norm:
                return None
            for phrase in _FILLER_PREFIXES:
                if norm.startswith(phrase + " "):
                    norm = norm[len(phrase) + 1:]
                    break
            words = [w for w in norm.split() if w not in stopwords_set and len(w) > 1]
            if not words:
                # Filler-only text ("can you?"): fall back to the raw tokens
                # rather than returning nothing at all.
                words = [w for w in _normalize(text).split() if w]
            if not words:
                return None
            return " ".join(words[:max_words or keyword_max_words])

        def _enforce_keyword_length(keyword, source_text):
            """
            Clamp a keyword to keyword_min_words..keyword_max_words.

            Applies to LLM keywords as well as fallback ones — the model is not bound by its
            own prompt rules, so its output is clamped rather than trusted.

            Extension words come ONLY from source_text, preserving its order, so the
            no-hallucination guarantee survives. A source with fewer usable words than the
            minimum (the question "Claims ?") yields what exists; padding would require
            inventing a word.
            """
            words = [w for w in (keyword or "").split() if w]
            if len(words) > keyword_max_words:
                return " ".join(words[:keyword_max_words])
            if len(words) >= keyword_min_words:
                return " ".join(words)

            src = [w for w in _normalize(source_text).split() if w]
            have = {w.lower() for w in words}
            # Content words first, then anything, so "Is it XL?" can still reach
            # two words once the content pool is exhausted.
            for pool in (
                [w for w in src if w not in stopwords_set and len(w) > 1],
                src,
            ):
                for w in pool:
                    if len(words) >= keyword_min_words:
                        break
                    if w.lower() not in have:
                        words.append(w)
                        have.add(w.lower())

            # Re-order by first appearance in the source so the phrase reads the
            # way it was written: "restocked" + "when" is "when restocked", not
            # "restocked when". Keyword words absent from the source (casing or
            # punctuation differences) sort last, keeping their relative order.
            pos = {}
            for i, w in enumerate(src):
                pos.setdefault(w.lower(), i)
            return " ".join(
                sorted(words, key=lambda w: (pos.get(w.lower(), len(src)),))
            )

        def _norm_tags(raw):
            """
            Tag list -> ordered, deduped, lowercase.

            _is_empty is required: pandas UDF deserialization hands back numpy arrays, and a
            bare `if not raw` raises ValueError on those.
            """
            if _is_empty(raw):
                return []
            out = []
            for t in raw:
                t = str(t).strip().lower()
                if t and t not in out:
                    out.append(t)
            return out

        def _assign_cluster(clusters, tags, min_shared):
            """
            Index of the cluster this tag set joins, or None for a new cluster.

            Compares against each cluster's REPRESENTATIVE tag set, not against any member.
            Single-linkage (match any member) chains: A~B and B~C but A≁C would still
            collapse A and C together, which on real data merged an item's protection_plan
            question into its cancellation/refund group. Representative-linkage keeps a
            cluster anchored to what it started as.

            An untagged question matches nothing and gets its own cluster — grouping on
            absent evidence would be inventing it.
            """
            if not tags:
                return None
            best, best_shared = None, 0
            for i, c in enumerate(clusters):
                shared = len(set(tags) & set(c["rep_tags"]))
                if shared >= min_shared and shared > best_shared:
                    best, best_shared = i, shared
            return best

        def _medoid(keywords):
            """
            The keyword most representative of its cluster: highest mean token overlap with
            the others. Ties break on shortest, then alphabetical.

            Determinism is the point — a medoid that depended on input order would rewrite
            question_keyword on every run for unchanged data.
            """
            uniq = sorted(set(k for k in keywords if k))
            if not uniq:
                return None
            if len(uniq) == 1:
                return uniq[0]
            toks = {k: set(k.lower().split()) for k in uniq}

            def score(k):
                others = [o for o in uniq if o != k]
                sims = []
                for o in others:
                    a, b = toks[k], toks[o]
                    sims.append(len(a & b) / len(a | b) if (a | b) else 0.0)
                return sum(sims) / len(sims)

            return max(uniq, key=lambda k: (score(k), -len(k.split()), -len(k),
                                            tuple(-ord(c) for c in k)))

        # ── Pass 1: one record per QUESTION ──────────────────────────────────
        # Keyed on tag_id, so one question is one entry.
        questions = {}
        for row in qa_rows:
            qid = row["tag_id"]
            q_text = row["question_text"] or ""
            if qid is None:
                continue

            if qid not in questions:
                q_matches = _extract_keywords(q_text, eff_q_kws)
                kw = row["question_keyword"]
                if _is_empty(kw):
                    kw = _fallback_keyword(q_text)
                questions[qid] = {
                    "keyword": _enforce_keyword_length(kw, q_text) if kw else None,
                    "tags": _norm_tags(row["question_tags"]),
                    # Keyword-derived topic, still the fallback when a question
                    # carries no LLM tags.
                    "topic": _classify_topic(q_matches[0][1] if q_matches else q_text),
                    "text_norm": _normalize(q_text),
                    "bucket": _bucket_ts(row["q_submission_ts"]),
                    # NULL from the tag table means "no verdict", which is not a
                    # conflict — read it as False here rather than carrying the
                    # tri-state into the output.
                    "conflict": bool(row["conflict_flag"]),
                    "answers": {},
                }

            a_text = row["answer_text"] or ""
            if a_text and a_text.strip():
                a_norm = _normalize(a_text)
                if len(a_norm) < 10 or a_norm in ("i dont know",):
                    continue
                if a_norm in questions[qid]["answers"]:
                    continue
                a_kw = row["answer_keyword"]
                if _is_empty(a_kw):
                    a_kw = _fallback_keyword(a_text)
                questions[qid]["answers"][a_norm] = {
                    "keyword": _enforce_keyword_length(a_kw, a_text) if a_kw else None,
                    "tags": _norm_tags(row["answer_tags"]),
                    "bucket": _bucket_ts(row["a_submission_ts"]),
                    # Recency applied HERE, once, against the answer's own
                    # timestamp — everything downstream carries the decayed
                    # score, never the raw one. Evergreen is decided by the
                    # QUESTION's tags: "what are the dimensions" makes its
                    # answers evergreen, whatever words the answer used.
                    "score": decay_answer_score(
                        row["answer_score"],
                        _age_days(row["a_submission_ts"], now),
                        row["time_bound"],
                        bool(set(questions[qid]["tags"]) & evergreen_tags),
                        score_decay_cfg,
                    ),
                }

        if not questions:
            return None

        # ── Pass 2: cluster questions that mean the same thing ───────────────
        # Iterate in tag_id order so clustering is reproducible; collect_list
        # gives no ordering guarantee of its own.
        clusters = []
        for qid in sorted(questions):
            q = questions[qid]
            idx = _assign_cluster(clusters, q["tags"], q_min_shared_tags)
            if idx is None:
                clusters.append({
                    "rep_tags": list(q["tags"]),
                    "keywords": [], "tags": [], "topic": q["topic"],
                    "q_buckets": {"under_30_days": 0, "30_to_60_days": 0,
                                  "60_to_90_days": 0, "over_90_days": 0},
                    "seen_questions": set(), "answers": [], "conflict": False,
                })
                idx = len(clusters) - 1
            c = clusters[idx]

            if q["keyword"]:
                c["keywords"].append(q["keyword"])
            # OR, not last-write-wins: one contradicted question anywhere in the
            # cluster is enough to flag the whole entry.
            c["conflict"] = c["conflict"] or q["conflict"]
            for t in q["tags"]:
                if t not in c["tags"]:
                    c["tags"].append(t)
            if q["text_norm"] not in c["seen_questions"]:
                c["seen_questions"].add(q["text_norm"])
                c["q_buckets"][q["bucket"]] += 1
            c["answers"].extend(q["answers"].values())

        # ── Pass 3: cluster each group's answers the same way ────────────────
        q_agg = {}
        for c in clusters:
            a_clusters = []
            for a in c["answers"]:
                idx = _assign_cluster(a_clusters, a["tags"], a_min_shared_tags)
                if idx is None:
                    a_clusters.append({
                        "rep_tags": list(a["tags"]),
                        "keywords": [], "tags": [], "scores": [],
                        "buckets": {"under_30_days": 0, "30_to_60_days": 0,
                                    "60_to_90_days": 0, "over_90_days": 0},
                    })
                    idx = len(a_clusters) - 1
                ac = a_clusters[idx]
                if a["keyword"]:
                    ac["keywords"].append(a["keyword"])
                if a["score"] is not None:
                    ac["scores"].append(a["score"])
                for t in a["tags"]:
                    if t not in ac["tags"]:
                        ac["tags"].append(t)
                ac["buckets"][a["bucket"]] += 1

            q_kw = _medoid(c["keywords"])
            if not q_kw:
                continue
            # Two clusters can land on the same medoid keyword; merge rather
            # than letting the later one overwrite the earlier.
            if q_kw in q_agg:
                tgt = q_agg[q_kw]
                for t in c["tags"]:
                    if t not in tgt["llm_tags"]:
                        tgt["llm_tags"].append(t)
                for b, n in c["q_buckets"].items():
                    tgt["q_buckets"][b] += n
                # Must be OR'd on this branch too, not just on first insert —
                # dropping it here would silently lose the flag whenever two
                # clusters happened to share a medoid keyword.
                tgt["conflict"] = tgt["conflict"] or c["conflict"]
                tgt["answer_clusters"].extend(a_clusters)
                continue
            q_agg[q_kw] = {
                "topic": c["topic"],
                "llm_tags": list(c["tags"]),
                "q_buckets": dict(c["q_buckets"]),
                "conflict": c["conflict"],
                "answer_clusters": a_clusters,
            }

        if not q_agg:
            return None

        results = []
        for q_kw, data in q_agg.items():
            q_freq = sum(data["q_buckets"].values())
            if q_freq == 0:
                continue

            answer_entries = []
            for a_data in data["answer_clusters"]:
                a_buckets = a_data["buckets"]
                a_freq = sum(a_buckets.values())
                a_kw = _medoid(a_data["keywords"])
                if a_freq > 0 and a_kw:
                    answer_entries.append({
                        "answer_keyword": a_kw,
                        # Union of the LLM tags across every answer in this
                        # cluster. Unlike question_tags there is no
                        # keyword-derived fallback for an answer, so this is
                        # NULL rather than a synthesised value when untagged —
                        # consumers must handle NULL.
                        "answer_tags": a_data["tags"] or None,
                        # MAX of the decayed scores in this cluster, not the
                        # mean: the cluster is a group of near-equivalent
                        # answers and a consumer wants the best one in it, not
                        # an average dragged down by weaker restatements.
                        # NULL when no answer here carried an LLM score.
                        "answer_score": max(a_data["scores"]) if a_data["scores"] else None,
                        "answer_frequency": a_freq,
                        "answer_recency": dict(a_buckets),
                    })
            # Deterministic order: frequency, then keyword, so equal-frequency
            # answers do not reshuffle between runs.
            answer_entries.sort(key=lambda x: (-x["answer_frequency"], x["answer_keyword"]))

            results.append({
                "question_keyword": q_kw,
                # LLM tags, else the keyword-derived topic as a single-element array; never empty.
                "question_tags": data["llm_tags"] or [data["topic"]],
                "question_frequency": q_freq,
                "question_recency": dict(data["q_buckets"]),
                # True when any question behind this keyword had directly
                # contradicting answers. Never NULL — "no verdict" is False.
                "conflict_flag": data["conflict"],
                "answers": answer_entries,
            })

        # Frequency first, then keyword — a stable tiebreak so equal-frequency
        # entries keep the same order across runs.
        results.sort(key=lambda x: (-x["question_frequency"], x["question_keyword"]))
        results = results[:max_results]
        return json.dumps(results) if results else None

    @F.pandas_udf(StringType())
    def faq_summary_pandas_udf(
        qa_rows_series: pd.Series,
        web_supercategory_nm_series: pd.Series,
    ) -> pd.Series:
        return pd.Series([
            _build_faq_summary(qa_rows, cat)
            for qa_rows, cat in zip(qa_rows_series, web_supercategory_nm_series)
        ])

    result_df = per_product.select(
        F.col("item_id"),
        F.col("web_supercategory_nm"),
        faq_summary_pandas_udf(F.col("qa_rows"), F.col("web_supercategory_nm")).alias(FAQ_SUMMARY_FIELD),
    )

    logger.info("FAQ summary Pandas UDF applied (count skipped for performance)")

    logger.info("=" * 70)
    logger.info("FAQ Summary : faq_summary_json enrichment COMPLETE")
    logger.info("=" * 70)

    return result_df


# =============================================================================
# 7.  PIPELINE ENTRY POINT
# =============================================================================

# Spark schemas for JSON → native type conversion
# LLM-generated shape (issues_tagging.py).
_SIGNALS_SCHEMA = ArrayType(StructType([
    StructField("issue_key", StringType()),
    StructField("issue_tags", ArrayType(StringType())),
    StructField("affected_component", StringType()),
    StructField("severity", StringType()),
    StructField("confidence", DoubleType()),
    StructField("sentiment_score", IntegerType()),
    StructField("root_cause", StringType()),
    # The only quotable evidence in the schema, and the anti-hallucination
    # guard. Validated as verbatim substrings in issues_tagging._ground_terms.
    # Stays an ARRAY: representative_quote picks from these, and collapsing it
    # to one string would throw away the spans it chooses between.
    StructField("matched_terms", ArrayType(StringType())),
    # No helpful_votes: no source column carries a vote count.
    StructField("source", StringType()),
    StructField("source_id", StringType()),
    StructField("source_create_dt", StringType()),
]))

_RECENCY_SCHEMA = StructType([
    StructField("under_30_days", IntegerType()),
    StructField("30_to_60_days", IntegerType()),
    StructField("60_to_90_days", IntegerType()),
    StructField("over_90_days", IntegerType()),
])

# The per-issue severity histogram. Its four counts SUM to mention_count, which
# is published alongside it — implying the count from this struct, as an earlier
# revision did, meant every consumer had to add four numbers to learn how often
# an issue was mentioned.
_SEVERITY_DIST_SCHEMA = StructType([
    StructField("critical", IntegerType()),
    StructField("high", IntegerType()),
    StructField("medium", IntegerType()),
    StructField("low", IntegerType()),
])

# One issue, rolled up across every mention of it on one product.
_ISSUE_SUMMARY_ITEM_SCHEMA = StructType([
    StructField("issue_key", StringType()),
    StructField("issue_tags", ArrayType(StringType())),
    StructField("top_components", ArrayType(StringType())),
    StructField("severity", StringType()),
    StructField("severity_distribution", _SEVERITY_DIST_SCHEMA),
    StructField("mention_count", IntegerType()),
    # total_reviews_considered was dropped from here: it was the same number on
    # every issue of a product, repeating the envelope's total_reviews. It is
    # still computed internally as mention_rate's denominator; it is just no
    # longer published per issue.
    StructField("mention_rate", DoubleType()),
    StructField("representative_quote", StringType()),
    StructField("top_root_causes", ArrayType(StringType())),
    StructField("unattributed_count", IntegerType()),
    StructField("first_seen", StringType()),
    StructField("last_seen", StringType()),
    StructField("trend", StringType()),
    # Renamed from `recency`. The struct itself is unchanged and is still shared
    # with the FAQ summary — only this field's name moved.
    StructField("recency_buckets", _RECENCY_SCHEMA),
    StructField("conflict_flag", BooleanType()),
])

# Envelope: header scalars answer "any known problems?" without walking `issues`.
# Inside an envelope counts are 0 and issues is []; the column is NULL when nothing was detected.
_ISSUE_SUMMARY_SCHEMA = StructType([
    # item_id, not product_id. The enriched table, product_issue_tags and every
    # downstream join key are item_id; the envelope was the last place that
    # still said product_id, and a reader had to know the two were the same
    # thing. The Snowflake-side column IS called PRODUCT_ID and the internal
    # frames still carry that name — the rename happens at publication, in the
    # same place and for the same reason as ISSUE_TAG_TABLE_SCHEMA's.
    StructField("item_id", StringType()),
    StructField("total_reviews", IntegerType()),
    StructField("distinct_issues_found", IntegerType()),
    # The maximum of the PUBLISHED per-issue severities — the worst issue in
    # `issues`, by _SEV_RANK. Deliberately not the worst individual mention: a
    # header saying "critical" when no issue in the array reads critical is a
    # header the reader cannot act on. An issue's own `severity` is its MODAL
    # band, so this is a max over modes, not a global max.
    #
    # has_high_severity_issue asks the broader question (did ANY mention score
    # critical or high) and can therefore be true while this reads "medium".
    StructField("max_severity", StringType()),
    StructField("overall_sentiment_avg", DoubleType()),
    StructField("issues", ArrayType(_ISSUE_SUMMARY_ITEM_SCHEMA)),
])

_FAQ_ANSWER_SCHEMA = ArrayType(StructType([
    StructField("position",       IntegerType()),
    StructField("answer_keyword", StringType()),
    StructField("answer_tags",    ArrayType(StringType())),
    StructField("answer_score",   IntegerType()),
]))

# faq_json is built directly from product_faq_tags (faq_tagging's tags_df) by
# add_faq_troubleshooting_features — no LLM call, no re-derivation from
# q_and_a. See that function's docstring.
_FAQ_SCHEMA = ArrayType(StructType([
    StructField("question_tags",    ArrayType(StringType())),
    StructField("question_keyword", StringType()),
    StructField("conflict_flag",    BooleanType()),
    StructField("answers",          _FAQ_ANSWER_SCHEMA),
]))

_FAQ_SUMMARY_SCHEMA = ArrayType(StructType([
    # NOTE: this question_keyword is the keyword-extraction AGGREGATION KEY —
    # question_frequency counts how many questions collapse onto it. It is not
    # the same thing as product_faq_tags.question_keyword, which is a specific
    # per-question phrase for search. Same name, opposite intent.
    StructField("question_keyword", StringType()),
    # Union of LLM intent tags behind this keyword; falls back to [topic], never empty.
    StructField("question_tags", ArrayType(StringType())),
    StructField("question_frequency", IntegerType()),
    StructField("question_recency", _RECENCY_SCHEMA),
    # True when any question behind this keyword had two answers that directly
    # contradict each other. Never NULL — the UDF emits False for "no verdict".
    StructField("conflict_flag", BooleanType()),
    StructField("answers", ArrayType(StructType([
        StructField("answer_keyword", StringType()),
        # Union of LLM answer tags across the answers in this keyword group,
        # matching the name used inside product_faq_tags.answers_meta.
        # NULL when none of those answers were tagged; unlike question_tags
        # there is no keyword-derived fallback for an answer.
        StructField("answer_tags", ArrayType(StringType())),
        # 0-10 usefulness, RECENCY-ADJUSTED. This is NOT
        # product_faq_tags.answers_meta.answer_score, which is the timeless
        # content score the LLM returned; decay_answer_score has already been
        # applied against the answer's submission timestamp by the time it
        # lands here. NULL when no answer in the group carried an LLM score.
        StructField("answer_score", IntegerType()),
        StructField("answer_frequency", IntegerType()),
        StructField("answer_recency", _RECENCY_SCHEMA),
    ]))),
]))


# product_discovery_data_all columns this task reads, Staples.com ones under their
# product_discovery_data names
SOURCE_COLUMNS = [
    "item_id", "web_supercategory_nm", "q_and_a", "web_supercategory_nm_contract",
    "q_and_a_contract", "in_product_discovery_data", "is_live_contract",
]


def _has_questions(column: str) -> "F.Column":
    return F.col(column).isNotNull() & (F.size(F.col(column)) > 0)


def _read_products(spark: SparkSession, source_table: str) -> DataFrame:
    """
    Every product of product_discovery_data_all. A product that is not on the Staples.com list
    and has no Staples.com category is tagged against its Staples Business category.
    """
    df = read_all_products(spark, source_table, SOURCE_COLUMNS).select(*SOURCE_COLUMNS)
    return df.withColumn(
        "web_supercategory_nm",
        F.when(F.col("in_product_discovery_data"), F.col("web_supercategory_nm"))
         .otherwise(F.coalesce("web_supercategory_nm", "web_supercategory_nm_contract")),
    )


def _contract_faq_source(
    spark: SparkSession,
    products_df: DataFrame,
    output_table: str,
    qa_changed_items: Optional[DataFrame],
) -> DataFrame:
    """
    Products whose Staples Business FAQ is built from their own SB questions this run, with
    q_and_a = those questions.

    Only products live on SB that have SB questions and no Staples.com questions; the others
    copy faq_json (step 9c). Incremental runs take Q&A changes plus products whose SB FAQ was
    never built (faq_summary_json_contract still empty): the one-time catch-up, then each new
    product.
    """
    df = products_df.filter(
        F.col("is_live_contract") & ~_has_questions("q_and_a") & _has_questions("q_and_a_contract")
    )
    if qa_changed_items is not None:
        existing = spark.table(output_table)
        if FAQ_SUMMARY_CONTRACT_FIELD in existing.columns:
            built = existing.filter(F.col(FAQ_SUMMARY_CONTRACT_FIELD).isNotNull()).select("item_id")
            never_built = df.select("item_id").join(built, "item_id", "left_anti")
            df = df.join(qa_changed_items.union(never_built).distinct(), "item_id", "inner")
    return df.select(
        "item_id", F.col("q_and_a_contract").alias("q_and_a"), "web_supercategory_nm",
    )


def run_review_mining_pipeline(
    spark: SparkSession,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None,
    yaml_path: str = None,
    faq_config_path: str = None,
    incremental: bool = True,
    issue_backfill: bool = False,
) -> DataFrame:
    """
    Run the full review mining pipeline end-to-end.

    Args:
        spark:           Active SparkSession.
        source_table:    Fully qualified product catalog table.
        output_table:    Output table name.
        output_catalog:  Optional catalog override for save_data.
        output_schema:   Optional schema override for save_data.
        yaml_path:       Path to issue_keywords.yaml (default: config/).
        faq_config_path: Path to faq_config.yaml (default: config/).
        incremental:     Only process data changed since the last run (False = full refresh).
        issue_backfill:  Incremental only: issue-tag the whole catalogue (cache makes
                         tagged reviews free) while FAQ stays scoped to changes.

    Returns:
        Enriched DataFrame.
    """
    yaml_path = yaml_path or os.path.join(PROJECT_ROOT, "config", "issue_keywords.yaml")
    faq_config_path = faq_config_path or os.path.join(PROJECT_ROOT, "config", "faq_config.yaml")

    print("=" * 80)
    print("REVIEW MINING ENRICHMENT PIPELINE")
    print("=" * 80)

    # 0. Derive cutoff + find changed products (incremental mode)
    cutoff_ts = None
    is_first_run = True
    if incremental:
        print("\n0. Checking for existing output table (incremental mode)...")
        cutoff_ts = get_cutoff_ts(spark, output_table)
        if cutoff_ts:
            is_first_run = False
            print(f"  \n Incremental mode: cutoff = {cutoff_ts}")
        else:
            print("\n  First run detected — full scan will be performed")
    else:
        print("\n0. Full refresh mode (incremental=False)")
        # Check if table exists so we can preserve created_at_ts via MERGE
        _existing_ts = get_cutoff_ts(spark, output_table)
        if _existing_ts is not None:
            is_first_run = False
            print("   Output table exists — will MERGE to preserve created_at_ts")

    # 1. Load source data
    print(f"\n1. Loading source data from {source_table}...")
    products_df = _read_products(spark, source_table)
    source_df = products_df

    # 1b. In incremental mode, filter source_df to ONLY the products that have
    #     new reviews or new Q&A since the last run.  All downstream functions
    #     (add_review_mining_features, etc.) join against source_df, so Spark's
    #     Catalyst optimizer will automatically restrict them to those products
    #     while still using the FULL review / Q&A history for correct aggregation.
    # None outside incremental mode: a full refresh / first run deliberately
    # re-tags everything, so the FAQ scope is then bounded by q_and_a alone.
    qa_changed_items = None

    if incremental and not is_first_run:
        tables_cfg = _ensure_table_config()

        # Apply a 5-minute safety buffer to absorb clock drift between
        # Python (datetime.now) and Snowflake (ROW_UPDATE_TMS)
        cutoff_ts_safe = cutoff_ts - timedelta(minutes=5)
        print(f"   Using safety buffer: cutoff_ts_safe = {cutoff_ts_safe}")

        # Products with new/updated reviews
        new_from_reviews = (
            spark.table(tables_cfg["REVIEW_TABLE"])
            .filter(F.col("ROW_UPDATE_TMS") > F.lit(cutoff_ts_safe))
            .select(F.col("PRODUCT_ID").cast("string").alias("item_id"))
        )

        # Products with new/updated questions
        new_from_questions = (
            spark.table(tables_cfg["QUESTIONS_TABLE"])
            .filter(F.col("ROW_UPDATE_TMS") > F.lit(cutoff_ts_safe))
            .select(F.col("PRODUCT_ID").cast("string").alias("item_id"))
        )

        # Products with new/updated answers (join answers → questions to get PRODUCT_ID)
        new_from_answers = (
            spark.table(tables_cfg["ANSWERS_TABLE"])
            .filter(F.col("ROW_UPDATE_TMS") > F.lit(cutoff_ts_safe))
            .select("QUESTION_ID")
            .join(
                spark.table(tables_cfg["QUESTIONS_TABLE"])
                     .select("QUESTION_ID", F.col("PRODUCT_ID").cast("string").alias("item_id")),
                "QUESTION_ID",
                "inner",
            )
            .select("item_id")
        )

        # Products only on Staples Business that have no row yet are mined once even with
        # nothing new since the cutoff: the one-time SB catch-up, then each new SB product.
        # Staples.com products keep the change-only scope.
        new_contract_items = (
            products_df.filter(~F.col("in_product_discovery_data")).select("item_id")
            .join(spark.table(output_table).select("item_id"), "item_id", "left_anti")
        )

        changed_items = (
            new_from_reviews
            .union(new_from_questions)
            .union(new_from_answers)
            .union(new_contract_items)
            .distinct()
            .cache()
        )
        changed_count = changed_items.count()
        print(f"   {changed_count} products have new reviews/Q&A since {cutoff_ts}, "
              f"or are new Staples Business products")

        if changed_count == 0 and not issue_backfill:
            changed_items.unpersist()
            print("   No new data — nothing to process. Pipeline finished.")
            return spark.createDataFrame([], source_df.schema)

        # FAQ tagging is scoped to Q&A changes only; review changes must not re-tag unchanged Q&A.
        qa_changed_items = (
            new_from_questions
            .union(new_from_answers)
            .distinct()
            .cache()
        )
        qa_changed_count = qa_changed_items.count()
        print(
            f"   {qa_changed_count} of those have new questions/answers "
            f"(the FAQ tagging scope)"
        )

        # LOG ONLY — nothing below is read by the pipeline, and a failure here
        # must never stop the run. What moved since the last run: review rows
        # and the products they touch, in one Snowflake round trip.
        try:
            review_stats = new_from_reviews.agg(
                F.count("*").alias("rows"),
                F.countDistinct("item_id").alias("products"),
            ).collect()[0]
            logger.info(
                "Review mining scope since %s:\n"
                "  products to update : %d\n"
                "  reviews            : %d new/updated across %d product(s)\n"
                "  FAQ products       : %d (new questions/answers)",
                cutoff_ts, changed_count,
                review_stats["rows"], review_stats["products"],
                qa_changed_count,
            )
        except Exception as error:
            logger.warning("Review mining scope summary skipped (%s)", error)

        if issue_backfill:
            # qa_changed_items above still bounds FAQ, so faq_json for the
            # rest of the catalogue is preserved by the MERGE as usual.
            print("   --issue-backfill: issue scope = FULL catalogue (FAQ stays incremental)")
        else:
            # Narrow source_df to only the changed products
            source_df = source_df.join(changed_items, on="item_id", how="inner")
        changed_items.unpersist()

    print("   Source DataFrame loaded")

    # 1b-i. Build the FAQ tagging scope: items that both have questions AND had
    #       one change since the last run. Everything downstream of the LLM
    #       (tagging, faq_json, faq_summary_json) reads THIS frame, not
    #       source_df, so an item outside it is simply not recomputed and the
    #       MERGE preserves whatever it already had.
    faq_source_df = source_df.filter(
        F.col("in_product_discovery_data")
        & F.col("q_and_a").isNotNull() & (F.size(F.col("q_and_a")) > 0)
    )
    if qa_changed_items is not None:
        faq_source_df = faq_source_df.join(
            qa_changed_items, on="item_id", how="inner"
        )
    faq_source_df = faq_source_df.cache()

    faq_scope_count = faq_source_df.count()
    # 1b-iii. The Staples Business FAQ scope (see _contract_faq_source)
    contract_faq_source_df = _contract_faq_source(
        spark, products_df, output_table, qa_changed_items,
    ).cache()
    contract_faq_count = contract_faq_source_df.count()
    if qa_changed_items is not None:
        qa_changed_items.unpersist()
    print(f"   FAQ scope: {faq_scope_count} items with q_and_a to tag")
    print(f"   SB FAQ scope: {contract_faq_count} items with Staples Business questions to tag")
    if faq_scope_count == 0:
        logger.info(
            "No item has both q_and_a and a Q&A change this run — skipping the "
            "LLM entirely; existing faq_json/faq_summary_json are preserved."
        )

    # 1c. FAQ LLM tagging. faq_source_df bounds the spend (mine_faq_tags has no anti-join).
    faq_tables_cfg = _ensure_table_config()
    faq_tag_opts = faq_tables_cfg.get("FAQ_TAGS_OPTS", {}) or {}
    faq_tags_df = None

    # 1b-ii. Resolve every question back to its Snowflake source row ONCE, and
    #        share the result with both consumers below. Doing it here rather
    #        than inside each of them is what guarantees faq_tagging's tag rows
    #        and faq_json's entries carry the SAME question_id — they resolve
    #        from one frame and fall back to the positional key together.
    print("\n1b-ii. Resolving FAQ question/answer keys from Snowflake...")
    question_keys_df = _resolve_question_keys(spark, faq_source_df)
    if question_keys_df is not None:
        question_keys_df = question_keys_df.cache()
        _resolved_items = question_keys_df.count()
        if _resolved_items == 0:
            logger.warning(
                "FAQ key resolution matched NOTHING — every faq_json "
                "question_id will be NULL and submission_date empty. "
                "Check %s and the product_id/question-text join.",
                faq_tables_cfg["QUESTIONS_TABLE"],
            )
        else:
            logger.info("FAQ keys resolved for %d items", _resolved_items)
    else:
        logger.warning(
            "FAQ key resolution unavailable — NULL question_id, empty "
            "submission_date"
        )

    if faq_tag_opts.get("enabled", True):
        # An unreachable model is a failed run, not a quiet one. Degrading
        # here writes faq_json = NULL over good data while faq_summary_json
        # keeps producing heuristic output, so the run still looks healthy on
        # every null-count check. Set
        # review_mining.faq.fail_on_llm_error=false only for a
        # deliberate no-LLM run.
        fail_loud = bool(faq_tag_opts.get("fail_on_llm_error", True))
        print("\n1c. Tagging FAQ questions...")
        try:
            # Function-scoped import: keeps a broken faq_tagging deploy from
            # taking down review_mining at import time.
            # pyrefly: ignore [missing-import]
            from faq_tagging import mine_faq_tags
            # resolve_question_ids=False is EXPLICIT, not a default. The
            # resolution above is shared with faq_json so both carry the same
            # question_id; if it returned None the questions table is
            # unreachable, and having faq_tagging resolve independently would
            # either disagree with faq_json or repeat a scan that just failed.
            faq_tags_df = mine_faq_tags(
                spark, source_df=faq_source_df, question_keys_df=question_keys_df,
                resolve_question_ids=False,
                raise_on_error=fail_loud,
            )
            print(
                "   no questions to tag" if faq_tags_df is None
                else "   FAQ tags ready"
            )
        except Exception as e:
            if fail_loud:
                logger.error(
                    "FAQ tagging FAILED (%s) — failing the task rather than "
                    "overwriting faq_json with NULL", e
                )
                raise
            logger.warning(
                "FAQ tagging skipped (%s) — question_tags will be NULL", e
            )
    else:
        print("\n1c. FAQ tag enrichment disabled by config")

    # 1c-ii. Staples Business FAQ tagging: the same tagger over SB questions, with their
    #        question ids looked up on the SB site.
    contract_keys_df = None
    contract_faq_tags_df = None
    if faq_tag_opts.get("enabled", True) and contract_faq_count:
        fail_loud = bool(faq_tag_opts.get("fail_on_llm_error", True))
        print("\n1c-ii. Tagging Staples Business FAQ questions...")
        contract_keys_df = _resolve_question_keys(
            spark, contract_faq_source_df, site_id=CONTRACT_QUESTION_SITE_ID,
        )
        if contract_keys_df is not None:
            contract_keys_df = contract_keys_df.cache()
        try:
            # pyrefly: ignore [missing-import]
            from faq_tagging import mine_faq_tags
            contract_faq_tags_df = mine_faq_tags(
                spark, source_df=contract_faq_source_df, question_keys_df=contract_keys_df,
                resolve_question_ids=False,
                raise_on_error=fail_loud,
            )
        except Exception as e:
            if fail_loud:
                logger.error("SB FAQ tagging FAILED (%s) — failing the task", e)
                raise
            logger.warning("SB FAQ tagging skipped (%s) — SB question_tags will be NULL", e)

    # 1d. LLM issue tagging (best effort — never fatal).
    #
    #     source_df is already narrowed to the changed items above, and THAT is
    #     what bounds the spend: mine_issue_tags tags exactly what it is handed.
    #     There is no keyword pre-filter — the model is the primary detector, so
    #     gating on the taxonomy would only ever find what the taxonomy already
    #     knows. The content-addressed LLM cache absorbs repeat work instead,
    #     and absorbs it better: an unchanged review is free even on a full
    #     refresh.
    print("\n1d. Tagging product issues with the LLM...")
    issues_df = None
    try:
        # Function-scoped import, same reason as faq_tagging above: a broken
        # issues_tagging deploy must not take down review_mining at import time.
        # pyrefly: ignore [missing-import]
        from issues_tagging import mine_issue_tags

        issues_df = mine_issue_tags(
            spark, source_df=source_df, issue_cfg=load_issue_keywords(yaml_path),
        )
        print("   no issues detected" if issues_df is None else "   issue tags ready")
    except Exception as e:
        logger.warning("LLM issue tagging failed (%s) — falling back to keywords", e)

    # 1e. Observability view over both tag tables. AFTER both taggers, so a
    #     first run creates it in the same pass that creates the tables.
    #     Read-only and never a dependency — see ensure_tag_union_view.
    print("\n1e. Refreshing the FAQ + issue tag union view...")
    _view = ensure_tag_union_view(spark)
    print(f"   {_view}" if _view else "   skipped (see log)")

    # 2. Issue signals + issue summary (keyword detection is the fallback when Vertex is unavailable).
    if issues_df is not None:
        print("\n2. Aggregating LLM issue signals + issue summary...")

        # The mention_rate / total_reviews denominator. Asked of issues_tagging
        # rather than recomputed here: it owns the source-loading filters (the
        # syndication exclusion above all), and a second copy of them here would
        # drift and silently divide by the wrong number. A failure is not fatal
        # — the three count fields go NULL and everything else still ships.
        rows_considered_df = None
        try:
            # pyrefly: ignore [missing-import]
            from issues_tagging import build_rows_considered
            rows_considered_df = build_rows_considered(spark, source_df)
        except Exception as e:
            logger.warning(
                "rows_considered unavailable (%s) — total_reviews and "
                "mention_rate will be NULL", e,
            )

        review_df = add_issue_features_from_llm(
            spark, source_df, issues_df, rows_considered_df=rows_considered_df,
        )

        # Novel keys: names the model coined that issue_keywords.yaml does not
        # hold. Logged, never dropped — this is how the taxonomy grows from what
        # the data actually says. Observability only; nothing reads it at runtime.
        try:
            from issues_tagging import summarize_novel_keys
            novel = summarize_novel_keys(issues_df).limit(20).collect()
            if novel:
                logger.info("Novel issue keys this run (top %d):", len(novel))
                for row in novel:
                    logger.info(
                        "  %-40s %6d occurrences across %d products",
                        row["issue_key"], row["occurrence_cnt"], row["product_cnt"],
                    )
        except Exception as e:
            logger.debug("Novel-key summary skipped (%s)", e)
    else:
        print("\n2. Applying issue_signals_json + issue_summary enrichment "
              "(KEYWORD FALLBACK — LLM unavailable)...")
        logger.warning(
            "Issue signals produced by KEYWORD FALLBACK. These carry no "
            "root_cause, no resolution_status and YAML-default severity. They "
            "are recomputed on the next healthy run because they were never "
            "written to the LLM cache."
        )
        review_df = add_review_mining_features(spark, source_df, yaml_path)

    # 3. FAQ troubleshooting
    print("\n3. Applying faq_json enrichment...")
    faq_df = add_faq_troubleshooting_features(
        spark, faq_source_df, faq_config_path, tags_df=faq_tags_df,
    )

    # 4. FAQ summary
    print("\n4. Applying faq_summary_json enrichment...")
    # No keys_df: this function keys on tag_id, which it computes itself.
    faq_summary_df = add_faq_summary_features(
        spark, faq_source_df, faq_config_path, tags_df=faq_tags_df,
    )

    # 4b. Staples Business faq_json / faq_summary_json, from the SB questions and their tags
    contract_faq_df = None
    if contract_faq_count:
        print("\n4b. Applying faq_json_contract + faq_summary_json_contract enrichment...")
        contract_faq_df = (
            add_faq_troubleshooting_features(
                spark, contract_faq_source_df, faq_config_path, tags_df=contract_faq_tags_df,
            )
            .select("item_id", F.col(FAQ_TROUBLESHOOTING_FIELD).alias(FAQ_CONTRACT_FIELD))
            .join(
                add_faq_summary_features(
                    spark, contract_faq_source_df, faq_config_path, tags_df=contract_faq_tags_df,
                ).select("item_id", F.col(FAQ_SUMMARY_FIELD).alias(FAQ_SUMMARY_CONTRACT_FIELD)),
                on="item_id", how="full_outer",
            )
        )

    # 7. Merge all enrichments
    print("\n7. Merging all enrichment features...")

    # The LLM path also produces the four precomputed scalars; the keyword
    # fallback does not. Registering them conditionally keeps a degraded run
    # writing a valid (narrower) row rather than failing on a missing column.
    _issue_fields = [ISSUE_SIGNALS_FIELD, ISSUE_SUMMARY_FIELD, RELIABILITY_SCORE_FIELD]
    _scalar_fields = [
        f for f in (HAS_HIGH_SEVERITY_FIELD, HAS_UNRESOLVED_FIELD,
                    TOP_ISSUE_KEYS_FIELD, TOP_ISSUE_TAGS_FIELD)
        if f in review_df.columns
    ]

    ENRICHMENT_REGISTRY = [
        (review_df,      _issue_fields + _scalar_fields),
        (faq_df,         [FAQ_TROUBLESHOOTING_FIELD]),
        (faq_summary_df, [FAQ_SUMMARY_FIELD]),
    ]

    enriched_df = source_df.select(
        F.col("item_id").cast("string").alias("item_id"),
        F.col("web_supercategory_nm"),
    ).dropDuplicates(["item_id"])

    all_fields = []
    for enrich_df, field_names in ENRICHMENT_REGISTRY:
        join_df = enrich_df.select("item_id", *field_names)
        enriched_df = enriched_df.join(join_df, on=["item_id"], how="left")
        all_fields.extend(field_names)

    logger.info("Enrichment fields: %s", all_fields)

    # 8. Convert JSON strings to native Spark types
    print("\n8. Converting JSON strings to native Spark types...")
    enriched_df = (
        enriched_df
        .withColumn(ISSUE_SIGNALS_FIELD, F.from_json(F.col(ISSUE_SIGNALS_FIELD), _SIGNALS_SCHEMA))
        .withColumn(ISSUE_SUMMARY_FIELD, F.from_json(F.col(ISSUE_SUMMARY_FIELD), _ISSUE_SUMMARY_SCHEMA))
        .withColumn(FAQ_TROUBLESHOOTING_FIELD, F.from_json(F.col(FAQ_TROUBLESHOOTING_FIELD), _FAQ_SCHEMA))
        .withColumn(FAQ_SUMMARY_FIELD, F.from_json(F.col(FAQ_SUMMARY_FIELD), _FAQ_SUMMARY_SCHEMA))
        .drop("web_supercategory_nm")
    )

    # 8b. Add timestamp columns
    print("\n8b. Adding pipeline timestamp columns...")
    now_ts = F.lit(datetime.now(timezone.utc))
    enriched_df = (
        enriched_df
        .withColumn("created_at_ts", now_ts)
        .withColumn("last_updated_ts", now_ts)
    )

    # 8c. Converge the target table on the schema we are about to write.
    #
    #     update_fields below COALESCES the two FAQ columns, and coalesce
    #     requires both arms to be the same type. It gets no by-name struct
    #     resolution, unlike a plain `updates.col` assignment, so any drift
    #     between _FAQ_SCHEMA / _FAQ_SUMMARY_SCHEMA and the live table stops
    #     the MERGE dead with DATATYPE_MISMATCH.DATA_DIFF_TYPES. That is
    #     exactly what happened once the LLM migration cut faq_json from 13
    #     struct fields to 4.
    #
    #     This now happens inside the save in step 9: save_data and
    #     incremental_save_data validate the target schema first, and migrate
    #     it on a mismatch, before they write (utils.validate_before_write).
    #     No-op when the table already agrees, and when it does not exist yet.
    #
    #     EVOLVE, not strict (the helpers' default). A keyword-only run (no
    #     review_mining.llm) does not produce the four issue scalars, so they
    #     are absent from enriched_df. Strict mode read that as "retired" and
    #     dropped them — with every good value from the last LLM run — across
    #     the whole table. Evolve keeps them, and the MERGE below already
    #     updates only the scalars this run produced.
    full_out = (
        output_table if output_table.count(".") >= 2
        else f"{output_catalog}.{output_schema}.{output_table}"
    )

    # 9. Save — MERGE (preserves created_at_ts) or first-run create
    print("\n9. Saving results...")
    if not is_first_run:
        # Delta MERGE preserving created_at_ts. Review columns overwrite; FAQ columns
        # coalesce (narrower batch, NULL means not looked at; step 9b clears removed Q&A).
        update_fields = {
            ISSUE_SIGNALS_FIELD:       f"updates.{ISSUE_SIGNALS_FIELD}",
            ISSUE_SUMMARY_FIELD:       f"updates.{ISSUE_SUMMARY_FIELD}",
            RELIABILITY_SCORE_FIELD:   f"updates.{RELIABILITY_SCORE_FIELD}",
            FAQ_TROUBLESHOOTING_FIELD: (
                f"coalesce(updates.{FAQ_TROUBLESHOOTING_FIELD}, "
                f"existing.{FAQ_TROUBLESHOOTING_FIELD})"
            ),
            FAQ_SUMMARY_FIELD: (
                f"coalesce(updates.{FAQ_SUMMARY_FIELD}, "
                f"existing.{FAQ_SUMMARY_FIELD})"
            ),
            "last_updated_ts":         "updates.last_updated_ts",
            # created_at_ts intentionally absent — preserved from existing row
        }
        # Only merge the scalars the run actually produced: a keyword-fallback
        # run must not blank out good values written by the last healthy one.
        for _f in (HAS_HIGH_SEVERITY_FIELD, HAS_UNRESOLVED_FIELD,
                   TOP_ISSUE_KEYS_FIELD, TOP_ISSUE_TAGS_FIELD):
            if _f in enriched_df.columns:
                update_fields[_f] = f"updates.{_f}"
        incremental_save_data(
            enriched_df,
            spark,
            table=output_table,
            update_fields=update_fields,
            catalog=output_catalog,
            schema=output_schema,
        )
    else:
        # First run: table doesn't exist yet — create it
        save_data(
            enriched_df,
            spark,
            catalog=output_catalog,
            schema=output_schema,
            table=output_table,
        )

    # 9a. Staples Business FAQ: its own MERGE, so a product that is only in the SB FAQ scope
    #     keeps its issue fields as they are.
    if contract_faq_df is not None:
        contract_df = (
            contract_faq_df
            .withColumn(FAQ_CONTRACT_FIELD, F.from_json(F.col(FAQ_CONTRACT_FIELD), _FAQ_SCHEMA))
            .withColumn(FAQ_SUMMARY_CONTRACT_FIELD,
                        F.from_json(F.col(FAQ_SUMMARY_CONTRACT_FIELD), _FAQ_SUMMARY_SCHEMA))
            .withColumn("created_at_ts", now_ts)
            .withColumn("last_updated_ts", now_ts)
        )
        incremental_save_data(
            contract_df,
            spark,
            table=output_table,
            update_fields={
                FAQ_CONTRACT_FIELD: (
                    f"coalesce(updates.{FAQ_CONTRACT_FIELD}, existing.{FAQ_CONTRACT_FIELD})"
                ),
                FAQ_SUMMARY_CONTRACT_FIELD: (
                    f"coalesce(updates.{FAQ_SUMMARY_CONTRACT_FIELD}, "
                    f"existing.{FAQ_SUMMARY_CONTRACT_FIELD})"
                ),
                "last_updated_ts": "updates.last_updated_ts",
            },
            catalog=output_catalog,
            schema=output_schema,
        )

    # 9b. Clear FAQ columns whose item no longer has any q_and_a.
    #     UPDATE scoped by anti-join (rows also hold review fields); last_updated_ts is
    #     not bumped because it is the incremental cutoff.
    if not is_first_run:
        catalog_table = faq_tables_cfg["PRODUCT_CATALOG_TABLE"]
        # full_out was resolved in step 8c above.
        try:
            cleared = spark.sql(f"""
                UPDATE {full_out} AS f
                SET {FAQ_TROUBLESHOOTING_FIELD} = NULL,
                    {FAQ_SUMMARY_FIELD} = NULL
                WHERE ({FAQ_TROUBLESHOOTING_FIELD} IS NOT NULL
                       OR {FAQ_SUMMARY_FIELD} IS NOT NULL)
                  AND NOT EXISTS (
                      SELECT 1 FROM {catalog_table} AS d
                      WHERE d.item_id = f.item_id
                        AND d.q_and_a IS NOT NULL
                        AND size(d.q_and_a) > 0
                  )
            """)
            logger.info(
                "Stale FAQ payloads cleared (item has no q_and_a): %s",
                cleared.collect()[0][0] if cleared.columns else "n/a",
            )
        except Exception as e:
            # Fatal on purpose: nothing downstream re-checks this invariant.
            logger.error(
                "Stale FAQ cleanup FAILED (%s) — failing the task rather than "
                "publishing FAQ payloads for items with no q_and_a", e
            )
            raise

    # 9c. Staples Business FAQ for every other product: a copy of faq_json when it is live on
    #     SB and has Staples.com questions; cleared when it is not on SB or has no questions.
    if FAQ_CONTRACT_FIELD in spark.table(full_out).columns:
        has_dotcom_q = "d.q_and_a_dotcom IS NOT NULL AND size(d.q_and_a_dotcom) > 0"
        has_contract_q = "d.q_and_a_contract IS NOT NULL AND size(d.q_and_a_contract) > 0"
        try:
            copied = spark.sql(f"""
                UPDATE {full_out} AS f
                SET {FAQ_CONTRACT_FIELD} = {FAQ_TROUBLESHOOTING_FIELD},
                    {FAQ_SUMMARY_CONTRACT_FIELD} = {FAQ_SUMMARY_FIELD}
                WHERE EXISTS (
                      SELECT 1 FROM {source_table} AS d
                      WHERE d.item_id = f.item_id AND d.is_live_contract AND {has_dotcom_q}
                  )
                  AND NOT (to_json(f.{FAQ_CONTRACT_FIELD}) <=> to_json(f.{FAQ_TROUBLESHOOTING_FIELD})
                           AND to_json(f.{FAQ_SUMMARY_CONTRACT_FIELD})
                               <=> to_json(f.{FAQ_SUMMARY_FIELD}))
            """)
            cleared = spark.sql(f"""
                UPDATE {full_out} AS f
                SET {FAQ_CONTRACT_FIELD} = NULL,
                    {FAQ_SUMMARY_CONTRACT_FIELD} = NULL
                WHERE ({FAQ_CONTRACT_FIELD} IS NOT NULL OR {FAQ_SUMMARY_CONTRACT_FIELD} IS NOT NULL)
                  AND NOT EXISTS (
                      SELECT 1 FROM {source_table} AS d
                      WHERE d.item_id = f.item_id AND d.is_live_contract
                        AND (({has_dotcom_q}) OR ({has_contract_q}))
                  )
            """)
            logger.info(
                "SB FAQ copied from Staples.com: %s rows; cleared: %s rows",
                copied.collect()[0][0] if copied.columns else "n/a",
                cleared.collect()[0][0] if cleared.columns else "n/a",
            )
        except Exception as e:
            logger.error("SB FAQ copy/cleanup FAILED (%s) — failing the task", e)
            raise

    # Release cached DataFrames after all actions have materialised
    if question_keys_df is not None:
        question_keys_df.unpersist()
    faq_source_df.unpersist()
    if contract_keys_df is not None:
        contract_keys_df.unpersist()
    contract_faq_source_df.unpersist()

    print("\n" + "=" * 80)
    print("REVIEW MINING ENRICHMENT COMPLETE")
    if incremental and not is_first_run:
        print(f"  Mode: INCREMENTAL (cutoff: {cutoff_ts}, buffered: {cutoff_ts_safe})")
    else:
        print(f"  Mode: FULL {'(first run)' if is_first_run else '(refresh)'}")
    print("=" * 80)

    return enriched_df



# =============================================================================
# 8.  STANDALONE EXECUTION
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    # py4j logs a "Received command" line every second at INFO. On run
    # 794719721372863 that filled the 5 MB run-output cap and cut off the start
    # of the run, including the cache hit/miss counts.
    logging.getLogger("py4j").setLevel(logging.WARNING)
    logger = logging.getLogger(__name__)

    spark = get_spark_session()
    
    # os.environ.setdefault("sf_env", "dev")
    tables = _ensure_table_config()

    full_refresh = tables["FULL_REFRESH"]
    if full_refresh:
        logger.warning(
            "full_refresh=true — reprocessing the ENTIRE catalogue, not just "
            "changed items. This re-tags every question and is expensive."
        )
    # One-off: issue-tag the WHOLE catalogue (cache misses only) while FAQ
    # stays incremental. CLI-only so it cannot be left on in config.
    issue_backfill = "--issue-backfill" in sys.argv
    if issue_backfill:
        logger.warning(
            "--issue-backfill — issue tagging covers the WHOLE catalogue this "
            "run; only reviews missing from the LLM cache are sent to the model."
        )

    run_review_mining_pipeline(
        spark,
        source_table=tables["SOURCE_TABLE"],
        output_table=tables["OUTPUT_TABLE"],
        incremental=not full_refresh,
        issue_backfill=issue_backfill,
    )   
