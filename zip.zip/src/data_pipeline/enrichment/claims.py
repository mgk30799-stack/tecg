"""
Data Enrichment Pipeline - Product Attribute Extraction

Extracts structured marketing claims from product bullet points using regex patterns
defined in `config/claims_config.yml`. Also extracts key specification highlights
for specific product categories (Paper, Trash Bags, Computers, Printers, Chairs, Ink & Toner),
and extracts electrical specifications (Voltage, Wattage, Amperage, Battery, etc.)
from `spec_json`.

Pipeline Steps:
1. Load product data from a source table defined in `config/general.yml`.
2. Extract claims from `bullets_json` using regex patterns.
3. Format extracted claims into a clean `claims` array based on `output_format` rules.
4. Extract key specs into `highlights_json` for Paper, Trash Bags, Computers, Printers, Chairs, and Ink & Toner categories.
5. Extract electrical specifications into `elec_spec_json`.
6. Save the enriched data to a Delta table using a generic `save_data` utility,
   supporting merge operations.

Output Columns:
- `extracted_claims_json`: Raw JSON array of all matched claims with details.
- `claims`: A clean array of formatted claim strings for display.
- `highlights_json`: A JSON map of key-value specs for specific categories.
- `elec_spec_json`: A JSON map of electrical attribute names to their values.

Usage:
    from src.data_pipeline.enrichment.claims import run_claims_pipeline

    # The pipeline is configured via YAML files, but can be overridden.
    run_claims_pipeline(
        spark,
        source_table="mld01_ml_de.product.product_discovery_data",
        output_table="product_claims"
    )
"""

import sys
import os
import re
import json
import logging
from typing import List, Dict, Any, Optional

# Add project root to sys.path for absolute imports
try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    # Fallback for Databricks notebooks/jobs where __file__ is missing
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from databricks.connect import DatabricksSession
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField, ArrayType

from utils import save_data, get_spark_session, read_config, read_all_products
from elec_spec import elec_spec_logic, ELEC_SPEC_SCHEMA
from schemas import CLAIM_STRUCT_TYPE, STRING_MAP_SCHEMA


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _log_section(title: str, width: int = 60) -> None:
    logger.info("")
    logger.info("=" * width)
    logger.info(title)
    logger.info("=" * width)


def _log_dataframe_rows(df: DataFrame, title: str, limit: Optional[int] = None) -> None:
    logger.info(title)
    rows_df = df.limit(limit) if limit is not None else df
    for row_json in rows_df.toJSON().collect():
        logger.info(row_json)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "claims_config.yml")
_config = read_config(CONFIG_PATH)
CLAIM_PATTERNS = _config.get("claim_patterns", {})


# ---------------------------------------------------------------------------
# Category Highlights — key spec attributes per web_supercategory_nm
# ---------------------------------------------------------------------------
CATEGORY_HIGHLIGHTS = {
    "paper": [
        "Paper Weight (lbs.)",
        "Brightness",
        "Total Number of Sheets",
        "Number of Reams",
        "Width in Inches",
        "Length in Inches",
    ],
    "trash bags": [
        "Max Trash Bag Capacity (Gallons)",
        "Density",
        "Trash Bag Strength",
        "Trash Bag Thickness",
        "Pack Qty",
        "Width in Inches",
        "Height in Inches",
        "Trash Bag Closure",
    ],
    "computers": [
        "Processor Speed (Ghz)",
        "Processor Type",
        "SSD Capacity",
        "Hard Drive Type",
        "Desktop Hard Drive Type",
        "Computer Operating System",
        "Installed RAM",
        "Memory Type",
        "Screen Size",
        "Screen Resolution",
        "Laptop Video Graphics",
        "Desktop Video Graphics",
    ],
    "printers": [
        "Printer Function",
        "Output Type",
        "Duplex Printing",
        "Printer Max Paper Size",
        "Printer Type",
    ],
    "chairs": [
        "Warranty Information",
        "Furnishing Material",
        "Maximum Weight Capacity",
        "Assembly Information",
        "Recline",
        "Ergonomic",
    ],
    "ink & toner": [
        "Ink or Toner Color",
        "Ink or Toner Pack Size",
        "Page Yield Per Cartridge (Up to)",
    ],
}


# ---------------------------------------------------------------------------
# Claims extraction helpers
# ---------------------------------------------------------------------------

def extract_claims_from_text(text: str) -> List[Dict[str, Any]]:
    """Extract claims from a single text using all configured regex patterns."""
    claims = []
    for pattern_name, pattern_info in CLAIM_PATTERNS.items():
        for match in re.finditer(pattern_info["pattern"], text, re.IGNORECASE):
            claims.append({
                "claim_type": pattern_info["claim_type"],
                "pattern": pattern_name,
                "text": match.group(0),
                "value": match.group(1) if match.groups() else None,
                "unit": match.group(2) if len(match.groups()) > 1 else None,
                "source": "bullets_json",
                "source_text": text,
                "confidence": 0.9,
            })
    return claims


def deduplicate_claims(claims: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate claims by normalized text."""
    seen = set()
    unique = []
    for claim in claims:
        norm = re.sub(r'\s+', ' ', claim.get('text', '').lower().replace('-', ' ')).strip()
        if norm not in seen:
            seen.add(norm)
            unique.append(claim)
    return unique


def extract_claims_logic(bullet_texts: Optional[List[str]]) -> Dict[str, Optional[str]]:
    """UDF logic: extract and deduplicate claims from bullet text list."""
    if not bullet_texts:
        return {"extracted_claims_json": None}

    all_claims = []
    for bullet in bullet_texts:
        if bullet:
            all_claims.extend(extract_claims_from_text(bullet))

    unique_claims = deduplicate_claims(all_claims)
    return {"extracted_claims_json": unique_claims if unique_claims else None}


# ---------------------------------------------------------------------------
# Highlights extraction (UDF logic at module level for testability)
# ---------------------------------------------------------------------------

def highlights_logic(category: str, specs: Any) -> Optional[Dict[str, Optional[str]]]:
    """
    Extract key specification highlights for a product category.

    Args:
        category: web_supercategory_nm value (matched case-insensitively).
        specs: spec_json column — list of Row/dict with attribute_nm & attribute_value_txt.

    Returns:
        Dict of attribute_name -> value for matched specs (sorted by key), or None.
    """
    if not category or not specs:
        return None

    # Parse specs into a lowercased lookup dict
    if isinstance(specs, str):
        try:
            specs_list = json.loads(specs)
        except (json.JSONDecodeError, TypeError):
            return None
    else:
        specs_list = specs

    spec_dict: Dict[str, str] = {}
    for row in specs_list:
        c = row.asDict() if hasattr(row, 'asDict') else row
        if isinstance(c, dict):
            nm = c.get("attribute_nm")
            val = c.get("attribute_value_txt")
            if nm:
                spec_dict[nm.strip().lower()] = val

    keys = CATEGORY_HIGHLIGHTS.get(category.strip().lower())
    if keys is None:
        return None

    res = {k: spec_dict.get(k.lower()) for k in keys}
    if not any(v is not None for v in res.values()):
        return None
    return dict(sorted(res.items()))


# ---------------------------------------------------------------------------
# Claims formatting (UDF logic at module level for testability)
# ---------------------------------------------------------------------------
UPPERCASE_ABBREVIATIONS = ["bpa", "epa", "ul", "ce", "fcc", "bifma", "greenguard", "usa", "uk"]


def format_claims_logic(extracted_claims) -> Optional[List[str]]:
    """Format extracted claim rows into clean display strings."""
    if not extracted_claims:
        return None

    result = []
    for row in extracted_claims:
        c = row.asDict() if hasattr(row, 'asDict') else row
        pattern = c.get("pattern", "")
        text = c.get("text", "")
        claim_type = c.get("claim_type", "")

        pattern_config = CLAIM_PATTERNS.get(pattern, {})
        fmt = pattern_config.get("output_format", "text")

        if fmt == "pattern":
            clean_pattern = pattern.replace("_", " ")
            if clean_pattern == "time savings":
                clean_pattern = "time saving"
            result.append(clean_pattern)
        elif fmt == "claim_type":
            result.append(claim_type)
        else:
            normalized = re.sub(r'\s+', ' ', (text or "").lower().replace('-', ' ')).strip()
            for abbr in UPPERCASE_ABBREVIATIONS:
                normalized = re.sub(rf'\b{abbr}\b', abbr.upper(), normalized)
            normalized = re.sub(r'\benergy star\b', 'Energy Star', normalized)
            result.append(normalized)

    return sorted(list(dict.fromkeys(result)))


# ---------------------------------------------------------------------------
# DataFrame orchestration
# ---------------------------------------------------------------------------

def _prepare_claims_df(df: DataFrame, id_col: str) -> DataFrame:
    """Select required columns and prepare bullets array for UDF consumption."""
    cols_to_select = [id_col, "bullets_json"]
    if "web_supercategory_nm" in df.columns:
        cols_to_select.append("web_supercategory_nm")
    if "spec_json" in df.columns:
        cols_to_select.append("spec_json")

    claims_df = df.select(*cols_to_select)

    bullets_field = [f for f in df.schema.fields if f.name == "bullets_json"][0]
    if isinstance(bullets_field.dataType, StringType):
        claims_df = claims_df.withColumn(
            "bullets_array", F.from_json(F.col("bullets_json"), ArrayType(StringType()))
        )
    else:
        claims_df = claims_df.withColumn("bullets_array", F.col("bullets_json"))

    return claims_df


def _apply_extraction_udfs(claims_df: DataFrame, id_col: str) -> DataFrame:
    """Apply all extraction UDFs and return a slim DataFrame with output columns."""
    result_schema = StructType([StructField("extracted_claims_json", CLAIM_STRUCT_TYPE, True)])
    extract_claims_udf = F.udf(extract_claims_logic, result_schema)
    extract_highlights_udf = F.udf(highlights_logic, STRING_MAP_SCHEMA)
    format_claims_udf = F.udf(format_claims_logic, ArrayType(StringType()))
    elec_spec_udf = F.udf(elec_spec_logic, ELEC_SPEC_SCHEMA)

    claims_df = claims_df.withColumn("claims_output", extract_claims_udf(F.col("bullets_array")))
    claims_df = claims_df.withColumn(
        "claims", format_claims_udf(F.col("claims_output.extracted_claims_json"))
    )

    if "web_supercategory_nm" in claims_df.columns and "spec_json" in claims_df.columns:
        claims_df = claims_df.withColumn(
            "highlights_json",
            extract_highlights_udf(F.col("web_supercategory_nm"), F.col("spec_json")),
        )
    else:
        claims_df = claims_df.withColumn(
            "highlights_json", F.lit(None).cast(STRING_MAP_SCHEMA)
        )

    if "spec_json" in claims_df.columns:
        claims_df = claims_df.withColumn("elec_spec_json", elec_spec_udf(F.col("spec_json")))
    else:
        claims_df = claims_df.withColumn(
            "elec_spec_json", F.lit(None).cast(STRING_MAP_SCHEMA)
        )

    return claims_df.select(
        id_col,
        F.col("claims_output.extracted_claims_json").alias("extracted_claims_json"),
        F.col("claims"),
        F.col("highlights_json"),
        F.col("elec_spec_json"),
    )


def extract_claims_data(df: DataFrame) -> DataFrame:
    """
    Apply claims extraction logic to DataFrame.

    Steps:
        1. Prepare a slim working DataFrame with required columns.
        2. Apply extraction UDFs (claims, highlights, electrical specs).
        3. Join results back and select final output columns.
    """
    if "bullets_json" not in df.columns:
        logger.warning("'bullets_json' column not found - skipping extraction.")
        return df

    id_col = "item_id" if "item_id" in df.columns else "product_id"
    claims_df = _prepare_claims_df(df, id_col)
    claims_df = _apply_extraction_udfs(claims_df, id_col)

    output_cols = ["extracted_claims_json", "claims", "highlights_json", "elec_spec_json"]
    base_df = df
    for col_name in output_cols:
        if col_name in base_df.columns:
            base_df = base_df.drop(col_name)

    result_df = base_df.join(claims_df, id_col, "left")

    final_cols = [
        id_col,
        "bullets_json",
        "spec_json",
        "extracted_claims_json",
        "claims",
        "highlights_json",
        "web_supercategory_nm",
        "web_category_nm",
        "web_department_nm",
        "web_class_nm",
        "elec_spec_json",
    ]
    return result_df.select(*[c for c in final_cols if c in result_df.columns])


# ---------------------------------------------------------------------------
# Pipeline entrypoint
# ---------------------------------------------------------------------------

# Columns this task reads from its source table.
SOURCE_COLUMNS = ["item_id", "bullets_json", "spec_json", "web_supercategory_nm",
                  "web_category_nm", "web_department_nm", "web_class_nm"]


def run_claims_pipeline(
    spark: DatabricksSession,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None,
    mode: str = "merge",
) -> DataFrame:
    """Run the claims extraction pipeline end-to-end."""
    _log_section("PRODUCT ATTRIBUTE EXTRACTION PIPELINE", width=80)

    logger.info("1. Loading data from %s...", source_table)
    try:
        df = read_all_products(spark, source_table, SOURCE_COLUMNS)
        logger.info("Loaded %s rows", df.count())
    except Exception:
        logger.exception("Error loading table %s", source_table)
        raise

    logger.info("2. Extracting claims, highlights, and electrical specs...")
    result_df = extract_claims_data(df)

    id_col = "item_id" if "item_id" in result_df.columns else "product_id"
    cols_to_show = [id_col, "extracted_claims_json"]
    if "highlights_json" in result_df.columns:
        cols_to_show.append("highlights_json")
    if "elec_spec_json" in result_df.columns:
        cols_to_show.append("elec_spec_json")
    _log_dataframe_rows(result_df.select(*cols_to_show), "Sample Results:", limit=5)

    logger.info("3. Saving results...")
    save_data(
        result_df,
        spark,
        catalog=output_catalog,
        schema=output_schema,
        table=output_table,
        mode=mode,
    )

    _log_section("PIPELINE COMPLETE", width=80)
    return result_df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    spark = get_spark_session()

    GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
    _general_config = read_config(GENERAL_CONFIG_PATH)

    SOURCE_TABLE = _general_config["claims"]["tables"]["source_table"]
    OUTPUT_TABLE = _general_config["claims"]["tables"]["output_table"]

    logger.info("Running Product Attribute Extraction Pipeline with the following configuration:")
    logger.info("Source Table: %s", SOURCE_TABLE)
    logger.info("Output Table: %s", OUTPUT_TABLE)

    run_claims_pipeline(spark, SOURCE_TABLE, OUTPUT_TABLE)
