"""
Product Lifecycle Data Enrichment Pipeline

This module extracts lifecycle information and creates new features natively using PySpark.
"""

import sys
import os
import json
import re
import logging
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, BooleanType, DateType
from typing import Optional, Tuple, Dict
from utils import (save_data, resolve_output_table, get_spark_session, read_config,
                   read_all_products, read_hazard_by_product)

logger = logging.getLogger(__name__)

# =============================================================================
# PROJECT ROOT
# =============================================================================

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# =============================================================================
# TABLE REFERENCES (lazy-loaded)
# =============================================================================

_table_config: Dict[str, str] = {}


def _ensure_table_config() -> Dict[str, str]:
    """Load table references from general.yml on first use."""
    if _table_config:
        return _table_config

    config_path = os.path.join(PROJECT_ROOT, "config", "general.yml")
    cfg = read_config(config_path)

    _table_config["HAZARD_TABLE"] = cfg["lifecycle"]["tables"]["HAZARD_TABLE"]
    _table_config["SOURCE_TABLE"] = cfg["lifecycle"]["tables"]["SOURCE_TABLE"]
    _table_config["PRODUCT_MASTER_TABLE"] = cfg["lifecycle"]["tables"]["PRODUCT_MASTER_TABLE"]
    _table_config["OUTPUT_TABLE"] = cfg["lifecycle"]["tables"]["output_table"]
    return _table_config


# Placeholder values seen in merchant free-text columns; shared with warning logic.
_RESTRICTION_JUNK = frozenset({
    'n', 'y', 'n/a', 'na', 'none', 'no', 'null', 'blank',
    '-', '--', 'u', 'unknown', 'see sds',
})


def _safe_str(v: Optional[str]) -> str:
    if v is None:
        return ""
    s = str(v)
    return "" if s.lower() == "nan" else s


def _has_real_text(v: Optional[str]) -> bool:
    """True when a merchant free-text field carries content, not a placeholder."""
    s = _safe_str(v).strip()
    return bool(s) and s.lower() not in _RESTRICTION_JUNK


def _spec_values(spec_json) -> list:
    """
    Normalise spec_json (array of Row/struct or JSON string) into a list of
    (attribute_nm, attribute_value_txt).
    """
    if spec_json is None:
        return []

    if isinstance(spec_json, str):
        if not spec_json.strip():
            return []
        try:
            spec_json = json.loads(spec_json)
        except Exception:
            return []

    if isinstance(spec_json, dict):
        return []

    if not isinstance(spec_json, (list, tuple)):
        try:
            spec_json = list(spec_json)
        except TypeError:
            return []

    out = []
    for spec in spec_json:
        if isinstance(spec, dict):
            nm, val = spec.get("attribute_nm"), spec.get("attribute_value_txt")
        elif hasattr(spec, "asDict"):                 # pyspark Row
            d = spec.asDict()
            nm, val = d.get("attribute_nm"), d.get("attribute_value_txt")
        elif hasattr(spec, "attribute_nm"):           # namedtuple-like
            nm, val = spec.attribute_nm, getattr(spec, "attribute_value_txt", None)
        else:
            continue
        out.append((_safe_str(nm).strip(), _safe_str(val).strip()))
    return out


def _bullet_values(bullets_json) -> list:
    """
    Normalise bullets_json into a list of strings.

    `bullets_json` is array<string> in product_discovery_data, so a Python UDF
    receives a real list — json.loads() on it raises TypeError. Every call site
    wrapped that in a bare except, so bullet scanning silently did nothing.
    Accepts a list or a JSON string; anything else yields [].
    """
    if bullets_json is None:
        return []

    if isinstance(bullets_json, str):
        if not bullets_json.strip():
            return []
        try:
            bullets_json = json.loads(bullets_json)
        except Exception:
            return []

    if isinstance(bullets_json, dict):
        return []

    if not isinstance(bullets_json, (list, tuple)):
        try:
            bullets_json = list(bullets_json)
        except TypeError:
            return []
    return [_safe_str(b) for b in bullets_json if b is not None]


def get_multipack_udf(title: str, bullets_json_str: str, specs_json_str: str) -> bool:
    title_lower = str(title if title is not None else "").lower()

    # Added word boundaries to prevent substring matching
    if re.search(r'\b([2-9]|[0-9]{2,})\s*(count|ct|per package|pc|pack|pk|bundle|set|pair|piece|pkg|dozen|dz)s?\b', title_lower):
        return True
    if re.search(r'\b([2-9]|[0-9]{2,})\s*/\s*(box|pack|case|ct|pk|set|pkg|dz|pck)s?\b', title_lower):
        return True

    for b in _bullet_values(bullets_json_str):
        b_lower = b.lower()
        # Count-word suffixes only; bare '/' and 'per' match fractions and ratios
        if re.search(r'\b([2-9]|[0-9]{2,})\s*(count|ct|pc|pack|pk|bundle|set|pair|piece)s?\b', b_lower):
            return True

    multipack_attrs = {
        'Selling Quantity', 'Pack Qty', 'Number of Plates per Pack',
        'Number of Gloves per Box', 'Number of Pairs',
        'Number of Dressings per Pack', 'Number of Cups per Pack',
        'Number of Bandages per Box', 'Pieces In Set',
        'Quantity/Pack', 'Total Number of Wipes', '# of Bags per Box',
    }
    for raw_nm, val in _spec_values(specs_json_str):
        if raw_nm in multipack_attrs:
            num_match = re.search(r'([0-9]+)', val)
            if num_match:
                qty = float(num_match.group(1))
                # Restrict to realistic multipack sizes (2 to 24) to avoid capturing single-item counts
                if 1 < qty <= 24:
                    return True

        # 'box' is excluded: a single box is not a multipack
        if raw_nm == 'Selling Quantity (UOM)' and val.lower() in {
            'carton', 'case', 'bundle', 'dozen', 'set', 'pack'
        }:
            return True

    return False


# =============================================================================
# WARNING — keyword patterns + resolve logic
# =============================================================================

# No flame words: "flame resistant" or "non-flammable" describes a feature, not a hazard.
# Only the aerosol flag in the hazard data gives a Flammable warning.
_WARNING_PATTERNS = re.compile(
    r'warning\s*:|caution\s*:|danger\s*:|do not use|'
    r'for external use only|proposition 65|prop\s*65|cancer|'
    r'reproductive harm|hazmat',
    re.IGNORECASE,
)

_WARNING_SCOPED_CATEGORIES = {
    'Cleaning Supplies', 'Free Sample Items', 'Laboratory & Scientific Supplies',
    'TV & Streaming Media', 'Phones, Cameras & Electronics', 'Kitchen Tools & Appliances',
    'Gaming', 'Networking & WiFi', 'Audio', 'Hard Drives & Data Storage',
    'Computer Software', 'Office Supplies', 'Education', 'Workwear',
    'Wearable Technology', 'Safety Supplies', 'Gift Cards',
    'Shredders, Projectors & Office Machines', 'Tablets & iPads', 'Paper',
    'Computers & Accessories', 'Batteries & Power', 'Restaurant & Foodservice Supplies',
    'Printers & Scanners', 'Office Decor, Homewares & Appliances', 'Healthcare Supplies',
    'Gift Shop', 'Smart Home & Security', 'Tools, Parts & Supplies',
    'Retail Store Supplies', 'Ink & Toner', 'Facilities', 'Coffee, Water & Snacks',
    'Expanded Assortment', 'Shipping, Packing & Mailing Supplies',
    'Bags, Backpacks & Luggage', 'Security, Banking & Cash', 'Arts & Crafts',
    'Party Supplies', 'Warranties & Protection Plans', 'Tech Services', 'Furniture',
}


def _extract_warning_bullets(bullets_json) -> Optional[str]:
    matched = [b.strip() for b in _bullet_values(bullets_json)
               if _WARNING_PATTERNS.search(b)]
    return "; ".join(matched) if matched else None


def _resolve_warning(
    web_supercategory_nm, description, bullets_json_str, specs_json_str,
    prop_65_ind, wercs_p65_warning_txt, wercs_p65_chem_txt, wercs_p651_ind,
    hazmat_cd, proper_shipping_nm, web_category_nm, sds_document_url,
    hazard_primary_label_txt, other_restrictions_txt,
    battery_ind, wercs_batt_ind, aerosol_ind, sds_required_ind,
) -> Tuple[Optional[str], Optional[str]]:

    def is_yes(val):
        return val and str(val).strip().upper() == 'Y'

    def has_text(val):
        return _has_real_text(val)

    # 1. WERCS Prop 65 text
    if has_text(wercs_p65_warning_txt):
        txt = str(wercs_p65_warning_txt).strip()
        txt_lower = txt.lower()
        if 'cancer' in txt_lower and 'reproductive' in txt_lower:
            label = 'Prop 65 - Cancer & Reproductive Harm'
        elif 'cancer' in txt_lower:
            label = 'Prop 65 - Cancer Risk'
        elif 'reproductive' in txt_lower:
            label = 'Prop 65 - Reproductive Harm'
        else:
            label = 'Prop 65 - Chemical Warning'
        return (label, txt)

    # 2. Prop 65 flag
    if is_yes(prop_65_ind) or is_yes(wercs_p651_ind):
        txt = ("WARNING: This product contains chemicals known to the State of California "
               "to cause cancer and birth defects or other reproductive harm.")
        if has_text(wercs_p65_chem_txt):
            txt += f" (Chemical: {str(wercs_p65_chem_txt).strip()})"
        return ('Prop 65 - Chemical Warning', txt)

    # 3. Hazmat shipping code
    if is_yes(hazmat_cd):
        txt = "HAZMAT WARNING"
        if has_text(proper_shipping_nm):
            txt += f": {str(proper_shipping_nm).strip()}"
        return ('Hazmat Warning', txt)

    # 4. Hazard primary label
    if has_text(hazard_primary_label_txt):
        label_txt = str(hazard_primary_label_txt).strip()
        label_lower = label_txt.lower()
        category = 'Battery Transport Hazard' if ('lithium' in label_lower or 'battery' in label_lower) else 'Hazmat Warning'
        return (category, f"HAZARD: {label_txt}")

    # 5. Battery indicators
    if is_yes(battery_ind) or is_yes(wercs_batt_ind):
        return ('Battery Transport Hazard',
                "WARNING: This product contains lithium batteries. "
                "Special handling and shipping restrictions may apply.")

    # 6. Aerosol indicator
    if is_yes(aerosol_ind):
        return ('Flammable / Aerosol Warning',
                "WARNING: This product is a pressurized aerosol container. "
                "Keep away from heat, sparks, and open flame.")

    # 7. SDS required
    if is_yes(sds_required_ind):
        return ('Chemical Hazard - SDS Required',
                "WARNING: This product requires a Safety Data Sheet (SDS). "
                "Handle with care and follow all safety instructions.")

    # 8. Other restrictions
    if has_text(other_restrictions_txt):
        return ('Other Safety Restriction', str(other_restrictions_txt).strip())

    # Rules 1-8 read the hazard data, so they apply to every product. Rules 9-11 read the
    # product's own text and category, so they stay limited to these supercategories.
    if web_supercategory_nm not in _WARNING_SCOPED_CATEGORIES:
        return (None, None)

    # 9. Spec attributes
    NEGATIVE_VALUES = {'no', 'n', 'false', 'none', 'n/a'}
    matched_specs = []
    for nm, val in _spec_values(specs_json_str):
        nm_lower = nm.lower()
        val_lower = val.lower()
        if 'prop 65' in nm_lower or 'proposition 65' in nm_lower:
            if val_lower not in NEGATIVE_VALUES:
                matched_specs.append(f"{nm}: {val}")
    if matched_specs:
        return ('Prop 65 - Chemical Warning', "; ".join(matched_specs))

    # 10. Bullet warnings
    bullet_warning = _extract_warning_bullets(bullets_json_str)
    if bullet_warning:
        bw_lower = bullet_warning.lower()
        if 'prop 65' in bw_lower or 'proposition 65' in bw_lower or 'cancer' in bw_lower:
            label = 'Prop 65 - Chemical Warning'
        elif 'battery' in bw_lower or 'lithium' in bw_lower:
            label = 'Battery Transport Hazard'
        else:
            label = 'Product Safety Warning'
        return (label, bullet_warning)

    # 11. SDS implicit
    SDS_IMPLICIT_CATEGORIES = {
        'cleaning chemicals & wipes', 'hand soaps & sanitizers',
        'dishwashing', 'laundry care', 'battery shop',
        'otc pharmaceuticals', 'personal care',
    }
    if has_text(sds_document_url):
        if (web_category_nm or "").lower() in SDS_IMPLICIT_CATEGORIES:
            return ('Chemical Hazard - SDS Required',
                    "WARNING: This product has an associated Safety Data Sheet. See warning_url for details.")

    return (None, None)


def get_warning_udf(
    web_supercategory_nm, description, bullets_json_str, specs_json_str,
    prop_65_ind, wercs_p65_warning_txt, wercs_p65_chem_txt, wercs_p651_ind,
    hazmat_cd, proper_shipping_nm, web_category_nm, sds_document_url,
    hazard_primary_label_txt, other_restrictions_txt,
    battery_ind, wercs_batt_ind, aerosol_ind, sds_required_ind,
) -> Optional[str]:
    label, text = _resolve_warning(
        web_supercategory_nm, description, bullets_json_str, specs_json_str,
        prop_65_ind, wercs_p65_warning_txt, wercs_p65_chem_txt, wercs_p651_ind,
        hazmat_cd, proper_shipping_nm, web_category_nm, sds_document_url,
        hazard_primary_label_txt, other_restrictions_txt,
        battery_ind, wercs_batt_ind, aerosol_ind, sds_required_ind,
    )
    if label and text:
        return f"{label}: {text}"
    elif text:
        return text
    return None


def get_warning_url_udf(
    web_supercategory_nm, web_category_nm, description,
    bullets_json_str, specs_json_str, seller_tos, sds_document_url,
) -> Optional[str]:
    # The safety data sheet comes from the hazard data, so it applies to every product.
    if sds_document_url and str(sds_document_url).strip():
        return str(sds_document_url).strip()
    return None


# =============================================================================
# MAIN: add_lifecycle_features()
# =============================================================================

def add_lifecycle_features(df: DataFrame) -> DataFrame:
    """Apply lifecycle enrichments over the aggregated product DataFrame."""
    tables = _ensure_table_config()
    logger.info("Starting lifecycle feature enrichment")

    df = df.dropDuplicates(["item_id"])

    evaluate_multipack = F.udf(get_multipack_udf, BooleanType())
    evaluate_warning = F.udf(get_warning_udf, StringType())
    evaluate_warning_url = F.udf(get_warning_url_udf, StringType())

    try:
        spark = df.sparkSession

        if spark.catalog.tableExists(tables["HAZARD_TABLE"]):
            hazard_cols = [
                "PROP_65_IND", "WERCS_P651_IND",
                "WERCS_P65_WARNING_TXT", "WERCS_P65_CHEM_TXT",
                "HAZMAT_CD", "PROPER_SHIPPING_NM", "SDS_DOCUMENT_URL",
                "SDS_DOCUMENT_LINK_URL", "SDS_REQUIRED_IND",
                "HAZARD_PRIMARY_LABEL_REQUIRED_TXT",
                "OTHER_RESTRICTIONS_COMMENT_TXT",
                "BATTERY_CONTAINING_PRODUCT_IND", "WERCS_BATT_IND",
                "AEROSOL_INDICATOR_CD",
            ]
            # One row per product: the table has a row per product per source system.
            hazard_df = (
                read_hazard_by_product(spark, tables["HAZARD_TABLE"], hazard_cols)
                     .withColumnRenamed("PRODUCT_ID",                        "hazard_product_id")
                     .withColumnRenamed("PROP_65_IND",                       "hazard_prop_65_ind")
                     .withColumnRenamed("WERCS_P651_IND",                    "hazard_wercs_p651_ind")
                     .withColumnRenamed("WERCS_P65_WARNING_TXT",             "hazard_wercs_p65_warning_txt")
                     .withColumnRenamed("WERCS_P65_CHEM_TXT",                "hazard_wercs_p65_chem_txt")
                     .withColumnRenamed("HAZMAT_CD",                         "hazard_hazmat_cd")
                     .withColumnRenamed("PROPER_SHIPPING_NM",                "hazard_proper_shipping_nm")
                     .withColumnRenamed("SDS_DOCUMENT_URL",                  "hazard_sds_document_url")
                     .withColumnRenamed("SDS_DOCUMENT_LINK_URL",             "hazard_sds_document_link_url")
                     .withColumnRenamed("SDS_REQUIRED_IND",                  "hazard_sds_required_ind")
                     .withColumnRenamed("HAZARD_PRIMARY_LABEL_REQUIRED_TXT", "hazard_primary_label_txt")
                     .withColumnRenamed("OTHER_RESTRICTIONS_COMMENT_TXT",    "hazard_other_restrictions_txt")
                     .withColumnRenamed("BATTERY_CONTAINING_PRODUCT_IND",    "hazard_battery_ind")
                     .withColumnRenamed("WERCS_BATT_IND",                    "hazard_wercs_batt_ind")
                     .withColumnRenamed("AEROSOL_INDICATOR_CD",              "hazard_aerosol_ind")
            )
            df = df.join(hazard_df, df.item_id == hazard_df.hazard_product_id, "left")
            df = df.withColumn("final_sds_url", F.coalesce(F.col("hazard_sds_document_url"), F.col("hazard_sds_document_link_url")))
        else:
            logger.info("Hazard table %s not found. Proceeding with fallback.", tables["HAZARD_TABLE"])

        if spark.catalog.tableExists(tables["PRODUCT_MASTER_TABLE"]):
            pm_df = (
                spark.table(tables["PRODUCT_MASTER_TABLE"])
                .select(
                    "PRODUCT_ID", "BACK_ORDER_IND", "DISCONTINUED_ALTERNATE_IND",
                    "DISCONTINUED_ALTERNATE_PRODUCT_ID", "PURCHASE_STATUS_CD", "out_of_stock_ind",
                )
                .withColumnRenamed("PRODUCT_ID", "pm_product_id")
                .withColumnRenamed("BACK_ORDER_IND", "pm_back_order_ind")
                .withColumnRenamed("DISCONTINUED_ALTERNATE_IND", "pm_discontinued_alternate_ind")
                .withColumnRenamed("DISCONTINUED_ALTERNATE_PRODUCT_ID", "pm_discontinued_alternate_product_id")
                .withColumnRenamed("PURCHASE_STATUS_CD", "pm_purchase_status_cd")
                .withColumnRenamed("out_of_stock_ind", "pm_out_of_stock_ind")
                .dropDuplicates(["pm_product_id"])
            )
            df = df.join(pm_df, df.item_id == pm_df.pm_product_id, "left")
        else:
            logger.info("Product master table %s not found. Proceeding with fallback.", tables["PRODUCT_MASTER_TABLE"])

    except Exception as e:
        logger.warning("Could not join tables: %s", e)

    def safe_col(col_name):
        return F.col(col_name) if col_name in df.columns else F.lit(None).cast(StringType())

    # Pre-cast dates
    df = (
        df
        .withColumn("pub_date", safe_col("web_first_published_date").cast(DateType()))
        .withColumn("create_date", safe_col("product_create_date").cast(DateType()))
    )

    # Publish era
    publish_era = (
        F.when(F.col("pub_date").isNull(), F.lit(None))
        .when(F.col("pub_date") >= F.date_sub(F.current_date(), 180), F.lit("Fresh"))
        .when(F.col("pub_date") >= F.date_sub(F.current_date(), 365), F.lit("Recent"))
        .when(F.col("pub_date") >= F.date_sub(F.current_date(), 365 * 5), F.lit("Mid-era"))
        .otherwise(F.lit("Legacy"))
    )
    df = df.withColumn("publish_era", publish_era)

    # Lifecycle status: "new" when the product was both published on Staples.com and created
    # in the last 6 months, otherwise NULL. The create date is checked too because the source
    # moved the publish date of many older products to 2026-10-14.
    six_months_ago = F.add_months(F.current_date(), -6)
    lifecycle = F.when(
        (F.col("pub_date") >= six_months_ago) & (F.col("create_date") >= six_months_ago),
        F.lit("new"),
    )
    # Staples Business has no publish date, so its status goes by the create date alone:
    # "new" when the product is live on Staples Business and was created in the last 6 months.
    lifecycle_contract = F.when(
        F.col("is_live_contract") & (F.col("create_date") >= six_months_ago),
        F.lit("new"),
    )
    df = (df.withColumn("lifecycle_status", lifecycle)
          .withColumn("lifecycle_status_contract", lifecycle_contract)
          .drop("pub_date", "create_date"))

    df = df.withColumn(
        "availability_last_updated_at",
        F.date_format(F.to_timestamp(safe_col("product_create_date")), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
    )

    # Gender, age_group and age_restriction are decided by product_tagging, not here.

    # Multipack
    df = df.withColumn("multipack", evaluate_multipack(safe_col("title"), safe_col("bullets_json"), safe_col("spec_json")))

    # Warning
    df = df.withColumn(
        "warning",
        evaluate_warning(
            safe_col("web_supercategory_nm"), safe_col("description"),
            safe_col("bullets_json"), safe_col("spec_json"),
            safe_col("hazard_prop_65_ind"), safe_col("hazard_wercs_p65_warning_txt"),
            safe_col("hazard_wercs_p65_chem_txt"), safe_col("hazard_wercs_p651_ind"),
            safe_col("hazard_hazmat_cd"), safe_col("hazard_proper_shipping_nm"),
            safe_col("web_category_nm"), safe_col("final_sds_url"),
            safe_col("hazard_primary_label_txt"), safe_col("hazard_other_restrictions_txt"),
            safe_col("hazard_battery_ind"), safe_col("hazard_wercs_batt_ind"),
            safe_col("hazard_aerosol_ind"), safe_col("hazard_sds_required_ind"),
        ),
    )

    # Sign-message fallback
    SIGN_WARNING_CATEGORIES = {'danger', 'safety', 'information', 'warning'}
    if "spec_json" in df.columns:
        try:
            sign_df = (
                df.select("item_id", F.col("spec_json"))
                  .withColumn("spec", F.explode(F.col("spec_json")))
                  .withColumn("attr_nm", F.lower(F.col("spec.attribute_nm")))
                  .withColumn("attr_val", F.col("spec.attribute_value_txt"))
                  .filter(F.col("attr_nm").isin("sign message", "sign message category"))
                  .groupBy("item_id")
                  .agg(
                      F.max(F.when(F.col("attr_nm") == "sign message category", F.col("attr_val"))).alias("sign_msg_cat"),
                      F.max(F.when(F.col("attr_nm") == "sign message", F.col("attr_val"))).alias("sign_msg"),
                  )
                  .filter(
                      F.lower(F.col("sign_msg_cat")).isin(*SIGN_WARNING_CATEGORIES) &
                      F.col("sign_msg_cat").isNotNull() &
                      (~F.lower(F.trim(F.col("sign_msg_cat"))).isin(
                          "blank", "n", "y", "n/a", "na", "none", "no", "null", "-", "--", "u", "unknown", "see sds"
                      ))
                  )
                  .filter(
                      F.col("sign_msg").isNotNull() & (F.trim(F.col("sign_msg")) != "") &
                      (~F.lower(F.trim(F.col("sign_msg"))).isin(
                          "blank", "n", "y", "n/a", "na", "none", "no", "null", "-", "--", "u", "unknown", "see sds"
                      ))
                  )
                  .withColumn("sign_combined_info", F.concat(F.col("sign_msg_cat"), F.lit(": "), F.col("sign_msg")))
                  .select("item_id", "sign_combined_info")
            )
            df = df.join(sign_df, on="item_id", how="left")
            df = df.withColumn(
                "warning",
                F.when(F.col("warning").isNull(), F.col("sign_combined_info")).otherwise(F.col("warning")),
            ).drop("sign_combined_info")
        except Exception as e:
            logger.warning("Sign-message fallback skipped: %s", e)

    # Warning URL
    df = df.withColumn(
        "warning_url",
        evaluate_warning_url(
            safe_col("web_supercategory_nm"), safe_col("web_category_nm"), safe_col("description"),
            safe_col("bullets_json"), safe_col("spec_json"), safe_col("seller_tos"), safe_col("final_sds_url"),
        ),
    )

    # Select final columns
    expected_columns = [
        "item_id", "web_supercategory_nm", "web_category_nm",
        "lifecycle_status", "lifecycle_status_contract",
        "multipack", "warning", "warning_url",
        "availability_last_updated_at",
    ]
    final_columns = [c for c in expected_columns if c in df.columns]
    return df.select(*final_columns).dropDuplicates(["item_id"])


# =============================================================================
# PIPELINE ENTRY POINT
# =============================================================================

# Columns this task reads from its source table.
SOURCE_COLUMNS = ["item_id", "title", "description", "bullets_json", "spec_json", "seller_tos",
                  "web_supercategory_nm", "web_category_nm", "web_first_published_date",
                  "product_create_date", "is_live_contract"]


def run_lifecycle_pipeline(
    spark,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None,
) -> DataFrame:
    """
    Run the lifecycle enrichment pipeline end-to-end.

    Args:
        spark:          Active SparkSession.
        source_table:   Fully qualified source table name.
        output_table:   Output table name.
        output_catalog: Optional catalog override.
        output_schema:  Optional schema override.

    Returns:
        Enriched DataFrame.
    """
    print("=" * 80)
    print("LIFECYCLE ENRICHMENT PIPELINE")
    print("=" * 80)

    print(f"\n1. Loading source data from {source_table}...")
    source_df = read_all_products(spark, source_table, SOURCE_COLUMNS)
    total_rows = source_df.count()
    print(f"   Loaded {total_rows:,} rows")

    print("\n2. Applying lifecycle enrichment features...")
    enriched_df = add_lifecycle_features(source_df)

    if total_rows == 0:
        raise ValueError(f"Source table {source_table} is empty; refusing to overwrite output.")
    
    print("\n3. Saving results...")
    save_data(
        enriched_df,
        spark,
        catalog=output_catalog,
        schema=output_schema,
        table=output_table,
        mode="overwrite",
        validate_schema=False,
    )
    saved_df = spark.table(resolve_output_table(output_table, output_catalog, output_schema)[3])

    print("\n4. Validating saved data...")
    saved_rows = saved_df.count()
    null_ids = saved_df.filter(F.col("item_id").isNull()).count()
    if null_ids > 0:
        raise ValueError(f"{null_ids} saved rows have null item_id")
    valid_lifecycle = {'new'}
    for status in ("lifecycle_status", "lifecycle_status_contract"):
        invalid_lifecycle = saved_df.filter(
            F.col(status).isNotNull() & ~F.col(status).isin(valid_lifecycle)
        ).count()
        if invalid_lifecycle > 0:
            print(f"   Warning: {invalid_lifecycle} rows with invalid {status}")
        else:
            print(f"   {status} validation passed")

        print(f"\n   {status} distribution:")
        saved_df.groupBy(status).agg(
            F.count("*").alias("count"),
            F.round((F.count("*") / saved_rows) * 100, 2).alias("percentage"),
        ).orderBy(F.desc("count")).show(truncate=False)

    print("\n" + "=" * 80)
    print("LIFECYCLE ENRICHMENT COMPLETE")
    print("=" * 80)

    return saved_df



# =============================================================================
# STANDALONE EXECUTION
# =============================================================================
  
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    logger = logging.getLogger(__name__)

    spark = get_spark_session()
    # os.environ.setdefault("sf_env", "dev")
    tables = _ensure_table_config()
 
    run_lifecycle_pipeline(
        spark,
        source_table=tables["SOURCE_TABLE"],
        output_table=tables["OUTPUT_TABLE"],
    )