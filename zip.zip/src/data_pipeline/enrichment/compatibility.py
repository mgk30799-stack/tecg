"""
Data Enrichment Pipeline - Compatibility Detection

This module detects product compatibility relationships using two independent
enrichment paths that run for ALL products, then merges results:

Path 1 — NLP + Vector Search:
    1. Text Scanning: Scan title, bullets, specs, and description for compatibility
       trigger phrases (e.g., "compatible with", "works with"). Capture the surrounding text window.
    2. Entity Extraction: Identify the target brand/product using:
       - Grammatical POS gating (Proper Noun checks)
       - spaCy NER (Named Entity Recognition)
       - Dynamic Brand Dictionary lookup (built from the catalog's 'brand' column)
       - POS Proper Noun fallback
    3. Vector Search Enrichment: Query a Databricks Vector Search index to map the extracted
       entity/search query to real 'item_id's in the catalog.

Path 2 — Demandshape Structured Lookup:
    1. Query the demandshape_product_alt_v table for known product pairings
       (e.g., printer-toner relationships via value_prop_id=91).
    2. Build bidirectional compatibility: original->alt and alt->original.
    3. All matches get confidence=1.0 (ground truth from catalog data).

Merge:
    Both paths produce a unified compatibility_json schema: {id, title, score, source}.
    Deduplication: for each compatible item_id, only the entry with the highest
    confidence score is kept (demandshape=1.0 always wins ties over NLP scores).

Sites:
    Both paths run for Staples.com products and write the attributes below.
    SB products get Path 2 only: the SBA pairs where both products are live on SB,
    written to compatible_item_ids_contract and compatibility_json_contract.

Output Attributes:
    - has_compatibilities            : Boolean
    - evidence                       : Array of structs detailing the NLP text matches
    - compatibility_json             : Array of structs {id, title, score, source}
    - compatible_item_ids_all        : Array of all matched catalog item IDs
    - compatible_item_ids            : Array of high-confidence matched item IDs
    - compatibility_scope            : Extent of compatibility (e.g., "brand", "structured")
    - relationship_type              : Type of relationship (e.g., "compatible_with", "structured_alternative")
    - compatibility_source           : "nlp_vector_search" | "demandshape" | "demandshape+nlp_vector_search"
    - compatibility_confidence       : Highest confidence score across both paths
    - compatibility_last_verified_at : Timestamp of execution
    - compatible_item_ids_contract   : SB: demandshape item IDs, both products live on SB
    - compatibility_json_contract    : SB: like compatibility_json, demandshape entries only

Pipeline Steps:
    1. Load product data
    2. NLP scan: extract compatibility evidence from text fields
    3a. Enrich NLP evidence with item IDs via Vector Search
    3b. Enrich with Demandshape structured compatibility data
    4. Merge both paths, dedup by item_id (highest score wins)
    4b. SB columns from the SBA Demandshape pairs
    5. Save to Unity Catalog

Requirements:
    spaCy MUST be installed on BOTH driver and workers (

    Cluster library (PyPI):
        spacy
        https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-<VER>/en_core_web_sm-<VER>-py3-none-any.whl

Usage:
    from src.data_pipeline.enrichment.compatibility import run_compatibility_pipeline

    run_compatibility_pipeline(
        spark,
        source_table="mld01_ml_de.product.product_discovery_data_all",
        output_table="product_compatibility",
        endpoint_name="product_discovery_endpoint",
        index_name="mld01_ml_de.product.title_embeddings",
        demandshape_table="snowflake_cap.prd_usd_opv.demandshape_product_alt_v",
    )
"""

import sys
import os
import re
import json
import logging
import time
import random
import requests
from typing import List, Dict, Any, Optional


# Add project root to sys.path for absolute imports
try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    # Fallback for Databricks notebooks/jobs where __file__ is missing
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# -- Windows compatibility fix --
if sys.platform == "win32":
    import socketserver

    if not hasattr(socketserver, "UnixStreamServer"):

        class UnixStreamServer:
            def __init__(self, *args, **kwargs):
                raise NotImplementedError("UnixStreamServer not available on Windows")

        socketserver.UnixStreamServer = UnixStreamServer
        socketserver.UnixDatagramServer = UnixStreamServer

from databricks.connect import DatabricksSession
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField, ArrayType, DoubleType, TimestampType
import pandas as pd
from utils import save_data, get_spark_session, read_config, read_all_products

# Struct schemas for the output arrays to ensure strict Databricks types
EVIDENCE_STRUCT_TYPE = ArrayType(StructType([
    StructField("source_field", StringType(), True),
    StructField("matched_keyword", StringType(), True),
    StructField("detection_method", StringType(), True),
    StructField("matched_entity", StringType(), True),
    StructField("search_query", StringType(), True),
    StructField("raw_text", StringType(), True),
    StructField("window", StringType(), True),
]))

COMPATIBILITY_HIT_STRUCT_TYPE = ArrayType(StructType([
    StructField("id", StringType(), True),
    StructField("title", StringType(), True),
    StructField("score", DoubleType(), True),
    StructField("source", StringType(), True),
]))

# -- Vector Search Client --

class DatabricksVectorSearch:
    """
    A client for performing vector searches on Databricks, with a fallback
    from the SDK to the REST API.
    """
    def __init__(self, host, token, endpoint_name=None, index_name=None, embedding_endpoint=None):
        # Normalize host to include a scheme. The SDK's VectorSearchClient and the
        # requests calls both need a fully-qualified URL; a bare host like
        # "adb-xxxx.azuredatabricks.net" makes the SDK raise "No scheme supplied".
        if host and not host.startswith("http"):
            host = f"https://{host}"
        self.host = host
        self.token = token
        self.endpoint_name = endpoint_name
        self.index_name = index_name
        self.embedding_endpoint = embedding_endpoint  # e.g. "databricks-gte-large-en"
        self.vsc = None
        self.index = None
        # self._available = False
        # self._init_error = None
        self._request_timeout = 30  # seconds per REST request
        self._embed_session = requests.Session()
        self._embed_session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        self._initialize_sdk_client()

    def embed_texts(self, texts: list, batch_size: int = 128,
                    max_retries: int = 6, base_delay: float = 1.0) -> list:
        """
        Batch-embed a list of strings via the foundation-model embeddings endpoint.
        Returns a list of vectors aligned 1:1 with `texts`. Retries on 429.

        Embedding once in bulk avoids the per-query embedding that the vector
        search endpoint would otherwise do on every query_text call — which is
        what was triggering REQUEST_LIMIT_EXCEEDED. The endpoint accepts an array
        input, so we send up to `batch_size` strings per request.
        """
        if not self.embedding_endpoint:
            raise RuntimeError("embed_texts called but no embedding_endpoint configured.")

        host = self.host if self.host.startswith("http") else f"https://{self.host}"
        url = f"{host.rstrip('/')}/serving-endpoints/{self.embedding_endpoint}/invocations"

        vectors: list = []
        for start in range(0, len(texts), batch_size):
            chunk = [str(t) for t in texts[start:start + batch_size]]
            payload = {"input": chunk}

            resp = None
            for attempt in range(max_retries):
                try:
                    resp = self._embed_session.post(url, json=payload, timeout=self._request_timeout)
                    if resp.status_code == 429 or "REQUEST_LIMIT_EXCEEDED" in resp.text:
                        raise RuntimeError(f"429 rate limited: {resp.text[:200]}")
                    if not resp.ok:
                        raise RuntimeError(f"{resp.status_code} {resp.reason}: {resp.text[:300]}")
                    break
                except Exception as exc:
                    msg = str(exc)
                    rate_limited = "429" in msg or "REQUEST_LIMIT_EXCEEDED" in msg or "RESOURCE_EXHAUSTED" in msg
                    if not rate_limited or attempt == max_retries - 1:
                        raise
                    delay = min(base_delay * (2 ** attempt), 60.0) + random.uniform(0, base_delay)
                    time.sleep(delay)

            data = resp.json().get("data", [])
            # Response preserves input order: data[i]["embedding"]
            for item in data:
                vectors.append(item.get("embedding"))

        if len(vectors) != len(texts):
            raise RuntimeError(
                f"Embedding count mismatch: got {len(vectors)} vectors for {len(texts)} texts."
            )
        return vectors

    def _initialize_sdk_client(self):
        """Initializes the Vector Search SDK client. Raises on failure."""
        from databricks.vector_search.client import VectorSearchClient

        host = self.host if self.host.startswith("http") else f"https://{self.host}"
        
        if not self.host or not self.token:
            raise ValueError("DATABRICKS_HOST and DATABRICKS_TOKEN must both be provided.")
        self.vsc = VectorSearchClient(
            workspace_url=host,
            personal_access_token=self.token,
            disable_notice=True,
        )

        # print(f"Accessing index '{self.index_name}' on endpoint '{self.endpoint_name}'...")
        self.index = self.vsc.get_index(
            endpoint_name=self.endpoint_name, index_name=self.index_name
        )
        if self.index is None:
            raise RuntimeError(
                f"Vector Search index '{self.index_name}' not found on endpoint '{self.endpoint_name}'."
            )

    @property
    def is_available(self) -> bool:
        """True if SDK connected OR REST API can be attempted."""
        return bool(self.host and self.token and self.index_name)

    def probe(self) -> bool:
        if not self.endpoint_name and not self.index_name:
            return False
        try:
            if self.embedding_endpoint:
                # For direct access indexes: embed a test string, then search by vector
                test_vec = self.embed_texts(["test probe query"])[0]
                self.search_by_vector(test_vec, num_results=1)
            else:
                self.search("test probe query", num_results=1)
            return True
        except Exception as exc:
            print(f"  [VectorSearch] Probe failed: {exc}")
            return False

    def search(self, query_text: str, num_results: int = 3) -> list:
        """
        Performs a similarity search. Tries the SDK first and falls back to
        the REST API.
        """
        if self.index:
            try:
                return self._search_with_sdk(query_text, num_results)
            except Exception as e:
                print(f"SDK search failed, falling back to API: {e}")
                return self._search_with_api(query_text, num_results)
        elif self.host and self.token and self.index_name:
            return self._search_with_api(query_text, num_results)
        else:
            raise RuntimeError("Vector Search unavailable: no endpoint/index configured")

    def search_with_retry(self, query_text: str, num_results: int = 3,
                          max_retries: int = 6, base_delay: float = 1.0,
                          max_delay: float = 60.0) -> list:
        """
        search() with exponential backoff + jitter on rate-limit (429) errors.

        The embedding endpoint (e.g. databricks-gte-large-en) enforces a QPS cap;
        without retry, throttled queries are lost permanently. This recovers them.
        """
        last_exc = None
        for attempt in range(max_retries):
            try:
                return self.search(query_text, num_results)
            except Exception as exc:
                last_exc = exc
                msg = str(exc)
                rate_limited = (
                    "429" in msg
                    or "REQUEST_LIMIT_EXCEEDED" in msg
                    or "RESOURCE_EXHAUSTED" in msg
                )
                if not rate_limited or attempt == max_retries - 1:
                    raise
                delay = min(base_delay * (2 ** attempt), max_delay) + random.uniform(0, base_delay)
                time.sleep(delay)
        raise last_exc  # unreachable, but keeps linters happy

    def search_by_vector(self, query_vector: list, num_results: int = 3) -> list:
        """
        Similarity search using a PRE-COMPUTED embedding (query_vector), so the
        endpoint does not re-embed text per call. Tries the SDK, falls back to REST.
        """
        if query_vector is None:
            raise RuntimeError("search_by_vector received a null query_vector.")
        if self.index:
            try:
                return self._search_vec_sdk(query_vector, num_results)
            except Exception as e:
                print(f"SDK vector search failed, falling back to API: {e}")
                return self._search_vec_api(query_vector, num_results)
        elif self.host and self.token and self.index_name:
            return self._search_vec_api(query_vector, num_results)
        else:
            raise RuntimeError("Vector Search unavailable: no endpoint/index configured")

    def search_by_vector_with_retry(self, query_vector: list, num_results: int = 3,
                                    max_retries: int = 6, base_delay: float = 1.0,
                                    max_delay: float = 60.0) -> list:
        """search_by_vector with exponential backoff on rate-limit errors (defense in depth)."""
        last_exc = None
        for attempt in range(max_retries):
            try:
                return self.search_by_vector(query_vector, num_results)
            except Exception as exc:
                last_exc = exc
                msg = str(exc)
                rate_limited = "429" in msg or "REQUEST_LIMIT_EXCEEDED" in msg or "RESOURCE_EXHAUSTED" in msg
                if not rate_limited or attempt == max_retries - 1:
                    raise
                time.sleep(min(base_delay * (2 ** attempt), max_delay) + random.uniform(0, base_delay))
        raise last_exc

    def _search_vec_sdk(self, query_vector: list, num_results: int) -> list:
        import io, contextlib
        f = io.StringIO()
        with contextlib.redirect_stdout(f), contextlib.redirect_stderr(f):
            results = self.index.similarity_search(
                num_results=num_results,
                columns=["title", "item_id"],
                query_vector=query_vector,
                query_type="ANN",
            )
        result_block = (results or {}).get("result", {})
        data_array = result_block.get("data_array")
        if not data_array:
            return []
        formatted = []
        for row in data_array:
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                formatted.append({"id": row[1], "title": row[0], "score": row[2] if len(row) > 2 else None})
        return formatted

    def _search_vec_api(self, query_vector: list, num_results: int) -> list:
        host = self.host if self.host.startswith("http") else f"https://{self.host}"
        url = f"{host.rstrip('/')}/api/2.0/vector-search/indexes/{self.index_name}/query"
        payload = {
            "num_results": num_results,
            "columns": ["title", "item_id"],
            "query_vector": query_vector,
            "query_type": "ANN",
        }
        response = self._embed_session.post(url, json=payload, timeout=self._request_timeout)
        if not response.ok:
            raise RuntimeError(f"{response.status_code} {response.reason}: {response.text}")
        result_block = response.json().get("result", {})
        data_array = result_block.get("data_array")
        if not data_array:
            return []
        col_names = [c["name"] for c in result_block.get("metadata", {}).get("columns", [])]
        try:
            title_idx = col_names.index("title")
            item_id_idx = col_names.index("item_id")
            score_idx = col_names.index("score") if "score" in col_names else None
        except ValueError:
            title_idx, item_id_idx, score_idx = 0, 1, 2
        formatted = []
        for row in data_array:
            formatted.append({
                "id": row[item_id_idx],
                "title": row[title_idx],
                "score": row[score_idx] if score_idx is not None and len(row) > score_idx else None,
            })
        return formatted

    def _search_with_sdk(self, query_text: str, num_results: int) -> list:
        """Search using the Databricks Vector Search Python SDK."""
        import io
        import contextlib

        f = io.StringIO()
        with contextlib.redirect_stdout(f), contextlib.redirect_stderr(f):
            results = self.index.similarity_search(
                num_results=num_results,
                columns=["title", "item_id"],
                query_text=query_text,
                query_type="ANN"
            )

        if not results or 'result' not in results or 'data_array' not in results.get('result', {}):
            if results and 'result' in results and 'docs' in results['result']:
                docs = results['result']['docs']
                formatted_results = []
                for doc in docs:
                    if isinstance(doc, (list, tuple)) and len(doc) >= 3:
                        formatted_results.append({"id": doc[1], "title": doc[0], "score": doc[2]})
                    elif isinstance(doc, dict):
                        formatted_results.append({"id": doc.get("item_id"), "title": doc.get("title"), "score": doc.get("score")})
                return formatted_results
            return []

        data_array = results['result']['data_array']
        formatted_results = []
        for row in data_array:
            if isinstance(row, (list, tuple)) and len(row) >= 2:
                formatted_results.append({"id": row[1], "title": row[0], "score": row[2] if len(row) > 2 else None})
        return formatted_results

    def _search_with_api(self, query_text: str, num_results: int) -> list:
        """Search using the Databricks Vector Search REST API."""
        host = self.host
        if not host:
            raise RuntimeError("No DATABRICKS_HOST provided for REST API fallback.")
        if not host.startswith("http"):
            host = f"https://{host}"

        url = f"{host.rstrip('/')}/api/2.0/vector-search/indexes/{self.index_name}/query"

        payload = {
            "num_results": num_results,
            "columns": ["title", "item_id"],
            "query_text": query_text,
            "query_type": "ANN"
        }

        response = self._embed_session.post(url, json=payload, timeout=self._request_timeout)
        if not response.ok:
            raise RuntimeError(
                f"{response.status_code} {response.reason}: {response.text}"
            )
        response_json = response.json()

        result_block = response_json.get('result', {})
        if 'data_array' in result_block:
            data_array = result_block['data_array']
            col_names  = [c['name'] for c in result_block.get('metadata', {}).get('columns', [])]
            formatted = []
            try:
                title_idx   = col_names.index('title')
                item_id_idx = col_names.index('item_id')
                score_idx   = col_names.index('score') if 'score' in col_names else None
            except ValueError:
                title_idx, item_id_idx, score_idx = 0, 1, 2
            for row in data_array:
                formatted.append({
                    "id":    row[item_id_idx],
                    "title": row[title_idx],
                    "score": row[score_idx] if score_idx is not None and len(row) > score_idx else None,
                })
            return formatted
        elif 'docs' in result_block:
            docs = result_block['docs']
            return [{"id": doc.get("item_id"), "title": doc.get("title"), "score": doc.get("score")} for doc in docs]
        else:
            return []


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# -- Constants --

COMPATIBILITY_KEYWORD_PATTERNS: List[Dict[str, Any]] = [
    {
        "name": "compatible_with",
        "ner_fallback": True,
        "regex": re.compile(r"compatible\s+with", re.IGNORECASE),
    },
    {
        "name": "works_with",
        "ner_fallback": True,
        "regex": re.compile(r"works\s+with", re.IGNORECASE),
    },
    {
        "name": "made_for",
        "ner_fallback": False,
        "regex": re.compile(r"made\s+for", re.IGNORECASE),
    },
    {
        "name": "use_with",
        "ner_fallback": True,
        "regex": re.compile(r"use\s+with", re.IGNORECASE),
    },
]


BRAND_EXCLUDE_WORDS = {
    "all", "any", "the", "and", "for", "not", "but", "are", "can",
    "new", "fit", "use", "pro", "max", "top", "eco", "air", "mix",
    "kit", "set", "duo", "box", "one", "two", "big", "red", "blu",
    "hot", "ice", "ace", "sun", "sky", "sea", "raw", "own", "our",
    "none", "other", "brand", "generic", "unbranded", "unknown", "misc",
    "n/a", "na", "yes", "no", "true", "false",
}

# -- Brand Dictionary helpers --

def build_brand_dictionary(df: DataFrame, min_brand_length:int) -> List[str]:
    if "brand" not in df.columns:
        raise ValueError(
            "'brand' column not found in DataFrame. "
            "Brand dictionary requires the source table to have a 'brand' column."
        )

    # print("Building brand dictionary from 'brand' column...")
    raw_brands = (
        df.select(F.col("brand"))
        .filter(F.col("brand").isNotNull() & (F.trim(F.col("brand")) != ""))
        .distinct()
        .toPandas()["brand"]
        .tolist()
    )

    brands = [
        str(b).strip() for b in raw_brands
        if b
        and len(str(b).strip()) >= min_brand_length
        and str(b).strip().lower() not in BRAND_EXCLUDE_WORDS
    ]

    brands.sort(key=len, reverse=True)
    print(f"  Brand dictionary: {len(brands)} unique brands (from {len(raw_brands)} raw, after filtering).")
    return brands


def _compile_brand_pattern(brand_list: List[str]) -> re.Pattern:
    return re.compile(
        r"\b(" + "|".join(re.escape(b) for b in brand_list) + r")\b",
        re.IGNORECASE,
    )

# -- Core Extraction Logic --

def _extract_window_after_match(text: str, match_end: int, n_words: int) -> str:
    remaining = text[match_end:].strip()
    tokens = remaining.split()
    return " ".join(tokens[:n_words])


# -- NER / POS helpers --

_NER_ENTITY_TYPES = {"ORG", "PRODUCT", "GPE", "FAC"}

_nlp_model_cache: Dict[str, Any] = {}


def _get_nlp_model():
    """
    Lazy-load spaCy on driver or worker. The import lives INSIDE this function so
    cloudpickle does not capture the spaCy module as a global of the pandas_udf
    (which would crash workers during UDF deserialization). If spaCy or a model
    is unavailable, returns (None, False) and the pipeline degrades to
    brand-dictionary-only detection rather than failing.
    """
    if "nlp" not in _nlp_model_cache:
        try:
            import spacy
        except ImportError:
            # Worker (or driver) lacks spaCy. Do NOT attempt runtime pip install:
            # it fails on most Databricks clusters and kills the task. Install
            # spaCy as a cluster library / init script instead.
            _nlp_model_cache["nlp"] = None
            _nlp_model_cache["available"] = False
            return None, False

        try:
            nlp = spacy.load("en_core_web_md", disable=["parser", "lemmatizer"])
            _nlp_model_cache["nlp"] = nlp
            _nlp_model_cache["available"] = True
        except OSError:
            try:
                nlp = spacy.load("en_core_web_sm", disable=["parser", "lemmatizer"])
                _nlp_model_cache["nlp"] = nlp
                _nlp_model_cache["available"] = True
                print("spaCy: en_core_web_md not found, using en_core_web_sm")
            except OSError:
                _nlp_model_cache["nlp"] = None
                _nlp_model_cache["available"] = False
                print("Warning: no spaCy model found (en_core_web_md / en_core_web_sm)")
    return _nlp_model_cache["nlp"], _nlp_model_cache.get("available", False)


def _ner_detect(window: str):
    nlp, available = _get_nlp_model()
    if not available or not nlp or not window:
        return None, None
    doc = nlp(window)
    for ent in doc.ents:
        if ent.label_ in _NER_ENTITY_TYPES:
            return ent.text.strip(), ent.label_
    return None, None


_SENTENCE_END = re.compile(r'[.!?;:]')

def _truncate_to_sentence(window: str) -> str:
    m = _SENTENCE_END.search(window)
    return window[:m.start()].strip() if m else window


def _pos_has_proper_noun(window: str) -> tuple:
    nlp, available = _get_nlp_model()
    if not available or not nlp:
        return True, ''

    doc = nlp(window)
    meaningful = [t for t in doc if not t.is_space and not t.is_punct][:5]

    found = False
    nnp_tokens: List[str] = []
    for tok in meaningful:
        if tok.tag_ in ("NNP", "NNPS"):
            found = True
            nnp_tokens.append(tok.text)
        elif found:
            break

    return found, " ".join(nnp_tokens)


def _scan_product(
    title: Optional[str],
    bullets_json: Optional[str],
    spec_json: Optional[str],
    description: Optional[str],
    brand_pattern: Any,
    window_words: int = 12
) -> Dict[str, Optional[str]]:
    plain_fields = {"title": title, "description": description}

    bullets_texts: List[str] = []
    if bullets_json is not None:
        if isinstance(bullets_json, list):
            bullets_texts = [str(b) for b in bullets_json if b]
        else:
            try:
                parsed = json.loads(bullets_json)
                bullets_texts = [str(b) for b in parsed if b] if isinstance(parsed, list) else [str(parsed)]
            except (json.JSONDecodeError, TypeError):
                bullets_texts = [str(bullets_json)]

    spec_texts: List[str] = []
    if spec_json is not None:
        entries: List[Any] = []
        if isinstance(spec_json, list):
            entries = spec_json
        else:
            try:
                entries = json.loads(spec_json)
            except (json.JSONDecodeError, TypeError):
                entries = []
        for entry in entries:
            if isinstance(entry, dict):
                val = entry.get("attribute_value_txt") or entry.get("value")
                if val:
                    spec_texts.append(str(val))

    all_evidence: List[Dict[str, Any]] = []

    def _scan_text(text: str, source_field: str, n_words: int) -> Optional[Dict[str, Any]]:
        if not text or not isinstance(text, str):
            return None

        def _build_search_query(w: str, fallback_entity: str) -> str:
            q = re.sub(r'\(.*?\)', '', w)
            q = re.split(r'[,;:-]', q)[0]
            q = re.split(r'\b(for|to|with(?:out)?|in|and|or)\b', q, 1, flags=re.IGNORECASE)[0]
            q = re.sub(r'^(the|a|an|all|any|your|our|their|its)\s+', '', q, flags=re.IGNORECASE)
            return q.strip() or fallback_entity

        for kp in COMPATIBILITY_KEYWORD_PATTERNS:
            for m in kp["regex"].finditer(text):
                raw_window = _extract_window_after_match(text, m.end(), n_words)
                window = _truncate_to_sentence(raw_window)

                if not window:
                    continue

                pos_ok, nnp_span = _pos_has_proper_noun(window)
                if not pos_ok:
                    continue

                if kp.get("ner_fallback", True):
                    entity_text, entity_label = _ner_detect(window)
                    if entity_text:
                        return {
                            "source_field": source_field,
                            "matched_keyword": m.group(0),
                            "detection_method": f"ner:{entity_label}",
                            "matched_entity": entity_text,
                            "search_query": _build_search_query(window, entity_text),
                            "raw_text": text[max(0, m.start() - 40):m.end() + len(window) + 40].strip() + "...",
                            "window": (m.group(0) + " " + window).strip(),
                        }

                bm = brand_pattern.search(window)
                if bm:
                    return {
                        "source_field": source_field,
                        "matched_keyword": m.group(0),
                        "detection_method": "brand_dictionary",
                        "matched_entity": bm.group(0),
                        "search_query": _build_search_query(window, bm.group(0)),
                        "raw_text": text[max(0, m.start() - 40):m.end() + len(window) + 40].strip() + "...",
                        "window": (m.group(0) + " " + window).strip(),
                    }

                if nnp_span:
                    return {
                        "source_field": source_field,
                        "matched_keyword": m.group(0),
                        "detection_method": "pos_nnp",
                        "matched_entity": nnp_span,
                        "search_query": _build_search_query(window, nnp_span),
                        "raw_text": text[max(0, m.start() - 40):m.end() + len(window) + 40].strip() + "...",
                        "window": (m.group(0) + " " + window).strip(),
                    }

        return None

    for field_name, text in plain_fields.items():
        ev = _scan_text(text, field_name, window_words)
        if ev:
            all_evidence.append(ev)

    for bullet in bullets_texts:
        ev = _scan_text(bullet, "bullets_json", window_words)
        if ev:
            all_evidence.append(ev)
            break

    for spec_val in spec_texts:
        ev = _scan_text(spec_val, "spec_json", window_words)
        if ev:
            all_evidence.append(ev)
            break

    if all_evidence:
        seen: set = set()
        unique_ev: List[Dict] = []
        for ev in all_evidence:
            key = (ev["source_field"], ev["matched_keyword"].lower(), ev["matched_entity"].lower())
            if key not in seen:
                seen.add(key)
                unique_ev.append(ev)
        return {
            "compatibility_mentioned": "yes",
            "evidence": json.dumps(unique_ev, ensure_ascii=False),
        }

    return {"compatibility_mentioned": "no", "evidence": None}


# -- Spark DataFrame Layer --

def extract_compatibility_data(df: DataFrame, window_words: int = 12, min_brand_length: int = 3) -> DataFrame:
    combined_brands = build_brand_dictionary(df,min_brand_length)
    brand_pattern   = _compile_brand_pattern(combined_brands)
    brand_pattern_str = brand_pattern.pattern

    def safe_col(col_name: str):
        return F.col(col_name) if col_name in df.columns else F.lit(None).cast(StringType())

    title_col        = safe_col("title")
    bullets_json_col = (
        F.to_json(F.col("bullets_json")) if "bullets_json" in df.columns
        else F.lit(None).cast(StringType())
    )
    spec_json_col = (
        F.to_json(F.col("spec_json")) if "spec_json" in df.columns
        else F.lit(None).cast(StringType())
    )
    description_col = safe_col("description")

    @F.pandas_udf(StringType())
    def compat_pandas_udf(
        titles: pd.Series,
        bullets: pd.Series,
        specs: pd.Series,
        descriptions: pd.Series,
    ) -> pd.Series:
        import re as _re
        _bp = _re.compile(brand_pattern_str, _re.IGNORECASE)

        # Warm the spaCy model once per worker partition (lazy import inside).
        _get_nlp_model()

        results = []
        for title, bj, sj, desc in zip(titles, bullets, specs, descriptions):
            out = _scan_product(
                title if pd.notna(title) else None,
                bj    if pd.notna(bj)    else None,
                sj    if pd.notna(sj)    else None,
                desc  if pd.notna(desc)  else None,
                _bp,
                window_words,
            )
            import json as _json
            results.append(_json.dumps(out))
        return pd.Series(results)

    enriched_df = (
        df.withColumn(
            "_compat_raw",
            compat_pandas_udf(title_col, bullets_json_col, spec_json_col, description_col),
        )
        .withColumn("compatibility_mentioned", F.get_json_object(F.col("_compat_raw"), "$.compatibility_mentioned"))
        .withColumn("evidence", F.from_json(F.get_json_object(F.col("_compat_raw"), "$.evidence"), EVIDENCE_STRUCT_TYPE))
        .drop("_compat_raw")
    )

    return enriched_df


def _skip_vector_search_columns(df: DataFrame) -> DataFrame:
    """
    Return df with all vector-search output columns set to NULL.
    Used when vector search is unavailable or skipped.
    """
    return (
        df
        .withColumn("compatibility_json", F.lit(None).cast(COMPATIBILITY_HIT_STRUCT_TYPE))
        .withColumn("compatible_item_ids_all", F.lit(None).cast(ArrayType(StringType())))
        .withColumn("compatible_item_ids", F.lit(None).cast(ArrayType(StringType())))
        .withColumn("compatibility_scope", F.lit(None).cast(StringType()))
        .withColumn("relationship_type", F.lit(None).cast(StringType()))
        .withColumn("compatibility_source", F.lit(None).cast(StringType()))
        .withColumn("compatibility_confidence", F.lit(None).cast(DoubleType()))
        .withColumn("compatibility_last_verified_at", F.lit(None).cast(TimestampType()))
        .withColumn("vector_search_error", F.lit(None).cast(StringType()))
    )


def _fqn(catalog: Optional[str], schema: Optional[str], table: str) -> str:
    """Build a fully-qualified table name from optional catalog/schema parts."""
    return ".".join(p for p in (catalog, schema, table) if p)


# Schema for the per-item vector-search result rows / staging table.
VECTOR_SEARCH_RESULT_SCHEMA = StructType([
    StructField("item_id",                       StringType(), True),
    StructField("compatibility_json",            COMPATIBILITY_HIT_STRUCT_TYPE, True),
    StructField("compatible_item_ids_all",       ArrayType(StringType()), True),
    StructField("compatible_item_ids",           ArrayType(StringType()), True),
    StructField("compatibility_scope",           StringType(), True),
    StructField("relationship_type",             StringType(), True),
    StructField("compatibility_source",          StringType(), True),
    StructField("compatibility_confidence",      DoubleType(), True),
    StructField("compatibility_last_verified_at", TimestampType(), True),
    StructField("vector_search_error",           StringType(), True),
])


def enrich_with_vector_search(df: DataFrame, spark: DatabricksSession, 
                              endpoint_name: str, index_name: str, full_refresh: bool = True,
                              output_catalog: str = None,  output_schema: str = None, output_table: str = None,
                              embedding_endpoint: str = None,num_results: int = 10,
                              max_hits_per_item: int = 5,
                              confidence_threshold: float = 0.70) -> DataFrame:
    """
    Vector-search the evidence text windows to find compatible item_ids.

    Runs on the driver in rate-limited batches with retry on 429. Results are flushed
    to "<output_table>_vs_staging" so an incremental rerun resumes where it stopped.

    Args:
        full_refresh: If False, resume from the staging table; if True, drop it and start clean.
    """
    print("\nEnriching with Vector Search for compatible items...")
    print(f"  Mode: {'FULL REFRESH' if full_refresh else 'INCREMENTAL'}")

    # Early exit if endpoint/index not configured
    if not endpoint_name or not index_name:
        print(f"  Skipping vector search: endpoint_name={endpoint_name!r}, index_name={index_name!r}")
        return _skip_vector_search_columns(df)

    # Filter for rows that need searching
    search_df = df.filter(F.col("compatibility_mentioned") == "yes").select("item_id", "evidence")

    if search_df.count() == 0:
        print("  No compatibility mentions found. Skipping vector search.")
        return _skip_vector_search_columns(df)

    search_df = search_df.withColumn(
        "first_ev",
        F.col("evidence").getItem(0)
    ).withColumn(
        "search_query", F.col("first_ev").getField("search_query")
    )
    null_entity_count = search_df.filter(F.col("search_query").isNull()).count()
    if null_entity_count > 0:
        print(f"\n  Warning: {null_entity_count} rows have null search_query after evidence parsing.")
        search_df.filter(F.col("search_query").isNull()).select("item_id", "evidence").show(5, truncate=120)

    search_df = search_df.filter(F.col("search_query").isNotNull()).select("item_id", "search_query", "first_ev")

    # ── Staging table: holds per-item vector-search results across runs ──
    # Resilience: results are flushed here every FLUSH_EVERY items so a crash in
    # a later step (demandshape / merge / save) never loses the search work.
    staging_table = None
    if output_table:
        staging_table = _fqn(output_catalog, output_schema, f"{output_table}_vs_staging")

    if staging_table and full_refresh:
        # Full refresh: start from a clean staging table.
        try:
            spark.sql(f"DROP TABLE IF EXISTS {staging_table}")
            print(f"  Full refresh: dropped staging table {staging_table}")
        except Exception as e:
            print(f"  Warning: could not drop staging table {staging_table}: {e}")

    # ── Incremental mode: skip items already present in the staging table ──
    if not full_refresh and staging_table:
        try:
            existing_df = spark.table(staging_table)
            already_processed = (
                existing_df
                .select(F.col("item_id").cast(StringType()).alias("item_id"))
                .distinct()
            )
            before_count = search_df.count()
            search_df = search_df.join(already_processed, "item_id", "left_anti")
            after_count = search_df.count()
            skipped = before_count - after_count
            print(f"  Incremental: skipping {skipped} already-staged items ({after_count} remaining)")

            if after_count == 0:
                print("  All items already in staging. Reading results straight from staging.")
                search_df = search_df.limit(0)  # nothing new to search; fall through to staging read
        except Exception as e:
            print(f"  Incremental check failed (staging may not exist yet): {e}")
            print("  Proceeding with full vector search...")

    # Load credentials on the driver
    try:
        from dotenv import load_dotenv as _load_dotenv
        _load_dotenv()
    except ImportError:
        pass

    databricks_host  = os.getenv("DATABRICKS_HOST", "")
    databricks_token = os.getenv("DATABRICKS_TOKEN", "")

    if not databricks_host:
        try:
            databricks_host = spark.conf.get("spark.databricks.workspaceUrl", "")
        except Exception:
            pass

    databricks_host = databricks_host.rstrip("/")

    if not databricks_token:
        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            header_factory = w.config.authenticate
            headers = header_factory()
            if isinstance(headers, dict) and "Authorization" in headers:
                databricks_token = headers["Authorization"].replace("Bearer ", "")
        except Exception as e:
            print(f"  Warning: WorkspaceClient auth failed: {e}")

    search_client = DatabricksVectorSearch(
        host=databricks_host, token=databricks_token,
        endpoint_name=endpoint_name, index_name=index_name,
        embedding_endpoint=embedding_endpoint,
    )

    # Probe once before committing to the loop
    if not search_client.is_available:
        raise RuntimeError("Vector Search unavailable: no endpoint/index configured")
    if not search_client.probe():
        print("  Probe FAILED — endpoint/index unreachable. Skipping vector search.")
        return _skip_vector_search_columns(df)

    # Collect to driver and search locally
    search_rows = search_df.collect()
    total_items = len(search_rows)
    print(f"  Running vector search for {total_items} items on driver...")

    from datetime import datetime, timezone
    from concurrent.futures import ThreadPoolExecutor, as_completed

    # ── Bulk-embed UNIQUE query strings once (the big win) ───────────────────
    # Embedding every query up front, in batches, means each similarity search
    # passes a precomputed query_vector and the endpoint never re-embeds per
    # call — which is what was causing REQUEST_LIMIT_EXCEEDED. Deduplicating
    # identical query strings (e.g. many "compatible with HP") further cuts the
    # embed count. If no embedding endpoint is configured, we fall back to the
    # old per-call query_text path.
    use_vectors = bool(embedding_endpoint)
    query_vec_map: Dict[str, list] = {}
    if use_vectors:
        unique_queries = sorted({str(r["search_query"]) for r in search_rows})
        print(f"  Bulk-embedding {len(unique_queries)} unique queries "
              f"(from {total_items} items) via '{embedding_endpoint}'...")
        try:
            t0 = time.time()
            vectors = search_client.embed_texts(unique_queries, batch_size=128)
            query_vec_map = dict(zip(unique_queries, vectors))
            print(f"  Embedded {len(query_vec_map)} queries in {time.time()-t0:.1f}s.")
        except Exception as e:
            print(f"  Bulk embedding failed ({e}); falling back to per-call query_text search.")
            use_vectors = False
            query_vec_map = {}

    # Embedding endpoint has a QPS cap: modest concurrency, pause between batches, retry on 429.
    MAX_WORKERS       = 4
    BATCH_SIZE        = 100
    INTER_BATCH_PAUSE = 1.0

    def _process_row(row):
        """Run one item through vector search (thread-safe; retries on 429)."""
        row_d      = row.asDict(recursive=True)
        item_id    = str(row_d["item_id"])
        query_text = str(row_d["search_query"])
        first_ev   = row_d.get("first_ev", {}) or {}

        detection_method = first_ev.get("detection_method")
        comp_scope = "brand" if detection_method == "brand_dictionary" else None

        raw_keyword = first_ev.get("matched_keyword")
        relationship_type = raw_keyword
        if raw_keyword:
            for kp in COMPATIBILITY_KEYWORD_PATTERNS:
                if kp["regex"].search(raw_keyword):
                    relationship_type = kp["name"]
                    break

        try:
            # Prefer precomputed-vector search; fall back to text search.
            qvec = query_vec_map.get(query_text) if use_vectors else None
            if qvec is not None:
                hits = search_client.search_by_vector_with_retry(query_vector=qvec, num_results=num_results)
            else:
                hits = search_client.search_with_retry(query_text=query_text, num_results=num_results)

            structured_hits = []
            item_ids = []
            high_conf_ids = []

            if hits:
                for hit in hits:
                    hit_id = hit.get("id")
                    if hit_id and str(hit_id) == str(item_id):
                        continue

                    score = hit.get("score")
                    structured_hits.append({
                        "id": hit_id,
                        "title": hit.get("title"),
                        "score": score,
                        "source": "nlp_vector_search",
                    })
                    if hit_id:
                        item_ids.append(hit_id)
                        if score is not None and score >= confidence_threshold:
                            high_conf_ids.append(hit_id)

                    if len(structured_hits) == max_hits_per_item:
                        break

            return {
                "item_id":           item_id,
                "compatibility_json": structured_hits if structured_hits else None,
                "compatible_item_ids_all": item_ids if item_ids else None,
                "compatible_item_ids": high_conf_ids if high_conf_ids else None,
                "compatibility_scope": comp_scope,
                "relationship_type": relationship_type if structured_hits else None,
                "compatibility_source": "nlp_vector_search" if structured_hits else None,
                "compatibility_confidence": structured_hits[0]["score"] if structured_hits and structured_hits[0].get("score") is not None else None,
                "compatibility_last_verified_at": datetime.now(timezone.utc),
                "vector_search_error": None,
            }
        except Exception as exc:
            return {
                "item_id":           item_id,
                "compatibility_json": None,
                "compatible_item_ids_all": None,
                "compatible_item_ids": None,
                "compatibility_scope": comp_scope,
                "relationship_type": None,
                "compatibility_source": None,
                "compatibility_confidence": None,
                "compatibility_last_verified_at": datetime.now(timezone.utc),
                "vector_search_error": str(exc),
            }

    results_by_idx: Dict[int, Dict[str, Any]] = {}
    completed = 0
    start_time = time.time()

    FLUSH_EVERY = 500          # flush successful results to staging every N keepers
    _flush_buffer: List[Dict[str, Any]] = []

    def _flush(buffer: List[Dict[str, Any]]):
        """Append a buffer of result rows to the Delta staging table."""
        if not buffer or not staging_table:
            return
        (
            spark.createDataFrame(pd.DataFrame(buffer), schema=VECTOR_SEARCH_RESULT_SCHEMA)
            .write.format("delta").mode("append").saveAsTable(staging_table)
        )

    def _is_rate_err(err: Optional[str]) -> bool:
        return bool(err) and any(
            t in err for t in ("429", "REQUEST_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED")
        )

    # Submit in controlled batches with modest concurrency to avoid 429 bursts.
    # Each completed result is buffered; rate-limited failures are held back for
    # the final sweep (NOT staged) so a rerun retries them instead of seeing a
    # duplicate/failed row in staging.
    for batch_start in range(0, total_items, BATCH_SIZE):
        batch_indices = range(batch_start, min(batch_start + BATCH_SIZE, total_items))
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_to_idx = {
                executor.submit(_process_row, search_rows[i]): i
                for i in batch_indices
            }
            for fut in as_completed(future_to_idx):
                idx = future_to_idx[fut]
                r = fut.result()
                results_by_idx[idx] = r
                completed += 1

                # Stage everything except transient rate-limit failures.
                if not _is_rate_err(r["vector_search_error"]):
                    _flush_buffer.append(r)
                    if len(_flush_buffer) >= FLUSH_EVERY:
                        _flush(_flush_buffer)
                        print(f"  Flushed {len(_flush_buffer)} results to staging "
                              f"({staging_table})")
                        _flush_buffer = []

                if completed % 500 == 0 or completed == total_items:
                    elapsed = time.time() - start_time
                    rate = completed / elapsed if elapsed > 0 else 0
                    eta_min = (total_items - completed) / rate / 60 if rate > 0 else 0
                    print(f"  Progress: {completed}/{total_items} "
                          f"({100*completed//total_items}%) | {rate:.1f} items/s | ETA {eta_min:.1f} min")
        # Brief pause between batches to smooth out request rate.
        time.sleep(INTER_BATCH_PAUSE)

    # ── Final sweep: serially retry anything still rate-limited after backoff ──
    rate_failed_idx = [i for i, r in results_by_idx.items() if _is_rate_err(r["vector_search_error"])]
    if rate_failed_idx:
        print(f"  Final sweep: retrying {len(rate_failed_idx)} rate-limited items serially...")
        recovered = 0
        for i in rate_failed_idx:
            time.sleep(1.0)  # deliberate slow pacing
            new_r = _process_row(search_rows[i])
            results_by_idx[i] = new_r
            # Stage swept results too (success or now-permanent failure).
            if not _is_rate_err(new_r["vector_search_error"]):
                _flush_buffer.append(new_r)
            if new_r["vector_search_error"] is None:
                recovered += 1
        print(f"  Final sweep recovered {recovered}/{len(rate_failed_idx)} items.")

    # Final flush of any remaining buffered results.
    if _flush_buffer:
        _flush(_flush_buffer)
        print(f"  Flushed final {len(_flush_buffer)} results to staging ({staging_table})")
        _flush_buffer = []

    results_data = [results_by_idx[i] for i in range(total_items)]

    # ── Build the result DataFrame from STAGING (covers this run + prior runs) ──
    # Reading staging — not the in-memory results — means a resume picks up
    # everything searched so far, not just the current run's remainder.
    if staging_table:
        try:
            compatibility_results_df = (
                spark.table(staging_table)
                .dropDuplicates(["item_id"])
                .select(*[f.name for f in VECTOR_SEARCH_RESULT_SCHEMA.fields])
            )
        except Exception as e:
            print(f"  Warning: could not read staging table ({e}); using in-memory results.")
            compatibility_results_df = spark.createDataFrame(
                pd.DataFrame(results_data), schema=VECTOR_SEARCH_RESULT_SCHEMA
            )
    else:
        compatibility_results_df = spark.createDataFrame(
            pd.DataFrame(results_data), schema=VECTOR_SEARCH_RESULT_SCHEMA
        )

    null_count  = sum(1 for r in results_data if r["compatibility_json"] is None)
    error_count = sum(1 for r in results_data if r["vector_search_error"] is not None)
    print(f"  Vector search complete. {len(results_data)} processed | "
          f"{len(results_data)-null_count} with results | {null_count} null | {error_count} errors")

    if error_count > 0:
        errors = [r for r in results_data if r["vector_search_error"]][:3]
        for e in errors:
            print(f"    Warning: item {e['item_id']}: {e['vector_search_error']}")

    _output_cols = [
        "compatibility_json",
        "compatible_item_ids_all",
        "compatible_item_ids",
        "compatibility_scope",
        "relationship_type",
        "compatibility_source",
        "compatibility_confidence",
        "has_compatibilities",
        "compatibility_last_verified_at",
        "vector_search_error"
    ]
    base_df = df
    for _c in _output_cols:
        if _c in base_df.columns:
            base_df = base_df.drop(_c)

    final_df = base_df.withColumn("item_id", F.col("item_id").cast(StringType())).join(
        compatibility_results_df, "item_id", "left"
    )

    return final_df

# -- Demandshape Structured Compatibility --

# product_master flags that make a product live on each demandshape business unit's site
DEMANDSHAPE_LIVE_FLAGS = {
    "Dotcom": ("INTENT_TO_SELL_DOTCOM_IND", "WEB_LIVE_ON_DOTCOM_IND"),
    "SBA": ("INTENT_TO_SELL_CONTRACT_IND", "WEB_LIVE_ON_CONTRACT_IND"),
}


def _demandshape_pairs(spark: DatabricksSession, demandshape_table: str, business_unit: str) -> DataFrame:
    """item_id and ds_compatible_ids from the business unit's pairs, both products live on its site."""
    intent_flag, live_flag = DEMANDSHAPE_LIVE_FLAGS[business_unit]
    query = f"""
    WITH pairs AS (
        SELECT DISTINCT
            a.original_sku AS original_id,
            a.alt_sku AS alt_id
        FROM {demandshape_table} a
        INNER JOIN snowflake_edh.product.product_master pm
            ON pm.product_id = a.original_sku
            AND pm.{intent_flag} = 'Y'
            AND pm.{live_flag} = 'Y'
        INNER JOIN snowflake_edh.product.product_master pm2
            ON pm2.product_id = a.alt_sku
            AND pm2.{intent_flag} = 'Y'
            AND pm2.{live_flag} = 'Y'
        WHERE a.business_unit = '{business_unit}'
            AND a.value_prop_id = 91
            AND a.original_sku != a.alt_sku
    ),
    original_compat AS (
        SELECT
            original_id AS item_id,
            COLLECT_SET(alt_id) AS compat_ids
        FROM pairs
        GROUP BY original_id
    ),
    alt_compat AS (
        SELECT
            alt_id AS item_id,
            COLLECT_SET(original_id) AS compat_ids
        FROM pairs
        GROUP BY alt_id
    ),
    combined AS (
        SELECT
            COALESCE(o.item_id, a.item_id) AS item_id,
            ARRAY_DISTINCT(ARRAY_UNION(
                COALESCE(o.compat_ids, ARRAY()),
                COALESCE(a.compat_ids, ARRAY())
            )) AS ds_compatible_ids
        FROM original_compat o
        FULL OUTER JOIN alt_compat a ON o.item_id = a.item_id
    )
    SELECT
        item_id,
        ds_compatible_ids
    FROM combined
    """
    return spark.sql(query)


def enrich_with_demandshape(df: DataFrame, spark: DatabricksSession, demandshape_table: str) -> DataFrame:
    ds_df = _demandshape_pairs(spark, demandshape_table, "Dotcom")
    ds_count = ds_df.count()
    print(f"  Demandshape: {ds_count} products found with compatibility")

    if ds_count == 0:
        print("  No demandshape matches. Skipping.")
        return df

    ds_df = ds_df.withColumn(
        "ds_compatibility_json",
        F.transform(
            F.col("ds_compatible_ids"),
            lambda x: F.struct(
                x.alias("id"),
                F.lit(None).cast(StringType()).alias("title"),
                F.lit(1.0).cast(DoubleType()).alias("score"),
                F.lit("demandshape").alias("source"),
            )
        )
    )

    df = df.withColumn("item_id", F.col("item_id").cast(StringType()))
    ds_df = ds_df.withColumn("item_id", F.col("item_id").cast(StringType()))

    result = df.join(
        ds_df.select("item_id", "ds_compatible_ids", "ds_compatibility_json"),
        "item_id",
        "left"
    )

    return result


def contract_demandshape_columns(spark: DatabricksSession, demandshape_table: str) -> DataFrame:
    """SB compatibility: the SBA demandshape pairs only; the text search does not run for SB.

    Returns item_id, compatible_item_ids_contract and compatibility_json_contract, typed like
    compatible_item_ids and compatibility_json.
    """
    ds_df = _demandshape_pairs(spark, demandshape_table, "SBA")
    ids = F.array_sort(F.col("ds_compatible_ids").cast(ArrayType(StringType())))
    hits = F.transform(
        ids,
        lambda x: F.struct(
            x.alias("id"),
            F.lit(None).cast(StringType()).alias("title"),
            F.lit(1.0).cast(DoubleType()).alias("score"),
            F.lit("demandshape").alias("source"),
        )
    ).cast(COMPATIBILITY_HIT_STRUCT_TYPE)
    sb_df = ds_df.select(
        F.col("item_id").cast(StringType()).alias("item_id"),
        ids.alias("compatible_item_ids_contract"),
        hits.alias("compatibility_json_contract"),
    )
    print(f"  SB demandshape: {sb_df.count()} products found with compatibility")
    return sb_df


def merge_compatibility_results(df: DataFrame) -> DataFrame:
    from datetime import datetime, timezone

    @F.udf(COMPATIBILITY_HIT_STRUCT_TYPE)
    def merge_and_dedup(nlp_json, ds_json):
        entries = {}
        for arr in [nlp_json, ds_json]:
            if arr is None:
                continue
            for entry in arr:
                entry_dict = entry.asDict() if hasattr(entry, 'asDict') else dict(entry)
                eid = entry_dict.get("id")
                if eid is None:
                    continue
                score = entry_dict.get("score") or 0.0
                if eid not in entries or score > (entries[eid].get("score") or 0.0):
                    entries[eid] = entry_dict
        if not entries:
            return None
        return list(entries.values())

    df = df.withColumn(
        "compatibility_json",
        merge_and_dedup(F.col("compatibility_json"), F.col("ds_compatibility_json"))
    )

    has_any_all = (
        F.col("compatible_item_ids_all").isNotNull() |
        F.col("ds_compatible_ids").isNotNull()
    )
    df = df.withColumn(
        "compatible_item_ids_all",
        F.when(
            has_any_all,
            F.array_distinct(F.array_union(
                F.coalesce(F.col("compatible_item_ids_all"), F.array().cast(ArrayType(StringType()))),
                F.coalesce(F.col("ds_compatible_ids"), F.array().cast(ArrayType(StringType())))
            ))
        ).otherwise(F.lit(None).cast(ArrayType(StringType())))
    )

    has_any_high = (
        F.col("compatible_item_ids").isNotNull() |
        F.col("ds_compatible_ids").isNotNull()
    )
    df = df.withColumn(
        "compatible_item_ids",
        F.when(
            has_any_high,
            F.array_distinct(F.array_union(
                F.coalesce(F.col("compatible_item_ids"), F.array().cast(ArrayType(StringType()))),
                F.coalesce(F.col("ds_compatible_ids"), F.array().cast(ArrayType(StringType())))
            ))
        ).otherwise(F.lit(None).cast(ArrayType(StringType())))
    )

    has_nlp = F.col("compatibility_source").isNotNull()
    has_ds = F.col("ds_compatible_ids").isNotNull()
    df = df.withColumn(
        "compatibility_source",
        F.when(has_nlp & has_ds, F.lit("demandshape+nlp_vector_search"))
         .when(has_ds, F.lit("demandshape"))
         .when(has_nlp, F.col("compatibility_source"))
         .otherwise(F.lit(None))
    )

    ds_confidence = F.when(F.col("ds_compatible_ids").isNotNull(), F.lit(1.0)).otherwise(F.lit(None).cast(DoubleType()))
    df = df.withColumn(
        "compatibility_confidence",
        F.greatest(F.col("compatibility_confidence"), ds_confidence)
    )

    df = df.withColumn(
        "relationship_type",
        F.when(F.col("relationship_type").isNotNull(), F.col("relationship_type"))
         .when(F.col("ds_compatible_ids").isNotNull(), F.lit("structured_alternative"))
         .otherwise(F.lit(None))
    )

    df = df.withColumn(
        "compatibility_scope",
        F.when(F.col("compatibility_scope").isNotNull(), F.col("compatibility_scope"))
         .when(F.col("ds_compatible_ids").isNotNull(), F.lit("structured"))
         .otherwise(F.lit(None))
    )

    df = df.withColumn(
        "has_compatibilities",
        F.when(F.col("compatibility_json").isNotNull(), F.lit(True)).otherwise(F.lit(False))
    )

    df = df.withColumn(
        "compatibility_last_verified_at",
        F.when(
            F.col("has_compatibilities"),
            F.lit(datetime.now(timezone.utc)).cast(TimestampType())
        ).otherwise(F.col("compatibility_last_verified_at"))
    )

    df = df.drop("ds_compatibility_json", "ds_compatible_ids", "compatibility_mentioned")

    total = df.count()
    has_compat = df.filter(F.col("has_compatibilities") == True).count()
    nlp_only = df.filter(F.col("compatibility_source") == "nlp_vector_search").count()
    ds_only = df.filter(F.col("compatibility_source") == "demandshape").count()
    both = df.filter(F.col("compatibility_source") == "demandshape+nlp_vector_search").count()
    print(f"  Merge complete: {has_compat}/{total} products with compatibility data")
    print(f"    NLP only: {nlp_only} | Demandshape only: {ds_only} | Both: {both}")

    return df


# -- Pipeline Entry Point --

def _probe_spacy_on_workers(spark: DatabricksSession, num_partitions: int = 8) -> Dict[str, int]:
    """
    Check spaCy availability across executors using a DataFrame UDF (works on
    classic clusters AND serverless / Spark Connect, unlike an RDD .parallelize
    probe). Mirrors _get_nlp_model: a task is "ok" if spaCy imports and either
    en_core_web_md or en_core_web_sm loads. Returns a {status: task_count} dict.
    """
    from pyspark.sql.types import StringType as _StringType

    @F.udf(_StringType())
    def _probe(_):
        try:
            import spacy
        except Exception as e:
            return f"no_spacy:{type(e).__name__}"
        for model in ("en_core_web_md", "en_core_web_sm"):
            try:
                spacy.load(model, disable=["parser", "lemmatizer"])
                return "ok"
            except Exception:
                continue
        return "no_model"

    n = max(int(num_partitions), 1)
    rows = (
        spark.range(0, n)
        .repartition(n)
        .withColumn("status", _probe(F.col("id")))
        .groupBy("status")
        .count()
        .collect()
    )
    return {r["status"]: r["count"] for r in rows}


def _assert_spacy_available(spark: DatabricksSession, require: bool = True, num_partitions: int = 8) -> bool:
    """
    Verify spaCy + a model are present on the executors and fail LOUD if not.

    require=True  -> raise RuntimeError when any probed task lacks spaCy/model.
    require=False -> print a warning and continue (brand-dictionary-only fallback).

    Note: this is a best-effort early check. On an autoscaling cluster it cannot
    guarantee every future executor is covered, but it reliably catches the
    common case where spaCy was never installed on the workers at all.
    Returns True if every probed task reported "ok".
    """
    # print("\n0. Checking spaCy availability on workers...")
    try:
        summary = _probe_spacy_on_workers(spark, num_partitions=num_partitions)
    except Exception as e:
        msg = f"Could not run spaCy worker probe: {e}"
        if require:
            raise RuntimeError(
                msg + " — pass require_spacy=False to skip this check and allow "
                "brand-dictionary-only detection."
            )
        print(f"  Warning: {msg}. Proceeding without verification.")
        return False

    # print(f"  spaCy worker status: {summary}")
    all_ok = set(summary.keys()) == {"ok"}
    if not all_ok:
        detail = (
            f"spaCy and/or a model (en_core_web_md / en_core_web_sm) is missing on "
            f"one or more workers: {summary}. Without it, detection SILENTLY degrades "
            "to brand-dictionary-only matching (no NER, no POS-NNP). Install spaCy + a "
            "model as a cluster library or init script, then rerun. To proceed anyway "
            "with degraded detection, pass require_spacy=False."
        )
        if require:
            raise RuntimeError(detail)
        print(f"  Warning: {detail}")
    else:
        print("  spaCy ready on all probed workers.")
    return all_ok


# Columns this task reads from its source table: the text the scan reads, the brand list
# and the two site flags.
SOURCE_COLUMNS = ["item_id", "title", "description", "bullets_json", "spec_json", "brand",
                  "in_product_discovery_data", "is_live_contract"]
# Staples.com output columns, from both paths
OUTPUT_COLUMNS = [
    "has_compatibilities",
    "evidence",
    "compatibility_json",
    "compatible_item_ids_all",
    "compatible_item_ids",
    "compatibility_scope",
    "relationship_type",
    "compatibility_source",
    "compatibility_confidence",
    "compatibility_last_verified_at",
    "vector_search_error",
]
# SB output columns, from Demandshape only
CONTRACT_COLUMNS = ["compatible_item_ids_contract", "compatibility_json_contract"]


def run_compatibility_pipeline(
    spark: DatabricksSession,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None,
    mode: str = "merge",
    endpoint_name: str = None,
    index_name: str = None,
    demandshape_table: str = None,
    full_refresh: bool = True,
    require_spacy: bool = True,
    embedding_endpoint: str = None,
    confidence_threshold: float = 0.70,
    num_results: int = 10,
    max_hits_per_item: int = 5,
    window_words: int = 12,
    min_brand_length: int = 3
) -> DataFrame:
    print("=" * 80)
    print("COMPATIBILITY DETECTION PIPELINE (NLP + Demandshape)")
    print(f"Mode: {'FULL REFRESH' if full_refresh else 'INCREMENTAL'}")
    print("=" * 80)

    # 1. Load Data: every product; only the Staples.com ones go through both paths
    print(f"\n1. Loading data from {source_table}...")
    all_df = read_all_products(spark, source_table, SOURCE_COLUMNS).select(*SOURCE_COLUMNS)
    df = all_df.filter(F.col("in_product_discovery_data")).drop("in_product_discovery_data", "is_live_contract")
    print(f"  Loaded {all_df.count()} rows, {df.count()} of them Staples.com products")

    # 0/2-pre. Fail loud if spaCy is missing on workers (silent degradation guard)
    _assert_spacy_available(spark, require=require_spacy)

    # 2. Extract Compatibility Mentions
    print("\n2. Finding compatibility signals...")
    result_df = extract_compatibility_data(df, window_words=window_words, min_brand_length=min_brand_length)

    # 3a. Enrich NLP mentions with Vector Search (skip if not configured)
    if endpoint_name and index_name:
        print("\n3. Enriching NLP mentions with Vector Search...")
        result_df = enrich_with_vector_search(result_df, spark, endpoint_name, index_name, 
                                              full_refresh=full_refresh, output_catalog=output_catalog, 
                                              output_schema=output_schema, output_table=output_table, 
                                              embedding_endpoint=embedding_endpoint,
                                              num_results=num_results, max_hits_per_item=max_hits_per_item,
                                              confidence_threshold=confidence_threshold,)
    else:
        print(f"\n3a. Skipping Vector Search (endpoint_name={endpoint_name!r}, index_name={index_name!r})")
        result_df = _skip_vector_search_columns(result_df)

    # 3b. Enrich with Demandshape structured data (all products)
    if demandshape_table:
        try:
            spark.table(demandshape_table)
        except Exception as e:
            raise RuntimeError(
                f"Demandshape table '{demandshape_table}' does not exist or is inaccessible: {e}"
            )
        print("4.Enriching with Demandshape")
        result_df = enrich_with_demandshape(result_df, spark, demandshape_table)
    else:
        raise ValueError(
            "demandshape_table is required but was not provided. "
        )

    # 4. Merge both paths
    print("\n5. Merging NLP + Demandshape compatibility results...")
    result_df = merge_compatibility_results(result_df)

    # 4b. SB: the Demandshape pairs only, on products live on SB
    print("\n5b. SB compatibility from Demandshape...")
    sb_df = (all_df.filter(F.col("is_live_contract")).select("item_id")
             .join(contract_demandshape_columns(spark, demandshape_table), "item_id"))

    # One row per product: Staples.com columns on Staples.com products, SB columns on SB products
    result_df = (all_df.select("item_id")
                 .join(result_df.select("item_id", *OUTPUT_COLUMNS), "item_id", "left")
                 .join(sb_df, "item_id", "left"))

    # 5. Save
    print("\n6. Saving results...")
    save_data(
        result_df.select("item_id", *OUTPUT_COLUMNS, *CONTRACT_COLUMNS).withColumns({
            "created_at": F.current_timestamp(),
            "updated_at": F.current_timestamp(),
        }),
        spark,
        catalog=output_catalog,
        schema=output_schema,
        table=output_table,
        mode=mode,
    )

    print("\n" + "=" * 80)
    print("PIPELINE COMPLETE")
    print("=" * 80)

    return result_df


# -- Standalone execution --

if __name__ == "__main__":
    spark = get_spark_session()

    GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")

    general_config = read_config(GENERAL_CONFIG_PATH)
    compat_config = general_config["compatibility"]
    SOURCE_TABLE = compat_config["tables"]["source_table"]
    OUTPUT_TABLE = compat_config["tables"]["output_table"]
    full_refresh = compat_config["tables"]["full_refresh"]
    ENDPOINT_NAME = general_config["vectorsearch"]["endpoint_name"]
    INDEX_NAME = general_config["vectorsearch"]["index_name"]
    DEMANDSHAPE_TABLE = compat_config["tables"]["demandshape_product_alt"]

    run_compatibility_pipeline(
        spark,
        source_table=SOURCE_TABLE,
        output_table=OUTPUT_TABLE,
        endpoint_name=ENDPOINT_NAME,
        index_name=INDEX_NAME,
        demandshape_table=DEMANDSHAPE_TABLE,
        full_refresh=full_refresh,
        require_spacy=True,
        embedding_endpoint="databricks-bge-large-en",
        confidence_threshold=compat_config["thresholds"]["confidence_threshold"],
        num_results=compat_config["vector_search"]["num_results"],
        max_hits_per_item=compat_config["vector_search"]["max_hits_per_item"],
        window_words=compat_config["nlp"]["window_words"],
        min_brand_length=compat_config["nlp"]["min_brand_length"],
    )