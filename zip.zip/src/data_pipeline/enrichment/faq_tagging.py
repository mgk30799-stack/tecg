"""
FAQ Question + Answer Tagging — LLM semantic tags for product Q&A.

Reads `q_and_a` from the product catalog, sends each question and its answers to
Gemma on Vertex AI through a pandas UDF, and returns snake_case intent tags plus
searchable keyword phrases.

Vertex is the only backend: gemma-4-26b-a4b-it-maas is served from Vertex's
OpenAI-compatible MaaS surface, which Databricks ai_query cannot reach. A missing
or incomplete review_mining.llm.vertex config fails the run.

FIELDS PRODUCED
    question_tags    ARRAY<STRING>  intent tags for the question
    question_keyword STRING         searchable phrase built from the question
    conflict_flag    BOOLEAN        true when two answers directly contradict
    answers_meta     ARRAY<STRUCT<position, answer_keyword, answer_tags,
                     answer_score, time_bound>> — one per answer sent,
                     positionally aligned

RESOLVED FROM SNOWFLAKE, NEVER FROM THE MODEL
    question_id             product_web_question.QUESTION_ID, or NULL
    question_submission_tms that row's SUBMISSION_TMS, or NULL
    answer_id               ARRAY<STRING> aligned to `answers`; a position is
                            NULL when that answer's text did not match

NOTHING HERE IS AGE-AWARE. answer_score judges content alone, time_bound says
whether that content expires, and review_mining applies the recency penalty
(decay_answer_score) from real timestamps.

TWO IDS
    tag_id      "{item_id}_{position}" (utils.question_id_expr), always present.
                The tag table's primary key, and the key for dedupe, batching,
                the Delta MERGE and the incremental anti-join.
    question_id The real QUESTION_ID, or NULL. Data only, never a key. Nothing is
                ever substituted for it — tag_id is not its fallback.

    tag_id is positional and q_and_a has no guaranteed order, so a tag_id can
    drift for an unchanged question, and does not change when a question is
    reworded at the same position. A periodic full_refresh=True run corrects
    both. Affects tag freshness only, never question_id.

COST
    `dedupe_by_text` sends one prompt per distinct question+answers pair. Answers
    are largely item-specific, so a boilerplate question costs roughly one call
    per item. Bounded by max_answers_per_question, max_answer_chars and
    max_questions_per_run in config/general.yml.

TABLE vs DATAFRAME
    `tag_table` controls persistence only. mine_faq_tags builds and returns the
    same DataFrame either way, and review_mining consumes that frame directly
    rather than reading the table back. Cost is bounded by the CALLER — handing
    mine_faq_tags an unnarrowed catalog tags the whole catalog.

Usage:
    python faq_tagging.py                      # standalone, full catalog

    from faq_tagging import generate_faq_tags  # config-driven, same semantics
    generate_faq_tags(spark)

    from faq_tagging import mine_faq_tags      # what review_mining calls
    tags_df = mine_faq_tags(spark, source_df=narrowed_catalog_df)
"""

import base64
import os
import re
import sys
import json
import uuid
import logging
from datetime import datetime, timezone
from functools import reduce
from typing import Any, Dict, Optional, Sequence

import pandas as pd
from pyspark.sql import Column, DataFrame, SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import (
    ArrayType, BooleanType, IntegerType, StringType, StructField, StructType,
    TimestampType,
)

logger = logging.getLogger(__name__)

# =============================================================================
# PROJECT ROOT
# =============================================================================

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# pyrefly: ignore [missing-import]
from utils import (
    faq_unit_rows, get_spark_session, read_config, read_faq_tags, write_unit_tags,
    question_id_expr, resolve_question_keys,
)
# pyrefly: ignore [missing-import]
# Renders the per-row prompt; make_vertex_invoke_udf below runs the model on it.
from reviews_prompts import build_faq_tagging_prompt_sql


# =============================================================================
# DEFAULTS  (overridden by config/general.yml -> faq_tagging)
# =============================================================================

DEFAULT_TEMPERATURE = 0.0
DEFAULT_BATCH_SIZE = 500
DEFAULT_TIMEOUT_S = 120.0
DEFAULT_DEDUPE_BY_TEXT = True
# Answers are unbounded in both count and length. These bound the prompt, and
# with it the cost of including answers at all — see the module docstring.
DEFAULT_MAX_ANSWERS_PER_QUESTION = 5
DEFAULT_MAX_ANSWER_CHARS = 500

# Whether to PERSIST the tag table. This controls persistence ONLY — never data
# flow. mine_faq_tags builds and returns the same DataFrame either way, and
# review_mining consumes that frame rather than reading the table back. The
# table is an observability artefact: keep it on for scheduled runs so a
# quality regression can be investigated after the fact, turn it off for local
# and ad-hoc work where the write is pure overhead.
DEFAULT_TAG_TABLE = True

# The contract for the output table. Enforced in _write_tags — question_tags and
# question_keyword each have to survive several explicit column projections, and
# dropping one is a silent failure that shows up much later as a NULL column.
#
# tag_id vs question_id: see the module docstring ("TWO IDS"). Short version —
# tag_id is the NEVER-NULL surrogate key everything key-shaped uses; question_id
# is the real, nullable Snowflake id, carried as data and never a key.
#
# question_submission_tms is the SOURCE ROW's SUBMISSION_TMS, resolved through
# the same match as question_id and NULL on exactly the same rows. It is the
# question's own submission time, never an answer's — review_mining's
# faq_summary_json makes the same distinction. Nothing here decays or ages on
# it; that is review_mining's job (see decay_answer_score).
TAG_TABLE_SCHEMA = StructType([
    StructField("item_id",          StringType(),            False),
    StructField("tag_id",           StringType(),            False),  # PK
    StructField("question_id",      StringType(),            True),
    StructField("question",         StringType(),            True),
    StructField("question_tags",    ArrayType(StringType()), True),
    StructField("question_keyword", StringType(),            True),
    # Resolved from product_web_question.SUBMISSION_TMS, or NULL when the
    # question's text matched no source row — same rows as question_id, since
    # both come out of one map lookup.
    StructField("question_submission_tms", TimestampType(),  True),
    # True when two of this question's answers directly contradict each other.
    # NULL = the model gave no usable verdict; review_mining reads that as false.
    StructField("conflict_flag",    BooleanType(),           True),
    # One entry per answer sent to the model, positionally aligned to the
    # question's q_and_a answer array. review_mining picks an answer's tags by
    # matching `position` to the answer's index, so this array must stay in
    # order and complete — the parser guarantees that, see _build_answers_meta.
    # NOTE the plural `answer_tags` here vs the singular `answer_tag` field in
    # faq_summary_json.answers[] — same data, two names, matching the requested
    # output format on the summary side.
    StructField("answers_meta", ArrayType(StructType([
        StructField("position",       IntegerType(),           True),
        StructField("answer_keyword", StringType(),            True),
        StructField("answer_tags",    ArrayType(StringType()), True),
        # 0-10 LLM usefulness score, judged on CONTENT ALONE with no reference
        # to the answer's age; review_mining blends it with its own
        # deterministic score to rank answers, and applies recency decay
        # separately. NULL = no LLM opinion.
        StructField("answer_score",   IntegerType(),           True),
        # True when this answer's truth expires (stock, availability, ETAs,
        # pricing) as opposed to standing facts (specs, warranty, dimensions).
        # Selects which decay table review_mining applies to answer_score.
        # NULL = no verdict, read downstream as "not time-bound" so a silent
        # model never costs an answer points it did not earn.
        StructField("time_bound",     BooleanType(),           True),
    ])), True),
    # The REAL product_web_answer.ANSWER_ID for each entry in `answers`, SAME
    # ORDER, SAME LENGTH, NEVER NULL ITSELF — index i here is that answer's
    # id, exactly as answers_meta[i] is that answer's tags. An entry is NULL
    # when that specific answer's text matched no source row, or when there
    # was nothing to resolve against at all (no ANSWERS_TABLE configured, or
    # an unreachable table) — see explode_questions' ALIGNMENT note. Resolved
    # by the same utils.resolve_question_keys call as question_id — see its
    # docstring for the (question_id, answer_text) match and the
    # latest-wins dedupe.
    StructField("answer_id", ArrayType(StringType()), True),
    StructField("model_endpoint",   StringType(),            True),
    StructField("created_at_ts",    TimestampType(),         True),
    StructField("last_updated_ts",  TimestampType(),         True),
])

TAG_TABLE_COLUMNS = [f.name for f in TAG_TABLE_SCHEMA.fields]


# =============================================================================
# TABLE / LLM CONFIG  (lazy-loaded — importing the module won't crash)
# =============================================================================

_faq_config: Dict[str, Any] = {}


def _ensure_table_config() -> Dict[str, Any]:
    """Load the FAQ half of the unified review_mining config on first use."""
    if _faq_config:
        return _faq_config

    config_path = os.path.join(PROJECT_ROOT, "config", "general.yml")
    cfg = read_config(config_path)
    # One config section for both halves: review_mining.llm is the shared
    # endpoint, review_mining.faq holds the FAQ-only settings.
    rm = cfg.get("review_mining", {}) or {}
    tables = rm.get("tables", {}) or {}
    shared = rm.get("llm", {}) or {}
    llm = rm.get("faq", {}) or {}

    _faq_config["SOURCE_TABLE"] = tables.get("PRODUCT_CATALOG_TABLE")
    _faq_config["OUTPUT_TABLE"] = tables.get("tag_table")
    _faq_config["QUESTIONS_TABLE"] = tables.get("QUESTIONS_TABLE")
    _faq_config["ANSWERS_TABLE"] = tables.get("ANSWERS_TABLE")
    _faq_config["FULL_REFRESH"] = bool(rm.get("full_refresh", False))
    # Persistence switch only — see DEFAULT_TAG_TABLE.
    _faq_config["TAG_TABLE"] = bool(rm.get("tag_table", DEFAULT_TAG_TABLE))
    # Vertex AI (Gemma MaaS) is the ONLY tagging backend — see vertex_settings
    # and the module docstring. The config is mandatory: a missing key fails the
    # run here rather than letting a half-configured run reach the model.
    _faq_config["VERTEX"] = dict(shared.get("vertex", {}) or {})
    _faq_config["VERTEX"]["max_concurrency"] = int(shared.get("faq_max_concurrency", 4))
    _faq_config["VERTEX"]["timeout_s"] = float(shared.get("timeout_s", DEFAULT_TIMEOUT_S))
    missing = [
        k for k in ("model", "project", "location", "secret_scope", "secret_key")
        if not _faq_config["VERTEX"].get(k)
    ]
    if missing:
        # Clear the partially-built cache so a later call re-reads config from
        # scratch rather than returning this half-populated dict (which would
        # KeyError on TEMPERATURE / BATCH_SIZE / ... below).
        _faq_config.clear()
        raise ValueError(
            "review_mining.llm.vertex is missing required key(s): "
            f"{', '.join(missing)}. FAQ tagging runs exclusively on Vertex; "
            "see config/general.yml."
        )
    _faq_config["TEMPERATURE"] = float(shared.get("faq_temperature", DEFAULT_TEMPERATURE))
    _faq_config["BATCH_SIZE"] = int(shared.get("faq_batch_size", DEFAULT_BATCH_SIZE))
    _faq_config["DEDUPE_BY_TEXT"] = bool(llm.get("dedupe_by_text", DEFAULT_DEDUPE_BY_TEXT))
    _faq_config["MAX_QUESTIONS_PER_RUN"] = int(llm.get("max_questions_per_run", -1))
    _faq_config["MAX_NEW_QUESTIONS_PER_TOPUP"] = int(
        llm.get("max_new_questions_per_topup", -1)
    )
    _faq_config["MAX_ANSWERS_PER_QUESTION"] = int(
        llm.get("max_answers_per_question", DEFAULT_MAX_ANSWERS_PER_QUESTION)
    )
    _faq_config["MAX_ANSWER_CHARS"] = int(
        llm.get("max_answer_chars", DEFAULT_MAX_ANSWER_CHARS)
    )

    # Keyword word range lives in faq_config.yaml, not here: review_mining
    # already reads it there for faq_summary_json, and one bound governing both
    # tables is the point. Read directly rather than importing review_mining's
    # load_faq_config — review_mining imports mine_faq_tags from this module, so
    # that would be a circular import.
    faq_cfg_path = os.path.join(PROJECT_ROOT, "config", "faq_config.yaml")
    faq_cfg = (read_config(faq_cfg_path) or {}).get("faq_troubleshooting", {}) or {}
    # Same max(min, max) clamp review_mining applies, so a config with the two
    # inverted cannot produce a max below the min.
    _faq_config["KEYWORD_MIN_WORDS"] = max(1, int(faq_cfg.get("keyword_min_words", 2)))
    _faq_config["KEYWORD_MAX_WORDS"] = max(
        _faq_config["KEYWORD_MIN_WORDS"],
        int(faq_cfg.get("keyword_max_words", MAX_KEYWORD_WORDS)),
    )
    return _faq_config


# =============================================================================
# LLM RESPONSE PARSER
# =============================================================================

_FENCE_RE = re.compile(r"```(?:json)?", re.IGNORECASE)

# Stripped from both sides when checking whether a keyword word came from the
# question, so "iPhone 14?" in the question matches "14" in the keyword.
_KW_STRIP = ".,;:!?\"'()[]{}<>/\\|@#$%^&*~`+=" + "‘’“”–—"

# Deliberately small and local. faq_config.yaml has a 49-word list, but that one
# is tuned for the faq_summary keyword extractor — importing it here would couple
# two unrelated pipelines to one another's tuning.
_KW_STOPWORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "do", "does",
    "did", "what", "how", "why", "when", "where", "which", "who", "for", "to",
    "of", "in", "on", "at", "with", "from", "by", "my", "your", "this", "that",
    "these", "those", "it", "its", "i", "we", "you", "they", "and", "or", "but",
    "if", "can", "will", "would", "should", "could", "have", "has", "had",
    "there", "any", "anyone", "some",
})

# Fallback only. The real bound is faq_config.yaml's keyword_max_words, threaded
# in as an argument — these apply to direct callers that pass nothing. Kept in
# step with the shipped config so the two never disagree by default.
MIN_KEYWORD_WORDS = 2
MAX_KEYWORD_WORDS = 5

# Must stay field-for-field identical to TAG_TABLE_SCHEMA's answers_meta struct
# above — this is the UDF's return type, that one is the write contract, and a
# mismatch surfaces only as a NULL column after the write.
_ANSWER_META_SCHEMA = ArrayType(StructType([
    StructField("position",       IntegerType(),           True),
    StructField("answer_keyword", StringType(),            True),
    StructField("answer_tags",    ArrayType(StringType()), True),
    StructField("answer_score",   IntegerType(),           True),
    StructField("time_bound",     BooleanType(),           True),
]))

_PARSE_SCHEMA = StructType([
    StructField("question_tags",    ArrayType(StringType()), True),
    StructField("question_keyword", StringType(),            True),
    StructField("conflict_flag",    BooleanType(),           True),
    StructField("answers_meta",     _ANSWER_META_SCHEMA,     True),
])


def _norm_word(w: str) -> str:
    """Lowercase and strip surrounding punctuation, for membership testing only."""
    return w.strip(_KW_STRIP).lower()


def _fallback_keyword(question: str, max_words: int = MAX_KEYWORD_WORDS) -> str:
    """
    Build a keyword from the question's own words, for when the model gives nothing
    usable. Preserves original order and casing.

    Returns "" only for an empty question; explode_questions filters those out.
    """
    if not question:
        return ""

    words = str(question).split()
    picked = [
        w.strip(_KW_STRIP)
        for w in words
        if len(_norm_word(w)) > 1 and _norm_word(w) not in _KW_STOPWORDS
    ]
    picked = [w for w in picked if w][:max_words]
    if picked:
        return " ".join(picked)

    # Nothing survived the stop-word filter (e.g. "is it?"). Fall back to the
    # first token of the question rather than returning empty.
    for w in words:
        cleaned = w.strip(_KW_STRIP)
        if cleaned:
            return cleaned[:60]
    return str(question).strip()[:60]


def _clean_keyword(raw_kw, question: str, max_words: int = MAX_KEYWORD_WORDS) -> str:
    """
    Validate and repair the model's question_keyword.

    Enforces in code what a prompt cannot guarantee: every word must appear in the
    question, and the result is never empty. Casing is preserved as the model wrote
    it (iPhone 14, Belkin) — this field is for display and search.

    Truncation to max_words cuts the END off, usually the most specific part, so the
    prompt asks for the same bound to keep this from firing.
    """
    if not raw_kw:
        return _fallback_keyword(question, max_words)

    allowed = {_norm_word(w) for w in str(question).split()}
    allowed.discard("")

    kept = []
    for w in str(raw_kw).split():
        cleaned = w.strip(_KW_STRIP)
        if not cleaned:
            continue
        if _norm_word(cleaned) not in allowed:
            continue  # hallucinated — the word is not in the question
        kept.append(cleaned)
        if len(kept) == max_words:
            break

    return " ".join(kept) if kept else _fallback_keyword(question, max_words)


def _normalize_tags(raw_tags) -> Optional[list]:
    """
    Lowercase / snake_case / dedupe a tag list, preserving first-seen order.
    Returns None when nothing usable survives — NULL means "not tagged".
    """
    if not isinstance(raw_tags, list):
        return None
    tags = []
    for t in raw_tags:
        if not t:
            continue
        tag = str(t).strip().lower().replace(" ", "_")
        if tag and tag not in tags:
            tags.append(tag)
    return tags or None


def _clean_answer_score(raw_score) -> Optional[int]:
    """
    Coerce the model's answer_score to an int in 0-10, or None.

    None means "no usable LLM opinion", which review_mining handles by falling back
    to deterministic-only ranking. A made-up default would look like a real judgement
    and silently drag that answer to the bottom or the middle of the ranking.

    Out-of-range values are clamped rather than rejected — 15 on a 0-10 scale still
    means "very useful". Floats are truncated ("8.5" -> 8).
    """
    if raw_score is None or isinstance(raw_score, bool):
        return None
    try:
        score = int(float(raw_score))
    except (TypeError, ValueError):
        return None
    return max(0, min(10, score))


_TRUE_WORDS = frozenset({"true", "yes", "y", "t", "1"})
_FALSE_WORDS = frozenset({"false", "no", "n", "f", "0"})


def _clean_bool(raw) -> Optional[bool]:
    """
    Coerce a model-supplied boolean to True/False, or None when unusable.

    None means "no usable verdict" and is NOT the same as False. Consumers read None
    as the safe reading — a missing conflict_flag is not a conflict, a missing
    time_bound costs no decay points — but keeping it distinct keeps "the model went
    quiet" observable.

    Accepts JSON true/false, "true"/"yes" strings, and 0/1. Anything else is None
    rather than truthy: bool("maybe") is True, a silent wrong answer.
    """
    if raw is None:
        return None
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, (int, float)):
        if raw == 1:
            return True
        if raw == 0:
            return False
        return None
    if isinstance(raw, str):
        token = raw.strip().lower()
        if token in _TRUE_WORDS:
            return True
        if token in _FALSE_WORDS:
            return False
    return None


def _build_answers_meta(
    raw_answers, answers: Sequence, max_words: int = MAX_KEYWORD_WORDS,
) -> list:
    """
    Align the model's per-answer output to the answers sent: exactly one entry per
    input answer, at positions 0..len(answers)-1. answer_keyword is never empty;
    answer_tags, answer_score (0-10) and time_bound may be None.
    """
    # Index whatever the model returned by its claimed position. Later duplicates
    # lose to the first — an arbitrary but deterministic choice.
    by_position = {}
    if isinstance(raw_answers, list):
        for entry in raw_answers:
            if not isinstance(entry, dict):
                continue
            raw_pos = entry.get("position")
            if raw_pos is None:
                continue
            try:
                pos = int(raw_pos)
            except (TypeError, ValueError):
                continue
            if 0 <= pos < len(answers) and pos not in by_position:
                by_position[pos] = entry

    meta = []
    for idx, answer_text in enumerate(answers):
        answer_text = "" if answer_text is None else str(answer_text)
        entry = by_position.get(idx) or {}
        meta.append((
            idx,
            _clean_keyword(entry.get("answer_keyword"), answer_text, max_words),
            _normalize_tags(entry.get("answer_tags")),
            _clean_answer_score(entry.get("answer_score")),
            _clean_bool(entry.get("time_bound")),
        ))
    return meta


def _parse_response(
    raw, question, answers, max_words: int = MAX_KEYWORD_WORDS,
) -> tuple:
    """
    Parse one raw model response into
    (question_tags, question_keyword, conflict_flag, answers_meta).

    Takes `question` and `answers` so the no-hallucination rule can be enforced
    rather than trusted, and unusable keywords rebuilt from the source text.

    Never raises. question_tags and conflict_flag are None when nothing usable came
    back, and the row is still persisted so an unparseable question is not retried
    and re-billed forever. question_keyword is never None. answers_meta always has
    exactly len(answers) entries. Tolerant of markdown fences.
    """
    question = "" if question is None else str(question)
    # Spark hands array<string> to a Python UDF as a list, but be tolerant of
    # None and of numpy-ish sequences so a malformed row cannot fail the batch.
    if answers is None:
        answers = []
    elif not isinstance(answers, (list, tuple)):
        try:
            answers = list(answers)
        except (TypeError, ValueError):
            answers = []

    def _empty():
        # Still emit one meta entry per answer, with keyword fallbacks, so the
        # positional contract holds even for a completely unusable response.
        return (
            None,
            _fallback_keyword(question, max_words),
            None,
            _build_answers_meta(None, answers, max_words),
        )

    if raw is None:
        return _empty()

    text = _FENCE_RE.sub("", str(raw)).strip()

    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end == 0:
        return _empty()

    try:
        data = json.loads(text[start:end])
    except (json.JSONDecodeError, ValueError):
        return _empty()

    if not isinstance(data, dict):
        return _empty()

    # --- question_tags ---
    tags = _normalize_tags(data.get("question_tags"))

    # --- question_keyword ---
    keyword = _clean_keyword(data.get("question_keyword"), question, max_words)

    # --- conflict_flag ---
    # Forced False below two answers rather than trusted: the prompt says so,
    # but a model that flags a contradiction in a single answer is plainly
    # wrong and there is no reason to carry that into the table.
    conflict_flag = _clean_bool(data.get("conflict_flag"))
    if conflict_flag and len(answers) < 2:
        conflict_flag = False

    # --- per-answer keyword + tags + score + time_bound ---
    answers_meta = _build_answers_meta(data.get("answers"), answers, max_words)

    return (tags, keyword, conflict_flag, answers_meta)


def make_parse_response_udf(keyword_max_words: int = MAX_KEYWORD_WORDS):
    """
    Build the parse UDF with the keyword bound baked into its closure.

    The bound must be captured here, on the driver. This body runs on the executors,
    where the config path is not guaranteed to resolve and a failure would silently
    fall back to the module default. A closure value is pickled with the UDF.
    """
    def _parse(raw, question, answers):
        return _parse_response(raw, question, answers, max_words=keyword_max_words)

    return F.udf(_parse, _PARSE_SCHEMA)


# =============================================================================
# VERTEX AI (GEMMA MaaS) BACKEND  (the only backend — see module docstring)
# =============================================================================
#
# WHY A UDF AND NOT ai_query: gemma-4-26b-a4b-it-maas is served from Vertex's
# OpenAI-compatible MaaS surface (.../endpoints/openapi/chat/completions).
# Databricks' google-cloud-vertex-ai external-model connector targets Gemini's
# native surface instead, so no serving endpoint can front this model and
# ai_query cannot reach it. The langchain client can.
#
# THE RULE THIS SECTION EXISTS TO ENFORCE: every credential and config value is
# resolved on the DRIVER (vertex_settings) and travels to the executors inside
# the UDF's closure. Nothing below reads YAML, a secret, or an env var from a
# worker node. Spark workers have no Databricks auth context — a secret fetch
# there fails with a permissions error — and the config file is not guaranteed
# to resolve either. Same reasoning as make_parse_response_udf's docstring.

_vertex_llm = None       # per-PROCESS cache: one client per executor, not per batch
_vertex_settings = None  # driver-side cache, so the secret is fetched once a run


def _load_service_account_info(scope: str, key: str) -> Dict[str, Any]:
    """
    DRIVER ONLY. Read the base64-encoded service-account JSON out of a Databricks
    secret and decode it to a plain dict.

    Returns a dict rather than a Credentials object: dicts pickle into a UDF closure
    cleanly, google-auth Credentials do not reliably.
    """
    from databricks.sdk import WorkspaceClient

    secret = WorkspaceClient().secrets.get_secret(scope=scope, key=key)
    try:
        return json.loads(base64.b64decode(secret.value).decode("utf-8"))
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RuntimeError(
            f"Databricks secret {scope}/{key} must contain base64-encoded "
            "Google service-account JSON."
        ) from error


def vertex_settings() -> Dict[str, Any]:
    """
    DRIVER ONLY. Everything the tagging UDF needs, as plain picklable values.

    Never None — Vertex is the only backend, and _ensure_table_config already raised
    if review_mining.llm.vertex was incomplete.

    `sa_info` is a private key serialized into the task closure. That is the pattern
    Databricks documents for this problem (fetch on the driver, pass as an argument)
    and it stays inside the workspace, but it is worth knowing.

    Cached with the same lifetime as _ensure_table_config, so a mid-session config
    change is picked up by neither and one run cannot straddle two configs.
    """
    global _vertex_settings
    if _vertex_settings is not None:
        return _vertex_settings

    cfg = _ensure_table_config()
    vertex = cfg["VERTEX"]
    _vertex_settings = {
        "model": vertex["model"],
        "project": vertex["project"],
        "location": vertex["location"],
        "temperature": cfg.get("TEMPERATURE", DEFAULT_TEMPERATURE),
        "max_concurrency": int(vertex.get("max_concurrency", 4)),
        "timeout_s": float(vertex.get("timeout_s", DEFAULT_TIMEOUT_S)),
        "sa_info": _load_service_account_info(
            vertex["secret_scope"], vertex["secret_key"],
        ),
    }
    return _vertex_settings


def _build_vertex_llm(settings: Dict[str, Any]):
    """
    Build (and per-process cache) the Vertex client from plain values. Safe on the
    driver or an executor: reads no config file and no secret.

    google-auth mints and refreshes the short-lived OAuth token from the
    service-account key, so a long tagging run cannot expire midway.
    """
    global _vertex_llm
    if _vertex_llm is not None:
        return _vertex_llm

    from google.oauth2 import service_account
    from langchain_google_genai import ChatGoogleGenerativeAI

    credentials = service_account.Credentials.from_service_account_info(
        settings["sa_info"],
        scopes=["https://www.googleapis.com/auth/cloud-platform"],
    )
    _vertex_llm = ChatGoogleGenerativeAI(
        model=settings["model"],
        vertexai=True,
        project=settings["project"],
        location=settings["location"],
        credentials=credentials,
        temperature=settings["temperature"],
        # Without it, a call that never answers holds its batch, and so the run, forever
        timeout=settings["timeout_s"],
    )
    return _vertex_llm


def _response_text(response: Any) -> Optional[str]:
    """
    One langchain reply -> the raw text _parse_response expects, or None.

    `.content` is not always a str: a multimodal or blocked reply can come back as a
    list of content-block dicts, which fails the UDF's Arrow conversion to string and
    takes the whole partition with it. Join the text parts instead.
    """
    if isinstance(response, BaseException):
        return None
    content = getattr(response, "content", None)
    if content is None or isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            block.get("text", "") if isinstance(block, dict) else str(block)
            for block in content
        ]
        joined = "".join(parts).strip()
        return joined or None
    return str(content)


def _vertex_responses_to_series(responses: Sequence[Any], index) -> pd.Series:
    """
    Map .batch() results onto a Series the pandas UDF can return.

    Three things this must get right; each silently corrupts a whole partition:
        INDEX   the return must carry the INPUT's index. A fresh 0-based Series makes
                pandas align on labels, and answers land on the wrong questions.
        DTYPE   pd.Series([]) is float64, which cannot convert to an Arrow string
                column. Empty partitions are normal after the per-batch filter.
        LENGTH  pad with None if .batch() returns fewer results than prompts.
    """
    texts = [_response_text(r) for r in responses]
    if len(texts) < len(index):
        logger.error(
            "Vertex returned %d responses for %d prompts — padding the "
            "shortfall with nulls", len(texts), len(index),
        )
        texts.extend([None] * (len(index) - len(texts)))
    return pd.Series(texts[: len(index)], index=index, dtype="object")


def make_vertex_invoke_udf(settings: Dict[str, Any]):
    """
    Pandas UDF: ai_prompt (string) -> raw model response text (string).

    Writes the `ai_query_raw` column that _parse_response reads (the name is
    historical; nothing here uses ai_query).

    return_exceptions=True so one bad row degrades to NULL — which the parser already
    treats as "no usable JSON" — instead of failing the whole batch.
    """
    max_concurrency = settings["max_concurrency"]

    @F.pandas_udf(StringType())
    def _invoke(prompts: pd.Series) -> pd.Series:
        nulls = pd.Series([None] * len(prompts), index=prompts.index, dtype="object")
        if prompts.empty:
            return nulls

        try:
            llm = _build_vertex_llm(settings)
        except Exception as error:
            logger.error(
                "Vertex client construction failed on executor (%s)", error,
            )
            return nulls

        try:
            responses = llm.batch(
                list(prompts),
                config={"max_concurrency": max_concurrency},
                return_exceptions=True,
            )
        except Exception as error:
            logger.error("Vertex batch invoke failed for a partition (%s)", error)
            return nulls

        failures = sum(1 for r in responses if isinstance(r, BaseException))
        if failures:
            # One line per partition, not per row: a rate-limited batch would
            # otherwise bury the executor log in identical warnings.
            logger.warning(
                "Vertex: %d/%d rows failed in this partition (first: %s)",
                failures, len(responses),
                next(r for r in responses if isinstance(r, BaseException)),
            )
        return _vertex_responses_to_series(responses, prompts.index)

    return _invoke


def validate_vertex(settings: Dict[str, Any]) -> None:
    """
    Driver-side pre-flight. One real round trip, so bad credentials, a wrong
    project/location or an unavailable model fail in a second rather than after a
    full source load and a wasted tagging pass.
    """
    logger.info("[Pre-flight] Validating Vertex model '%s'...", settings["model"])
    try:
        response = _build_vertex_llm(settings).invoke(
            "Respond with exactly one word: ready"
        )
    except Exception as error:
        raise RuntimeError(
            f"Vertex validation FAILED for model '{settings['model']}' "
            f"(project={settings['project']}, location={settings['location']}). "
            f"The pipeline will NOT run. Root cause: {error}"
        ) from error

    content = getattr(response, "content", None)
    if content is None or str(content).strip() == "":
        raise RuntimeError(
            f"Vertex model '{settings['model']}' returned a null/empty response "
            "on probe query."
        )

    logger.info("  Vertex model '%s' is reachable and responding.", settings["model"])


# =============================================================================
# QUESTION EXTRACTION
# =============================================================================

# The element type of utils.resolve_question_keys' _answer_meta_map values —
# ARRAY<STRUCT<position, answer_id, submission_tms>>, one entry per raw q_and_a
# answer position that resolved. Declared here (not in utils) because this is
# the one place that reads the struct's FIELDS directly (x["position"],
# x["answer_id"]) rather than just passing the map through; a name or order
# drift in resolve_question_keys' own F.struct(...) would surface here as a
# silently-NULL answer_id column, not an error, so the field order below is
# kept identical to utils.py's on purpose.
_ANSWER_META_ELEMENT_ARRAY_TYPE = ArrayType(StructType([
    StructField("position",       IntegerType(), True),
    StructField("answer_id",      StringType(),  True),
    StructField("submission_tms", StringType(),  True),
]))


def _resolve_question_ids(
    spark: SparkSession, source_df: DataFrame,
) -> Optional[DataFrame]:
    """
    Build the question-id and answer-id lookup for a run that was not handed one.

    Thin wrapper over utils.resolve_question_keys: supplies this module's table
    config and logs how much of the input resolved.

    Returns None when no questions table is configured or resolution failed.
    explode_questions reads that as "emit NULL question_id and NULL answer_id" —
    nothing is ever substituted for a missing id, least of all tag_id.
    """
    cfg = _ensure_table_config()
    questions_table = cfg.get("QUESTIONS_TABLE")
    if not questions_table:
        logger.warning(
            "No questions table configured (review_mining.tables."
            "QUESTIONS_TABLE in general.yml) — question_id and answer_id will "
            "be NULL on every row"
        )
        return None

    answers_table = cfg.get("ANSWERS_TABLE")
    if not answers_table:
        logger.warning(
            "No answers table configured (review_mining.tables.ANSWERS_TABLE "
            "in general.yml) — answer_id will be NULL on every row"
        )

    keys_df = resolve_question_keys(
        spark, source_df, questions_table=questions_table,
        answers_table=answers_table,
    )
    if keys_df is None:
        logger.warning(
            "Question-id resolution against %s failed — question_id will be "
            "NULL on every row", questions_table,
        )
        return None

    # Cached because it is read twice: once by the count below and once by
    # explode_questions' join. Without this the questions-table scan, the
    # window dedupe and the text join all run twice. Callers release it — see
    # run_faq_tagging_pipeline.
    keys_df = keys_df.cache()

    # Counted here rather than left to the caller: a text match that silently
    # stops matching produces a full, healthy-looking tag table whose
    # question_id column is entirely NULL, and this is the only place that
    # would show it. Cheap next to the tagging run that follows.
    try:
        resolved_items = keys_df.count()
        if resolved_items == 0:
            logger.warning(
                "Question-id resolution matched NOTHING in %s — every "
                "question_id will be NULL. Check the item_id/PRODUCT_ID and "
                "question-text join, and the site filter.", questions_table,
            )
        else:
            logger.info(
                "Question ids resolved for %d item(s) from %s",
                resolved_items, questions_table,
            )
    except Exception as e:
        logger.warning("Could not size question-id resolution (%s)", e)

    return keys_df


def explode_questions(
    source_df: DataFrame,
    max_answers: int = DEFAULT_MAX_ANSWERS_PER_QUESTION,
    question_keys_df: Optional[DataFrame] = None,
) -> DataFrame:
    """
    Explode q_and_a into one row per question with its (capped) answers.

    Returns: item_id, tag_id, question_id, question_submission_tms, question, answers,
    answer_id (same length as answers; NULL where unresolved). Position is taken
    before the empty-question filter.
    """
    exploded = (
        source_df
        .select("item_id", "q_and_a")
        .filter(F.col("q_and_a").isNotNull() & (F.size(F.col("q_and_a")) > 0))
        .select(
            F.col("item_id").cast(StringType()).alias("item_id"),
            F.posexplode("q_and_a").alias("position", "qa_pair"),
        )
        .withColumn(
            "tag_id",
            question_id_expr(F.col("item_id"), F.col("position")),
        )
    )

    if question_keys_df is not None:
        # One join on item_id, then a map lookup per row — the same shape
        # review_mining uses to attach FAQ tags. The map is keyed by tag_id,
        # which is the only key a pandas UDF can rebuild for itself.
        #
        # element_at over a MAP returns NULL for a missing key (it does not
        # raise the way an out-of-range ARRAY index does under ANSI), so an
        # unresolved question yields question_id = NULL rather than failing the
        # job. That NULL is the intended output — see the docstring.
        #
        # ONE lookup into _q_meta, then both fields off it. Calling element_at
        # twice would re-do the map probe per row for no gain, and it is what
        # keeps question_id and question_submission_tms NULL on exactly the same
        # rows — they are two fields of one resolved source row, not two
        # independent resolutions.
        #
        # _answer_meta_map is OPTIONAL on question_keys_df: a caller that only
        # asked resolve_question_keys for questions (answers_table=None) hands
        # back a frame without it. .columns is metadata only — no job runs —
        # so this costs nothing when the column is present, which today is
        # always (both entry points request it), and degrades cleanly the day
        # a caller opts back out.
        has_answer_map = "_answer_meta_map" in question_keys_df.columns
        select_cols = ["item_id", "_question_meta_map"]
        if has_answer_map:
            select_cols.append("_answer_meta_map")

        exploded = (
            exploded
            .join(
                question_keys_df.select(*select_cols),
                on="item_id",
                how="left",
            )
            .withColumn(
                "_q_meta",
                F.element_at(F.col("_question_meta_map"), F.col("tag_id")),
            )
            .withColumn("question_id", F.col("_q_meta")["question_id"])
            # The map carries submission_tms as a STRING: resolve_question_keys
            # casts it so review_mining's pandas UDF can datetime.fromisoformat
            # it. Cast to a real timestamp here rather than widening the map's
            # struct — that struct shape is the contract utils.resolve_question_keys
            # shares with review_mining, so an extra field would have to be
            # mirrored there too. This keeps the shared contract untouched.
            .withColumn(
                "question_submission_tms",
                F.col("_q_meta")["submission_tms"].cast(TimestampType()),
            )
        )
        exploded = (
            exploded.withColumn(
                "_a_meta", F.element_at(F.col("_answer_meta_map"), F.col("tag_id")),
            )
            if has_answer_map
            else exploded.withColumn(
                "_a_meta", F.lit(None).cast(_ANSWER_META_ELEMENT_ARRAY_TYPE),
            )
        )
        exploded = exploded.drop("_q_meta", "_question_meta_map", "_answer_meta_map")
    else:
        # Nothing to resolve against, so nothing resolves. Typed NULLs, never
        # tag_id — the two are different facts about the row.
        exploded = (
            exploded
            .withColumn("question_id", F.lit(None).cast(StringType()))
            .withColumn(
                "question_submission_tms", F.lit(None).cast(TimestampType()),
            )
            .withColumn(
                "_a_meta", F.lit(None).cast(_ANSWER_META_ELEMENT_ARRAY_TYPE),
            )
        )

    exploded = exploded.withColumn(
        "answers",
        F.slice(
            F.coalesce(
                F.col("qa_pair.a"),
                F.array().cast(ArrayType(StringType())),
            ),
            1,
            max_answers,
        ),
    )

    # answer_id: one lookup per row, built AFTER `answers` exists because its
    # length is the loop bound below. _a_meta's positions are raw-array indices
    # (see the docstring's ALIGNMENT note) and `answers` is an unreordered
    # prefix of that same raw array, so index i needs no join — only a map
    # keyed by position.
    #
    # coalesced to [] first so a genuinely-NULL _a_meta (nothing resolved for
    # this row at all) and an empty-but-present one behave identically here;
    # the size guard below is what keeps `answer_id` itself from ever being
    # NULL, matching how `answers` is coalesced rather than left NULL.
    _a_id_map = F.map_from_entries(
        F.transform(
            F.coalesce(F.col("_a_meta"), F.array().cast(_ANSWER_META_ELEMENT_ARRAY_TYPE)),
            lambda x: F.struct(x["position"].cast("int"), x["answer_id"]),
        )
    )
    # F.sequence(0, -1) does NOT return [] — with no explicit step it infers
    # -1 whenever start > stop, so a 0-length `answers` would yield [0, -1]
    # instead of an empty sequence. Guarded explicitly rather than relying on
    # that inference to happen to produce the right thing.
    exploded = exploded.withColumn(
        "answer_id",
        F.when(
            F.size(F.col("answers")) > 0,
            F.transform(
                F.sequence(F.lit(0), F.size(F.col("answers")) - F.lit(1)),
                lambda i: F.element_at(_a_id_map, i),
            ),
        ).otherwise(F.array().cast(ArrayType(StringType()))),
    )

    return (
        exploded
        .select(
            "item_id",
            "tag_id",
            "question_id",
            "question_submission_tms",
            F.col("qa_pair.q").alias("question"),
            "answers",
            "answer_id",
        )
        .filter(F.col("question").isNotNull() & (F.trim(F.col("question")) != ""))
        # tag_id, NOT question_id. question_id is nullable, and dropDuplicates
        # treats all NULLs as EQUAL — keying on it would collapse every
        # unresolved question in the input down to a single row.
        .dropDuplicates(["tag_id"])
    )


# =============================================================================
# TAGGING
# =============================================================================

def _norm_qa_key(question_col: Column, answers_col: Column) -> Column:
    """
    Dedupe key for one prompt: a hash of the normalized question AND its answers.

    Covers the answers because they are part of the prompt — two items asking the
    same question with different answers need separate calls.

    Hashed rather than concatenated because answers make the raw key arbitrarily
    large. The \x01 separator stops ("ab", ["c"]) and ("a", ["bc"]) colliding.
    """
    return F.sha2(
        F.concat_ws(
            "\x01",
            F.lower(F.trim(F.coalesce(question_col, F.lit("")))),
            F.coalesce(F.array_join(answers_col, "\x02"), F.lit("")),
        ),
        256,
    )


def tag_questions(
    spark: SparkSession,
    questions_df: DataFrame,
    batch_size: int = DEFAULT_BATCH_SIZE,
    dedupe_by_text: bool = DEFAULT_DEDUPE_BY_TEXT,
    max_answer_chars: int = DEFAULT_MAX_ANSWER_CHARS,
    keyword_min_words: int = MIN_KEYWORD_WORDS,
    keyword_max_words: int = MAX_KEYWORD_WORDS,
) -> Optional[DataFrame]:
    """
    Run the Vertex tagging UDF over questions_df in batches and parse the results.

    Args:
        spark:            Active SparkSession.
        questions_df:     item_id, question_id, question, answers.
        batch_size:       Questions per model pass.
        dedupe_by_text:   Tag DISTINCT question+answers content, fan results back out.
        max_answer_chars: Per-answer truncation applied inside the prompt.
        keyword_min_words, keyword_max_words: Keyword word range (prompt and parse clamp).

    Returns:
        Tagged DataFrame, or None if every batch failed.
    """
    questions_df = questions_df.cache()
    total_rows = questions_df.count()
    if total_rows == 0:
        logger.info("No questions to tag.")
        questions_df.unpersist()
        return None

    # Choose what actually goes to the model.
    if dedupe_by_text:
        # One representative row per distinct question+answers content.
        prompts_df = (
            questions_df
            .withColumn("_norm_qa", _norm_qa_key(F.col("question"), F.col("answers")))
            .groupBy("_norm_qa")
            .agg(
                # The representative's own ids are discarded when the results
                # fan back out on _norm_qa below; tag_id is kept only because
                # batch assignment needs a non-null key.
                F.min("tag_id").alias("tag_id"),
                F.min("item_id").alias("item_id"),
                F.first("question").alias("question"),
                F.first("answers").alias("answers"),
            )
            .select("item_id", "tag_id", "question", "answers")
        )
        prompts_df = prompts_df.cache()
        prompt_rows = prompts_df.count()
        logger.info(
            "Tagging %d distinct question+answer sets covering %d (item, question) pairs",
            prompt_rows, total_rows,
        )
    else:
        prompts_df = questions_df
        prompt_rows = total_rows
        logger.info("Tagging %d questions (no dedupe)", prompt_rows)

    # Deterministic, driver-free batching. crc32 gives balanced buckets without
    # a Window.orderBy(), which (having no partitionBy) would funnel every row
    # through one partition. tag_id is a structured "{item_id}_{position}"
    # string rather than a uniform hash, but crc32's own diffusion is enough to
    # spread even near-identical strings like "108616_1" / "108616_2" across
    # buckets reasonably evenly.
    #
    # KEYED ON tag_id, NOT question_id. question_id is nullable, and
    # crc32(NULL) is NULL -> pmod(NULL, n) is NULL -> `_batch == batch_idx` is
    # never true. Every unresolved question would be dropped from every batch,
    # never tagged, and never counted as failed.
    num_batches = max(1, (prompt_rows + batch_size - 1) // batch_size)
    numbered_df = prompts_df.withColumn(
        "_batch", F.pmod(F.crc32(F.col("tag_id")), F.lit(num_batches))
    ).cache()
    numbered_df.count()  # materialise so batch filters are cheap

    view_name = f"_faq_tagging_batch_{uuid.uuid4().hex[:8]}"
    # Settings resolved ONCE here, not per batch, so a mid-run config change
    # cannot alter the model halfway through a pipeline.
    vertex_cfg = vertex_settings()
    model_name = vertex_cfg["model"]
    prompt_sql = build_faq_tagging_prompt_sql(
        view_name=view_name, max_answer_chars=max_answer_chars,
        keyword_min_words=keyword_min_words, keyword_max_words=keyword_max_words,
    )
    vertex_response_col = make_vertex_invoke_udf(vertex_cfg)(F.col("ai_prompt"))
    backend_label = f"Vertex model '{model_name}'"
    logger.info("Tagging backend: %s", backend_label)

    # Built once here, on the driver, so the bound rides to the executors inside
    # the closure. The prompt asks the model for this range and this clamp
    # enforces it on the reply — both from the same value, so they cannot drift.
    parse_udf = make_parse_response_udf(keyword_max_words)

    tagged_batches = []
    failed = 0

    logger.info("Processing %d batch(es) of up to %d questions...", num_batches, batch_size)

    for batch_idx in range(num_batches):
        batch_df = (
            numbered_df
            .filter(F.col("_batch") == F.lit(batch_idx))
            # question_id is NOT sent to the model — it is not needed to tag
            # anything, and the prompt must never carry a database identifier.
            # tag_id rides along only so the reply can be matched back to its row.
            .select("tag_id", "item_id", "question", "answers")
        )

        batch_count = batch_df.count()
        if batch_count == 0:
            continue

        batch_df.createOrReplaceTempView(view_name)

        try:
            # spark.sql() is LAZY — the model is not called yet. The Vertex UDF
            # writes `ai_query_raw` (name kept for historical reasons).
            tagged_raw = spark.sql(prompt_sql).withColumn(
                "ai_query_raw", vertex_response_col,
            )

            tagged = (
                tagged_raw
                .withColumn("llm_raw_str", F.col("ai_query_raw").cast(StringType()))
                # The parser needs the question AND answers too — it enforces
                # that every keyword word actually came from its own source
                # text, rebuilds keywords the model botched, and forces one
                # answers_meta entry per input answer regardless of what came
                # back.
                .withColumn(
                    "_parsed",
                    parse_udf(
                        F.col("llm_raw_str"), F.col("question"), F.col("answers"),
                    ),
                )
                .select(
                    "item_id",
                    "tag_id",
                    "question",
                    "answers",
                    F.col("_parsed.question_tags").alias("question_tags"),
                    F.col("_parsed.question_keyword").alias("question_keyword"),
                    F.col("_parsed.conflict_flag").alias("conflict_flag"),
                    F.col("_parsed.answers_meta").alias("answers_meta"),
                )
            )

            # Force execution NOW so model / permission errors surface inside
            # this try/except rather than later during the write.
            tagged = tagged.cache()
            tagged_count = tagged.count()

            if tagged_count == 0:
                failed += 1
                logger.error(
                    "Batch %d/%d FAILED: produced 0 rows after %s",
                    batch_idx + 1, num_batches, backend_label,
                )
                tagged.unpersist()
                continue

            non_null_count = tagged.filter(F.col("question_tags").isNotNull()).count()

            if non_null_count == 0:
                failed += 1
                logger.error(
                    "Batch %d/%d FAILED: model returned %d rows but ALL parsed to "
                    "null tags. Possible causes: empty model response, model not "
                    "ready, or a credential/quota problem on %s.",
                    batch_idx + 1, num_batches, tagged_count, backend_label,
                )
                tagged.unpersist()
                continue

            null_count = tagged_count - non_null_count
            if null_count > 0:
                logger.warning(
                    "Batch %d/%d: %d/%d rows had null tags (no parseable JSON)",
                    batch_idx + 1, num_batches, null_count, tagged_count,
                )

            tagged_batches.append(tagged)
            logger.info(
                "Batch %d/%d done — %d/%d tagged",
                batch_idx + 1, num_batches, non_null_count, tagged_count,
            )

        except Exception as e:
            failed += 1
            logger.error("Batch %d/%d FAILED: %s", batch_idx + 1, num_batches, e)
            continue

    logger.info("Batches: %d succeeded, %d failed", num_batches - failed, failed)

    try:
        spark.catalog.dropTempView(view_name)
    except Exception:
        pass

    if not tagged_batches:
        logger.error("No batches succeeded — nothing to write.")
        numbered_df.unpersist()
        if dedupe_by_text:
            prompts_df.unpersist()
        questions_df.unpersist()
        return None

    tags_df = reduce(DataFrame.unionByName, tagged_batches)

    if dedupe_by_text:
        # Fan the per-content results back out to every matching row. Keyed on
        # the same question+answers hash used to pick representatives, so
        # answers_meta lands only on rows whose answer array it actually
        # describes — positional alignment would be meaningless otherwise.
        text_tags = (
            tags_df
            .select(
                _norm_qa_key(F.col("question"), F.col("answers")).alias("_norm_qa"),
                F.col("question_tags"),
                F.col("question_keyword"),
                F.col("conflict_flag"),
                F.col("answers_meta"),
            )
            .dropDuplicates(["_norm_qa"])
        )
        # INNER, not LEFT. A batch that threw is absent from text_tags entirely;
        # a LEFT join would stamp NULL tags on its questions and write them, and
        # _already_tagged_ids would then treat them as permanently done. INNER
        # drops them so they retry next run — while still keeping NULL-tag rows
        # from batches that succeeded but returned unparseable JSON, since those
        # questions ARE present in text_tags.
        result_df = (
            questions_df
            .withColumn("_norm_qa", _norm_qa_key(F.col("question"), F.col("answers")))
            .join(text_tags, on="_norm_qa", how="inner")
            .drop("_norm_qa")
        )
    else:
        # tags_df comes back from the prompt projection, which deliberately
        # never carried question_id — the model is not shown identifiers. Rejoin
        # it from questions_df on tag_id, which every row does have.
        result_df = tags_df.join(
            questions_df.select(
                "tag_id", "question_id", "question_submission_tms", "answer_id",
            ),
            on="tag_id",
            how="left",
        )

    now_ts = F.lit(datetime.now(timezone.utc))
    result_df = (
        result_df
        .select(
            "item_id", "tag_id", "question_id", "question",
            "question_tags", "question_keyword", "question_submission_tms",
            "conflict_flag", "answers_meta", "answer_id",
        )
        .withColumn("model_endpoint", F.lit(model_name))
        .withColumn("created_at_ts", now_ts)
        .withColumn("last_updated_ts", now_ts)
    )

    # Materialise BEFORE unpersisting the upstream caches. The caller runs at
    # least two actions on this DataFrame (validate/count, then the write), and
    # the model-call lineage is still in the plan — leaving it lazy over evicted
    # caches risks re-issuing paid model calls.
    result_df = result_df.cache()
    result_df.count()

    numbered_df.unpersist()
    if dedupe_by_text:
        prompts_df.unpersist()
    questions_df.unpersist()
    for batch in tagged_batches:
        batch.unpersist()

    return result_df


# =============================================================================
# WRITE
# =============================================================================

def _sever_llm_lineage(
    df: Optional[DataFrame],
    spark: Optional[SparkSession] = None,
    written_table: Optional[str] = None,
) -> Optional[DataFrame]:
    """
    Cut the model calls out of `df`'s lineage so Spark cannot re-issue billed calls:
    read back from `written_table` when it was just written, else localCheckpoint.
    """
    if df is None:
        return None
    if spark is not None and written_table:
        run_ts = df.agg(F.max("last_updated_ts")).first()[0]
        columns = df.columns
        schema = df.schema
        df.unpersist()
        # The table accumulates across runs; this run's rows share one last_updated_ts.
        return (
            read_faq_tags(spark, written_table, schema)
            .where(F.col("last_updated_ts") == F.lit(run_ts))
            .select(*columns)
        )
    try:
        return df.localCheckpoint(eager=True)
    except Exception as e:
        # Never fail the run over this. A cached-but-not-checkpointed frame is
        # still correct; it just carries the re-billing risk described above.
        logger.warning(
            "Could not checkpoint FAQ tags (%s) — falling back to cache. If the "
            "executors are under memory pressure this run may re-issue Vertex "
            "model calls.", e,
        )
        return df


# Columns TAG_TABLE_SCHEMA has gained since this table was first created, each
# with the column it must sit AFTER. Adding the next one is a line here, not
# another helper. Order matters: entries are applied top to bottom, so a column
# positioned after another new column must come second.
def _write_tags(df: DataFrame, spark: SparkSession, output_table: str) -> None:
    """Persist FAQ payloads in the shared unit table without clearing issue payloads."""
    missing = [c for c in TAG_TABLE_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"FAQ tag DataFrame is missing expected column(s) {missing}. "
            f"Got {df.columns}. A column was probably dropped by a .select() in "
            f"tag_questions — check the batch projection and the dedupe fan-out."
        )

    write_unit_tags(spark, faq_unit_rows(df), output_table, "faq_json")


# =============================================================================
# PIPELINE
# =============================================================================

def run_faq_tagging_pipeline(
    spark: SparkSession,
    source_table: str,
    output_table: str,
    batch_size: int = DEFAULT_BATCH_SIZE,
    dedupe_by_text: bool = DEFAULT_DEDUPE_BY_TEXT,
    full_refresh: bool = False,
    max_questions: int = -1,
    retry_failed: bool = False,
    max_answers: int = DEFAULT_MAX_ANSWERS_PER_QUESTION,
    max_answer_chars: int = DEFAULT_MAX_ANSWER_CHARS,
    keyword_min_words: int = MIN_KEYWORD_WORDS,
    keyword_max_words: int = MAX_KEYWORD_WORDS,
    tag_table: bool = DEFAULT_TAG_TABLE,
) -> Optional[DataFrame]:
    """
    Read the catalog, tag every untagged question, write the tag table.

    Args:
        spark:             Active SparkSession.
        source_table:      Fully qualified product catalog table.
        output_table:      Fully qualified FAQ tag table.
        batch_size:        Questions per model pass.
        dedupe_by_text:    Tag DISTINCT question text, fan out to item pairs.
        full_refresh:      True = re-tag everything; False = only new questions.
        max_questions:     Cap on questions tagged this run (-1 = no cap).
        retry_failed:      Also re-tag rows whose previous run produced no tags.
        max_answers:       Cap on answers per question sent to the model.
        max_answer_chars:  Per-answer truncation inside the prompt.
        tag_table:         Persist to output_table (returned DataFrame is the same either way).

    Returns:
        The tagged DataFrame, or None when there was nothing to do.
    """
    cfg = _ensure_table_config()
    # Cheap — the model name is in the config dict; the secret fetch that
    # vertex_settings() does is deferred until there is actually work to tag.
    model_name = cfg["VERTEX"]["model"]

    logger.info("=" * 70)
    logger.info("FAQ TAGGING PIPELINE")
    logger.info("  Source       : %s", source_table)
    logger.info("  Output       : %s", output_table)
    logger.info("  Model        : Vertex %s (temp=%s)", model_name, cfg["TEMPERATURE"])
    logger.info("  Batch size   : %s", batch_size)
    logger.info("  Full refresh : %s", full_refresh)
    logger.info("=" * 70)

    source_df = spark.table(source_table)

    # Resolve question_id for ourselves. review_mining resolves once and passes
    # the frame into mine_faq_tags; nothing passes anything to this entry point,
    # so before this it tagged every question with question_id = NULL.
    question_keys_df = _resolve_question_ids(spark, source_df)

    questions_df = explode_questions(
        source_df, max_answers=max_answers, question_keys_df=question_keys_df,
    )

    # Incremental filter on tag_id; edited questions at a tagged position need a full_refresh.
    if not full_refresh:
        already_tagged = _already_tagged_ids(spark, output_table, retry_failed)
        if already_tagged is not None:
            questions_df = questions_df.join(
                already_tagged, on="tag_id", how="left_anti"
            )

    if max_questions > 0:
        questions_df = questions_df.limit(max_questions)
        logger.info("Capped at %d questions for this run", max_questions)

    questions_df = questions_df.cache()
    pending = questions_df.count()
    logger.info("Questions to tag: %d", pending)

    # questions_df is cached and counted, so the resolved ids are baked into it
    # and the lookup is dead weight from here on.
    if question_keys_df is not None:
        question_keys_df.unpersist()

    if pending == 0:
        logger.info("Nothing to tag — pipeline finished.")
        questions_df.unpersist()
        return None

    # One real round trip to Vertex before the tagging pass, so bad credentials
    # or an unavailable model fail fast rather than after a full source load.
    # vertex_settings() fetches the service-account secret here (first use).
    validate_vertex(vertex_settings())

    tagged_df = tag_questions(
        spark,
        questions_df,
        batch_size=batch_size,
        dedupe_by_text=dedupe_by_text,
        max_answer_chars=max_answer_chars,
        keyword_min_words=keyword_min_words,
        keyword_max_words=keyword_max_words,
    )

    questions_df.unpersist()

    if tagged_df is None:
        logger.error("Tagging produced no results — nothing written.")
        return None

    if tag_table:
        _write_tags(tagged_df, spark, output_table)
    else:
        logger.info("tag_table=False — skipping the write to %s", output_table)

    logger.info("=" * 70)
    logger.info("FAQ TAGGING COMPLETE — %d questions processed", pending)
    logger.info("=" * 70)
    return _sever_llm_lineage(
        tagged_df, spark, output_table if tag_table else None,
    )


def _already_tagged_ids(
    spark: SparkSession,
    output_table: str,
    retry_failed: bool = False,
) -> Optional[DataFrame]:
    """
    tag_ids whose tags are complete (question_keyword, answers_meta and answer_scores
    present), or None when the tag table does not exist yet. Rows with no tags count
    as tagged unless retry_failed=True.
    """
    try:
        if not spark.catalog.tableExists(output_table):
            logger.info("Tag table '%s' not found — first run, tagging all", output_table)
            return None
    except Exception:
        return None

    tbl = read_faq_tags(spark, output_table, TAG_TABLE_SCHEMA)
    df = tbl

    # Guard the references: a tag table predating any of these columns would
    # otherwise raise AnalysisException instead of simply re-tagging.
    # conflict_flag is existence-checked but NOT null-filtered — see docstring.
    for col_name in ("question_keyword", "answers_meta", "conflict_flag"):
        if col_name not in tbl.columns:
            logger.info(
                "Tag table has no %s column yet — all rows will be re-tagged "
                "once to populate it", col_name,
            )
            return None

    # IS NOT NULL, not size() > 0: a question with no answers legitimately
    # has an empty answers_meta and must not re-tag on every single run.
    for col_name in ("question_keyword", "answers_meta"):
        df = df.filter(F.col(col_name).isNotNull())

    # answer_score and time_bound live INSIDE answers_meta, so `in tbl.columns`
    # cannot see them. A table written before either field existed has a
    # perfectly non-NULL answers_meta, so the loop above passes and nothing
    # would ever re-tag — the field would stay NULL forever. Check the nested
    # schema directly.
    meta_type = tbl.schema["answers_meta"].dataType
    meta_fields = (
        set(meta_type.elementType.fieldNames())
        if isinstance(meta_type, ArrayType)
        and isinstance(meta_type.elementType, StructType)
        else set()
    )
    for nested in ("answer_score", "time_bound"):
        if nested not in meta_fields:
            logger.info(
                "Tag table's answers_meta has no %s field yet — all rows "
                "will be re-tagged once to populate it", nested,
            )
            return None

    # Same empty-array escape hatch as above: a question with no answers has no
    # score to populate, so exists() is false for it forever. Without the
    # size()==0 branch those questions would be re-tagged, and re-billed, every
    # run.
    df = df.filter(
        (F.size("answers_meta") == 0)
        | F.exists("answers_meta", lambda x: x["answer_score"].isNotNull())
    )

    if retry_failed:
        df = df.filter(F.col("question_tags").isNotNull())
    return df.select("tag_id").distinct()


def generate_faq_tags(
    spark: Optional[SparkSession] = None,
    config: Optional[dict] = None,
) -> Optional[DataFrame]:
    """
    Config-driven entry point: resolve general.yml, then run the pipeline.

    The ONLY place config becomes parameters. Both the standalone task and
    review_mining's inline top-up go through it, so they cannot drift onto different
    endpoints and write two tag vocabularies into one table.

    Args:
        spark:  Active SparkSession (created if omitted).
        config: Optional overrides applied on top of general.yml, using the same keys
                as _ensure_table_config (SOURCE_TABLE, OUTPUT_TABLE, ...).
    """
    spark = spark or get_spark_session()
    cfg = dict(_ensure_table_config())
    if config:
        cfg.update(config)

    if not cfg.get("SOURCE_TABLE") or not cfg.get("OUTPUT_TABLE"):
        raise ValueError(
            "faq_tagging.tables.source_table and .output_table must be set in "
            "config/general.yml"
        )

    return run_faq_tagging_pipeline(
        spark=spark,
        source_table=cfg["SOURCE_TABLE"],
        output_table=cfg["OUTPUT_TABLE"],
        batch_size=cfg["BATCH_SIZE"],
        dedupe_by_text=cfg["DEDUPE_BY_TEXT"],
        full_refresh=cfg["FULL_REFRESH"],
        max_questions=cfg["MAX_QUESTIONS_PER_RUN"],
        max_answers=cfg["MAX_ANSWERS_PER_QUESTION"],
        max_answer_chars=cfg["MAX_ANSWER_CHARS"],
        keyword_min_words=cfg["KEYWORD_MIN_WORDS"],
        keyword_max_words=cfg["KEYWORD_MAX_WORDS"],
        tag_table=cfg.get("TAG_TABLE", DEFAULT_TAG_TABLE),
    )


def mine_faq_tags(
    spark: SparkSession,
    source_df: Optional[DataFrame] = None,
    source_table: Optional[str] = None,
    tag_table: Optional[bool] = None,
    output_table: Optional[str] = None,
    batch_size: Optional[int] = None,
    dedupe_by_text: Optional[bool] = None,
    max_questions: Optional[int] = None,
    raise_on_error: bool = False,
    question_keys_df: Optional[DataFrame] = None,
    resolve_question_ids: bool = True,
) -> Optional[DataFrame]:
    """
    Tag the questions in `source_df` and return them (entry point for review_mining).
    Tags exactly what it is handed, so the caller must pre-narrow the input. Never
    raises unless raise_on_error=True.

    Args:
        spark:            Active SparkSession.
        source_df:        Pre-narrowed catalog rows. Preferred over source_table.
        source_table:     Fallback when no source_df is given.
        tag_table:        Persist the result. None -> general.yml -> DEFAULT_TAG_TABLE.
        max_questions:    Cap on questions tagged this run (-1 = no cap).
        raise_on_error:   Re-raise instead of degrading.
        question_keys_df: utils.resolve_question_keys' output, for question_id.
        resolve_question_ids: Resolve question_id here when no question_keys_df is given.

    Returns:
        Tagged DataFrame cut from the model-call lineage, or None when there was
        nothing to tag or on a handled failure.
    """
    try:
        # Resolve every argument to a concrete value up front: explicit
        # parameter wins, then general.yml, then the module default.
        cfg = _ensure_table_config()
        out_table: str = output_table or cfg.get("OUTPUT_TABLE") or ""
        batch: int = int(batch_size or cfg.get("BATCH_SIZE") or DEFAULT_BATCH_SIZE)
        dedupe: bool = bool(
            cfg.get("DEDUPE_BY_TEXT", DEFAULT_DEDUPE_BY_TEXT)
            if dedupe_by_text is None else dedupe_by_text
        )
        max_q: int = int(
            cfg.get("MAX_NEW_QUESTIONS_PER_TOPUP", -1)
            if max_questions is None else max_questions
        )
        max_ans: int = int(
            cfg.get("MAX_ANSWERS_PER_QUESTION", DEFAULT_MAX_ANSWERS_PER_QUESTION)
        )
        max_ans_chars: int = int(
            cfg.get("MAX_ANSWER_CHARS", DEFAULT_MAX_ANSWER_CHARS)
        )
        persist: bool = bool(
            cfg.get("TAG_TABLE", DEFAULT_TAG_TABLE) if tag_table is None else tag_table
        )

        # Only the WRITE needs a table name. With tag_table=False there is
        # nothing to write, so a missing output_table is not a problem — the
        # DataFrame is still produced and returned.
        if persist and not out_table:
            logger.warning(
                "tag_table is on but no output table is configured — tagging "
                "will run and return data, but nothing will be persisted"
            )
            persist = False

        if source_df is None:
            src_table: str = source_table or cfg.get("SOURCE_TABLE") or ""
            if not src_table:
                logger.warning("No FAQ source or source table given — nothing to tag")
                return None
            source_df = spark.table(src_table)

        # Tracked rather than inferred from the flag: a caller may set the flag
        # AND pass a frame, and unpersisting review_mining's frame out from
        # under faq_json would be a genuinely confusing bug to chase.
        keys_are_ours = False
        if question_keys_df is None and resolve_question_ids:
            question_keys_df = _resolve_question_ids(spark, source_df)
            keys_are_ours = question_keys_df is not None

        # No anti-join against previously tagged rows: the caller's incremental
        # filter is what bounds this. See the docstring.
        questions_df = explode_questions(
            source_df, max_answers=max_ans, question_keys_df=question_keys_df,
        )

        questions_df = questions_df.cache()
        pending = questions_df.count()

        # Only release what we resolved ourselves — a caller-supplied frame is
        # review_mining's, which shares it with faq_json and unpersists it
        # itself at the end of its run.
        if keys_are_ours:
            question_keys_df.unpersist()

        # Order matters: check for work BEFORE probing Vertex. Otherwise every
        # steady-state review_mining run pays a model round-trip, and an
        # unreachable model fails the job even when there is nothing to tag.
        if pending == 0:
            logger.info("No FAQ questions in this batch — nothing to tag")
            questions_df.unpersist()
            return None

        if max_q > 0 and pending > max_q:
            logger.warning(
                "%d questions to tag; capping this run at %d", pending, max_q,
            )
            questions_df = questions_df.limit(max_q)
            pending = max_q

        logger.info(
            "Tagging %d FAQ questions (tag_table=%s)...", pending, persist,
        )
        # Same Vertex pre-flight as run_faq_tagging_pipeline, but inside
        # mine_faq_tags' broad try/except — a misconfigured Vertex path degrades
        # review_mining to "continuing without tags" rather than crashing it.
        validate_vertex(vertex_settings())

        tagged_df = tag_questions(
            spark,
            questions_df,
            batch_size=batch,
            dedupe_by_text=dedupe,
            max_answer_chars=max_ans_chars,
            keyword_min_words=cfg["KEYWORD_MIN_WORDS"],
            keyword_max_words=cfg["KEYWORD_MAX_WORDS"],
        )
        questions_df.unpersist()

        if tagged_df is None:
            logger.warning("FAQ tagging produced no results")
            return None

        if persist:
            _write_tags(tagged_df, spark, out_table)
        else:
            logger.info("tag_table=False — returning tags without persisting")

        # AFTER the write, so the write and the returned frame share one model pass.
        return _sever_llm_lineage(tagged_df, spark, out_table if persist else None)

    except Exception as e:
        if raise_on_error:
            raise
        logger.warning("FAQ tagging failed (%s) — continuing without tags", e)
        return None


# =============================================================================
# STANDALONE EXECUTION
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    spark = get_spark_session()
    # os.environ.setdefault("sf_env", "dev")
    generate_faq_tags(spark)
