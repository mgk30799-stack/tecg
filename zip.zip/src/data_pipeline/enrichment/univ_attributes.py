"""
Data Enrichment Pipeline - Style Extraction

This module extracts style, pattern, and aesthetic information for all supported product categories.
It uses web_supercategory_nm for pattern gating across 19 product supercategories
(see PATTERN_SUPERCATEGORIES list for the full set).
It maps specific EAV attributes to standardized style fields.

Pipeline Steps:
1. Load product data (filtered for target categories)
2. Explode and filter specifications based on category-specific mappings
3. Extract and structure style data
4. Save to Unity Catalog

Usage:
    from src.data_pipeline.enrichment.enrichment_pipeline_style import run_style_pipeline
    
    run_style_pipeline(
        spark,
        source_table="mld01_ml_de.product.product_discovery_data",
        output_table="product_style_data"
    )
"""

import sys
import os

# Windows compatibility fix
if sys.platform == 'win32':
    import socketserver
    if not hasattr(socketserver, 'UnixStreamServer'):
        class UnixStreamServer:
            def __init__(self, *args, **kwargs):
                raise NotImplementedError("UnixStreamServer not available on Windows")
        socketserver.UnixStreamServer = UnixStreamServer
        socketserver.UnixDatagramServer = UnixStreamServer

# Add project root to sys.path for absolute imports
try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    # Fallback for Databricks notebooks/jobs where __file__ is missing
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from databricks.connect import DatabricksSession
from pyspark.sql import Column, DataFrame
import pyspark.sql.functions as F
from pyspark.sql.functions import (
    col, explode, collect_set, collect_list, to_json, lower, trim, when, lit, struct,
    first
)
from pyspark.sql.types import StringType, ArrayType, StructField, IntegerType, StructType
from utils import save_data, get_spark_session, read_config, read_all_products

# Constants
# Pattern extraction gating uses web_supercategory_nm (not target_category)
# Excluded: Ink & Toner, Printers & Scanners — no pattern attributes exist
PATTERN_SUPERCATEGORIES = [
    "Furniture",
    "Bags, Backpacks & Luggage",
    "Coffee, Water & Snacks",
    "Restaurant & Foodservice Supplies",
    "Kitchen Tools & Appliances",
    "Arts & Crafts",
    "Paper",
    "Office Supplies",
    "Phones, Cameras & Electronics",
    "Tablets & iPads",
    "Party Supplies",
    "Facilities",
    "Education",
    "Safety Supplies",
    "Retail Store Supplies",
    "Healthcare Supplies",
    "Office Decor, Homewares & Appliances",
    "Computers & Accessories"
]

PATTERN_ATTRS = [
    "pattern",
    "luggage_pattern",
    "travel_accessory_pattern",
    "backpack_pattern",
    "tote___handbag_pattern",
    "laptop_bag_pattern",
    "wrapping_supplies_pattern_or_style",
    "design_and_pattern",
    "dinnerware_pattern",
    "flatware_handle_pattern",
    "box___bag_pattern",
    "water_bottle__tumbler___mug_pattern",
    "lunch_bag___box_pattern",
    "floor_mat_pattern",
    "mixing_bowl_pattern",
    "shower_curtain_pattern",
    "painting_style",
    "stationery_pattern",
    "style",
    "rug_primary_pattern",
    "design_elements"
]

MATERIAL_ATTRS = [
    "material", "base_material", "seat_material", "furnishing_material", 
    "office_chair_back_material", "back_material", "material_of_item", 
    "fill_materials", "item_material", "arm_material", "chair_back_material", 
    "patio_chair_woven_material", "mattress_cover_material", "table_surface_material", 
    "upholstery_material", "leg_or_base_material", "cushion_material", 
    "frame_materials", "panel_material", 
    # "shell_type", 
    "luggage_material", 
    "sport___duffel_bag_material", "briefcase_material", "travel_accessory_material", 
    "backpack_material", "tote___handbag_material", "laptop_bag_material", 
    "wrapping_supplies_material", "disposable_cutlery_material", "balloon_material", 
    "gift_box_and_bag_material", "restaurant_appliance_material", 
    "pot_or_pan_base_material", "material_finish", "carafe_base_material", 
    "product_material", "container_material", "placemat___tablecloth_material", 
    "appliance_material", "kitchen_supply_material", "food_wrap_material", 
    "lining_material", "cooking_tool_material", "box___bag_material", 
    "bakeware_material", "host___server_supply_material", "pasta_maker_material", 
    "water_bottle__tumbler___mug_material", "lunch_bag___box_material", 
    "filament_material", "build_platform_material"
]


'''
material_buckets
1. Plastics — ABS, PLA, PET, Polypropylene, Polycarbonate, Polyethylene, HDPE, LDPE, Polystyrene, BPA-free Plastic, Acrylic, Resin, Polypropylene/PP, Plastic/Poly, Polymer, Melamine
2. Metals — Steel, Stainless Steel, Aluminum, Cast Iron, Iron, Chrome, Brass, Copper, Wire, Wire Mesh, Carbon Steel, Cast Aluminum, Wrought Iron, Chrome-Plated, Metallic
3. Leather & Faux Leather — Leather, Bonded Leather, Faux Leather, Vegan Leather, Luxhide, Luxura, SofThread Leather, LeatherSoft, PureSoft, CaressoftPlus, PU/Polyurethane (when upholstery)
4. Textiles / Fabric — Fabric, Mesh, Nylon, Polyester, Cotton, Microfiber, Velvet, Linen, Tweed, Twill, Chenille, Wool, Felt, Boucle, Canvas, Terry, Organza, Satin
5. Vinyl — Vinyl, PVC, Polyvinyl Chloride
6. Glass & Ceramics — Glass, Borosilicate Glass, Ceramic, Porcelain, Stoneware
7. Foam & Rubber — Foam, Memory Foam, Polyurethane Foam, Rubber, Silicone, Latex, Neoprene
8. Wood & Natural Fibers — Wood, Bamboo, Wicker, Rattan, Sisal, Raffia, Engineered Wood, Fiberboard, Laminate
9. Paper & Fiber — Paper, Cardboard, Paperboard, Kraft Paper, Tissue, Cellophane, Wax Paper, Cellulose, Fiber/Bagasse, Cardstock
10. Plant-Based / Eco — Plant-Based, Plant Starch/Oil, Renewable Content, Corn, PLA (could also live under Plastics depending on your intent)
11. Composite / Mixed / Unknown — Assorted Materials, Mixed Materials, Blend, null

A couple of decisions you'd want to make:

1. PLA — is it "Plastics" or "Eco/Plant-Based"? Depends on whether you're grouping by physical properties or sustainability story.
2. Polyurethane — sometimes it's foam (chairs), sometimes it's a leather-like surface. You might need to split by context/category.
Vinyl vs. Plastics — Vinyl is technically plastic, but in furniture/chairs it behaves more like an upholstery material. Keeping it separate may be more useful.
'''

'''
Core Colours: Black, White, Gray, Blue, Red, Green, Brown, Yellow, Orange, Pink, Purple

'''
COLOR_ATTRS = [
    "color", "true_color", 
    # "color_family",
    "furnishing_color", "base_color", 
    "toaster_color", "dinnerware_color", "appliance_color", "ice_cream_maker_color", 
    "cooktop_color", "pasta_maker_color", "salad_spinner_color"
]

WARRANTY_ATTRS = [
    "warranty_information",
    "printer_warranty"
]

COLLECTION_ATTRS = [
    "series_or_collection", "collection"
]

FINISH_ATTRS = [
    'bar finish', 'bath fan finish', 'box & bag finish', 'call bell finish', 'card finish',
    'card stock paper finish', 'ceiling fan blade finish', 'coating', 'connector finish', 
    'cooktop surface', 'copy & printer paper finish', 'darts equipment finish', 
    'envelope paper finish', 'finish', 'flower pot finish', 'folder finish', 
    'food box and bag finish', 'frame finish', 'gift box and bag finish', 'glass finish', 
    'glove grip finish', 'glove texture/coating location', 'hot surface indicator', 
    'interior finish', 'jewelry case finish', 'laminating pouch & sheet finish', 
    'lens coating', 'lighting fixture finish', 'material finish', 'motor finish', 
    'non-stick cooking surface', 'non-stick surface', 'outdoor heater finish', 
    'paint finish', 'paint surface texture', 'paper finish', 'printing paper finish', 
    'product finish', 'scissor blade coating', 'surface design', 'surface material', 
    'surface style', 'surface use', 'table surface material', 'tape finish', 'texture', 
    'toilet and urinal finish', 'transformer finish', 'wide format paper finish', 
    'work glove coating material', 'wrapping supplies finish'
]

ALL_STYLE_ATTRS = PATTERN_ATTRS + MATERIAL_ATTRS + COLOR_ATTRS + WARRANTY_ATTRS + COLLECTION_ATTRS

# Split regex patterns per attribute label (mirrors fm_all_cat_attributes_loader approach)
_SPLIT_COLOR    = r"\s*/\s*|\s+(?i)and\s+|\s*,\s*"
_SPLIT_PATTERN  = r"\s*/\s*|\s*,\s*(?:(?i)and\s+)?|\s+&\s+|\s+(?i)and\s+"
_SPLIT_MATERIAL = r"\s*/\s*|\s*,\s*(?:(?i)and\s+)?|\s+&\s+|\s+(?i)and\s+"
# _SPLIT_FINISH   = r"\s*/\s*|\s*,\s*(?:(?i)and\s+)?|\s+(?i)and\s+"

# CCT (color temperature) detection, scoped to web_department_nm == "Lamps & Lighting"
_LIGHTING_DEPARTMENT = "lamps & lighting"
_CCT_DETECT_PATTERN = r"(?i)\d{3,4}\s*k\b"
_CCT_EXTRACT_PATTERN = r"(?i)(\d{3,4})\s*k"

# Prose-shape rejection for the 'color' attribute: legitimate color values are
# short tokens ("black", "cool white", "midnight blue metallic"); free-text
# sentences (e.g. "the processor does not have a true color specification")
# leak into color specs for some categories (e.g. Computers & Accessories) and
# must be excluded rather than treated as literal color values.
#
# Deliberately vocabulary-independent: a fixed stopword list only catches
# prose that happens to use those exact words, so anything phrased without
# them (e.g. "designed for professional use in studio settings") would slip
# through untouched. Word count and character length are structural signals
# that generalize to ANY long/sentence-like value regardless of wording.
_PROSE_MAX_WORDS = 4
_PROSE_MAX_LENGTH = 31
_PROSE_PUNCTUATION_PATTERN = r'[."]'

# Shade/product-code stripping for the 'color' attribute: paint/marker style
# values carry a leading or trailing standalone number (e.g. "silver 800",
# "105 titanium white") that isn't part of the color name. Quantity phrases
# like "10 assorted colors" or "12 mixed colors" must NOT be touched -- the
# keep-guard below detects those by the presence of "color(s)"/"assort*" and
# skips stripping entirely for them.
_SHADE_CODE_KEEP_GUARD = r"(?i)\b(color|colors|colour|colours|assort\w*)\b"
_SHADE_CODE_LEADING_PATTERN = r"^\d+\s+"
_SHADE_CODE_TRAILING_PATTERN = r"\s+\d+$"


def _build_cct_color_name_column(kelvin_col: "Column") -> "Column":
    """
    Map a Kelvin (CCT) integer column to a bucketed color name using
    inclusive range checks (not exact-value matching).
    """
    return (
        when(kelvin_col.between(500, 2699), lit("warm white"))
        .when(kelvin_col.between(2700, 3400), lit("soft white"))
        .when(kelvin_col.between(3500, 4499), lit("cool white"))
        .when(kelvin_col.between(4500, 5500), lit("daylight"))
        .when(kelvin_col.between(5501, 8000), lit("bright daylight"))
        .otherwise(lit(None).cast(StringType()))
    )


# Attribute names that contain "color" but are NOT actual color values.
# These are excluded from the %color% LIKE extraction in extract_style_data.
EXCLUDE_COLOR_ATTRIBUTES = [
    "number of color cartridges",
    "display colors",
    "color print speed",
    "color brightness lumens (idms rated)",
    "projector display color",
    "iso color print speed (ipm)",
    "yield per cartridge (tri-color)",
    "color brightness (lumens \u2013 idms rated)",
    "color copy speed (cpm)",
    "color copy resolution (up to)",
    "color first page out (seconds)",
    "color temperature",
    "# of colors",
    "color brightness (lumens)",
    "color brightness (lumen)",
]

def analyze_style_attributes(df: DataFrame) -> None:
    """
    Analyze attributes to verify style fields.
    """
    print("\n" + "="*60)
    print("STRATEGY: Analyzing Attributes for Style")
    print("="*60)
    
    exploded = df.select(
        explode(col("spec_json")).alias("spec")
    ).select(
        col("spec.attribute_nm").alias("attribute_nm"),
        col("spec.attribute_value_txt").alias("attribute_value_txt"),
        lower(col("spec.attribute_nm")).alias("attribute_nm_lower")
    ).withColumn(
        "attribute_nm_norm",
        F.regexp_replace(col("attribute_nm_lower"), r"[^a-z0-9]", "_")
    )
    
    print("Scanning for style attributes...")
    
    # Filter for interesting attributes using normalized names
    target_attrs = [a.lower() for a in ALL_STYLE_ATTRS]
    
    exploded.filter(col("attribute_nm_norm").isin(target_attrs)) \
        .groupBy("attribute_nm", "attribute_nm_norm") \
        .agg(F.count("*").alias("count"), F.slice(collect_set("attribute_value_txt"), 1, 3).alias("samples")) \
        .orderBy(col("count").desc()) \
        .show(20, truncate=False)

def generate_finish_attribute(df: DataFrame) -> DataFrame:
    """
    Extract the 'finish' attribute from finish-related spec_json attributes
    (first match per item, ordered by attribute_nm).

    Args:
        df: Input DataFrame with 'item_id' and 'spec_json'.

    Returns:
        DataFrame with columns: item_id, finish, finish_source_attr
    """
    from pyspark.sql.functions import (
        explode_outer
    )

    # ─────────────────────────────────────────────────────────────
    # Step A: Spec-JSON extraction  (array aggregation)
    # ─────────────────────────────────────────────────────────────
    # _SPLIT_FINISH is defined at module level alongside _SPLIT_COLOR etc.

    exploded = df.select(
        col("item_id"),
        explode_outer(col("spec_json")).alias("spec")
    )

    finish_candidates = exploded.select(
        col("item_id"),
        lower(trim(col("spec.attribute_value_txt"))).alias("finish_value"),
        lower(trim(col("spec.attribute_nm"))).alias("source_attr")
    ).filter(
        col("finish_value").isNotNull()
        & (trim(col("finish_value")) != "")
        & col("source_attr").like("%finish%")
    )

    spec_finish_df = (
        finish_candidates
        .groupBy("item_id")
        .agg(
            first(col("finish_value"), ignorenulls=True).alias("spec_finish"),
            first(col("source_attr"),  ignorenulls=True).alias("spec_finish_source_attr")
        )
    )

    # ─────────────────────────────────────────────────────────────
    # Final merge: spec_finish (highest priority)
    # Also expose finish_source_attr: the specific attribute name (spec)
    # ─────────────────────────────────────────────────────────────
    merged = spec_finish_df.withColumn(
        "finish", col("spec_finish")
    ).withColumn(
        "finish_source_attr", col("spec_finish_source_attr")
    ).select("item_id", "finish", "finish_source_attr")

    return merged


def _extract_specs_from_spec_json(
    df: DataFrame,
    label: str,
    like_patterns: list,
    extra_filter=None,
) -> DataFrame:
    """
    Extract distinct (item_id, label, attribute_nm, attribute_value_txt)
    from spec_json for rows whose attribute_nm matches any of the
    given LIKE patterns (case-insensitive).

    Mirrors the _extract_specs helper from fm_all_cat_attributes_loader
    but operates on spec_json (array of structs) instead of the raw
    product_specifications table.
    """
    from pyspark.sql.functions import explode_outer

    exploded = df.select(
        col("item_id"),
        explode_outer(col("spec_json")).alias("spec")
    ).select(
        col("item_id"),
        F.trim(col("spec.attribute_nm")).alias("attribute_nm"),
        F.trim(
            F.regexp_replace(
                col("spec.attribute_value_txt"),
                r"\s*\(\s*\d+\s*\)\s*$",  # strip trailing "(123456)" product-code suffix
                ""
            )
        ).alias("attribute_value_txt"),
    )

    condition = F.lower(F.col("attribute_nm")).like(like_patterns[0])
    for pattern in like_patterns[1:]:
        condition = condition | F.lower(F.col("attribute_nm")).like(pattern)

    result = exploded.filter(condition)

    if extra_filter is not None:
        result = result.filter(extra_filter)

    non_empty = (
        F.col("attribute_value_txt").isNotNull()
        & (F.col("attribute_value_txt") != F.lit(""))
    )

    return (
        result.filter(non_empty)
        .select("item_id", "attribute_nm", "attribute_value_txt")
        .distinct()
        .withColumn("label", F.lit(label))
    )


def extract_cct_color(df: DataFrame) -> DataFrame:
    """
    Map CCT Kelvin values in the 'color' attribute of Lamps & Lighting products to
    color names (e.g. "4000k & 5000k" -> ["cool white", "daylight"]).

    Returns rows shaped like _extract_specs_from_spec_json (label="color"), one per Kelvin value.
    """
    from pyspark.sql.functions import explode_outer

    if "web_department_nm" not in df.columns:
        return df.sparkSession.createDataFrame(
            [], schema="item_id string, attribute_nm string, attribute_value_txt string, label string"
        )

    lighting_df = df.filter(lower(col("web_department_nm")) == _LIGHTING_DEPARTMENT)

    exploded = lighting_df.select(
        col("item_id"),
        explode_outer(col("spec_json")).alias("spec")
    ).select(
        col("item_id"),
        F.trim(col("spec.attribute_nm")).alias("attribute_nm"),
        F.trim(
            F.regexp_replace(
                col("spec.attribute_value_txt"),
                r"\s*\(\s*\d+\s*\)\s*$",  # strip trailing "(123456)" product-code suffix
                ""
            )
        ).alias("attribute_value_txt"),
    )

    color_rows = exploded.filter(
        F.lower(col("attribute_nm")).like("%color%")
        & col("attribute_value_txt").isNotNull()
        & (col("attribute_value_txt") != "")
        & col("attribute_value_txt").rlike(_CCT_DETECT_PATTERN)
    )

    # regexp_extract_all takes its pattern as a SQL string literal, where a
    # bare backslash (e.g. "\d") is not a valid escape and gets silently
    # stripped by the SQL parser -- turning "\d{3,4}" into "d{3,4}" and
    # breaking the match entirely. Escaping backslashes here makes the
    # pattern survive SQL string-literal parsing intact.
    _cct_extract_sql_pattern = _CCT_EXTRACT_PATTERN.replace("\\", "\\\\")
    kelvin_values = color_rows.select(
        "item_id", "attribute_nm",
        F.explode(F.expr(f"regexp_extract_all(attribute_value_txt, '{_cct_extract_sql_pattern}', 1)")).alias("kelvin_str")
    ).withColumn(
        "color_name",
        _build_cct_color_name_column(col("kelvin_str").cast(IntegerType()))
    ).filter(
        col("color_name").isNotNull()
    )

    return (
        kelvin_values
        .select(
            "item_id", "attribute_nm",
            col("color_name").alias("attribute_value_txt")
        )
        .distinct()
        .withColumn("label", F.lit("color"))
    )


def extract_style_data(df: DataFrame) -> DataFrame:
    """
    Extract style data for all supported product categories; pattern is gated by
    web_supercategory_nm (PATTERN_SUPERCATEGORIES).

    Args:
        df: Input DataFrame with spec_json and web_supercategory_nm.

    Returns:
        DataFrame with item_id and style columns
    """
    # ── Step 1: Extract attributes using LIKE patterns on spec_json ──────────
    # Uses LIKE pattern matching (fm_all_cat_attributes_loader approach)
    # instead of hard-coded attribute name lists.
    _color_exclusion_filter = ~F.lower(F.col("attribute_nm")).isin(EXCLUDE_COLOR_ATTRIBUTES)
    extract_color = _extract_specs_from_spec_json(df, "color", ["%color%"], extra_filter=_color_exclusion_filter)

    # CCT (color temperature) handling — isolated to Lamps & Lighting only.
    # Raw CCT values (e.g. "4000k & 5000k") are dropped from extract_color and
    # replaced with their resolved color names from extract_cct_color, so the
    # underlying spec entry isn't processed twice.
    extract_color = extract_color.filter(
        ~col("attribute_value_txt").rlike(_CCT_DETECT_PATTERN)
    )
    extract_color_cct = extract_cct_color(df)

    extract_material = _extract_specs_from_spec_json(df, "material", ["%material%"])
    # '%pattern%' catches most PATTERN_ATTRS, but 'style', 'painting_style' and
    # 'design_elements' don't contain the word 'pattern' in their name and would
    # be missed.  Add explicit LIKE patterns for those to match the old isin() coverage.
    extract_pattern = _extract_specs_from_spec_json(
        df, "pattern",
        ["%pattern%", "%style%", "design_elements", "design and pattern", "design_and_pattern"]
    )
    extract_series = _extract_specs_from_spec_json(df, "series", ["%collection%"])
    extract_warranty = _extract_specs_from_spec_json(df, "warranty", ["%warranty%"])

    # ── Step 2: Extract true_color separately (scalar, not array) ────────────
    true_color_df = extract_color.filter(
        F.lower(F.col("attribute_nm")).like("%true color%")
        | F.lower(F.col("attribute_nm")).like("%true_color%")
    ).groupBy("item_id").agg(
        F.first("attribute_value_txt").alias("true_color")
    )

    # Define pattern supercategories for filtering (uses web_supercategory_nm)
    pattern_supercats_lower = [c.lower() for c in PATTERN_SUPERCATEGORIES]

    # ── Step 3: Extract collection_name (scalar, series_or_collection > collection)
    collection_df = extract_series.groupBy("item_id").agg(
        F.first(
            when(
                F.lower(col("attribute_nm")).like("%series or collection%")
                | F.lower(col("attribute_nm")).like("%series_or_collection%"),
                col("attribute_value_txt")
            ), ignorenulls=True
        ).alias("val_series"),
        F.first(
            when(
                ~(F.lower(col("attribute_nm")).like("%series or collection%"))
                & ~(F.lower(col("attribute_nm")).like("%series_or_collection%")),
                col("attribute_value_txt")
            ), ignorenulls=True
        ).alias("val_collection")
    ).select(
        col("item_id"),
        F.coalesce(col("val_series"), col("val_collection")).alias("collection_name")
    )

    # ── Step 4: Union color, material, pattern → split → explode ────────────
    # extract_color_cct rows are already resolved atomic color names (e.g.
    # "cool white"); _SPLIT_COLOR only splits on '/', 'and', ',' — not spaces —
    # so they pass through the split/explode step below unaffected.
    all_extracted = (
        extract_color
        .unionByName(extract_color_cct)
        .unionByName(extract_material)
        .unionByName(extract_pattern)
    )

    # Per-label split regex (splits compound values like "Red/White" into atoms)
    split_expr = (
        F.when(F.col("label") == "color", F.split(F.col("attribute_value_txt"), _SPLIT_COLOR))
         .when(F.col("label") == "pattern", F.split(F.col("attribute_value_txt"), _SPLIT_PATTERN))
         .when(F.col("label") == "material", F.split(F.col("attribute_value_txt"), _SPLIT_MATERIAL))
    )

    all_with_split = all_extracted.withColumn(
        "original_value_txt", col("attribute_value_txt")
    ).withColumn(
        "attribute_nm_orig", col("attribute_nm")
    ).withColumn(
        "split_values", split_expr
    )

    # Explode to individual atomic values
    atomic_values = all_with_split.select(
        "item_id", "label", "attribute_nm", "attribute_nm_orig",
        "original_value_txt",
        F.explode("split_values").alias("atomic_value")
    ).filter(
        F.trim(col("atomic_value")) != ""
    ).withColumn(
        "atomic_value", F.trim(col("atomic_value"))
    )

    # ── Step 5: Apply bucketing for pattern, lowercasing for color/material ──
    c = lower(col("atomic_value"))
    bucketed_pattern = (
        when(c.rlike("solid|smooth|^lime$|^blue$|^classic$|^neon$|^pastel$"), "solid")
        .when(c.rlike("raised|texture|pile|dome|pebble|bubble|waffle|loop|\\bbar\\b|contoured|glass|molded|twill|herringbone|marble|metallic|glitter|pearlescent"), "textured")
        .when(c.rlike("stripe|\\brib\\b|cable|chevron|^wave|^dotted$|^dots$"), "striped")
        .when(c.rlike("check|gingham|argyle|parquet|diamond|^square$|^geometric$|plaid|ikat"), "checkered")
        .when(c.isin("assorted", "patterned", "multi-patterned", "multi camo", "multicolored", "camouflage", "camo", "tie-dye", "tie dye", "camouflage / military"), "multi-patterned")
        .when(c.isin("null", "",), lit(None))
        .otherwise("print")
    )

    # Prose-shape rejection, scoped to color only: free-text sentences that
    # leak into color specs (e.g. "the processor does not have a true color
    # specification") are excluded before they'd otherwise pass through as a
    # literal (bogus) color value.
    is_prose_color = (
        (col("label") == "color")
        & (
            (F.size(F.split(F.trim(col("atomic_value")), r"\s+")) > _PROSE_MAX_WORDS)
            | (F.length(F.trim(col("atomic_value"))) > _PROSE_MAX_LENGTH)
            | col("atomic_value").rlike(_PROSE_PUNCTUATION_PATTERN)
        )
    )

    # Shade/product-code stripping, scoped to color only: "silver 800" ->
    # "silver", "105 titanium white" -> "titanium white". Quantity phrases
    # like "10 assorted colors" are protected by the keep-guard and pass
    # through this expression completely unchanged.
    color_shade_stripped = (
        when(col("atomic_value").rlike(_SHADE_CODE_KEEP_GUARD), col("atomic_value"))
        .when(
            col("atomic_value").rlike(_SHADE_CODE_LEADING_PATTERN),
            F.trim(F.regexp_replace(col("atomic_value"), _SHADE_CODE_LEADING_PATTERN, ""))
        )
        .when(
            col("atomic_value").rlike(_SHADE_CODE_TRAILING_PATTERN),
            F.trim(F.regexp_replace(col("atomic_value"), _SHADE_CODE_TRAILING_PATTERN, ""))
        )
        .otherwise(col("atomic_value"))
    )

    atomic_transformed = atomic_values.withColumn(
        "attribute_value_txt",
        when(is_prose_color, lit(None).cast(StringType()))  # prose-shaped color values become null
        .when(col("label") == "pattern", bucketed_pattern)
        .when(col("label") == "color", lower(color_shade_stripped))
        .when(col("label") == "material", lower(col("atomic_value")))
        .otherwise(col("atomic_value"))
    ).filter(
        col("attribute_value_txt").isNotNull()
        & (F.trim(col("attribute_value_txt")) != "")  # drop any empty-string tokens post-bucketing
        & (~col("attribute_value_txt").rlike(r"^\d+\.?\d*$"))  # exclude pure numeric strings (e.g. "0", "1003981")
    )

    # Rename label to style_field for downstream compatibility
    atomic_transformed = atomic_transformed.withColumn("style_field", col("label"))

    # ── Step 6: Simple aggregation — collect_set → array_distinct ────────────
    simple_agg = atomic_transformed.groupBy("item_id", "style_field").agg(
        F.array_distinct(F.collect_set("attribute_value_txt")).alias("values")
    )
    pivoted_simple = simple_agg.groupBy("item_id").pivot("style_field").agg(
        F.first("values")
    )

    # ── Step 7: Facets aggregation (for style_facets_json) ───────────────────
    facets_base = atomic_transformed.filter(
        col("style_field").isin(["pattern", "material", "color"])
    )

    facets_with_meta = facets_base.withColumn(
        "source",
        lit("spec_json")
    ).withColumn(
        "evidence_str",
        F.format_string("'%s' keyword in %s", col("original_value_txt"), col("attribute_nm_orig"))
    )

    # Group by item_id, style_field, value to aggregate evidence
    facets_dedup = facets_with_meta.groupBy("item_id", "style_field", "attribute_value_txt", "source").agg(
        collect_set("evidence_str").alias("evidence")
    )

    facets_struct = facets_dedup.select(
        col("item_id"),
        col("style_field"),
        struct(
            col("attribute_value_txt").alias("value"),
            lit(1).alias("confidence"),
            col("source").alias("source"),
            col("evidence")
        ).alias("facet_entry")
    )

    facets_lists = facets_struct.groupBy("item_id", "style_field").agg(
        collect_list("facet_entry").alias("entries")
    )

    pivoted_facets = facets_lists.groupBy("item_id").pivot("style_field").agg(
        F.first("entries")
    )

    # ── Step 8: Build combined DataFrame ─────────────────────────────────────
    # Collect all item_ids that had any extracted attribute
    all_item_ids = (
        extract_color.select("item_id")
        .union(extract_color_cct.select("item_id"))
        .union(extract_material.select("item_id"))
        .union(extract_pattern.select("item_id"))
        .union(extract_warranty.select("item_id"))
        .union(extract_series.select("item_id"))
        .distinct()
    )

    # Add web_supercategory_nm
    if "web_supercategory_nm" in df.columns:
        all_items = all_item_ids.join(
            df.select("item_id", "web_supercategory_nm").dropDuplicates(["item_id"]),
            "item_id", "left"
        )
    else:
        all_items = all_item_ids.withColumn(
            "web_supercategory_nm", lit(None).cast(StringType())
        )

    combined = all_items.join(pivoted_simple, "item_id", "left")

    # Rename facets columns to avoid collision
    for c_name in pivoted_facets.columns:
        if c_name != "item_id":
            pivoted_facets = pivoted_facets.withColumnRenamed(c_name, c_name + "_facet")

    combined = combined.join(pivoted_facets, "item_id", "left")

    # Join true_color
    combined = combined.join(true_color_df, "item_id", "left")

    # Join collection_name
    combined = combined.join(collection_df, "item_id", "left")

    # Join finish attribute (also brings finish_source_attr for source tracking)
    finish_df = generate_finish_attribute(df)
    combined = combined.join(finish_df, "item_id", "left")

    # ── Step 9: Warranty (new loader-based approach) ─────────────────────────
    warranty_base = extract_warranty.filter(
        F.col("attribute_value_txt").isNotNull()
        & (F.trim(F.col("attribute_value_txt")) != F.lit(""))
    )

    # Per-row boolean flags for warranty classification
    is_lifetime = (
        F.col("attribute_value_txt").rlike(r"(?i)^lifetime")
        | F.col("attribute_value_txt").rlike(r"(?i)^\d+.*lifetime(?!.*limited)")
    )
    is_limited_lifetime = (
        F.col("attribute_value_txt").rlike(r"(?i)limited\s+lifetime")
        | F.col("attribute_value_txt").rlike(r"(?i)lifetime.*limited")
    )
    is_pure_lifetime = (
        F.col("attribute_value_txt").rlike(r"(?i)^lifetime")
        | (
            F.col("attribute_value_txt").rlike(r"(?i)lifetime")
            & ~F.col("attribute_value_txt").rlike(r"(?i)limited\s+lifetime")
            & ~F.col("attribute_value_txt").rlike(r"(?i)lifetime.*limited")
        )
    )

    # Duration extraction: year/yr → *12, month → keep, day → ceil(/30)
    duration_months = (
        F.when(is_pure_lifetime, F.lit(9999).cast(IntegerType()))
         .when(
             F.col("attribute_value_txt").rlike(r"(?i)(\d+)\s*(year|yr)"),
             F.regexp_extract(
                 F.col("attribute_value_txt"), r"(?i)(\d+)\s*(-|\s)*(year|yr)", 1
             ).cast("int") * 12,
         )
         .when(
             F.col("attribute_value_txt").rlike(r"(?i)(\d+)\s*(month)"),
             F.regexp_extract(
                 F.col("attribute_value_txt"), r"(?i)(\d+)\s*(month)", 1
             ).cast("int"),
         )
         .when(
             F.col("attribute_value_txt").rlike(r"(?i)(\d+)\s*(day)"),
             F.ceil(
                 F.regexp_extract(
                     F.col("attribute_value_txt"), r"(?i)(\d+)\s*(day)", 1
                 ).cast("int") / 30.0
             ).cast("int"),
         )
    )

    # Additional type flags
    is_extended = F.lower(F.col("attribute_value_txt")).contains("extended")
    is_onsite = (
        F.lower(F.col("attribute_value_txt")).contains("on-site")
        | F.lower(F.col("attribute_value_txt")).contains("onsite")
    )
    has_limited_word = F.lower(F.col("attribute_value_txt")).contains("limited")

    # Add duration column for aggregation
    warranty_with_duration = warranty_base.withColumn("_duration", duration_months)

    # Resolve duplicate map keys: same attribute_nm can have multiple values per item
    df.sparkSession.conf.set("spark.sql.mapKeyDedupPolicy", "LAST_WIN")

    # Aggregate warranty per item_id
    warranty_agg = warranty_with_duration.groupBy("item_id").agg(
        # warranty_json: map<string, string> of attribute_nm → attribute_value_txt
        F.map_from_entries(
            F.collect_set(
                F.struct(F.col("attribute_nm").alias("key"), F.col("attribute_value_txt").alias("value"))
            )
        ).alias("warranty_json"),

        # warranty_type: priority order
        F.when(F.max(is_limited_lifetime.cast("int")) == 1, F.lit("limited_lifetime"))
         .when(F.max(is_lifetime.cast("int")) == 1, F.lit("lifetime"))
         .when(F.max(has_limited_word.cast("int")) == 1, F.lit("limited"))
         .when(F.max(is_extended.cast("int")) == 1, F.lit("extended"))
         .when(F.max(is_onsite.cast("int")) == 1, F.lit("onsite"))
         .when(F.max(F.when(F.col("_duration").isNotNull(), F.lit(1)).otherwise(F.lit(0))) == 1, F.lit("limited"))
         .otherwise(F.lit("unspecified"))
         .alias("warranty_type"),

        # support_warranty_duration_months: maximum across all entries
        F.max("_duration").alias("support_warranty_duration_months"),
    )

    combined = combined.join(warranty_agg, "item_id", "left")

    # Helper to safely get column
    def get_col(df_obj, name):
        if name in df_obj.columns:
            return col(name)
        return lit(None)

    @F.udf(StringType())
    def extract_compliance_tags_2(bullets, specs):
        import re
        import json
        
        found_tags = {}

        # --- Keyword-match pattern (tag + qualifying word) ---
        keyword_pattern = re.compile(
            r'(?i)\b('
            # Original
            r'EPA|BIFMA|GREENGUARD|Energy\s*Star|UL|CE|FCC'
            # Chairs
            r'|ANSI[/ ]BIFMA|SCS\s*Indoor\s*Advantage|TB[\s-]?117|CAL[\s-]?133'
            # Jan/San
            r'|Green\s*Seal|EPA\s*Safer\s*Choice|DfE|NSF'
            # Hydration / Breakroom
            r'|FDA|BPA[\s-]?Free'
            # Printers
            r'|EPEAT|Blue\s*Angel|RoHS|REACH'
            # General
            r'|ISO[\s-]?\d+'
            # --- NEW: Forestry (Paper, Office Supplies) ---
            r'|FSC|SFI|PEFC'
            # --- NEW: Food & Beverage (Coffee, Water & Snacks) ---
            r'|Fair\s*Trade|Kosher|Halal|Compostable|Biodegradable'
            # --- NEW: Art Materials Safety (Arts & Crafts) ---
            r'|AP\s*Non[\s-]?Toxic|ACMI|ASTM\s*D[\s-]?4236'
            # --- NEW: Electronics (Ink & Toner, Printers) ---
            r'|TCO'
            r')\b'
            r'\s*(?:certified|approved|compliant|registered|listed|rated|standard|met)?',
            re.IGNORECASE
        )

        # --- Standalone tags (no qualifying word needed) ---
        standalone_pattern = re.compile(
            r'(?i)\b('
            r'Energy\s*Star'
            r'|GREENGUARD(?:\s*Gold)?'
            r'|Green\s*Seal'
            r'|EPA\s*Safer\s*Choice'
            r'|BPA[\s-]?Free'
            r'|EPEAT(?:\s*Gold|\s*Silver|\s*Bronze)?'
            r'|Blue\s*Angel'
            r'|SCS\s*Indoor\s*Advantage(?:\s*Gold)?'
            r'|RoHS'
            r'|REACH'
            # --- NEW: Forestry ---
            r'|FSC(?:\s*Certified)?'
            r'|SFI(?:\s*Certified)?'
            r'|PEFC(?:\s*Certified)?'
            # --- NEW: Food & Beverage ---
            r'|Fair\s*Trade(?:\s*Certified)?'
            r'|USDA\s*Organic'
            r'|Kosher(?:\s*Certified)?'
            r'|Halal(?:\s*Certified)?'
            # --- NEW: Waste / Eco ---
            r'|Compostable'
            r'|Biodegradable'
            # --- NEW: Art Materials ---
            r'|AP\s*Non[\s-]?Toxic'
            r'|ACMI(?:\s*Certified)?'
            # --- NEW: Electronics ---
            r'|TCO(?:\s*Certified)?'
            r')\b'
        )

        # --- Spec attribute names that are direct indicators ---
        indicator_attrs = {
            "eco_energy_star_certified_ind":       ("Energy Star",       lambda v: str(v).strip().upper() == "Y"),
            "greenguard_certified_ind":            ("GREENGUARD",        lambda v: str(v).strip().upper() == "Y"),
            "bifma_certified_ind":                 ("BIFMA",             lambda v: str(v).strip().upper() == "Y"),
            "epa_safer_choice_ind":                ("EPA Safer Choice",  lambda v: str(v).strip().upper() == "Y"),
            "green_seal_certified_ind":            ("Green Seal",        lambda v: str(v).strip().upper() == "Y"),
            "epeat_certified_ind":                 ("EPEAT",             lambda v: str(v).strip().upper() == "Y"),
            "nsf_certified_ind":                   ("NSF",               lambda v: str(v).strip().upper() == "Y"),
            "bpa_free_ind":                        ("BPA-Free",          lambda v: str(v).strip().upper() == "Y"),
            "rohs_compliant_ind":                  ("RoHS",              lambda v: str(v).strip().upper() == "Y"),
            # --- NEW: Forestry (Paper, Office Supplies) ---
            "fsc_certified_ind":                   ("FSC",               lambda v: str(v).strip().upper() == "Y"),
            "sfi_certified_ind":                   ("SFI",               lambda v: str(v).strip().upper() == "Y"),
            "pefc_certified_ind":                  ("PEFC",              lambda v: str(v).strip().upper() == "Y"),
            # --- NEW: Food & Beverage (Coffee, Water & Snacks) ---
            "kosher_certified_ind":                ("Kosher",            lambda v: str(v).strip().upper() == "Y"),
            "halal_certified_ind":                 ("Halal",             lambda v: str(v).strip().upper() == "Y"),
            "organic_certified_ind":               ("USDA Organic",      lambda v: str(v).strip().upper() == "Y"),
            "fair_trade_certified_ind":            ("Fair Trade",        lambda v: str(v).strip().upper() == "Y"),
            # --- NEW: Waste / Eco ---
            "compostable_ind":                     ("Compostable",       lambda v: str(v).strip().upper() == "Y"),
            "biodegradable_ind":                   ("Biodegradable",     lambda v: str(v).strip().upper() == "Y"),
            "recyclable_ind":                      ("Recyclable",        lambda v: str(v).strip().upper() == "Y"),
            # --- NEW: Electronics (Ink & Toner, Printers) ---
            "blue_angel_certified_ind":            ("Blue Angel",        lambda v: str(v).strip().upper() == "Y"),
            "tco_certified_ind":                   ("TCO",               lambda v: str(v).strip().upper() == "Y"),
            # --- NEW: Art Materials (Arts & Crafts) ---
            "ap_non_toxic_ind":                    ("AP Non-Toxic",      lambda v: str(v).strip().upper() == "Y"),
            "acmi_certified_ind":                  ("ACMI",              lambda v: str(v).strip().upper() == "Y"),
        }

        NORMALIZE = {
            "ENERGY STAR":       "Energy Star",
            "ENERGYSTAR":        "Energy Star",
            "GREENGUARD GOLD":   "GREENGUARD Gold",
            "GREENGUARD":        "GREENGUARD",
            "GREEN SEAL":        "Green Seal",
            "GREENSEAL":         "Green Seal",
            "EPA SAFER CHOICE":  "EPA Safer Choice",
            "DFE":               "DfE",
            "BPA FREE":          "BPA-Free",
            "BPA-FREE":          "BPA-Free",
            "BPAFREE":           "BPA-Free",
            "EPEAT GOLD":        "EPEAT Gold",
            "EPEAT SILVER":      "EPEAT Silver",
            "EPEAT BRONZE":      "EPEAT Bronze",
            "EPEAT":             "EPEAT",
            "BLUE ANGEL":        "Blue Angel",
            "SCS INDOOR ADVANTAGE":      "SCS Indoor Advantage",
            "SCS INDOOR ADVANTAGE GOLD": "SCS Indoor Advantage Gold",
            "ANSI/BIFMA":        "ANSI/BIFMA",
            "ANSI BIFMA":        "ANSI/BIFMA",
            "BIFMA":             "BIFMA",
            "ROHS":              "RoHS",
            "REACH":             "REACH",
            "TB 117":            "TB 117",
            "TB117":             "TB 117",
            "TB-117":            "TB 117",
            "CAL 133":           "CAL 133",
            "CAL133":            "CAL 133",
            "CAL-133":           "CAL 133",
            "ISO-9296":          "ISO 9296",
            # --- NEW: Forestry (Paper, Office Supplies) ---
            "FSC":               "FSC",
            "FSC CERTIFIED":     "FSC",
            "SFI":               "SFI",
            "SFI CERTIFIED":     "SFI",
            "PEFC":              "PEFC",
            "PEFC CERTIFIED":    "PEFC",
            # --- NEW: Food & Beverage (Coffee, Water & Snacks) ---
            "FAIR TRADE":        "Fair Trade",
            "FAIRTRADE":         "Fair Trade",
            "FAIR TRADE CERTIFIED": "Fair Trade",
            "USDA ORGANIC":      "USDA Organic",
            "ORGANIC":           "USDA Organic",
            "ORGANIC CERTIFIED": "USDA Organic",
            "KOSHER":            "Kosher",
            "KOSHER CERTIFIED":  "Kosher",
            "HALAL":             "Halal",
            "HALAL CERTIFIED":   "Halal",
            # --- NEW: Waste / Eco ---
            "COMPOSTABLE":       "Compostable",
            "BIODEGRADABLE":     "Biodegradable",
            "RECYCLABLE":        "Recyclable",
            # --- NEW: Art Materials (Arts & Crafts) ---
            "AP NON-TOXIC":      "AP Non-Toxic",
            "AP NONTOXIC":       "AP Non-Toxic",
            "ACMI":              "ACMI",
            "ACMI CERTIFIED":    "ACMI",
            "ASTM D-4236":       "ASTM D-4236",
            "ASTM D4236":        "ASTM D-4236",
            # --- NEW: Electronics (Ink & Toner, Printers) ---
            "TCO":               "TCO",
            "TCO CERTIFIED":     "TCO",
        }

        # Strip qualifier suffixes so "BIFMA CERTIFIED" → "BIFMA"
        QUALIFIER_SUFFIX = re.compile(
            r'\s+(?:CERTIFIED|APPROVED|COMPLIANT|REGISTERED|LISTED|RATED|STANDARD|MET)$',
            re.IGNORECASE
        )

        def normalize_tag(raw):
            key = re.sub(r'\s+', ' ', raw.strip().upper())
            # Strip qualifier suffix first
            key = QUALIFIER_SUFFIX.sub('', key).strip()
            return NORMALIZE.get(key, key)

        def add_tag(tag_val, source_name):
            val = normalize_tag(tag_val)
            if val not in found_tags:
                found_tags[val] = source_name

        def scan_text(text, source_name):
            if not text:
                return
            for match in keyword_pattern.finditer(str(text)):
                add_tag(match.group(0).strip(), source_name)
            for match in standalone_pattern.finditer(str(text)):
                add_tag(match.group(0).strip(), source_name)

        # --- Scan specs ---
        if specs:
            s_list = specs
            if isinstance(specs, str):
                try:
                    s_list = json.loads(specs)
                except:
                    s_list = []

            if isinstance(s_list, (list,)) or (hasattr(s_list, '__iter__') and type(s_list) != str):
                for s in s_list:
                    c = s.asDict() if hasattr(s, 'asDict') else s
                    if isinstance(c, dict):
                        nm = str(c.get("attribute_nm", "")).strip()
                        v = str(c.get("attribute_value_txt", "")).strip()
                        nm_key = re.sub(r'[^a-z0-9_]', '', nm.lower())

                        # Check indicator attributes
                        if nm_key in indicator_attrs:
                            tag_name, check_fn = indicator_attrs[nm_key]
                            if check_fn(v):
                                add_tag(tag_name, "spec_json")

                        # Free-text scan on value
                        scan_text(v, "spec_json")

        # --- Scan bullets ---
        if bullets:
            b_list = bullets
            if isinstance(bullets, str):
                try:
                    b_list = json.loads(bullets)
                except:
                    b_list = [bullets]

            if isinstance(b_list, (list,)) or (hasattr(b_list, '__iter__') and type(b_list) != str):
                for b in b_list:
                    scan_text(b, "bullets_json")

        result = [
            {"name": name, "source": source, "confidence": 1}
            for name, source in found_tags.items()
        ]

        return json.dumps(result) if result else None
    
    COMPLIANCE_TAGS_SCHEMA = ArrayType(
        StructType([
            StructField("name", StringType(), True),
            StructField("source", StringType(), True),
            StructField("confidence", IntegerType(), True)
        ])
    )
    
    # Construct style_facets_struct
    style_facets_struct = struct(
        get_col(combined, "pattern_facet").alias("pattern"),
        get_col(combined, "material_facet").alias("material"),
        get_col(combined, "color_facet").alias("color")
    )
    
    bullets_col = col("bullets_json") if "bullets_json" in df.columns else lit(None).cast(StringType())
    specs_col = col("spec_json") if "spec_json" in df.columns else lit(None).cast(StringType())
    
    compliance_df = df.select("item_id", bullets_col.alias("b_json"), specs_col.alias("s_json")).dropDuplicates(["item_id"])
    compliance_df = compliance_df.withColumn("compliance_tags_json", extract_compliance_tags_2("b_json", "s_json"))

    compliance_df = compliance_df.withColumn(
        "compliance_tags_json",
        F.from_json(col("compliance_tags_json"), COMPLIANCE_TAGS_SCHEMA)
    )
    
    combined = combined.join(compliance_df.select("item_id", "compliance_tags_json"), "item_id", "left")

    # ── Build source_column JSON ──────────────────────────────────────────────
    # Records, per item, which raw source field each enriched column was derived
    # from.  Format: JSON object with keys = column_name, values = source_attr.
    #
    #   e.g. {"material":"spec_json", "finish":"coating",
    #          "color":"spec_json", "pattern":"spec_json",
    #          "collection_name":"spec_json", "warranty":"spec_json",
    #          "compliance_tags":"spec_json,bullets_json"}
    #
    # finish_source_attr holds either an EAV attribute name (e.g. "coating", "finish")
    # when the value came from spec_json, or "bullets_json" / "title" when it came
    # from free-text extraction.  Normalise so that any EAV attr name becomes "spec_json".
    finish_source_normalised = (
        when(
            get_col(combined, "finish_source_attr").isin("bullets_json", "title", "description"),
            get_col(combined, "finish_source_attr")        # already a source name — keep it
        ).when(
            get_col(combined, "finish_source_attr").isNotNull(),
            lit("spec_json")                               # EAV attr name → map to "spec_json"
        ).otherwise(lit(None).cast(StringType()))
    )

    source_column_expr = to_json(
        struct(
            # material, pattern, color, collection_name, warranty all come from spec_json EAV
            when(get_col(combined, "material").isNotNull(),        lit("spec_json")).alias("material"),
            when(get_col(combined, "pattern").isNotNull(),         lit("spec_json")).alias("pattern"),
            when(get_col(combined, "color").isNotNull(),           lit("spec_json")).alias("color"),
            when(get_col(combined, "collection_name").isNotNull(), lit("spec_json")).alias("collection_name"),
            # finish: "spec_json", "bullets_json", or "title" depending on extraction path
            finish_source_normalised.alias("finish"),
            # warranty always sourced from spec_json EAV (WARRANTY_ATTRS)
            when(get_col(combined, "warranty_json").isNotNull(), lit("spec_json")).alias("warranty"),
            # compliance tags can come from both spec_json and bullets_json
            when(get_col(combined, "compliance_tags_json").isNotNull(),
                 lit("spec_json,bullets_json")).alias("compliance_tags"),
        )
    )

    result_df = combined.select(
        col("item_id"),
        F.array_sort(get_col(combined, "pattern").cast("array<string>")).alias("pattern"),
        F.array_sort(get_col(combined, "material").cast("array<string>")).alias("material"),
        F.array_sort(get_col(combined, "color").cast("array<string>")).alias("color"),
        get_col(combined, "true_color").cast("string").alias("true_color"),
        get_col(combined, "collection_name").cast("string").alias("collection_name"),
        get_col(combined, "finish").cast("string").alias("finish"),
        when(
            lower(col("web_supercategory_nm")).isin(pattern_supercats_lower),
            to_json(style_facets_struct)
        ).otherwise(lit(None)).alias("style_facets_json"),
        col("warranty_json"),
        col("warranty_type"),
        col("support_warranty_duration_months"),
        col("compliance_tags_json"),
        source_column_expr.alias("source_column"),
        F.current_timestamp().alias("updated_at"),
        F.current_timestamp().alias("created_at"),
    )
    
    # Add missing columns as nulls (room_context_json)
    # room_context_json is marked as "snythetic q" in requirements, implying external source or placeholder
    result_df = result_df \
        .withColumn("room_context_json", lit(None).cast(StringType()))

    # Join back to original DF, avoiding column ambiguity.
    # The source `df` might already contain columns that this pipeline regenerates.
    # To prevent an ambiguous join error, we must drop these columns from the
    # source df before joining with the new `result_df`.
    new_column_names = result_df.columns
    new_column_names.remove("item_id")

    base_df = df
    for col_name in new_column_names:
        if col_name in base_df.columns:
            base_df = base_df.drop(col_name)

    final_df = base_df.join(result_df, "item_id", "left")
    
    final_cols = [
        "item_id",
        "web_supercategory_nm",
        "material",
        "pattern",
        "color",
        "collection_name",
        "finish",
        "warranty_json",
        "warranty_type",
        "support_warranty_duration_months",
        "compliance_tags_json",
        "source_column",  # JSON: {column_name: source_attr} provenance map
        "created_at",
        "updated_at"

    ]

    existing_cols = [c for c in final_cols if c in final_df.columns]
    return final_df.select(*existing_cols)

def generate_summary_report(df: DataFrame) -> None:
    """
    Generate a summary report of style extraction results.
    """
    print("\n" + "="*60)
    print("STYLE EXTRACTION SUMMARY REPORT")
    print("="*60)
    
    total_all_items = df.count()
    
    # Filter for relevant categories for the summary stats (uses web_supercategory_nm)
    if "web_supercategory_nm" in df.columns:
        relevant_df = df.filter(lower(col("web_supercategory_nm")).isin([c.lower() for c in PATTERN_SUPERCATEGORIES]))
        total_items = relevant_df.count()
        print(f"Reporting on Pattern Supercategories: {', '.join(PATTERN_SUPERCATEGORIES)}")
    else:
        relevant_df = df
        total_items = total_all_items
        print("Reporting on All Categories (web_supercategory_nm column missing)")
    
    if total_items == 0:
        print("No data found for target categories.")
        return

    # Calculate coverage for each main field within relevant items
    material_count = df.filter(col("material").isNotNull()).count()
    color_count = df.filter(col("color").isNotNull()).count()
    facets_count = relevant_df.filter(col("style_facets_json").isNotNull()).count()
    
    print(f"\nTotal Style Category Items: {total_items}")
    print(f"Total All Items: {total_all_items}")
    
    print("-" * 30)
    print("Global Attributes (Material, Color)")
    print("-" * 30)
    print(f"Items with Material: {material_count} ({material_count/total_all_items*100:.2f}%)")
    print(f"Items with Color: {color_count} ({color_count/total_all_items*100:.2f}%)")
    
    print("-" * 30)
    print("Style Attributes (Pattern)")
    print("-" * 30)
    print(f"Items with Style Facets: {facets_count} ({facets_count/total_items*100:.2f}%)")

    # Display unique pattern values explicitly here
    print("\n--- Unique Categorized Patterns ---")
    df.filter(col("pattern").isNotNull()).select(explode(col("pattern")).alias("pattern_value")) \
        .groupBy("pattern_value").count().orderBy(F.desc("count")).show(truncate=False)

    # Breakdown by Category (using web_supercategory_nm)
    if "web_supercategory_nm" in df.columns:
        print("\nCoverage by Web Supercategory:")
        
        category_stats = df.groupBy("web_supercategory_nm").agg(
            F.count("*").alias("total"),
            F.sum(when(col("pattern").isNotNull(), 1).otherwise(0)).alias("with_pattern"),
            F.sum(when(col("material").isNotNull(), 1).otherwise(0)).alias("with_material"),
            F.sum(when(col("color").isNotNull(), 1).otherwise(0)).alias("with_color")
        ).withColumn(
            "pattern_pct", F.round(col("with_pattern") / col("total") * 100, 2)
        ).withColumn(
            "material_pct", F.round(col("with_material") / col("total") * 100, 2)
        ).withColumn(
            "color_pct", F.round(col("with_color") / col("total") * 100, 2)
        ).orderBy(col("total").desc())
        
        category_stats.show(truncate=False)

# Columns this task reads from its source table.
SOURCE_COLUMNS = ["item_id", "spec_json", "bullets_json", "web_department_nm", "web_supercategory_nm"]


def run_style_pipeline(
    spark: DatabricksSession,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None
) -> DataFrame:
    """
    Run the style extraction pipeline.
    """
    print("=" * 80)
    print("STYLE EXTRACTION PIPELINE (All Pattern Categories)")
    print("=" * 80)
    
    print(f"\n1. Loading data from {source_table}...")
    df = read_all_products(spark, source_table, SOURCE_COLUMNS)
    print(f"Loaded {df.count()} rows")

    analyze_style_attributes(df)

    print("\n2. Extracting style data...")
    result_df = extract_style_data(df)
    
    # Generate Summary Report
    # generate_summary_report(result_df)
    
    print("\nSample Results:")
    result_df.select("item_id", "material", "color", "warranty_type", "support_warranty_duration_months").show(5, truncate=False)
    
    print("\n3. Saving results...")
    save_data(
        result_df, 
        spark, 
        catalog=output_catalog, 
        schema=output_schema, 
        table=output_table,
        # mode="overwrite"
    )
    
    print("\n" + "=" * 80)
    print("PIPELINE COMPLETE")
    print("=" * 80)
    
    return result_df


if __name__ == "__main__":
    spark = get_spark_session()
    # os.environ.setdefault("sf_env", "dev")
    # Load general configuration
    GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
    

    _general_config = read_config(GENERAL_CONFIG_PATH)        
    SOURCE_TABLE = _general_config["universal_attributes"]["tables"]["source_table"]
    OUTPUT_TABLE = _general_config["universal_attributes"]["tables"]["output_table"]


    run_style_pipeline(spark, SOURCE_TABLE, OUTPUT_TABLE)