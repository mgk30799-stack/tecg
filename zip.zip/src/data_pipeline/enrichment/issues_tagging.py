"""
Product Issue Tagging — LLM-extracted quality issues from reviews and Q&A.

Sends each review or Q&A text to Gemma on Vertex AI through a pandas UDF and
returns one structured record per problem the model finds in it. This module is
a SERVICE: it reads its own source rows, calls the model, validates the reply,
and returns a DataFrame. It performs no aggregation and writes no enrichment
table — review_mining.py orchestrates, joins and aggregates.

TABLE STORAGE
    cache_table        shared LLM cache, keyed on (cache_kind, cache_key).
                       Issue and conflict responses use separate kinds in
                       review_mining.tables.cache_table and are read on reruns.
    ISSUE_TAGS_TABLE   shared per-unit observability table. Detected issues are
                       grouped by product, source and source id into issues_json;
                       FAQ tagging owns the separate faq_json payload.
                       Written only when review_mining.tag_table is true.

THE MODEL IS THE DETECTOR, AND ISSUE TYPES ARE OPEN
The model names every issue from what the review describes; the prompt carries
only ~20 example keys for naming style (reviews_prompts.ISSUE_KEY_REFERENCES),
not a list to choose from. config/issue_keywords.yaml is used only after the
reply: a canonicalization target (alias map) and a severity fallback. It does
NOT gate which rows are sent: there is no keyword pre-filter, because the point
of the design is to find problems the 95-key taxonomy has no word for.
review_mining.detect_issues_in_review remains, but
only as the liveness fallback when Vertex is unreachable — see the module note
in review_mining.

FIELDS PRODUCED (one row per detected issue, not per review)
    issue_key          STRING   canonicalized problem name
    is_novel_key       BOOLEAN  true when the model coined a name not in the
                                taxonomy. Kept, not dropped — this is how the
                                vocabulary grows from observed data.
    issue_tags         ARRAY<STRING>
    affected_component STRING
    severity           STRING   critical|high|medium|low
    severity_reason    STRING
    confidence         DOUBLE   LLM self-reported, clamped to [0,1]
    confidence_band    STRING   derived in code from confidence
    sentiment_score    INT      1-5, clamped
    resolution_status  STRING   unresolved|resolved_by_user|
                                resolved_by_manufacturer|unknown
    time_bound         BOOLEAN
    root_cause         STRING
    matched_terms      ARRAY<STRING>  verbatim spans, validated against source

CARRIED FROM THE ROW, NEVER ASKED OF THE MODEL
    product_id, source ('review'|'qa'), source_id, source_create_dt,
    rating. Every field moved out of the reply is output tokens
    saved on every row.

COST MODEL
Every row reaches the model, so the LLM cache is the only volume lever. It is
content-addressed on sha2(review_text || category || prompt_version || model),
and an EMPTY reply is cached like any other — most reviews report no problem, so
"[]" is the single most common answer in the corpus and re-asking it every run
would defeat the cache entirely.

Vertex implicit context caching does the rest: reviews_prompts emits the whole
static body before anything row-specific, so the ~2,700-token prefix is billed
at 10% on a cache hit.

Usage:
    python issues_tagging.py                     # standalone, full catalog

    from issues_tagging import generate_issue_tags   # config-driven, same semantics
    generate_issue_tags(spark)

    from issues_tagging import mine_issue_tags       # what review_mining calls
    issues_df = mine_issue_tags(spark, narrowed_catalog_df, issue_cfg)

A standalone run writes the LLM cache and the tag table, NOT
product_reviews_faq_enriched_data — issue_signals_json and issue_summary_json
are per-product aggregations review_mining owns. Run review_mining afterwards to
roll these tags up; it hits the cache this run filled and pays almost nothing.

See docs/issue_signals_schema_migration_3.md for the full architecture.
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
import uuid
from datetime import datetime, timezone
from functools import reduce
from typing import Any, Dict, List, Optional, Sequence

import pandas as pd
import yaml
from pyspark import TaskContext
from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    DoubleType,
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from reviews_prompts import (
    ISSUE_CONFLICT_PROMPT_VERSION,
    ISSUE_TAGGING_PROMPT_VERSION,
    build_issue_conflict_prompt_sql,
    build_issue_tagging_prompt_sql,
)

from faq_tagging import (  # pyrefly: ignore [missing-import]
    _clean_bool,
    _load_service_account_info,
    _vertex_responses_to_series,
)
from utils import (  # pyrefly: ignore [missing-import]
    get_spark_session,
    issue_unit_rows,
    read_config,
    validate_before_write,
    write_unit_tags,
)

logger = logging.getLogger(__name__)

# =============================================================================
# PROJECT ROOT
# =============================================================================
#
# __file__ DOES NOT EXIST when this module's source is pasted into a Databricks
# notebook cell, which is how it gets run interactively — so the plain
# dirname(abspath(__file__)) form raises NameError at import and the cell never
# reaches a single line of logic. Every other enrichment module already guards
# this; this one was the exception.
#
# The fallback prefers cwd when it looks like the repo root (it holds config/),
# and otherwise climbs the same three levels the file-based path would, which
# covers a notebook opened from inside src/data_pipeline/enrichment/.

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))


def config_path(filename: str) -> str:
    """
    Locate a file in config/: try PROJECT_ROOT, then ancestors of cwd, then ancestors
    of every sys.path entry. Raises FileNotFoundError listing every path tried.
    """
    candidates = [PROJECT_ROOT]

    starts = [os.getcwd(), CURRENT_DIR]
    # Only real directories: sys.path carries "" and zip/egg entries too.
    starts += [p for p in sys.path if p and os.path.isdir(p)]

    for start in starts:
        path = os.path.abspath(start)
        while True:
            candidates.append(path)
            parent = os.path.dirname(path)
            if parent == path:
                break
            path = parent

    seen = set()
    for root in candidates:
        if root in seen:
            continue
        seen.add(root)
        candidate = os.path.join(root, "config", filename)
        if os.path.exists(candidate):
            return candidate

    raise FileNotFoundError(
        f"config/{filename} not found. Looked under: "
        + ", ".join(sorted(seen))
        + ". Set the working directory to the repo root, or pass an explicit "
        "path."
    )

# =============================================================================
# DEFAULTS  (only apply when config/general.yml omits the key)
# =============================================================================

DEFAULT_TEMPERATURE = 0.0          # deterministic: signal_id is content-addressed
DEFAULT_BATCH_SIZE = 500
DEFAULT_MAX_REVIEW_CHARS = 1200
DEFAULT_NUM_PARTITIONS = 128       # the real throughput knob — see tag_issues
DEFAULT_MAX_CONCURRENCY = 8
DEFAULT_MAX_OUTPUT_TOKENS = 2048   # worst real reply (5 issues) is ~600 tokens
DEFAULT_TIMEOUT_S = 120.0
DEFAULT_ISSUE_TAGS_MIN = 1
DEFAULT_ISSUE_TAGS_MAX = 5
DEFAULT_SENTIMENT_MIN = 1
DEFAULT_SENTIMENT_MAX = 5
DEFAULT_MAX_MATCHED_TERMS = 3
DEFAULT_MIN_CONFIDENCE = 0.5       # the prompt's own floor, enforced on the reply

# Prefix the invoke UDF writes in place of a reply when the Vertex call itself
# raised. The batch loops strip it back to NULL before parsing and count it, so
# the driver log can say WHY a reply is unparseable (429 vs bad JSON).
VERTEX_ERROR_MARK = "__vertex_error__:"

# --- conflict detection (the second pass) -----------------------------------
# On by default: without it conflict_flag is the sentiment heuristic, which is
# a fallback, not the intended behaviour.
DEFAULT_CONFLICT_DETECTION = True
# A single mention cannot conflict; raising this trades recall for spend.
DEFAULT_CONFLICT_MIN_MENTIONS = 2
# Excerpts sent per group. A contradiction that needs more than ten excerpts to
# see is not one a reader would call obvious, and the cap bounds both the token
# cost and the prompt's variance.
DEFAULT_MAX_CONFLICT_EXCERPTS = 10
DEFAULT_MAX_EVIDENCE_CHARS = 1500

# Whether to PERSIST the per-issue tag table. Persistence ONLY — never data
# flow. mine_issue_tags builds and returns the same DataFrame either way, and
# review_mining consumes that frame rather than reading the table back, exactly
# as faq_tagging.DEFAULT_TAG_TABLE governs product_faq_tags. Keep it on for
# scheduled runs so a bad tag can be investigated after the fact; turn it off
# for local and ad-hoc work where the write is pure overhead.
DEFAULT_TAG_TABLE = True

VALID_SEVERITY = ("critical", "high", "medium", "low")
VALID_RESOLUTION = (
    "unresolved", "resolved_by_user", "resolved_by_manufacturer", "unknown",
)
# The prompt tells the model to answer this when the text names no cause. It is
# the model saying "none given", not a cause, so it is published as NULL.
ROOT_CAUSE_UNKNOWN = "(unknown)"
# The same idea for affected_component. The prompt says to answer "(none)" when
# the text names no part, and the model sometimes uses "(unknown)" too. Either
# way the mention is UNATTRIBUTED — NULL, which is what unattributed_count
# counts — not a part called "(none)".
COMPONENT_PLACEHOLDERS = ("(none)", "(unknown)", "")

# =============================================================================
# OUTPUT SCHEMA
# =============================================================================

# The LLM half of one issue, as it comes back from the parse UDF. product_id /
# source / source_id / source_create_dt are attached in Spark afterwards, from
# columns we already hold.
ISSUE_RECORD_SCHEMA = StructType([
    StructField("issue_key",          StringType()),
    StructField("is_novel_key",       BooleanType()),
    StructField("issue_tags",         ArrayType(StringType())),
    StructField("affected_component", StringType()),
    StructField("severity",           StringType()),
    StructField("severity_reason",    StringType()),
    StructField("confidence",         DoubleType()),
    StructField("confidence_band",    StringType()),
    StructField("sentiment_score",    IntegerType()),
    StructField("resolution_status",  StringType()),
    StructField("time_bound",         BooleanType()),
    StructField("root_cause",         StringType()),
    StructField("matched_terms",      ArrayType(StringType())),
])

PARSED_SCHEMA = ArrayType(ISSUE_RECORD_SCHEMA)

CACHE_SCHEMA = StructType([
    StructField("cache_kind",     StringType(), False),
    StructField("cache_key",      StringType(), False),
    StructField("payload_json",   StringType(), False),
    StructField("prompt_version", StringType(), False),
    StructField("model",          StringType(), False),
    StructField("created_at",     StringType(), False),
])

# The observability tag table — the issue-side counterpart of
# faq_tagging.TAG_TABLE_SCHEMA. Enforced in write_issue_tags, for the same
# reason: a column lost to an upstream .select() is otherwise silent and only
# surfaces as an all-NULL column days later.
#
# item_id, not product_id: the column is renamed on the way in so the union
# view and every downstream join key match product_faq_tags.
#
# THIS TABLE IS NEVER READ BACK. It is not the LLM cache (that is CACHE_SCHEMA /
# cache_table, keyed on a content hash) and it is not an incremental anti-join
# source — issue tagging has neither. Deleting it costs observability and
# nothing else.
ISSUE_TAG_TABLE_SCHEMA = StructType([
    StructField("item_id",            StringType(),            False),
    StructField("tag_id",             StringType(),            False),  # PK
    StructField("source",             StringType(),            True),   # review|qa
    StructField("source_id",          StringType(),            True),
    # NULL for every Q&A row by construction — product_web_question carries no
    # timestamp we resolve here. Same gap as review_mining's recency buckets.
    StructField("source_create_dt",   StringType(),            True),
    # The text the model actually judged, kept so a questionable tag can be
    # read back without a join to Snowflake. faq_tagging stores `question` for
    # the same reason.
    StructField("source_text",        StringType(),            True),
    StructField("issue_key",          StringType(),            True),
    # True when the model coined a name issue_keywords.yaml does not hold.
    # summarize_novel_keys aggregates exactly this column.
    StructField("is_novel_key",       BooleanType(),           True),
    StructField("issue_tags",         ArrayType(StringType()), True),
    StructField("affected_component", StringType(),            True),
    StructField("severity",           StringType(),            True),
    StructField("severity_reason",    StringType(),            True),
    StructField("confidence",         DoubleType(),            True),
    StructField("confidence_band",    StringType(),            True),
    StructField("sentiment_score",    IntegerType(),           True),
    StructField("resolution_status",  StringType(),            True),
    StructField("time_bound",         BooleanType(),           True),
    StructField("root_cause",         StringType(),            True),
    # The only quotable evidence, already proven to be a verbatim substring of
    # source_text by _ground_terms. An entry with none of these never reaches
    # this table — the parser drops it.
    StructField("matched_terms",      ArrayType(StringType()), True),
    StructField("model_endpoint",     StringType(),            True),
    StructField("created_at_ts",      TimestampType(),         True),
    StructField("last_updated_ts",    TimestampType(),         True),
])

ISSUE_TAG_TABLE_COLUMNS = [f.name for f in ISSUE_TAG_TABLE_SCHEMA.fields]


# =============================================================================
# CONFIG  (lazy-loaded — importing the module will not crash)
# =============================================================================

_issues_config: Dict[str, Any] = {}


def _ensure_config() -> Dict[str, Any]:
    """
    Load the issues half of the unified review_mining config on first use:
    review_mining.llm is the shared Vertex endpoint, review_mining.issues holds
    the issue-only settings.

    Mirrors faq_tagging._ensure_table_config, including its failure mode: an
    incomplete vertex block raises HERE, on the driver, rather than letting a
    half-configured run reach the model and fail one partition at a time.
    """
    if _issues_config:
        return _issues_config

    cfg = read_config(config_path("general.yml"))
    rm = cfg.get("review_mining", {}) or {}
    shared = rm.get("llm", {}) or {}
    llm = rm.get("issues", {}) or {}
    tables = rm.get("tables", {}) or {}

    _issues_config["ENABLED"] = bool(llm.get("enabled", True))
    _issues_config["REVIEW_TABLE"] = tables.get("REVIEW_TABLE")
    _issues_config["QUESTIONS_TABLE"] = tables.get("QUESTIONS_TABLE")
    # Only the STANDALONE path reads this. review_mining hands mine_issue_tags a
    # source_df it has already narrowed to changed items; a solo run has no
    # orchestrator to narrow anything, so it loads the catalog itself.
    _issues_config["PRODUCT_CATALOG_TABLE"] = tables.get("PRODUCT_CATALOG_TABLE")
    # Cap on catalog items per standalone run. -1 = no cap. THIS IS THE ONLY
    # BRAKE on a solo run: every review of every item it is handed reaches the
    # model on a cache miss, so an uncapped first run against the full catalogue
    # is a full backfill whether or not that was the intent.
    _issues_config["MAX_ITEMS_PER_RUN"] = int(llm.get("max_items_per_run", -1))
    _issues_config["TAG_TABLE"] = bool(rm.get("tag_table", DEFAULT_TAG_TABLE))
    _issues_config["ISSUE_TAGS_TABLE"] = tables.get("tag_table")

    _issues_config["VERTEX"] = dict(shared.get("vertex", {}) or {})
    _issues_config["VERTEX"]["max_concurrency"] = int(
        shared.get("issue_max_concurrency", DEFAULT_MAX_CONCURRENCY)
    )
    _issues_config["VERTEX"]["max_output_tokens"] = int(
        shared.get("issue_max_output_tokens", DEFAULT_MAX_OUTPUT_TOKENS)
    )
    _issues_config["VERTEX"]["timeout_s"] = float(shared.get("timeout_s", DEFAULT_TIMEOUT_S))
    # Off unless config says so: Gemma MaaS support for responseMimeType on
    # generateContent is unverified, and a rejection would fail every call.
    _issues_config["VERTEX"]["json_mode"] = bool(shared.get("issue_json_mode", False))
    missing = [
        k for k in ("model", "project", "location", "secret_scope", "secret_key")
        if not _issues_config["VERTEX"].get(k)
    ]
    if missing:
        # Clear the partial cache so a later call re-reads from scratch rather
        # than returning this half-populated dict.
        _issues_config.clear()
        raise ValueError(
            "review_mining.llm.vertex is missing required key(s): "
            f"{', '.join(missing)}. Issue tagging runs exclusively on Vertex; "
            "see config/general.yml."
        )

    _issues_config["TEMPERATURE"] = float(shared.get("issue_temperature", DEFAULT_TEMPERATURE))
    # Distinct texts per tag_issues pass. FAQ has its own faq_batch_size: its
    # loop does not repartition, so a larger batch would not raise its throughput.
    _issues_config["ISSUE_BATCH_SIZE"] = int(
        shared.get("issue_batch_size", DEFAULT_BATCH_SIZE)
    )
    # Distinct groups per detect_issue_conflicts pass, for the same reason.
    _issues_config["CONFLICT_BATCH_SIZE"] = int(
        shared.get("conflict_batch_size", DEFAULT_BATCH_SIZE)
    )
    _issues_config["NUM_PARTITIONS"] = int(
        shared.get("num_partitions", DEFAULT_NUM_PARTITIONS)
    )
    _issues_config["MAX_REVIEW_CHARS"] = int(
        llm.get("max_review_chars", DEFAULT_MAX_REVIEW_CHARS)
    )
    _issues_config["ISSUE_TAGS_MIN"] = int(
        llm.get("issue_tags_min", DEFAULT_ISSUE_TAGS_MIN)
    )
    _issues_config["ISSUE_TAGS_MAX"] = max(
        _issues_config["ISSUE_TAGS_MIN"],
        int(llm.get("issue_tags_max", DEFAULT_ISSUE_TAGS_MAX)),
    )
    _issues_config["SENTIMENT_MIN"] = int(
        llm.get("sentiment_min", DEFAULT_SENTIMENT_MIN)
    )
    _issues_config["SENTIMENT_MAX"] = max(
        _issues_config["SENTIMENT_MIN"],
        int(llm.get("sentiment_max", DEFAULT_SENTIMENT_MAX)),
    )
    _issues_config["MIN_CONFIDENCE"] = float(
        llm.get("min_confidence", DEFAULT_MIN_CONFIDENCE)
    )
    _issues_config["MAX_MATCHED_TERMS"] = int(
        llm.get("max_matched_terms", DEFAULT_MAX_MATCHED_TERMS)
    )
    # Empty/absent disables caching entirely: every row is classified, which
    # costs money but never correctness.
    _issues_config["CACHE_TABLE"] = tables.get("cache_table") or None

    # --- conflict detection (second pass) --------------------------------
    _issues_config["CONFLICT_DETECTION"] = bool(
        llm.get("conflict_detection", DEFAULT_CONFLICT_DETECTION)
    )
    # Floored at 2: below that the pass would send single-mention groups, which
    # cannot contain a contradiction and would be pure spend.
    _issues_config["CONFLICT_MIN_MENTIONS"] = max(
        2, int(llm.get("conflict_min_mentions", DEFAULT_CONFLICT_MIN_MENTIONS))
    )
    _issues_config["MAX_CONFLICT_EXCERPTS"] = int(
        llm.get("max_conflict_excerpts", DEFAULT_MAX_CONFLICT_EXCERPTS)
    )
    _issues_config["MAX_EVIDENCE_CHARS"] = int(
        llm.get("max_evidence_chars", DEFAULT_MAX_EVIDENCE_CHARS)
    )
    # True re-sends every row to the model, ignoring the cache. Distinct from
    # review_mining.full_refresh, which widens the CATALOGUE processed: this one
    # widens what is re-classified, and is the only one of the two that costs
    # model spend. review_mining.full_refresh drives an anti-join instead, because
    # it has no content cache to bypass.
    _issues_config["FULL_REFRESH"] = bool(llm.get("full_refresh", False))
    return _issues_config


# =============================================================================
# CANONICALIZATION  (issue_keywords.yaml as SECONDARY source)
# =============================================================================

def _snake(text: str) -> str:
    """Lowercase, collapse every non-alphanumeric run to a single underscore."""
    return re.sub(r"^_+|_+$", "", re.sub(r"[^a-z0-9]+", "_", (text or "").lower().strip()))


def build_alias_map(issues: Sequence[dict]) -> Dict[str, str]:
    """
    DRIVER ONLY. Map many surface forms onto one canonical issue_key.

    Three sources, cheapest first — an exact hit short-circuits the rest:
        * the canonical keys themselves
        * each issue's `title`, snake_cased ("Delivery or Packaging Damage")
        * naive singular/plural variants, since the model is inconsistent about
          them and it is the commonest fragmentation we can pre-empt

    Deliberately NOT fuzzy. Edit-distance matching on every entry of every row
    is both slow and silently wrong when it fires on a genuinely new issue whose
    name merely resembles an old one. Fuzzy matching belongs in the offline
    review of the novel-keys table, where a human sees it before it merges.
    """
    alias: Dict[str, str] = {}
    for issue in issues or []:
        key = issue.get("key")
        if not key:
            continue
        alias[key] = key
        title = issue.get("title")
        if title:
            alias.setdefault(_snake(title), key)
        for variant in (key + "s", key.rstrip("s")):
            alias.setdefault(variant, key)
    return alias


def build_severity_defaults(issues: Sequence[dict]) -> Dict[str, str]:
    """
    DRIVER ONLY. {issue_key: severity_default} — the fallback when the model
    omits or garbles severity.

    This is the ONLY place severity_default is used. It is deliberately withheld
    from the prompt: shown to the model it would anchor the very judgement it
    exists to backstop.
    """
    return {
        issue["key"]: str(issue.get("severity_default", "medium")).lower()
        for issue in (issues or [])
        if issue.get("key")
    }


# =============================================================================
# STRUCTURED OUTPUT VALIDATION
# =============================================================================
#
# pydantic v2 (a declared dependency, requirements.txt:10) carries the SHAPE
# contract: which fields exist and what type each one is, declared once in an
# object that reads like the JSON the prompt asks for.
#
# IT DELIBERATELY DECLARES NO RANGES. `confidence: float = Field(ge=0, le=1)`
# reads like good validation and is a trap here: a model returning 1.5 would
# raise, the whole reply would be discarded as unparseable, and — because
# unparseable replies are deliberately not cached (§8.1) — that review would be
# re-asked on every run forever. A value that is merely out of range is
# recoverable, and _clamp_confidence recovers it. Only a value that is not a
# number at all is a real failure.
#
# Ranges, enums and defaults therefore live in the coercion helpers above, which
# are total: they never raise and never return an out-of-range value.
#
# Entries are also validated ONE AT A TIME rather than as List[IssueRecord].
# Validating the list means one malformed entry discards every good entry beside
# it — on a review reporting three problems, one bad field would lose all three.
#
# What pydantic does NOT do here is anything requiring the source text. Grounding
# matched_terms against the review, canonicalizing issue_key against the alias
# map, and applying severity_default all need per-row context a validator cannot
# see, so they run in _parse_response after validation succeeds.

try:
    from pydantic import BaseModel, ConfigDict, Field, ValidationError

    class IssueRecord(BaseModel):
        """
        One issue as the model is asked to emit it (reviews_prompts, issue tagging).

        Every field is optional except issue_key, and nothing is range-checked —
        see the note above. This validates SHAPE, not plausibility.
        """

        # Unknown keys are dropped rather than raising: a model that adds a
        # field is not a reason to lose the eleven that are correct.
        model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)

        issue_key: str = Field(min_length=1)
        issue_tags: List[Any] = Field(default_factory=list)
        affected_component: Optional[str] = None
        severity: Optional[str] = None
        severity_reason: Optional[str] = None
        # float, not confloat: out-of-range is clamped downstream, not rejected.
        confidence: Optional[float] = None
        # float rather than int so "2.0" and 2.0 both survive; rounded on clamp.
        sentiment_score: Optional[float] = None
        resolution_status: Optional[str] = None
        time_bound: Optional[bool] = None
        root_cause: Optional[str] = None
        matched_terms: List[Any] = Field(default_factory=list)

    class IssueReply(BaseModel):
        """
        The envelope only. `issues: []` is valid and common.

        Entries stay as raw dicts here and are validated individually in
        _parse_response, so one bad entry cannot take its siblings with it.
        """

        model_config = ConfigDict(extra="ignore")
        issues: List[Any] = Field(default_factory=list)

    _PYDANTIC_AVAILABLE = True

except ImportError:  # pragma: no cover
    # The coercion helpers below are total — they never raise and never return
    # an out-of-range value — so losing pydantic costs the declarative contract
    # and nothing else. Warn once rather than failing the run.
    logger.warning(
        "pydantic unavailable; issue replies validated by coercion only. "
        "Install pydantic>=2.5.0 (requirements.txt) to restore the schema check."
    )
    _PYDANTIC_AVAILABLE = False
    ValidationError = Exception  # type: ignore[assignment,misc]


# --- coercion helpers: total functions, never raise --------------------------

def _clamp_confidence(raw: Any) -> float:
    """[0,1]. Unparseable or absent -> 0.0, which the min_confidence floor drops."""
    try:
        return max(0.0, min(1.0, float(raw)))
    except (TypeError, ValueError):
        return 0.0


def _confidence_band(confidence: float) -> str:
    """
    Derived in code, never asked of the model — it is a pure function of
    confidence, so asking would spend output tokens on arithmetic. Thresholds
    match review_mining's historical bands (:651-655) so the two eras of this
    column mean the same thing.
    """
    if confidence >= 0.7:
        return "high"
    if confidence >= 0.4:
        return "medium"
    return "low"


def _clamp_sentiment(raw: Any, lo: int, hi: int) -> int:
    """Midpoint on failure: a missing sentiment must not read as the worst one."""
    try:
        return max(lo, min(hi, int(round(float(raw)))))
    except (TypeError, ValueError):
        return (lo + hi) // 2


def _coerce_severity(raw: Any, issue_key: str, defaults: Dict[str, str]) -> str:
    """
    Unknown value -> the taxonomy's severity_default -> 'medium'.

    Never NULL: severity is a groupBy input downstream, and a NULL there becomes
    a phantom bucket in severity_distribution.
    """
    value = str(raw or "").strip().lower()
    if value in VALID_SEVERITY:
        return value
    fallback = defaults.get(issue_key, "medium")
    return fallback if fallback in VALID_SEVERITY else "medium"


def _coerce_resolution(raw: Any) -> str:
    """
    Unknown value -> 'unknown', NOT 'unresolved'.

    Defaulting to unresolved inflates has_unresolved_issue downstream and
    silently over-excludes products from search results.
    """
    value = str(raw or "").strip().lower()
    return value if value in VALID_RESOLUTION else "unknown"


def _normalize_tags(raw: Any, max_tags: int) -> List[str]:
    """snake_case, de-duplicated, order preserved, capped."""
    if not isinstance(raw, (list, tuple)):
        return []
    out: List[str] = []
    for tag in raw:
        norm = _snake(str(tag))
        if norm and norm not in out:
            out.append(norm)
    return out[:max_tags]


def _ground_terms(raw: Any, source_text: str, max_terms: int) -> List[str]:
    """
    Keep only spans that are literal substrings of the source text.

    matched_terms is quoted to customers. A paraphrased span is a fabricated
    quote attributed to a real reviewer, which is worse than no quote at all.

    Under the keyword design this was guaranteed structurally — only matched
    keywords were collected. Under an LLM it has to be enforced, and it is now
    the ONLY mechanical link between what the model claims and what the customer
    wrote, so an entry left with nothing here is dropped entirely by the caller.

    Case-insensitive, because models routinely fix a reviewer's capitalisation.
    The span STORED is the model's, but only once it is proven to exist.
    """
    if not isinstance(raw, (list, tuple)) or not source_text:
        return []
    haystack = source_text.lower()
    out: List[str] = []
    for term in raw:
        span = str(term or "").strip()
        if span and span.lower() in haystack and span not in out:
            out.append(span)
    return out[:max_terms]


# =============================================================================
# RESPONSE PARSING
# =============================================================================

_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.DOTALL)


def _extract_json_object(raw: str) -> Optional[dict]:
    """
    Raw model text -> dict, or None.

    Two passes. The fence strip handles the common case (a model that adds
    ```json despite being told not to); the brace slice handles a model that
    prefixes prose. Anything else is unparseable and the caller logs it.
    """
    if not raw or not isinstance(raw, str):
        return None
    cleaned = _FENCE_RE.sub("", raw).strip()
    try:
        obj = json.loads(cleaned)
        return obj if isinstance(obj, dict) else None
    except (ValueError, json.JSONDecodeError):
        pass

    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        obj = json.loads(cleaned[start : end + 1])
        return obj if isinstance(obj, dict) else None
    except (ValueError, json.JSONDecodeError):
        return None


def _parse_response(
    raw: str,
    source_text: str,
    alias_map: Dict[str, str],
    severity_defaults: Dict[str, str],
    opts: Dict[str, Any],
) -> Optional[List[dict]]:
    """
    One raw reply -> a list of validated issue records, or None.

    Returns None only when the reply could not be parsed at all. An empty LIST
    is a real, common and cacheable answer: most reviews report no problem, and
    with no keyword gate every one of them reaches the model.

    The distinction matters at the call site — None is retried next run, [] is
    cached forever.
    """
    obj = _extract_json_object(raw)
    if obj is None:
        return None

    if _PYDANTIC_AVAILABLE:
        try:
            entries = IssueReply.model_validate(obj).issues
        except ValidationError as error:
            # The ENVELOPE is malformed — there is no `issues` list to read.
            # Nothing is salvageable, so this is a genuine parse failure and the
            # row is retried next run rather than cached.
            logger.debug("Issue reply envelope failed validation: %s", error)
            return None
    else:
        entries = obj.get("issues")
        if not isinstance(entries, list):
            return None

    min_confidence = opts["min_confidence"]
    records: List[dict] = []
    seen_keys = set()

    for raw_entry in entries:
        if not isinstance(raw_entry, dict):
            continue

        # Per-entry validation: a malformed entry is skipped, and its siblings
        # survive. Validating the whole list instead would mean one bad field
        # discarding every good issue found in the same review.
        if _PYDANTIC_AVAILABLE:
            try:
                entry = IssueRecord.model_validate(raw_entry).model_dump()
            except ValidationError as error:
                logger.debug("Skipping malformed issue entry: %s", error)
                continue
        else:
            entry = raw_entry

        raw_key = _snake(str(entry.get("issue_key") or ""))
        if not raw_key:
            continue

        # Canonicalize. An unmatched key passes through UNCHANGED and is KEPT —
        # it may be the model correctly naming something the taxonomy has no
        # word for, which is the whole point of the LLM-primary design.
        canonical = alias_map.get(raw_key, raw_key)
        is_novel = raw_key not in alias_map

        # One entry per problem. A model that repeats a key has split one
        # problem in two; keep the first, which the prompt orders by appearance.
        if canonical in seen_keys:
            continue

        confidence = _clamp_confidence(entry.get("confidence"))
        if confidence < min_confidence:
            # The prompt tells the model not to emit below this. Enforce it:
            # the model is not bound by its own prompt.
            continue

        matched_terms = _ground_terms(
            entry.get("matched_terms"), source_text, opts["max_matched_terms"],
        )
        if not matched_terms:
            # THE load-bearing rejection. Under the keyword design an entry had
            # to survive two independent checks — naming a candidate the scan
            # had already found, AND quoting the text. Only the second remains,
            # so an entry that cannot be quoted is dropped, not merely
            # un-quoted.
            continue

        seen_keys.add(canonical)
        records.append({
            "issue_key":          canonical,
            "is_novel_key":       is_novel,
            "issue_tags":         _normalize_tags(entry.get("issue_tags"),
                                                  opts["issue_tags_max"]),
            "affected_component": (str(entry.get("affected_component") or "").strip()
                                   or None),
            "severity":           _coerce_severity(entry.get("severity"), canonical,
                                                   severity_defaults),
            "severity_reason":    (str(entry.get("severity_reason") or "").strip()
                                   or None),
            "confidence":         round(confidence, 4),
            "confidence_band":    _confidence_band(confidence),
            "sentiment_score":    _clamp_sentiment(entry.get("sentiment_score"),
                                                   opts["sentiment_min"],
                                                   opts["sentiment_max"]),
            "resolution_status":  _coerce_resolution(entry.get("resolution_status")),
            "time_bound":         bool(entry.get("time_bound")),
            "root_cause":         (str(entry.get("root_cause") or "").strip() or None),
            "matched_terms":      matched_terms,
        })

    return records


def make_parse_response_udf(
    alias_map: Dict[str, str],
    severity_defaults: Dict[str, str],
    opts: Dict[str, Any],
):
    """
    Pandas UDF: (raw reply, source text) -> ARRAY<STRUCT<...>>.

    alias_map, severity_defaults and opts are resolved on the DRIVER and ride to
    the executors inside this closure. Nothing inside reads YAML, a secret or an
    env var — Spark workers have no Databricks auth context and the config file
    is not guaranteed to resolve there either. Same rule, same reason, as
    faq_tagging.make_parse_response_udf and build_issue_signals_udf.

    A NULL return means "unparseable, retry next run". An empty array means "the
    model found nothing", which is a real answer and gets cached.
    """

    @F.pandas_udf(PARSED_SCHEMA)
    def _parse(raw: pd.Series, source_text: pd.Series) -> pd.Series:
        out = [
            _parse_response(r, t, alias_map, severity_defaults, opts)
            for r, t in zip(raw, source_text)
        ]
        # dtype='object' explicitly: an all-None column infers float64, which
        # cannot convert to an Arrow array column and takes the partition with
        # it. All-None is normal when a whole batch fails.
        return pd.Series(out, index=raw.index, dtype="object")

    return _parse


# =============================================================================
# VERTEX AI (GEMMA MaaS) BACKEND
# =============================================================================
#
# See the import block at the top for why the client is NOT shared with
# faq_tagging. Everything else about the contract is identical: every credential
# and config value is resolved on the DRIVER (vertex_settings) and travels to
# the executors inside the UDF's closure.

_vertex_llm = None       # per-PROCESS cache: one client per executor, not per batch
_vertex_settings = None  # driver-side cache, so the secret is fetched once a run


def vertex_settings() -> Dict[str, Any]:
    """
    DRIVER ONLY. Everything the tagging UDF needs, as plain picklable values.

    `sa_info` is a private key serialized into the task closure. That is the
    pattern Databricks documents for this problem (fetch on the driver, pass as
    an argument) and it stays inside the workspace, but it is worth knowing.

    Cached with the same lifetime as _ensure_config, so a mid-session config
    change is picked up by neither and one run cannot straddle two configs.
    """
    global _vertex_settings
    if _vertex_settings is not None:
        return _vertex_settings

    cfg = _ensure_config()
    vertex = cfg["VERTEX"]
    _vertex_settings = {
        "model": vertex["model"],
        "project": vertex["project"],
        "location": vertex["location"],
        "temperature": cfg["TEMPERATURE"],
        "max_concurrency": int(vertex.get("max_concurrency", DEFAULT_MAX_CONCURRENCY)),
        "max_output_tokens": int(vertex.get("max_output_tokens", DEFAULT_MAX_OUTPUT_TOKENS)),
        "timeout_s": float(vertex.get("timeout_s", DEFAULT_TIMEOUT_S)),
        "json_mode": bool(vertex.get("json_mode", False)),
        "sa_info": _load_service_account_info(
            vertex["secret_scope"], vertex["secret_key"],
        ),
    }
    return _vertex_settings


def _build_vertex_llm(settings: Dict[str, Any]):
    """
    Build the Vertex client from plain values (no config or secret reads).
    Cached on executors only, so no live client is pickled into the UDF closure.
    """
    global _vertex_llm
    if _vertex_llm is not None:
        return _vertex_llm

    from google.oauth2 import service_account
    from langchain_google_genai import ChatGoogleGenerativeAI

    credentials = service_account.Credentials.from_service_account_info(
        settings["sa_info"],
        scopes=["https://www.googleapis.com/auth/cloud-platform"],
    )
    json_kwargs = (
        # Constrained decoding: the endpoint may only emit valid JSON, so there
        # is no prose to strip. Outside the cache key: answers mean the same.
        {"response_mime_type": "application/json"} if settings.get("json_mode") else {}
    )
    llm = ChatGoogleGenerativeAI(
        model=settings["model"],
        vertexai=True,
        project=settings["project"],
        location=settings["location"],
        credentials=credentials,
        temperature=settings["temperature"],
        # Explicit, not the endpoint default: a reply cut off mid-JSON is
        # unparseable. The invoke UDF labels any that still hit it.
        max_output_tokens=settings.get("max_output_tokens", DEFAULT_MAX_OUTPUT_TOKENS),
        # Without it, a call that never answers holds its batch, and so the run, forever
        timeout=settings.get("timeout_s", DEFAULT_TIMEOUT_S),
        **json_kwargs,
    )

    if TaskContext.get() is not None:
        # Executor: cache for the life of this Python worker process.
        _vertex_llm = llm
    return llm


def make_vertex_invoke_udf(settings: Dict[str, Any]):
    """
    Pandas UDF: ai_prompt (string) -> raw model response text (string).

    Writes the `ai_query_raw` column the parser reads. The name is faq_tagging's
    and is historical — Gemma MaaS cannot be reached through ai_query at all.

    return_exceptions=True so one bad row degrades instead of failing the whole
    batch. A failed call comes back as VERTEX_ERROR_MARK + its error class, not
    a reply: callers MUST map that to NULL before parsing (see tag_issues).
    """
    max_concurrency = settings["max_concurrency"]

    @F.pandas_udf(StringType())
    def _invoke(prompts: pd.Series) -> pd.Series:
        nulls = pd.Series([None] * len(prompts), index=prompts.index, dtype="object")
        if prompts.empty:
            return nulls

        try:
            llm = _build_vertex_llm(settings)
        except Exception as error:
            logger.error("Vertex client construction failed on executor (%s)", error)
            return pd.Series(
                [f"{VERTEX_ERROR_MARK}client construction failed"] * len(prompts),
                index=prompts.index, dtype="object",
            )

        try:
            responses = llm.batch(
                list(prompts),
                config={"max_concurrency": max_concurrency},
                return_exceptions=True,
            )
        except Exception as error:
            logger.error("Vertex batch invoke failed for a partition (%s)", error)
            return pd.Series(
                [f"{VERTEX_ERROR_MARK}batch invoke failed"] * len(prompts),
                index=prompts.index, dtype="object",
            )

        failures = sum(1 for r in responses if isinstance(r, BaseException))
        if failures:
            # One line per partition, not per row: a rate-limited batch would
            # otherwise bury the executor log in identical warnings.
            logger.warning(
                "Vertex: %d/%d rows failed in this partition (first: %s)",
                failures, len(responses),
                next(r for r in responses if isinstance(r, BaseException)),
            )
        series = _vertex_responses_to_series(responses, prompts.index)
        # Carry each failure's class to the driver; the parse step turns the
        # marker back into NULL, so nothing downstream changes.
        for pos, response in enumerate(responses[: len(series)]):
            if isinstance(response, BaseException):
                code = re.search(r"\b([45]\d\d)\b", str(response))
                series.iloc[pos] = (
                    f"{VERTEX_ERROR_MARK}{type(response).__name__}"
                    f" {code.group(1) if code else ''}"
                ).rstrip()
            elif str((getattr(response, "response_metadata", None) or {})
                     .get("finish_reason", "")).upper().endswith("MAX_TOKENS"):
                # Cut off mid-JSON: not a model judgement, never cache it.
                series.iloc[pos] = f"{VERTEX_ERROR_MARK}truncated (MAX_TOKENS)"
        return series

    # ai_query_raw is read by several columns (_records, _llm_error,
    # _bad_reply). Nondeterministic guarantees the optimizer never inlines the
    # call into each of them — which would mean one PAID call per reference.
    return _invoke.asNondeterministic()


def _vertex_reply(col: str = "ai_query_raw") -> "F.Column":
    """The model's reply, or NULL when the call failed (VERTEX_ERROR_MARK).

    The marker must never reach a parser: an error body can carry JSON, and a
    parsed "{}" would be cached as a real "no issue" answer.
    """
    return F.when(F.col(col).startswith(VERTEX_ERROR_MARK), F.lit(None)).otherwise(F.col(col))


def _vertex_error(col: str = "ai_query_raw") -> "F.Column":
    """The failed call's error class ("ChatGoogleGenerativeAIError 429"), else NULL."""
    return F.when(
        F.col(col).startswith(VERTEX_ERROR_MARK),
        F.substring_index(F.col(col), VERTEX_ERROR_MARK, -1),
    )


def _failure_causes(parsed: DataFrame, result_col: str, limit: int = 3) -> str:
    """Top reasons a materialised batch has no result: the Vertex error class, else bad JSON."""
    rows = (
        parsed.filter(F.col(result_col).isNull())
        .groupBy(F.coalesce(F.col("_llm_error"), F.lit("bad JSON")).alias("cause"))
        .agg(F.count("*").alias("n"))
        .orderBy(F.desc("n"))
        .limit(limit)
        .collect()
    )
    return ", ".join(f"{row['n']}× {row['cause']}" for row in rows)


def validate_vertex(settings: Dict[str, Any]) -> None:
    """
    Driver-side pre-flight. One real round trip, so bad credentials, a wrong
    project/location or an unavailable model fail in a second rather than after
    a full source load and a wasted tagging pass.
    """
    logger.info("[Pre-flight] Validating Vertex model '%s'...", settings["model"])
    try:
        response = _build_vertex_llm(settings).invoke(
            "Respond with exactly one word: ready"
        )
    except Exception as error:
        raise RuntimeError(
            f"Vertex validation FAILED for model '{settings['model']}' "
            f"(project={settings['project']}, location={settings['location']}). "
            f"Issue tagging will NOT run. Root cause: {error}"
        ) from error

    if not str(getattr(response, "content", "") or "").strip():
        raise RuntimeError(
            f"Vertex model '{settings['model']}' returned a null/empty response "
            "on probe query."
        )
    logger.info("  Vertex model '%s' is reachable and responding.", settings["model"])


def validate_executors(spark: SparkSession) -> None:
    """
    Executor-side pre-flight: check the workers can import the Vertex client libraries.
    """
    logger.info("[Pre-flight] Checking the Vertex client imports on executors...")

    def _probe(_):
        try:
            import langchain_google_genai  # noqa: F401
            from google.oauth2 import service_account  # noqa: F401
        except Exception as error:  # ImportError, but also a broken install
            return [f"{type(error).__name__}: {error}"]
        return []

    probes = 8
    try:
        failures = (
            spark.sparkContext.parallelize(range(probes), probes)
            .mapPartitions(_probe)
            .collect()
        )
    except Exception as error:
        # A probe job that will not even launch is a cluster problem, not a
        # library problem. Say so rather than blaming the import.
        raise RuntimeError(
            f"Executor pre-flight could not run ({error}). Issue tagging needs "
            "working executors; it will NOT run."
        ) from error

    if failures:
        raise RuntimeError(
            "langchain_google_genai / google-auth is NOT importable on the "
            f"executors ({failures[0]}). The driver has it — that is why the "
            "Vertex probe passed — but the tagging UDF runs on the workers, "
            "where it would return NULL for every row and surface only as "
            "'all replies unparseable' after a full pass. Install the library "
            "on the CLUSTER (cluster libraries or the job's environment), not "
            "just in the notebook session."
        )

    logger.info("  Vertex client imports cleanly on the executors.")


# =============================================================================
# LLM CACHE  (the only volume lever — there is no keyword gate)
# =============================================================================

def with_signal_id(df: DataFrame, model_name: str) -> DataFrame:
    """
    Content-addressed cache key over review_text, category, prompt_version and model.
    """
    return df.withColumn(
        "signal_id",
        F.sha2(
            F.concat_ws(
                "||",
                F.coalesce(F.col("review_text"), F.lit("")),
                F.coalesce(F.col("category"), F.lit("")),
                F.lit(ISSUE_TAGGING_PROMPT_VERSION),
                F.lit(model_name),
            ),
            256,
        ),
    )


def split_on_cache(spark: SparkSession, df: DataFrame, cache_table: Optional[str]):
    """
    Left-join + boolean, not two anti-joins: one shuffle instead of two.

    Every degradation path costs money rather than correctness — a missing or
    unreadable cache classifies everything, which is expensive and right.
    """
    def _all_misses() -> DataFrame:
        return df.withColumn("_cache_hit", F.lit(False)).withColumn(
            "issues_json", F.lit(None).cast(StringType())
        )

    if not cache_table:
        logger.info("No LLM cache configured — every row will be classified.")
        return _all_misses()

    # A cache that does not exist yet is the NORMAL first run, not a fault:
    # write_cache creates it with saveAsTable at the end of this pass. Logging
    # it as a warning with a full UnresolvedRelation dump sends people hunting
    # for a misconfiguration that is not there.
    try:
        exists = spark.catalog.tableExists(cache_table)
    except Exception:
        # A missing CATALOG or SCHEMA raises here rather than returning False.
        # That IS worth a warning — it usually means a wrong {env} expansion.
        exists = None

    if exists is False:
        logger.info(
            "LLM cache %s does not exist yet — classifying all rows. The table "
            "is created at the end of this run.", cache_table,
        )
        return _all_misses()

    try:
        cache = (
            spark.table(cache_table)
            .filter(F.col("cache_kind") == F.lit("issue"))
            .select(
                F.col("cache_key").alias("signal_id"),
                F.col("payload_json").alias("issues_json"),
            )
        )
    except Exception as error:
        logger.warning(
            "LLM cache %s unreadable (%s) — classifying all rows", cache_table, error,
        )
        return _all_misses()

    return (
        df.join(cache, on="signal_id", how="left")
          .withColumn("_cache_hit", F.col("issues_json").isNotNull())
    )


def cache_rows(parsed: DataFrame, model_name: str) -> DataFrame:
    """
    The cache projection of one tagged batch.

    `parsed` must already be materialised (cached and counted) before this is
    called: the LLM-call lineage is still in its plan, and building this on a
    lazy frame re-issues every paid call.
    """
    return (
        parsed
        .filter(F.col("_records").isNotNull())   # never cache a parse failure
        .select(
            "signal_id",
            F.to_json(F.col("_records")).alias("issues_json"),
            F.lit(ISSUE_TAGGING_PROMPT_VERSION).alias("prompt_version"),
            F.lit(model_name).alias("model"),
            F.date_format(F.current_timestamp(), "yyyy-MM-dd HH:mm:ss")
             .alias("created_at"),
        )
        .dropDuplicates(["signal_id"])
    )


def _write_cache_entries(
    spark: SparkSession, to_cache: DataFrame, cache_table: Optional[str],
) -> bool:
    """
    Insert entries keyed by kind and content without replacing another pass's cache.

    Returns True only when the entries landed, so a caller can drop its own copy
    of them and read them back from the cache instead.
    """
    if not cache_table:
        return False
    view_name = f"_llm_cache_updates_{uuid.uuid4().hex}"
    try:
        to_cache = to_cache.dropDuplicates(["cache_kind", "cache_key"])
        # Validate first: this MERGE has no schema evolution.
        validate_before_write(spark, cache_table, to_cache.schema)
        if spark.catalog.tableExists(cache_table):
            to_cache.createOrReplaceTempView(view_name)
            spark.sql(f"""
                MERGE INTO {cache_table} AS t
                USING {view_name} AS s
                  ON t.cache_kind = s.cache_kind AND t.cache_key = s.cache_key
                WHEN NOT MATCHED THEN INSERT *
            """)
        else:
            to_cache.write.format("delta").saveAsTable(cache_table)
        logger.info("LLM cache updated: %s", cache_table)
        return True
    except Exception as error:
        logger.warning("LLM cache write to %s failed (%s)", cache_table, error)
        return False
    finally:
        try:
            spark.catalog.dropTempView(view_name)
        except Exception:
            pass


def write_cache(spark: SparkSession, to_cache: DataFrame, cache_table: Optional[str]) -> bool:
    """Store issue responses in the shared cache without replacing conflict entries."""
    if not cache_table:
        return False
    return _write_cache_entries(
        spark,
        to_cache.select(
            F.lit("issue").alias("cache_kind"),
            F.col("signal_id").alias("cache_key"),
            F.col("issues_json").alias("payload_json"),
            "prompt_version", "model", "created_at",
        ),
        cache_table,
    )


# =============================================================================
# MAIN TAGGING PASS
# =============================================================================

def _fold_component_synonyms(df: DataFrame) -> DataFrame:
    """
    Merge names for the same part within one (product_id, issue_key) group:
    A. spelling variants (underscores, trailing "s") fold to the snake_case singular;
    B. a bare word folds into the one longer name ending with it ("towel" -> "paper_towel").
    Ambiguous candidates are left as is; NULLs are skipped.
    """
    group = Window.partitionBy("product_id", "issue_key")
    comp = F.col("affected_component")

    def _word(c):
        return F.regexp_replace(F.regexp_replace(c, "_", ""), "s$", "")

    # --- rule A: one canonical spelling per word ----------------------------
    df = df.withColumn("_comps", F.collect_set("affected_component").over(group))
    df = df.withColumn(
        "affected_component",
        F.when(
            comp.isNotNull(),
            F.element_at(
                F.transform(
                    F.array_sort(F.transform(
                        F.filter("_comps", lambda o: _word(o) == _word(comp)),
                        lambda o: F.struct(
                            (F.instr(o, "_") == 0).alias("no_underscore"),
                            o.endswith("s").alias("plural"),
                            o.alias("value"),
                        ),
                    )),
                    lambda x: x["value"],
                ),
                1,
            ),
        ),
    )

    # --- rule B: bare word -> the one compound whose head it is -------------
    # Re-collected: the set must be the rule-A spellings, not the raw ones.
    df = df.withColumn("_comps", F.collect_set("affected_component").over(group))
    heads = F.filter(
        "_comps", lambda o: o.endswith(F.concat(F.lit("_"), comp)),
    )
    df = df.withColumn(
        "affected_component",
        F.when(F.size(heads) == 1, F.element_at(heads, 1)).otherwise(comp),
    )
    return df.drop("_comps")


def tag_issues(
    spark: SparkSession,
    rows_df: DataFrame,
    issue_cfg: dict,
    batch_size: Optional[int] = None,
    num_partitions: Optional[int] = None,
    use_cache: bool = True,
) -> Optional[DataFrame]:
    """
    Run the Vertex tagging UDF over rows_df and parse the results.

    Args:
        spark:          Active SparkSession.
        rows_df:        product_id, source, source_id, source_create_dt, category, review_text.
        issue_cfg:      Parsed issue_keywords.yaml (alias map, severity defaults).
        batch_size:     Distinct texts per model pass (review_mining.llm.issue_batch_size).
        num_partitions: Throughput knob; in-flight calls = num_partitions x max_concurrency.
        use_cache:      False forces a full re-classification.

    Returns:
        One row per detected issue (source columns, review_text, ISSUE_RECORD_SCHEMA
        fields, model_endpoint, created_at_ts), or None when nothing was tagged.
    """
    cfg = _ensure_config()
    batch_size = batch_size or cfg["ISSUE_BATCH_SIZE"]
    num_partitions = num_partitions or cfg["NUM_PARTITIONS"]
    cache_table = cfg["CACHE_TABLE"] if use_cache else None

    rows_df = rows_df.cache()
    total_rows = rows_df.count()
    if total_rows == 0:
        logger.info("No rows to tag for issues.")
        rows_df.unpersist()
        return None

    # --- driver-side artefacts, all run-constant ----------------------------
    # Issue types are open: the prompt carries only a few example keys. The YAML
    # canonicalizes the model's keys and backstops severity after the reply.
    issues = issue_cfg.get("issues", []) or []
    alias_map = build_alias_map(issues)
    severity_defaults = build_severity_defaults(issues)
    logger.info(
        "Issue types: open (alias map from %d known issues, applied post-reply)",
        len(issues),
    )

    # Settings resolved ONCE, not per batch, so a mid-run config change cannot
    # alter the model halfway through a pipeline.
    vertex_cfg = vertex_settings()
    model_name = vertex_cfg["model"]

    # --- cache split --------------------------------------------------------
    keyed = with_signal_id(
        rows_df.select(
            "product_id", "source", "source_id", "source_create_dt",
            "category", "review_text",
        ),
        model_name,
    )
    scored = split_on_cache(spark, keyed, cache_table).cache()
    cache_hits = scored.filter(F.col("_cache_hit"))
    cache_misses = scored.filter(~F.col("_cache_hit")).drop("issues_json")

    n_miss = cache_misses.count()
    n_hit = scored.count() - n_miss
    logger.info(
        "LLM cache: %d hit / %d miss (%.1f%% hit rate)",
        n_hit, n_miss, (100.0 * n_hit / max(1, n_hit + n_miss)),
    )

    parse_opts = {
        "issue_tags_max":    cfg["ISSUE_TAGS_MAX"],
        "sentiment_min":     cfg["SENTIMENT_MIN"],
        "sentiment_max":     cfg["SENTIMENT_MAX"],
        "min_confidence":    cfg["MIN_CONFIDENCE"],
        "max_matched_terms": cfg["MAX_MATCHED_TERMS"],
    }
    parse_udf = make_parse_response_udf(alias_map, severity_defaults, parse_opts)

    # Batches whose cache write did not land; the rest are read back from the
    # cache after the loop.
    tagged_batches: List[DataFrame] = []
    cached_batches = 0

    if n_miss > 0:
        # Before the first paid call, not after the last failed batch.
        validate_executors(spark)

        prompt_sql = build_issue_tagging_prompt_sql(
            view_name="_issue_tagging_batch_placeholder",
            max_review_chars=cfg["MAX_REVIEW_CHARS"],
            issue_tags_min=cfg["ISSUE_TAGS_MIN"],
            issue_tags_max=cfg["ISSUE_TAGS_MAX"],
            sentiment_min=cfg["SENTIMENT_MIN"],
            sentiment_max=cfg["SENTIMENT_MAX"],
        )
        invoke_col = make_vertex_invoke_udf(vertex_cfg)(F.col("ai_prompt"))

        # crc32 buckets on signal_id give balanced, driver-free batches.
        # One model call per signal_id; results fan back out to rows at assembly.
        n_unique = cache_misses.select("signal_id").distinct().count()
        num_batches = max(1, (n_unique + batch_size - 1) // batch_size)
        numbered = cache_misses.dropDuplicates(["signal_id"]).withColumn(
            "_batch", F.pmod(F.crc32(F.col("signal_id")), F.lit(num_batches))
        ).cache()
        numbered.count()

        # Running tasks are capped by executor cores, not by partitions: on
        # 8 × DS3_v2 that is 32, whatever num_partitions says.
        running_tasks = min(num_partitions, spark.sparkContext.defaultParallelism)
        logger.info(
            "Tagging %d distinct texts (%d rows) in %d batch(es) of up to %d, "
            "%d running tasks × %d concurrency = %d calls in flight",
            n_unique, n_miss, num_batches, batch_size, running_tasks,
            vertex_cfg["max_concurrency"],
            running_tasks * vertex_cfg["max_concurrency"],
        )

        failed = 0
        for batch_idx in range(num_batches):
            view_name = f"_issue_tagging_batch_{uuid.uuid4().hex[:8]}"
            batch_sql = prompt_sql.replace(
                "_issue_tagging_batch_placeholder", view_name,
            )
            batch_df = numbered.filter(F.col("_batch") == F.lit(batch_idx)).select(
                "signal_id", "product_id", "source", "source_id",
                "source_create_dt", "category", "review_text",
            )
            # repartition HERE, not on the whole frame: this is the only stage
            # whose width is set by call latency rather than data volume.
            batch_df = batch_df.repartition(num_partitions)
            batch_df.createOrReplaceTempView(view_name)

            batch_rows = batch_df.count()
            logger.info(
                "Batch %d/%d: running %d rows",
                batch_idx + 1, num_batches, batch_rows,
            )

            try:
                # spark.sql() is LAZY — no model call yet.
                raw = spark.sql(batch_sql).withColumn("ai_query_raw", invoke_col)
                parsed = (
                    raw
                    .withColumn(
                        "_records",
                        parse_udf(_vertex_reply(), F.col("review_text")),
                    )
                    # Log-only: why a row has no _records. cache_rows and the
                    # read-back select explicit columns, so it is never stored.
                    .withColumn("_llm_error", _vertex_error())
                    # Log-only: a reply that came back but did not parse. Whole
                    # reply when <= 1,600 chars (~99.9% of real replies: every
                    # 1-2 issue reply, ~99% of 3-issue ones); longer ones keep
                    # head AND tail, since prose sits at the start and
                    # truncation or trailing text at the end.
                    .withColumn("_bad_reply", F.when(
                        F.col("_records").isNull() & F.col("_llm_error").isNull(),
                        F.concat(
                            F.lit("["), F.length("ai_query_raw").cast("string"),
                            F.lit(" chars] "),
                            F.when(F.length("ai_query_raw") <= 1600, F.col("ai_query_raw"))
                             .otherwise(F.concat(
                                 F.substring("ai_query_raw", 1, 800),
                                 F.lit(" … "),
                                 F.expr("right(ai_query_raw, 800)"),
                             )),
                        ),
                    ))
                    .select(
                        "signal_id", "product_id", "source", "source_id",
                        "source_create_dt", "review_text", "_records", "_llm_error",
                        "_bad_reply",
                    )
                )
                # Force execution NOW so model/permission errors surface inside
                # this try/except rather than later during the write.
                parsed = parsed.cache()
                batch_count = parsed.count()

                if batch_count == 0:
                    failed += 1
                    logger.error(
                        "Batch %d/%d FAILED: 0 rows after the model pass",
                        batch_idx + 1, num_batches,
                    )
                    parsed.unpersist()
                    continue

                unparseable = parsed.filter(F.col("_records").isNull()).count()
                causes = _failure_causes(parsed, "_records") if unparseable else ""
                if unparseable:
                    # Two real bad replies per batch, so the cause is seen, not
                    # guessed. A limit(2) over the already-cached batch.
                    for row in (parsed.filter(F.col("_bad_reply").isNotNull())
                                .limit(2).collect()):
                        logger.warning(
                            "Batch %d/%d bad JSON sample: %r",
                            batch_idx + 1, num_batches, row["_bad_reply"],
                        )
                if unparseable == batch_count:
                    failed += 1
                    logger.error(
                        "Batch %d/%d FAILED: all %d replies unparseable [%s] on "
                        "'%s'.",
                        batch_idx + 1, num_batches, batch_count, causes, model_name,
                    )
                    parsed.unpersist()
                    continue
                if unparseable:
                    logger.warning(
                        "Batch %d/%d: %d/%d replies unparseable [%s] — NOT "
                        "cached; retried only when the product is next in scope",
                        batch_idx + 1, num_batches, unparseable, batch_count, causes,
                    )

                # Cache this batch now so a later failure does not re-bill it.
                if write_cache(spark, cache_rows(parsed, model_name), cache_table):
                    # Landed: the re-split after the loop reads it back. Keeping
                    # every batch cached for the whole run grew executor memory
                    # batch over batch, and each lost worker recomputed its
                    # blocks — re-issuing paid model calls.
                    cached_batches += 1
                    parsed.unpersist()
                else:
                    # No cache, or the write failed: this copy is the only one.
                    tagged_batches.append(parsed)

                logger.info(
                    "Batch %d/%d done — %d/%d rows parsed",
                    batch_idx + 1, num_batches, batch_count - unparseable, batch_count,
                )
            except Exception as error:
                failed += 1
                logger.error("Batch %d/%d FAILED: %s", batch_idx + 1, num_batches, error)
            finally:
                try:
                    spark.catalog.dropTempView(view_name)
                except Exception:
                    pass

        logger.info("Batches: %d succeeded, %d failed", num_batches - failed, failed)
        numbered.unpersist()

    # --- assemble: fresh results + cache hits -------------------------------
    # No bulk cache write here: each batch wrote itself as it finished, so a
    # run that dies partway keeps everything it already paid for.

    # Re-split against the cache now holding this run's batches: every cached
    # result comes back as a hit, joined by signal_id onto EVERY row sharing it.
    if cached_batches:
        scored.unpersist()
        scored = split_on_cache(spark, keyed, cache_table).cache()
        cache_hits = scored.filter(F.col("_cache_hit"))
        n_hit = cache_hits.count()
        logger.info(
            "LLM cache re-read: %d of %d rows now hit (%d batch(es) written this run)",
            n_hit, total_rows, cached_batches,
        )

    # Batches that never reached the cache hold one row per signal_id; join
    # them onto `keyed` to fan back out. `keyed`, not `cache_misses`: the latter
    # re-derives from the cache join, which this run has since changed.
    fresh = None
    if tagged_batches:
        fresh_records = reduce(
            DataFrame.unionByName,
            [batch.select("signal_id", "_records") for batch in tagged_batches],
        )
        fresh = keyed.join(fresh_records, on="signal_id", how="inner")

    hits = cache_hits.select(
        "signal_id", "product_id", "source", "source_id", "source_create_dt",
        "review_text",
        F.from_json(F.col("issues_json"), PARSED_SCHEMA).alias("_records"),
    )

    if fresh is None and n_hit == 0:
        logger.error("No batches succeeded and no cache hits — nothing to return.")
        scored.unpersist()
        rows_df.unpersist()
        return None

    combined = (
        hits if fresh is None
        else (fresh.select(*hits.columns) if n_hit == 0
              else fresh.select(*hits.columns).unionByName(hits))
    )

    # --- explode to one row per detected issue ------------------------------
    now_ts = F.lit(datetime.now(timezone.utc))
    result_df = (
        combined
        .filter(F.col("_records").isNotNull() & (F.size("_records") > 0))
        .select(
            "product_id", "source", "source_id", "source_create_dt", "review_text",
            F.explode("_records").alias("r"),
        )
        .select(
            "product_id", "source", "source_id", "source_create_dt", "review_text",
            F.col("r.*"),
        )
        # "(unknown)" -> NULL. Done here, not in the parse UDF, because this is
        # where fresh results and cache hits meet: the cache holds PARSED
        # records, so a parser-only fix would leave every cached "(unknown)" in
        # place until a prompt-version bump re-paid for all of them.
        .withColumn(
            "root_cause",
            F.when(
                F.lower(F.trim(F.col("root_cause"))) != F.lit(ROOT_CAUSE_UNKNOWN),
                F.col("root_cause"),
            ),
        )
        # affected_component, here for the same cache reason. First to the lower
        # snake_case the prompt asks for: the model sometimes answers
        # "paper towel" for "paper_towel", which splits one part's count in two.
        # Then placeholder -> NULL, so a mention that names no part counts as
        # unattributed instead of ranking as a part called "(none)".
        .withColumn(
            "affected_component",
            F.regexp_replace(
                F.lower(F.trim(F.col("affected_component"))), r"[\s\-]+", "_",
            ),
        )
        .withColumn(
            "affected_component",
            F.when(
                ~F.col("affected_component").isin(*COMPONENT_PLACEHOLDERS),
                F.col("affected_component"),
            ),
        )
    )
    result_df = _fold_component_synonyms(result_df)
    result_df = (
        result_df
        .withColumn("model_endpoint", F.lit(model_name))
        .withColumn("created_at_ts", now_ts)
    )

    # Materialise BEFORE unpersisting upstream. The caller runs at least two
    # actions on this frame, and the model-call lineage is still in the plan —
    # leaving it lazy over evicted caches risks re-issuing paid model calls.
    result_df = result_df.cache()
    n_issues = result_df.count()

    scored.unpersist()
    rows_df.unpersist()
    for batch in tagged_batches:
        batch.unpersist()

    logger.info(
        "Issue tagging produced %d issue records from %d rows (%.2f issues/row)",
        n_issues, total_rows, n_issues / max(1, total_rows),
    )
    return result_df


# =============================================================================
# CONFLICT DETECTION  (second pass — one call per (product_id, issue_key) group)
# =============================================================================
#
# Separate pass because a single-review call cannot see reviewers disagreeing.
# Gated at CONFLICT_MIN_MENTIONS; verdicts are cached on the evidence content.


def _build_evidence_text(max_excerpts: int):
    """
    Numbered excerpt block ("[1] span\\n[2] span...") from the group's `_spans`,
    sorted, deduped and capped so it is stable inside the cache key.
    """
    capped = F.slice(F.array_sort(F.array_distinct(F.col("_spans"))), 1, max_excerpts)
    return F.array_join(
        F.transform(
            capped,
            lambda span, i: F.concat(
                F.lit("["), (i + F.lit(1)).cast("string"), F.lit("] "), span,
            ),
        ),
        "\n",
    )


def with_conflict_id(df: DataFrame, model_name: str) -> DataFrame:
    """
    Content-addressed cache key for one conflict verdict over evidence_text,
    issue_key and affected_component (coalesced to "unspecified"); product_id is not hashed.
    """
    return df.withColumn(
        "conflict_id",
        F.sha2(
            F.concat_ws(
                "||",
                F.coalesce(F.col("evidence_text"), F.lit("")),
                F.coalesce(F.col("issue_key"), F.lit("")),
                F.coalesce(F.col("affected_component"), F.lit("unspecified")),
                F.lit(ISSUE_CONFLICT_PROMPT_VERSION),
                F.lit(model_name),
            ),
            256,
        ),
    )


def _parse_conflict_response(raw: str) -> Optional[bool]:
    """
    Raw model text -> True / False / None.

    None means "no usable verdict" and is NOT False, following
    faq_tagging._clean_bool. review_mining coalesces it to False when it builds
    the summary — the safe reading — but the two stay distinct up to that point
    so a model that goes quiet on a whole batch is visible in the logs rather
    than indistinguishable from a model that confidently found no conflicts.
    """
    obj = _extract_json_object(raw)
    if obj is None:
        return None
    return _clean_bool(obj.get("conflict_flag"))


def make_conflict_parse_udf():
    """
    Pandas UDF: raw model reply (string) -> conflict verdict (boolean, nullable).

    Mirrors make_parse_response_udf's shape. No closure state is needed here —
    the verdict is a single boolean with no vocabulary, thresholds or grounding
    to apply — but it stays a factory so the two passes read the same way.
    """
    @F.pandas_udf(BooleanType())
    def _parse(raw_col: pd.Series) -> pd.Series:
        return pd.Series(
            [_parse_conflict_response(raw) for raw in raw_col],
            index=raw_col.index,
            dtype="object",
        )

    return _parse


def split_on_conflict_cache(
    spark: SparkSession, df: DataFrame, cache_table: Optional[str],
):
    """
    Left-join + boolean, exactly as split_on_cache does for the tagging pass.

    The hit test is on a `_cached` marker column, NOT on conflict_flag itself: a
    cached NULL verdict is a real hit, and testing the value would re-send every
    unparseable group forever.
    """
    def _all_misses() -> DataFrame:
        return (
            df.withColumn("_cache_hit", F.lit(False))
              .withColumn("conflict_flag", F.lit(None).cast(BooleanType()))
        )

    if not cache_table:
        logger.info("No conflict cache configured — every group will be asked.")
        return _all_misses()

    try:
        exists = spark.catalog.tableExists(cache_table)
    except Exception:
        # A missing CATALOG or SCHEMA raises here rather than returning False.
        exists = None

    if exists is False:
        logger.info(
            "Conflict cache %s does not exist yet — asking all groups. The "
            "table is created at the end of this run.", cache_table,
        )
        return _all_misses()

    try:
        cache = (
            spark.table(cache_table)
            .filter(F.col("cache_kind") == F.lit("issue_conflict"))
            .select(
                F.col("cache_key").alias("conflict_id"),
                F.from_json(F.col("payload_json"), "conflict_flag BOOLEAN")
                 .getField("conflict_flag").alias("conflict_flag"),
            )
            .withColumn("_cached", F.lit(True))
            .dropDuplicates(["conflict_id"])
        )
    except Exception as error:
        logger.warning(
            "Conflict cache %s unreadable (%s) — asking all groups",
            cache_table, error,
        )
        return _all_misses()

    return (
        df.join(cache, on="conflict_id", how="left")
          .withColumn("_cache_hit", F.coalesce(F.col("_cached"), F.lit(False)))
          .drop("_cached")
    )


def write_conflict_cache(
    spark: SparkSession, to_cache: DataFrame, cache_table: Optional[str],
) -> bool:
    """Store nullable conflict verdicts in the shared cache's conflict namespace."""
    if not cache_table:
        return False
    return _write_cache_entries(
        spark,
        to_cache.select(
            F.lit("issue_conflict").alias("cache_kind"),
            F.col("conflict_id").alias("cache_key"),
            F.to_json(
                F.struct("conflict_flag"), options={"ignoreNullFields": "false"},
            ).alias("payload_json"),
            "prompt_version", "model", "created_at",
        ),
        cache_table,
    )


def sentiment_conflict_fallback(min_mentions: int = 2):
    """
    No-LLM conflict_flag fallback: true when one (product, issue_key) group has both
    clearly positive and clearly negative sentiment (score 3 excluded).
    Requires `frequency`, `_n_pos` and `_n_neg` in the enclosing aggregation.
    """
    return (
        (F.col("frequency") >= F.lit(min_mentions))
        & (F.col("_n_pos") > 0)
        & (F.col("_n_neg") > 0)
    )


def detect_issue_conflicts(
    spark: SparkSession,
    issues_df: DataFrame,
    batch_size: Optional[int] = None,
    num_partitions: Optional[int] = None,
    use_cache: bool = True,
) -> Optional[DataFrame]:
    """
    Ask the model, per (product_id, issue_key), whether its mentions contradict.

    Args:
        issues_df:      tag_issues output (product_id, issue_key, affected_component, matched_terms).
        batch_size:     Distinct groups per model pass (review_mining.llm.conflict_batch_size).
        num_partitions: Latency knob, as in tag_issues.
        use_cache:      False re-asks every qualifying group.

    Returns:
        product_id, issue_key, conflict_flag for groups reaching CONFLICT_MIN_MENTIONS,
        or None when there is nothing to ask or every batch failed.
    """
    cfg = _ensure_config()
    batch_size = batch_size or cfg["CONFLICT_BATCH_SIZE"]
    num_partitions = num_partitions or cfg["NUM_PARTITIONS"]
    cache_table = cfg["CACHE_TABLE"] if use_cache else None
    min_mentions = cfg["CONFLICT_MIN_MENTIONS"]

    vertex_cfg = vertex_settings()
    model_name = vertex_cfg["model"]

    # --- build one row per qualifying group ---------------------------------
    # Header shows the modal affected_component; the mention gate counts distinct source rows.
    groups = (
        issues_df
        .groupBy("product_id", "issue_key")
        .agg(
            F.count("*").alias("_n"),
            F.countDistinct(F.concat_ws(
                "||",
                F.coalesce(F.col("source"), F.lit("")),
                F.coalesce(F.col("source_id"), F.col("review_text"), F.lit("")),
            )).alias("_distinct_sources"),
            F.flatten(F.collect_list("matched_terms")).alias("_spans"),
            # try_: a group whose mentions all name no part has an EMPTY list
            # here (collect_list drops NULLs), and element_at raises under ANSI.
            F.try_element_at(
                F.transform(
                    F.array_sort(F.transform(
                        F.array_distinct(F.collect_list("affected_component")),
                        lambda v: F.struct(
                            (-F.size(F.filter(
                                F.collect_list("affected_component"),
                                lambda x: x == v,
                            ))).alias("neg_count"),
                            v.alias("value"),
                        ),
                    )),
                    lambda x: x["value"],
                ),
                F.lit(1),
            ).alias("affected_component"),
        )
        .filter(F.col("_distinct_sources") >= F.lit(min_mentions))
        .withColumn("evidence_text", _build_evidence_text(cfg["MAX_CONFLICT_EXCERPTS"]))
        # A group whose mentions collapse to ONE distinct span after the dedupe
        # is the same sentence repeated, not two customers. Asking costs money
        # for a guaranteed false.
        .filter(F.size(F.array_distinct(F.col("_spans"))) >= F.lit(2))
        .select("product_id", "issue_key", "affected_component", "evidence_text")
    )

    keyed = with_conflict_id(groups, model_name).cache()
    total_groups = keyed.count()
    if total_groups == 0:
        logger.info(
            "No issue group reaches %d mentions with distinct evidence — "
            "skipping the conflict pass.", min_mentions,
        )
        keyed.unpersist()
        return None

    scored = split_on_conflict_cache(spark, keyed, cache_table).cache()
    cache_hits = scored.filter(F.col("_cache_hit"))
    cache_misses = scored.filter(~F.col("_cache_hit")).drop("conflict_flag")

    n_miss = cache_misses.count()
    n_hit = scored.count() - n_miss
    logger.info(
        "Conflict pass: %d group(s) at >=%d mentions — cache %d hit / %d miss "
        "(%.1f%% hit rate)",
        total_groups, min_mentions, n_hit, n_miss,
        (100.0 * n_hit / max(1, n_hit + n_miss)),
    )

    parse_udf = make_conflict_parse_udf()
    # Batches whose cache write did not land; the rest are read back from the
    # cache after the loop, as in tag_issues.
    verdict_batches: List[DataFrame] = []
    cached_batches = 0

    if n_miss > 0:
        # Before the first paid call, not after the last failed batch.
        validate_executors(spark)

        prompt_sql = build_issue_conflict_prompt_sql(
            view_name="_issue_conflict_batch_placeholder",
            max_evidence_chars=cfg["MAX_EVIDENCE_CHARS"],
        )
        invoke_col = make_vertex_invoke_udf(vertex_cfg)(F.col("ai_prompt"))

        # One call per conflict_id, not per group: product_id is not hashed, so
        # two products with byte-identical evidence ask the identical question.
        # The fan-out back to every group happens at assembly, by conflict_id.
        n_unique = cache_misses.select("conflict_id").distinct().count()
        num_batches = max(1, (n_unique + batch_size - 1) // batch_size)
        numbered = cache_misses.dropDuplicates(["conflict_id"]).withColumn(
            "_batch", F.pmod(F.crc32(F.col("conflict_id")), F.lit(num_batches))
        ).cache()
        numbered.count()

        logger.info(
            "Asking %d distinct conflict verdict(s) (%d groups) in %d batch(es) "
            "of up to %d",
            n_unique, n_miss, num_batches, batch_size,
        )

        failed = 0
        for batch_idx in range(num_batches):
            view_name = f"_issue_conflict_batch_{uuid.uuid4().hex[:8]}"
            batch_sql = prompt_sql.replace(
                "_issue_conflict_batch_placeholder", view_name,
            )
            batch_df = numbered.filter(F.col("_batch") == F.lit(batch_idx)).select(
                "conflict_id", "product_id", "issue_key", "affected_component",
                "evidence_text",
            ).repartition(num_partitions)
            batch_df.createOrReplaceTempView(view_name)

            try:
                # spark.sql() is LAZY — no model call yet.
                raw = spark.sql(batch_sql).withColumn("ai_query_raw", invoke_col)
                parsed = (
                    raw
                    .withColumn("conflict_flag", parse_udf(_vertex_reply()))
                    # A failed CALL is not a verdict: it must not be cached as
                    # NULL (a cached NULL is a hit, so it would never be re-asked).
                    .withColumn("_llm_error", _vertex_error())
                    .select(
                        "conflict_id", "product_id", "issue_key", "conflict_flag",
                        "_llm_error",
                    )
                )
                # Force execution NOW so model/permission errors surface here.
                parsed = parsed.cache()
                batch_count = parsed.count()

                if batch_count == 0:
                    failed += 1
                    logger.error(
                        "Conflict batch %d/%d FAILED: 0 rows after the model pass",
                        batch_idx + 1, num_batches,
                    )
                    parsed.unpersist()
                    continue

                unparseable = parsed.filter(F.col("conflict_flag").isNull()).count()
                causes = _failure_causes(parsed, "conflict_flag") if unparseable else ""
                if unparseable == batch_count:
                    # Every reply unusable is a credential/quota/model problem,
                    # not "no conflicts here". Do NOT cache it — caching would
                    # freeze the outage into every future run.
                    failed += 1
                    logger.error(
                        "Conflict batch %d/%d FAILED: all %d replies unparseable "
                        "[%s] on '%s'.",
                        batch_idx + 1, num_batches, batch_count, causes, model_name,
                    )
                    parsed.unpersist()
                    continue
                if unparseable:
                    logger.warning(
                        "Conflict batch %d/%d: %d/%d replies unparseable [%s] — "
                        "failed calls NOT cached",
                        batch_idx + 1, num_batches, unparseable, batch_count, causes,
                    )

                # Cache THIS batch now, like tag_issues: a later failure must not
                # throw away calls already paid for. Failed CALLS are left out;
                # a real reply with no usable verdict is still cached as NULL.
                landed = write_conflict_cache(
                    spark,
                    parsed.filter(F.col("_llm_error").isNull()).select(
                        "conflict_id",
                        "conflict_flag",
                        F.lit(ISSUE_CONFLICT_PROMPT_VERSION).alias("prompt_version"),
                        F.lit(model_name).alias("model"),
                        F.date_format(F.current_timestamp(), "yyyy-MM-dd HH:mm:ss")
                         .alias("created_at"),
                    ).dropDuplicates(["conflict_id"]),
                    cache_table,
                )
                if landed:
                    # Read back by the re-split after the loop — NULL verdicts
                    # included, since split_on_conflict_cache treats a cached
                    # NULL as a hit.
                    cached_batches += 1
                    parsed.unpersist()
                else:
                    # No cache, or the write failed: this copy is the only one.
                    verdict_batches.append(parsed)

                logger.info(
                    "Conflict batch %d/%d done — %d/%d verdicts",
                    batch_idx + 1, num_batches, batch_count - unparseable, batch_count,
                )
            except Exception as error:
                failed += 1
                logger.error(
                    "Conflict batch %d/%d FAILED: %s",
                    batch_idx + 1, num_batches, error,
                )
            finally:
                try:
                    spark.catalog.dropTempView(view_name)
                except Exception:
                    pass

        logger.info(
            "Conflict batches: %d succeeded, %d failed", num_batches - failed, failed,
        )
        numbered.unpersist()

    # Re-split against the cache now holding this run's verdicts: each comes back
    # as a hit on EVERY group sharing its conflict_id.
    if cached_batches:
        scored.unpersist()
        scored = split_on_conflict_cache(spark, keyed, cache_table).cache()
        cache_hits = scored.filter(F.col("_cache_hit"))
        n_hit = cache_hits.count()
        logger.info(
            "Conflict cache re-read: %d of %d group(s) now hit (%d batch(es) "
            "written this run)", n_hit, total_groups, cached_batches,
        )

    # Batches that never reached the cache hold one row per conflict_id; join
    # them onto `keyed` to fan back out. `keyed`, not `cache_misses`: the latter
    # re-derives from the cache join, which this run has since changed.
    fresh = None
    if verdict_batches:
        fresh_verdicts = reduce(
            DataFrame.unionByName,
            [batch.select("conflict_id", "conflict_flag") for batch in verdict_batches],
        )
        fresh = keyed.join(fresh_verdicts, on="conflict_id", how="inner")
    hits = cache_hits.select("conflict_id", "product_id", "issue_key", "conflict_flag")

    if fresh is None and n_hit == 0:
        logger.warning(
            "Conflict pass produced nothing — no batches succeeded and no cache "
            "hits. conflict_flag falls back to the sentiment heuristic."
        )
        scored.unpersist()
        keyed.unpersist()
        return None

    combined = (
        hits if fresh is None
        else (fresh.select(*hits.columns) if n_hit == 0
              else fresh.select(*hits.columns).unionByName(hits))
    )

    result_df = combined.select("product_id", "issue_key", "conflict_flag").cache()
    n_verdicts = result_df.count()
    n_true = result_df.filter(F.col("conflict_flag")).count()
    n_null = result_df.filter(F.col("conflict_flag").isNull()).count()

    scored.unpersist()
    keyed.unpersist()
    for batch in verdict_batches:
        batch.unpersist()

    logger.info(
        "Conflict verdicts: %d group(s) — %d true, %d false, %d no-verdict",
        n_verdicts, n_true, n_verdicts - n_true - n_null, n_null,
    )
    return result_df


# =============================================================================
# TAG TABLE  (observability — never read back)
# =============================================================================

def issue_tag_id() -> "F.Column":
    """
    Tag table primary key: sha2(item_id || source || source_id || issue_key).
    """
    return F.sha2(
        F.concat_ws(
            "||",
            F.coalesce(F.col("product_id"), F.lit("")),
            F.coalesce(F.col("source"), F.lit("")),
            F.coalesce(F.col("source_id"), F.lit("")),
            F.coalesce(F.col("issue_key"), F.lit("")),
        ),
        256,
    )


def to_issue_tag_rows(issues_df: DataFrame) -> DataFrame:
    """
    tag_issues' output -> ISSUE_TAG_TABLE_SCHEMA's columns, in order.

    Split out from the write so the projection is testable without a table, and
    so the column contract is enforced in one place.
    """
    return (
        issues_df
        .withColumn("tag_id", issue_tag_id())
        .withColumn("last_updated_ts", F.col("created_at_ts"))
        .select(
            F.col("product_id").cast("string").alias("item_id"),
            "tag_id", "source", "source_id", "source_create_dt",
            F.col("review_text").alias("source_text"),
            "issue_key", "is_novel_key", "issue_tags", "affected_component",
            "severity", "severity_reason", "confidence", "confidence_band",
            "sentiment_score", "resolution_status", "time_bound", "root_cause",
            "matched_terms", "model_endpoint", "created_at_ts", "last_updated_ts",
        )
    )


def write_issue_tags(
    spark: SparkSession, issues_df: DataFrame, output_table: Optional[str],
) -> None:
    """Persist grouped issue payloads in the shared unit table; failures only warn."""
    if not output_table:
        return

    try:
        rows = to_issue_tag_rows(issues_df)
    except Exception as error:
        logger.warning(
            "Could not project issue tag rows (%s) — skipping the tag table "
            "write. A column was probably dropped upstream in tag_issues.",
            error,
        )
        return

    missing = [c for c in ISSUE_TAG_TABLE_COLUMNS if c not in rows.columns]
    if missing:
        logger.warning(
            "Issue tag DataFrame is missing column(s) %s — skipping the tag "
            "table write. Got %s.", missing, rows.columns,
        )
        return

    try:
        write_unit_tags(spark, issue_unit_rows(rows), output_table, "issues_json")
        logger.info("Issue tag table updated: %s", output_table)
    except Exception as error:
        logger.warning("Issue tag write to %s failed (%s)", output_table, error)


# =============================================================================
# NOVEL-KEY OBSERVABILITY
# =============================================================================

def summarize_novel_keys(issues_df: DataFrame) -> DataFrame:
    """
    Keys the model coined that the taxonomy does not hold, for vocabulary review.
    Promoting a key into the YAML requires an ISSUE_TAGGING_PROMPT_VERSION bump.
    """
    return (
        issues_df
        .filter(F.col("is_novel_key"))
        .groupBy("issue_key")
        .agg(
            F.count("*").alias("occurrence_cnt"),
            F.countDistinct("product_id").alias("product_cnt"),
            F.slice(F.flatten(F.collect_list("matched_terms")), 1, 5).alias("sample_terms"),
            F.min("source_create_dt").alias("first_seen"),
            F.max("source_create_dt").alias("last_seen"),
        )
        .orderBy(F.desc("occurrence_cnt"))
    )


# =============================================================================
# SOURCE LOADING
# =============================================================================

def _load_source_rows(
    spark: SparkSession,
    source_df: DataFrame,
    cfg: dict,
    include_qa: bool = True,
) -> DataFrame:
    """
    The reviews + Q&A rows this module tags, for the products in source_df.

    Factored out of mine_issue_tags because build_rows_considered below needs
    the SAME set, counted. Two copies of this select/filter would drift — and
    the one filter that matters most, the syndication exclusion, is exactly the
    kind of thing that gets fixed in one copy and not the other, leaving
    mention_rate quietly divided by the wrong denominator.

    Returns:
        product_id, review_text, source_id, source_create_dt, source, category.
        One row per review or question, empty text already dropped.
    """
    # Category rides with every row: it is prompt CONTEXT (so the model reads
    # "run" correctly for a printer vs a treadmill) and part of the cache key.
    product_categories = source_df.select(
        F.col("item_id").cast("string").alias("cat_item_id"),
        F.col("web_supercategory_nm").alias("category"),
    ).distinct()

    frames: List[DataFrame] = []

    # --- reviews ------------------------------------------------------------
    reviews = (
        spark.table(cfg["REVIEW_TABLE"])
        .select(
            F.col("PRODUCT_ID").cast("string").alias("product_id"),
            F.col("REVIEW_DETAIL_TXT").alias("review_text"),
            F.col("WEB_REVIEW_ID").cast("string").alias("source_id"),
            F.col("REVIEW_CREATE_DT").cast("string").alias("source_create_dt"),
            F.col("CONTENT_SYNDICATION_SOURCE_NM").alias("syndication_source"),
        )
        # Syndicated copies are the same text on many products; tagging them all
        # would multiply cost for one answer. (The content-addressed cache would
        # absorb it, but not paying at all is better than paying once.)
        .filter(F.col("syndication_source").isNull())
        .drop("syndication_source")
        .withColumn("source", F.lit("review"))
    )
    frames.append(
        reviews.join(
            product_categories.hint("broadcast"),
            reviews["product_id"] == product_categories["cat_item_id"],
            "inner",
        ).drop("cat_item_id")
    )

    # --- Q&A ----------------------------------------------------------------
    if include_qa and cfg["QUESTIONS_TABLE"]:
        questions = (
            spark.table(cfg["QUESTIONS_TABLE"])
            .select(
                F.col("PRODUCT_ID").cast("string").alias("product_id"),
                F.col("QUESTION_DETAILS_TXT").alias("review_text"),
                F.col("QUESTION_ID").cast("string").alias("source_id"),
                F.lit(None).cast("string").alias("source_create_dt"),
            )
            .withColumn("source", F.lit("qa"))
        )
        frames.append(
            questions.join(
                product_categories.hint("broadcast"),
                questions["product_id"] == product_categories["cat_item_id"],
                "inner",
            ).drop("cat_item_id")
        )

    return reduce(DataFrame.unionByName, frames).filter(
        F.col("review_text").isNotNull() & (F.length(F.trim("review_text")) > 0)
    )


def build_rows_considered(
    spark: SparkSession,
    source_df: DataFrame,
    include_qa: bool = True,
) -> DataFrame:
    """
    Per-product count of texts the model was shown (denominator for mention_rate).

    Returns:
        product_id, rows_considered. Products with no reviews or questions are absent.
    """
    cfg = _ensure_config()
    return (
        _load_source_rows(spark, source_df, cfg, include_qa)
        .groupBy("product_id")
        .agg(F.count("*").alias("rows_considered"))
    )


# =============================================================================
# PUBLIC ENTRY POINT
# =============================================================================

def mine_issue_tags(
    spark: SparkSession,
    source_df: DataFrame,
    issue_cfg: dict,
    include_qa: bool = True,
    use_cache: bool = True,
) -> Optional[DataFrame]:
    """
    Load reviews and Q&A for the given products, tag them, return issue records.
    Tags exactly what it is handed; the LLM cache handles repeat work.

    Args:
        spark:       Active SparkSession.
        source_df:   Product catalog rows with item_id, web_supercategory_nm.
        issue_cfg:   Parsed issue_keywords.yaml.
        include_qa:  Also tag Q&A question text.
        use_cache:   False forces full re-classification.

    Returns:
        One row per detected issue (with a per-group conflict_flag), or None.
    """
    cfg = _ensure_config()
    if not cfg["ENABLED"]:
        logger.info("Issue LLM tagging disabled by config (review_mining.issues.enabled)")
        return None

    # Config full_refresh bypasses the LLM cache. AND, not OR: a caller that
    # passed use_cache=False meant it, and config cannot turn the cache back on
    # underneath them.
    if use_cache and cfg["FULL_REFRESH"]:
        logger.warning(
            "review_mining.llm.full_refresh=true — bypassing the LLM cache and "
            "re-classifying EVERY row handed to this run. This costs model "
            "spend proportional to the input, not to what changed."
        )
        use_cache = False

    rows_df = _load_source_rows(spark, source_df, cfg, include_qa)

    issues_df = tag_issues(spark, rows_df, issue_cfg, use_cache=use_cache)

    # --- conflict verdicts (second pass) ------------------------------------
    #
    # Attached here, not in review_mining, so the aggregation step stays free of
    # model calls — the property that makes a daily rerun of the rollup cost
    # nothing. Every group that did not qualify or did not get a verdict comes
    # back NULL from the left join; review_mining decides what that means.
    #
    # A failure here degrades conflict_flag to the sentiment heuristic and must
    # not take the tagging results down with it — those have already been paid
    # for.
    if issues_df is not None and cfg["CONFLICT_DETECTION"]:
        try:
            verdicts = detect_issue_conflicts(spark, issues_df, use_cache=use_cache)
        except Exception as error:
            logger.warning(
                "Conflict detection failed (%s) — conflict_flag falls back to "
                "the sentiment heuristic", error,
            )
            verdicts = None

        if verdicts is not None:
            issues_df = issues_df.join(
                verdicts.hint("broadcast"), on=["product_id", "issue_key"], how="left",
            )
        else:
            issues_df = issues_df.withColumn(
                "conflict_flag", F.lit(None).cast(BooleanType()),
            )
    elif issues_df is not None:
        logger.info(
            "Conflict detection disabled (review_mining.issues.conflict_detection) "
            "— conflict_flag falls back to the sentiment heuristic"
        )
        issues_df = issues_df.withColumn(
            "conflict_flag", F.lit(None).cast(BooleanType()),
        )

    # Persist AFTER tagging, like faq_tagging.mine_faq_tags. tag_issues has
    # already cache()d and count()ed this frame, so the write is a second action
    # over a materialised plan and cannot re-issue a paid model call.
    if issues_df is not None and cfg["TAG_TABLE"]:
        if cfg["ISSUE_TAGS_TABLE"]:
            write_issue_tags(spark, issues_df, cfg["ISSUE_TAGS_TABLE"])
        else:
            logger.warning(
                "review_mining.tag_table is on but "
                "review_mining.tables.tag_table is not set — tagging ran "
                "and returned data, but nothing was persisted"
            )

    return issues_df


# =============================================================================
# STANDALONE PIPELINE
# =============================================================================
#
# WHAT A SOLO RUN DOES AND DOES NOT WRITE
# It writes the LLM cache and the tag table. It does NOT write
# product_reviews_faq_enriched_data: issue_signals_json and issue_summary_json
# are per-PRODUCT aggregations that review_mining owns, and half-writing that
# table from here would clobber its faq_json and faq_summary_json columns with
# NULLs. Run review_mining afterwards to roll these tags up — it will hit the
# cache this run populated and pay almost nothing to do it.
#
# So the useful shapes are:
#   backfill the cache cheaply, then aggregate   python issues_tagging.py
#                                                python review_mining.py
#   smoke-test the prompt on 50 items            max_items=50
#
# There is deliberately no incremental anti-join here, unlike
# faq_tagging.run_faq_tagging_pipeline. Issue tagging has never had one — the
# content-addressed LLM cache does that job, and does it better, because it is
# keyed on the review text rather than on a positional id. An item that was
# tagged yesterday and is handed to this function again costs cache reads, not
# model calls.


def load_issue_config(yaml_path: Optional[str] = None) -> dict:
    """
    Read config/issue_keywords.yaml.

    Duplicated from review_mining.load_issue_keywords rather than imported:
    review_mining imports THIS module, so importing it back at module scope
    would be a cycle, and a function-scoped import of a 3,000-line orchestrator
    just to read a YAML file is worse than eight lines.
    """
    yaml_path = yaml_path or config_path("issue_keywords.yaml")
    if not os.path.exists(yaml_path):
        raise FileNotFoundError(f"issue_keywords.yaml not found at: {yaml_path}")

    with open(yaml_path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    logger.info(
        "Loaded issue_keywords.yaml: %d issue definitions",
        len(data.get("issues", []) or []),
    )
    return data


def run_issue_tagging_pipeline(
    spark: SparkSession,
    source_table: str,
    issue_cfg: Optional[dict] = None,
    yaml_path: Optional[str] = None,
    include_qa: bool = True,
    use_cache: bool = True,
    max_items: int = -1,
) -> Optional[DataFrame]:
    """
    Read the catalog, tag every review and Q&A on it, write the tag table.

    Args:
        spark:        Active SparkSession.
        source_table: Fully qualified product catalog table.
        issue_cfg:    Parsed issue_keywords.yaml. Loaded from yaml_path if None.
        yaml_path:    Override for config/issue_keywords.yaml.
        include_qa:   Also tag Q&A question text.
        use_cache:    False re-classifies everything.
        max_items:    Cap on catalog items this run (-1 = no cap).

    Returns:
        One row per detected issue, or None when there was nothing to tag.
    """
    cfg = _ensure_config()
    if not cfg["ENABLED"]:
        logger.info("Issue LLM tagging disabled by config (review_mining.issues.enabled)")
        return None

    # Cheap — the model name is already in the config dict. The secret fetch
    # that vertex_settings() does is deferred until there is work to tag.
    model_name = cfg["VERTEX"]["model"]

    logger.info("=" * 70)
    logger.info("ISSUE TAGGING PIPELINE (standalone)")
    logger.info("  Source       : %s", source_table)
    logger.info("  Tag table    : %s", cfg["ISSUE_TAGS_TABLE"] if cfg["TAG_TABLE"]
                else "(disabled)")
    logger.info("  LLM cache    : %s", cfg["CACHE_TABLE"] or "(disabled)")
    logger.info("  Model        : Vertex %s (temp=%s)", model_name, cfg["TEMPERATURE"])
    logger.info("  Prompt ver   : %s", ISSUE_TAGGING_PROMPT_VERSION)
    logger.info("  Full refresh : %s", cfg["FULL_REFRESH"] or not use_cache)
    logger.info("  Max items    : %s", "no cap" if max_items <= 0 else max_items)
    logger.info("=" * 70)

    source_df = spark.table(source_table).select("item_id", "web_supercategory_nm")

    if max_items > 0:
        # limit() before the review join, so the cap bounds the number of ITEMS
        # whose full review history is loaded — capping afterwards would still
        # have scanned every review in the catalogue to get there.
        source_df = source_df.dropDuplicates(["item_id"]).limit(max_items)
        logger.info("Capped at %d catalog items for this run", max_items)

    # One real round trip before the source scan, so bad credentials or an
    # unavailable model fail in a second rather than after a full load.
    validate_vertex(vertex_settings())

    issues_df = mine_issue_tags(
        spark,
        source_df=source_df,
        issue_cfg=issue_cfg if issue_cfg is not None else load_issue_config(yaml_path),
        include_qa=include_qa,
        use_cache=use_cache,
    )

    if issues_df is None:
        logger.warning("Issue tagging produced no results — nothing written.")
        return None

    # Novel keys, same summary review_mining logs. Observability only: this is
    # how issue_keywords.yaml grows from what the data actually says, rather
    # than fragmenting into wheel_broke / wheel_broken / broken_wheel.
    try:
        novel = summarize_novel_keys(issues_df).limit(20).collect()
        if novel:
            logger.info("Novel issue keys this run (top %d):", len(novel))
            for row in novel:
                logger.info(
                    "  %-40s %6d occurrences across %d products",
                    row["issue_key"], row["occurrence_cnt"], row["product_cnt"],
                )
    except Exception as error:
        logger.debug("Novel-key summary skipped (%s)", error)

    logger.info("=" * 70)
    logger.info("ISSUE TAGGING COMPLETE")
    logger.info(
        "  Run review_mining.py next to roll these into issue_signals_json / "
        "issue_summary_json — it will hit the cache this run just filled."
    )
    logger.info("=" * 70)
    return issues_df


def generate_issue_tags(
    spark: Optional[SparkSession] = None,
    config: Optional[dict] = None,
) -> Optional[DataFrame]:
    """
    Config-driven entry point: resolve general.yml, then run the pipeline.

    The ONLY place config becomes parameters, mirroring
    faq_tagging.generate_faq_tags.

    Args:
        spark:  Active SparkSession (created if omitted).
        config: Overrides applied on top of general.yml, using the same keys as
                _ensure_config (PRODUCT_CATALOG_TABLE, MAX_ITEMS_PER_RUN, ...).
    """
    spark = spark or get_spark_session()
    cfg = dict(_ensure_config())
    if config:
        cfg.update(config)

    source_table = cfg.get("PRODUCT_CATALOG_TABLE")
    if not source_table:
        raise ValueError(
            "review_mining.tables.PRODUCT_CATALOG_TABLE must be set in "
            "config/general.yml to run issue tagging standalone."
        )

    return run_issue_tagging_pipeline(
        spark=spark,
        source_table=source_table,
        max_items=int(cfg.get("MAX_ITEMS_PER_RUN", -1)),
    )


# =============================================================================
# STANDALONE EXECUTION
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # os.environ.setdefault("sf_env", "dev")
    generate_issue_tags()
