"""
Prompt templates over customer reviews and Q&A: issue tagging and issue conflict
(issues_tagging), FAQ tagging (faq_tagging). Each family is independent: a wording change
that helps one must never move another.

All prompt text lives in config/prompts/issue_tagging.yaml and faq_tagging.yaml, with the
rationale beside each text. This module keeps only the assembly.

Static prompt text is emitted before row text for Vertex prefix caching. Text reaches the SQL
by variable substitution, so JSON braces are fine in it; the two RULES templates are
.format()ted and may contain only their named placeholders (prompt_store.check_placeholders
enforces this at import).
"""

import os
import sys

# prompt_store sits alone in src/data_pipeline/prompts on purpose: putting src/data_pipeline
# itself on sys.path would make a flat `import utils` pick up src/data_pipeline/utils.py
# instead of enrichment/utils.py.
try:
    _PROMPT_STORE_DIR = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "prompts")
except NameError:
    _ROOT = os.getcwd() if os.path.exists(os.path.join(os.getcwd(), "config")) else os.path.abspath(
        os.path.join(os.getcwd(), "..", "..", ".."))
    _PROMPT_STORE_DIR = os.path.join(_ROOT, "src", "data_pipeline", "prompts")
if _PROMPT_STORE_DIR not in sys.path:
    sys.path.insert(0, _PROMPT_STORE_DIR)

import prompt_store  # noqa: E402

_ISSUE = prompt_store.load("issue_tagging")
_TAG = _ISSUE["tagging"]
_CONFLICT = _ISSUE["conflict"]
_FAQ = prompt_store.load("faq_tagging")

# ---------------------------------------------------------------------------
# Prompt version — hashed into the LLM cache key by review_mining.
#
# BUMP THE VERSION in config/prompts/issue_tagging.yaml on any edit to the static
# prompt text of that pass (system instruction, examples, rules, JSON format). The cache
# keys on sha2(review_text || category || prompt_version || model), so without a bump an
# improved prompt keeps serving replies produced by the old one, forever.
#
# The version sits in the same file as the text so editing the prompt and invalidating its
# cache are the same edit, and cannot be done separately.
# ---------------------------------------------------------------------------
ISSUE_TAGGING_PROMPT_VERSION = str(_TAG["version"])


# ---------------------------------------------------------------------------
# Issue tagging — prompt text (config/prompts/issue_tagging.yaml, `tagging`)
# ---------------------------------------------------------------------------

ISSUE_TAGGING_SYSTEM_INSTRUCTION = _TAG["system_instruction"]

# A SMALL, fixed sample of issue_keywords.yaml keys — names only. Editing the list changes
# the prompt: bump the version.
ISSUE_KEY_REFERENCES = _TAG["key_references"]

# `text -> issue_key | affected_component | severity` lines plus the worked examples.
ISSUE_TAGGING_EXAMPLES = _TAG["examples"]

# Defaults for callers that thread no config through. Keep in step with
# config/general.yml's review_mining.llm block, which is the source of truth.
DEFAULT_ISSUE_TAGS_MIN = int(_TAG["defaults"]["issue_tags_min"])
DEFAULT_ISSUE_TAGS_MAX = int(_TAG["defaults"]["issue_tags_max"])
DEFAULT_SENTIMENT_MIN = int(_TAG["defaults"]["sentiment_min"])
DEFAULT_SENTIMENT_MAX = int(_TAG["defaults"]["sentiment_max"])

# TEMPLATE, not a plain constant: the tag range and sentiment scale are rendered
# from config by build_issue_tagging_rules(), so the bounds the model is asked
# for and the clamps review_mining applies cannot drift apart. Both are needed —
# the model is not bound by its own prompt.
ISSUE_TAGGING_RULES_TEMPLATE = prompt_store.check_placeholders(
    _TAG["rules_template"],
    {"issue_tags_min", "issue_tags_max", "sentiment_min", "sentiment_max"},
    "issue_tagging.yaml tagging.rules_template",
)


def build_issue_tagging_rules(
    issue_tags_min: int = DEFAULT_ISSUE_TAGS_MIN,
    issue_tags_max: int = DEFAULT_ISSUE_TAGS_MAX,
    sentiment_min: int = DEFAULT_SENTIMENT_MIN,
    sentiment_max: int = DEFAULT_SENTIMENT_MAX,
) -> str:
    """
    Render ISSUE_TAGGING_RULES_TEMPLATE for a given tag range and sentiment scale.

    Bounds come from config/general.yml (review_mining.llm), so the range stated
    in the prompt is the one review_mining clamps the reply to. The result is
    constant for a whole run, so the prefix cache is unaffected.
    """
    return ISSUE_TAGGING_RULES_TEMPLATE.format(
        issue_tags_min=issue_tags_min,
        issue_tags_max=issue_tags_max,
        sentiment_min=sentiment_min,
        sentiment_max=sentiment_max,
    )


# Single-line exemplar of the per-issue object. NOT templated: it is full of
# literal JSON braces. confidence_band is absent on purpose — it is a pure function
# of confidence and is computed in code.
ISSUE_TAGGING_JSON_FORMAT = _TAG["json_format"]

_ISSUE_LAYOUT = _TAG["layout"]


def _sql_escape(s: str) -> str:
    """SQL string literals are single-quoted: double any apostrophe in prompt text."""
    return s.replace("'", "''")


def _issue_tagging_prompt_cte(
    view_name: str,
    max_review_chars: int,
    issue_tags_min: int,
    issue_tags_max: int,
    sentiment_min: int,
    sentiment_max: int,
) -> str:
    """
    Shared `with_prompt` CTE: signal_id, product_id, source, source_id,
    source_create_dt, ai_prompt.

    Requires temp view `view_name` with string columns signal_id, product_id, source,
    source_id, source_create_dt, category, review_text. category is context, not a filter.

    Args:
        view_name:        Temp view holding the batch.
        max_review_chars: Front-anchored review text truncation.
        issue_tags_min, issue_tags_max, sentiment_min, sentiment_max: Bounds rendered into the rules.
    """
    # SQL string literals are single-quoted: an apostrophe in the prompt text
    # terminates the literal early -> PARSE_SYNTAX_ERROR. Escape every constant.
    _esc = _sql_escape

    sys_instruction = _esc(ISSUE_TAGGING_SYSTEM_INSTRUCTION)
    key_references = _esc(ISSUE_KEY_REFERENCES)
    examples = _esc(ISSUE_TAGGING_EXAMPLES).replace("\n", "\\n")
    rules = _esc(
        build_issue_tagging_rules(
            issue_tags_min, issue_tags_max, sentiment_min, sentiment_max,
        )
    ).replace("\n", "\\n")
    json_format = _esc(ISSUE_TAGGING_JSON_FORMAT)
    L = {k: _esc(v) for k, v in _ISSUE_LAYOUT.items()}

    # Everything above the category heading is byte-identical for every row in a run —
    # that block is what the prefix cache matches on. Adding any row-dependent
    # value to it costs full price on 100% of rows, with no error to notice.
    return f"""
    WITH with_prompt AS (
      SELECT
        b.signal_id,
        b.product_id,
        b.source,
        b.source_id,
        b.source_create_dt,
        b.category,
        b.review_text,
        CONCAT(
          '{sys_instruction}\\n',
          '\\n{L['key_references_heading']}\\n',
          '{key_references}\\n',
          '\\n{L['examples_heading']}\\n',
          '{examples}\\n',
          '\\n{L['rules_heading']}\\n',
          '{rules}\\n',
          '\\n{L['json_heading']}\\n',
          '{json_format}\\n',
          '\\n{L['category_heading']}\\n',
          COALESCE(b.category, '{L['unknown_category']}'),
          '\\n\\n{L['review_heading']}\\n',
          LEFT(COALESCE(b.review_text, '{L['missing_text']}'), {max_review_chars})
        ) AS ai_prompt
      FROM {view_name} b
    )
    """


def build_issue_tagging_prompt_sql(
    view_name: str = "_issue_tagging_batch",
    max_review_chars: int = 1200,
    issue_tags_min: int = DEFAULT_ISSUE_TAGS_MIN,
    issue_tags_max: int = DEFAULT_ISSUE_TAGS_MAX,
    sentiment_min: int = DEFAULT_SENTIMENT_MIN,
    sentiment_max: int = DEFAULT_SENTIMENT_MAX,
) -> str:
    """
    Render the issue extraction prompt per row (no model call in the SQL); a Vertex
    UDF fills ai_query_raw afterwards.

    Returns SQL producing: signal_id, product_id, source, source_id, source_create_dt,
    category, review_text, ai_prompt, est_ai_input_tokens.
    """
    cte = _issue_tagging_prompt_cte(
        view_name,
        max_review_chars,
        issue_tags_min,
        issue_tags_max,
        sentiment_min,
        sentiment_max,
    )
    return cte + """
    SELECT
      signal_id,
      product_id,
      source,
      source_id,
      source_create_dt,
      category,
      review_text,
      ai_prompt,
      CAST(CEIL(LENGTH(ai_prompt) / 4.0) AS INT) AS est_ai_input_tokens
    FROM with_prompt
    """


# ---------------------------------------------------------------------------
# CONFLICT DETECTION — a SECOND pass, one call per (product_id, issue_key)
#
# WHY A SEPARATE PASS AT ALL. The tagging prompt above is one call per review.
# A call that sees one review can never observe two reviewers disagreeing, so
# contradiction is structurally invisible to it. The FAQ side gets this for free
# because a question and ALL its answers go up in one call; issues have no
# equivalent single-call unit, so the disagreement question has to be asked
# again, over the evidence the first pass already collected.
#
# The unit here is therefore the GROUP, not the row: every mention of one
# issue_key on one product, represented by its grounded matched_terms spans.
# Groups with a single mention are never sent — one mention cannot contradict
# itself — which is what keeps this pass a fraction of the first one.
#
# Text: config/prompts/issue_tagging.yaml, `conflict`.
# ---------------------------------------------------------------------------

# Bumped independently of ISSUE_TAGGING_PROMPT_VERSION: the two passes have
# separate cache keys, and re-wording one must not invalidate the other's
# (far more expensive) cache.
ISSUE_CONFLICT_PROMPT_VERSION = str(_CONFLICT["version"])

ISSUE_CONFLICT_SYSTEM_INSTRUCTION = _CONFLICT["system_instruction"]

# Deliberately verbose, and kept that way (see the note in the YAML).
ISSUE_CONFLICT_RULES = _CONFLICT["rules"]

ISSUE_CONFLICT_EXAMPLES = _CONFLICT["examples"]

# Single-line exemplar. NOT templated — literal JSON braces would break .format().
ISSUE_CONFLICT_JSON_FORMAT = _CONFLICT["json_format"]

_CONFLICT_LAYOUT = _CONFLICT["layout"]


def build_issue_conflict_prompt_sql(
    view_name: str = "_issue_conflict_batch",
    max_evidence_chars: int = 1500,
) -> str:
    """
    Render the conflict-verdict prompt per issue group (no model call in the SQL).

    Requires temp view `view_name` with string columns conflict_id, product_id,
    issue_key, affected_component, evidence_text (from issues_tagging._build_evidence_text).

    Returns SQL producing: conflict_id, product_id, issue_key, ai_prompt, est_ai_input_tokens.
    """
    _esc = _sql_escape

    sys_instruction = _esc(ISSUE_CONFLICT_SYSTEM_INSTRUCTION)
    rules = _esc(ISSUE_CONFLICT_RULES).replace("\n", "\\n")
    examples = _esc(ISSUE_CONFLICT_EXAMPLES).replace("\n", "\\n")
    json_format = _esc(ISSUE_CONFLICT_JSON_FORMAT)
    L = {k: _esc(v) for k, v in _CONFLICT_LAYOUT.items()}

    return f"""
    WITH with_prompt AS (
      SELECT
        b.conflict_id,
        b.product_id,
        b.issue_key,
        CONCAT(
          '{sys_instruction}\\n',
          '\\n{L['rules_heading']}\\n',
          '{rules}\\n',
          '\\n{L['examples_heading']}\\n',
          '{examples}\\n',
          '\\n{L['json_heading']}\\n',
          '{json_format}\\n',
          '\\n{L['issue_heading']}\\n',
          COALESCE(b.issue_key, '{L['unknown_issue']}'),
          '{L['component_label']}',
          COALESCE(b.affected_component, '{L['unspecified_component']}'),
          '\\n\\n{L['excerpts_heading']}\\n',
          LEFT(COALESCE(b.evidence_text, '{L['missing_text']}'), {max_evidence_chars})
        ) AS ai_prompt
      FROM {view_name} b
    )
    SELECT
      conflict_id,
      product_id,
      issue_key,
      ai_prompt,
      CAST(CEIL(LENGTH(ai_prompt) / 4.0) AS INT) AS est_ai_input_tokens
    FROM with_prompt
    """


# ---------------------------------------------------------------------------
# FAQ question + answer tagging
# (config/prompts/faq_tagging.yaml)
#
# One call per question with its answers: question_tags, question_keyword,
# conflict_flag, and per answer answer_keyword, answer_tags, answer_score, time_bound.
# Not age-aware: review_mining applies recency decay from real timestamps.
# ---------------------------------------------------------------------------

FAQ_TAGGING_SYSTEM_INSTRUCTION = _FAQ["system_instruction"]

# `question -> tags | keyword` lines plus the worked examples.
FAQ_TAGGING_EXAMPLES = _FAQ["examples"]

# Fallback keyword word range; faq_config.yaml is the source of truth.
DEFAULT_KEYWORD_MIN_WORDS = int(_FAQ["defaults"]["keyword_min_words"])
DEFAULT_KEYWORD_MAX_WORDS = int(_FAQ["defaults"]["keyword_max_words"])

# TEMPLATE, not a plain constant: the keyword word range is rendered
# from faq_config.yaml's keyword_min_words / keyword_max_words by
# build_faq_tagging_rules() below, so the bound the model is asked for and the
# clamp faq_tagging applies to its output cannot drift apart.
FAQ_TAGGING_RULES_TEMPLATE = prompt_store.check_placeholders(
    _FAQ["rules_template"],
    {"keyword_min_words", "keyword_max_words"},
    "faq_tagging.yaml rules_template",
)


def build_faq_tagging_rules(
    keyword_min_words: int = DEFAULT_KEYWORD_MIN_WORDS,
    keyword_max_words: int = DEFAULT_KEYWORD_MAX_WORDS,
) -> str:
    """
    Render FAQ_TAGGING_RULES_TEMPLATE for a given keyword word range.

    The bounds come from faq_config.yaml (keyword_min_words / keyword_max_words)
    via faq_tagging, so the range stated in the prompt is the same one
    faq_tagging._clean_keyword enforces on the reply. Callers that do not care
    get the defaults, which match the shipped config.

    The result is constant for a whole run, so the endpoint's prefix cache is
    unaffected — every row of every batch still sees byte-identical static text.
    """
    return FAQ_TAGGING_RULES_TEMPLATE.format(
        keyword_min_words=keyword_min_words,
        keyword_max_words=keyword_max_words,
    )


FAQ_TAGGING_JSON_FORMAT = _FAQ["json_format"]

_FAQ_LAYOUT = _FAQ["layout"]


def _faq_tagging_prompt_cte(
    view_name: str,
    max_answer_chars: int,
    keyword_min_words: int,
    keyword_max_words: int,
) -> str:
    """
    Shared `with_prompt` CTE: tag_id, item_id, question, answers, ai_prompt.

    Requires temp view `view_name` with tag_id, item_id, question (string) and
    answers (array<string>, non-NULL).

    Args:
        view_name:        Temp view holding the batch.
        max_answer_chars: Per-answer truncation.
        keyword_min_words, keyword_max_words: Keyword word range rendered into the rules.
    """
    # SQL string literals use single quotes, so any apostrophe in the static
    # prompt text must be doubled or it terminates the literal early
    # → PARSE_SYNTAX_ERROR. Escape every interpolated constant.
    _esc = _sql_escape

    sys_instruction = _esc(FAQ_TAGGING_SYSTEM_INSTRUCTION)
    examples = _esc(FAQ_TAGGING_EXAMPLES).replace("\n", "\\n")
    rules = _esc(
        build_faq_tagging_rules(keyword_min_words, keyword_max_words)
    ).replace("\n", "\\n")
    json_format = _esc(FAQ_TAGGING_JSON_FORMAT)
    L = {k: _esc(v) for k, v in _FAQ_LAYOUT.items()}

    # transform()'s two-argument lambda yields the 0-based element index, which
    # IS the "position" the model must echo back for each answer. Keeping the
    # numbering here (rather than pre-rendering it in Python) means the prompt
    # text and the array the parser validates against cannot drift apart.
    return f"""
    WITH with_prompt AS (
      SELECT
        b.tag_id,
        b.item_id,
        b.question,
        b.answers,
        CONCAT(
          '{sys_instruction}\\n',
          '\\n{L['examples_heading']}\\n',
          '{examples}\\n',
          '\\n{L['rules_heading']}\\n',
          '{rules}\\n',
          '\\n{L['json_heading']}\\n',
          '{json_format}\\n',
          '\\n{L['question_heading']}\\n',
          COALESCE(b.question, '{L['missing_text']}'),
          '\\n\\n{L['answers_heading']}\\n',
          CASE
            WHEN b.answers IS NULL OR size(b.answers) = 0 THEN '{L['no_answers_text']}'
            ELSE array_join(
                   transform(
                     b.answers,
                     (x, i) -> concat('[', CAST(i AS STRING), '] ',
                                      LEFT(COALESCE(x, ''), {max_answer_chars}))
                   ),
                   '\\n'
                 )
          END
        ) AS ai_prompt
      FROM {view_name} b
    )
    """


def build_faq_tagging_prompt_sql(
    view_name: str = "_faq_tagging_batch",
    max_answer_chars: int = 500,
    keyword_min_words: int = DEFAULT_KEYWORD_MIN_WORDS,
    keyword_max_words: int = DEFAULT_KEYWORD_MAX_WORDS,
) -> str:
    """
    Render the FAQ tagging prompt per row — no model call in the SQL itself.

    Spark builds the `ai_prompt` column, then faq_tagging.make_vertex_invoke_udf
    calls Gemma on Vertex via langchain, producing the `ai_query_raw` column
    that faq_tagging._parse_response reads back. (The column keeps that name for
    historical reasons; there is no ai_query involved.)

    Returns SQL producing:
        tag_id, item_id, question, answers, ai_prompt, est_ai_input_tokens

    See _faq_tagging_prompt_cte for parameter docs.
    """
    cte = _faq_tagging_prompt_cte(
        view_name, max_answer_chars, keyword_min_words, keyword_max_words,
    )
    return cte + """
    SELECT
      tag_id,
      item_id,
      question,
      answers,
      ai_prompt,
      CAST(CEIL(LENGTH(ai_prompt) / 4.0) AS INT) AS est_ai_input_tokens
    FROM with_prompt
    """
