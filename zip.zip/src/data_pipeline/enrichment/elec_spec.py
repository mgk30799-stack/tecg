"""
Electrical Specification Extraction & Normalization

Identifies electrical attributes from product `spec_json` and normalizes values:
- Voltage → "V", Wattage → "W" (kW converted), Amperage → "A"
- Cord Length → "in" (ft converted), Frequency → "Hz"
- Power → "W" or "VA", Energy → "kWh", Battery → "Wh"/"mAh"
- Ranges formatted as "min - max unit"

Exports:
    elec_spec_logic  — UDF-compatible function (spec_json → Dict[str, str])
    ELEC_SPEC_SCHEMA — MapType(StringType(), StringType())
"""

import re
import json
from typing import Dict, Any, Optional

from pyspark.sql.types import StringType, MapType


# --------------------------------------------------------------------------
# Constants: Electrical attribute category mapping
# --------------------------------------------------------------------------

CATEGORY_MAPPING = {
    "Adapter": [
        "Network Adapter Type", "Adapter Use", "Adapter & Splitter Type"
    ],
    "Amperage": [
        "Amperage (amps)", "Amperage", "Number of Amps"
    ],
    "Battery": [
        "Battery Backup or UPS Form Factor", "Battery Backup or UPS Device Type",
        "Battery Backup", "Battery Backup Connectivity", "Battery Backup LCD Display",
        "Battery Backup Run Time", "Battery Capacity (Wh)", "Battery Capacity (mAh)",
        "Battery Charge Time in Hours", "Battery Compatibility", "Battery Composition",
        "Battery Included", "Battery Life (Years)", "Battery Life (up to hours)",
        "Battery Location", "Battery Pack Size", "Battery Size", "Battery Type",
        "Battery Type Filter", "Battery Volts", "Auto Scrubber Battery Type",
        "Hearing Aid Battery Size", "Rechargeable Battery", "Low Battery Indicator",
        "Type of Battery", "Types of Battery", "Required Battery Size", "Number of Battery Cells"
    ],
    "Charging": [
        "Laptop Adapter & Charger Type", "Wireless Charging Compatible",
        "Charger Included", "Charger or Charging Cable Type"
    ],
    "Cord": [
        "Corded or Cordless", "Corded or Cordless Work Lights", "Corded Handsets Included",
        "Cord Length (Inches)", "Cord Length (ft)", "Cord Length (ft.)",
        "Extension Cord Length (ft)", "Video Recording", "Strap & Bungee Cord Type",
        "Answering System Recording Time (Minutes)", "Power Cord Length"
    ],
    "Electrical": [
        "ANSI Electrical Classification", "Electric or Manual", "Gas or Electric"
    ],
    "Energy": [
        "Energy Consumption per Year (kWh)", "Energy & Sport Drink Type"
    ],
    "Frequency": [
        "Frequency (Hz)", "Vertical Refresh Rate (Hz)", "Refresh Rate (Hz)"
    ],
    "Outlet": [
        "Number of Outlets", "Transformer Current Type", "Input Current",
        "Outlet Count", "Outlet Connectors", "Plug or Connector", "Plug Type",
        "Outlet Powered"
    ],
    "Power": [
        "Output Power Capacity (W)", "Power Capacity (VA)", "Power Distribution Unit Type",
        "Power Supply", "Power Supply Form Factor", "Power Source", "Power Source Type",
        "Power Source Information", "Power Type", "Power Control Type", "Mechanism Power",
        "Continuous Output Power (W)", "Peak Output Power (W)", "Output Power (Watts)",
        "Lighting Power Type", "Lighting Power Output", "Diffuser Power Source",
        "Fan Power Source", "Alarm Power Source", "Magnifying Power",
        "Power Inverter Input Connector", "Power-Volts", "Power-Wattage", "Power-Voltage",
        "Built in Power Strip", "Power Cord Length", "Space Heater Power Type",
        "Reading Glasses Power (Diopter)", "Power Consumption (Off Mode)(Watts)",
        "Power Consumption (Watts)", "Surge Protector & Power Strip Form Factor"
    ],
    "Protection": [
        "Surge Protection", "Joules Of Surge Protection"
    ],
    "Voltage": [
        "Voltage Output", "Plugs and Connectors Voltage", "Voltage", "Voltage-volts",
        "Hand Dryer Voltage", "Input Voltage", "Output Voltage", "Air Conditioner Voltage",
        "Maximum Voltage", "Transformer Voltage Input", "Automatic Voltage Regulation"
    ],
    "Wattage": [
        "Work Lights Bulb Wattage", "Wattage (watts)", "Watts", "Microwave Wattage",
        "Incandescent Equivalent Wattage", "Maximum Wattage", "Heater Maximum Wattage",
        "Wattage (kW)", "Starting Watts"
    ]
}

# Build a flat set of all electrical attribute names for fast lookup
ELECTRICAL_ATTRIBUTES = set()
for _attrs in CATEGORY_MAPPING.values():
    ELECTRICAL_ATTRIBUTES.update(_attrs)

# Reverse mapping: attribute_name -> category
ATTR_TO_CATEGORY = {}
for _category, _attrs in CATEGORY_MAPPING.items():
    for _attr in _attrs:
        ATTR_TO_CATEGORY[_attr] = _category

# UDF return schema — consistent with highlights_json
ELEC_SPEC_SCHEMA = MapType(StringType(), StringType())


# --------------------------------------------------------------------------
# Normalization Helpers
# --------------------------------------------------------------------------

def _extract_numeric(value: str) -> Optional[float]:
    """Extract first numeric value from string."""
    if not value:
        return None
    match = re.search(r'(\d+\.?\d*)', value)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            return None
    return None


def _extract_range(value: str) -> Optional[tuple]:
    """Extract range values (min-max) from string. Returns (min, max) or None."""
    if not value:
        return None
    match = re.search(r'(\d+\.?\d*)\s*[-–]\s*(\d+\.?\d*)', value)
    if match:
        try:
            return (float(match.group(1)), float(match.group(2)))
        except ValueError:
            return None
    return None


def _format_value(numeric: float, unit: str) -> str:
    """Format a numeric value with unit, dropping trailing .0 for integers."""
    if numeric == int(numeric):
        return f"{int(numeric)} {unit}"
    return f"{numeric} {unit}"


def _format_range(min_val: float, max_val: float, unit: str) -> str:
    """Format a range with unit."""
    min_str = str(int(min_val)) if min_val == int(min_val) else str(min_val)
    max_str = str(int(max_val)) if max_val == int(max_val) else str(max_val)
    return f"{min_str} - {max_str} {unit}"


def normalize_value(attr_name: str, value: str, category: str) -> str:
    """
    Normalize an electrical attribute value based on its category.
    Returns a string representation with standardized units.
    Falls back to the original value if normalization is not applicable.
    """
    if not value or value.strip() == '':
        return value

    val = value.strip()
    upper_val = val.upper()
    if upper_val in ('N/A', 'NA', 'NOT APPLICABLE', 'NONE', ''):
        return val

    # --- Voltage ---
    if category == 'Voltage':
        rng = _extract_range(val)
        if rng:
            return _format_range(rng[0], rng[1], "V")
        num = _extract_numeric(val)
        if num:
            return _format_value(num, "V")
        return val

    # --- Wattage ---
    if category == 'Wattage':
        rng = _extract_range(val)
        if rng:
            if 'kW' in attr_name:
                return _format_range(rng[0] * 1000, rng[1] * 1000, "W")
            return _format_range(rng[0], rng[1], "W")
        num = _extract_numeric(val)
        if num:
            if 'kW' in attr_name and num < 100:
                num = num * 1000
            return _format_value(num, "W")
        return val

    # --- Amperage ---
    if category == 'Amperage':
        rng = _extract_range(val)
        if rng:
            return _format_range(rng[0], rng[1], "A")
        num = _extract_numeric(val)
        if num:
            return _format_value(num, "A")
        return val

    # --- Cord (normalize to inches) ---
    if category == 'Cord':
        # Only normalize length attributes, not categorical ones like "Corded or Cordless"
        if 'Length' not in attr_name and 'ft' not in attr_name.lower():
            return val
        rng = _extract_range(val)
        if rng:
            if 'ft' in attr_name.lower():
                return _format_range(rng[0] * 12, rng[1] * 12, "in")
            return _format_range(rng[0], rng[1], "in")
        num = _extract_numeric(val)
        if num:
            if 'Inches' in attr_name:
                return _format_value(num, "in")
            elif 'ft' in attr_name.lower():
                return _format_value(num * 12, "in")
            else:
                return _format_value(num, "in")
        return val

    # --- Frequency ---
    if category == 'Frequency':
        rng = _extract_range(val)
        if rng:
            return _format_range(rng[0], rng[1], "Hz")
        num = _extract_numeric(val)
        if num:
            return _format_value(num, "Hz")
        return val

    # --- Power ---
    if category == 'Power':
        # Only normalize numeric power attributes
        if '(W)' in attr_name or 'Watts' in attr_name or 'Wattage' in attr_name:
            unit = 'W'
        elif '(VA)' in attr_name:
            unit = 'VA'
        else:
            return val  # Non-numeric power attributes (e.g., "Power Source Type")
        rng = _extract_range(val)
        if rng:
            return _format_range(rng[0], rng[1], unit)
        num = _extract_numeric(val)
        if num:
            return _format_value(num, unit)
        return val

    # --- Energy ---
    if category == 'Energy':
        if 'kWh' in attr_name:
            num = _extract_numeric(val)
            if num:
                return _format_value(num, "kWh")
        return val

    # --- Battery (normalize capacity attributes) ---
    if category == 'Battery':
        if 'Capacity (Wh)' in attr_name:
            num = _extract_numeric(val)
            if num:
                return _format_value(num, "Wh")
        elif 'Capacity (mAh)' in attr_name:
            num = _extract_numeric(val)
            if num:
                return _format_value(num, "mAh")
        elif 'Volts' in attr_name:
            num = _extract_numeric(val)
            if num:
                return _format_value(num, "V")
        return val

    # --- Protection ---
    if category == 'Protection':
        if 'Joules' in attr_name:
            num = _extract_numeric(val)
            if num:
                return _format_value(num, "J")
        return val

    # --- All others (Adapter, Charging, Electrical, Outlet) ---
    return val


# --------------------------------------------------------------------------
# Core Logic (exported for use in claims.py UDF)
# --------------------------------------------------------------------------

def elec_spec_logic(specs: Any) -> Optional[Dict[str, str]]:
    """
    Extract electrical specifications from spec_json as a simple key-value map.
    Same pattern as highlights extraction, with normalization applied.

    Args:
        specs: List of spec items (rows or dicts) with attribute_nm / attribute_value_txt

    Returns:
        Dict mapping attribute_name -> normalized_value (sorted by key), or None if no electrical attrs found.
    """
    if not specs:
        return None

    if isinstance(specs, str):
        try:
            specs_list = json.loads(specs)
        except:
            return None
    else:
        specs_list = specs

    result = {}
    for row in specs_list:
        c = row.asDict() if hasattr(row, 'asDict') else row
        if isinstance(c, dict):
            attr_name = c.get("attribute_nm")
            attr_value = c.get("attribute_value_txt")
            if attr_name and attr_name in ELECTRICAL_ATTRIBUTES and attr_value:
                category = ATTR_TO_CATEGORY.get(attr_name, "")
                result[attr_name] = normalize_value(attr_name, attr_value, category)

    return dict(sorted(result.items())) if result else None
