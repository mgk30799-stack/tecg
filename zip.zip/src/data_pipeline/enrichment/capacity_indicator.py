"""
Data Enrichment Pipeline - Capacity Indicator Extraction

Extracts capacity/load information from product specifications, titles,
descriptions, and bullet points. Capacity includes:
  - Weight capacity (e.g., chair: 250 lb capacity, shelf: 50 lb per shelf)
  - Volume capacity (e.g., bottle: 32 oz, trash bag: 13 gallon)
  - Count capacity (e.g., paper tray: 500 sheets)
  - Seating capacity (e.g., table seats 8 people)

Pipeline Steps:
1. Load product data from the source table (product_discovery_data).
2. Extract capacity from `spec_json` attributes (primary, structured source).
3. Fallback: regex extraction from title, bullets_json, and description.
4. Classify capacity type (weight, volume, count, seating).
5. Save the enriched data to a Delta table using `save_data` utility.

Output Columns:
- `capacity_value`: Numeric value extracted (as string for precision).
- `capacity_unit`: Unit of measurement (lbs, oz, gallons, seats, etc.).
- `capacity_type`: Classification (weight_capacity, volume_capacity, count_capacity, seating_capacity).
- `capacity_raw_text`: Original text the value was extracted from.
- `capacity_source`: Where the value was found (spec_json, title, bullets, description).

Usage:
    from src.data_pipeline.enrichment.capacity_indicator import run_capacity_indicator_pipeline

    run_capacity_indicator_pipeline(
        spark,
        source_table="mld01_ml_de.product.product_discovery_data",
        output_table="mld01_ml_de.product.product_capacity_indicator"
    )
"""

import sys
import os
import re
import json
import logging
from typing import Dict, Any, Optional

# Add project root to sys.path for absolute imports
try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    # Fallback for Databricks notebooks/jobs where __file__ is missing
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from databricks.connect import DatabricksSession
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField

from utils import save_data, get_spark_session, read_config, read_all_products


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _log_section(title: str, width: int = 60) -> None:
    logger.info("")
    logger.info("=" * width)
    logger.info(title)
    logger.info("=" * width)


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------
CAPACITY_SCHEMA = StructType([
    StructField("capacity_value", StringType(), True),
    StructField("capacity_unit", StringType(), True),
    StructField("capacity_type", StringType(), True),
    StructField("capacity_raw_text", StringType(), True),
    StructField("capacity_source", StringType(), True),
])


# ---------------------------------------------------------------------------
# Spec attributes that indicate capacity
# ---------------------------------------------------------------------------
CAPACITY_SPEC_ATTRIBUTES = [
    # --- Weight/Load capacity ---
    "Maximum Weight Capacity", "Weight Capacity", "Max Weight Capacity",
    "Load Capacity", "Maximum Load", "Max Load Capacity", "Weight Limit",
    "Capacity (lbs)", "Capacity (lb)", "Capacity (lbs.)",  # with period!
    "Bed Weight Capacity",
    "TV Mount Max Weight (Lbs)", "Weight Supported (Lbs)",
    "Folding Table Weight Capacity (lbs.)", "Maximum Weight Capacity (Lbs)",
    "Postal Scale & Meter Weight Capacity", "Bed Part Weight Capacity",
    "Weight Range (lbs.)", "Weight Capacity Per Shelf (Lbs)",
    "Chair Weight Capacity (lbs.)", "Max Weight Capacity (Lbs)",
    "Weight Limit (Lbs)", "Weight Capacity in Pounds",
    "Maximum Weight Capacity in Lbs", "Mounting Weight Capacity (lbs)",
    "Transfer Equipment Weight Capacity (Lbs)", "Weight Bench Capacity",
    "Weight Bar Capacity", "Body Weights (Lbs)", "Weight Capacity (lbs.)",
    "Ramp Weight Capacity (Lbs)",
    "Table Capacity (lbs.)",           
    "Chair Capacity (lbs.)",          
    "Load Capacity (lbs)",            
    "Step Stool & Ladder Capacity",    
    # --- Volume capacity ---
    "Capacity", "Volume Capacity", "Liquid Capacity",
    "Max Trash Bag Capacity (Gallons)", "Tank Capacity", "Water Capacity",
    "Capacity (oz)", "Capacity (Gallons)", "Capacity (fl oz)",
    "Cup Capacity", "Bottle Capacity", "Container Capacity",
    # --- Count/sheet capacity ---
    "Sheet Capacity", "Paper Capacity", "Tray Capacity",
    # --- Seating capacity ---
    "Seat Capacity",                  
    "Seating Capacity",               
]

_CAPACITY_ATTRS_LOWER = {a.lower() for a in CAPACITY_SPEC_ATTRIBUTES}


WEIGHT_UNITS = {"lb", "lbs", "pound", "pounds", "kg", "kilogram", "kilograms", "g", "gram", "grams"}
VOLUME_UNITS = {
    "oz", "fl oz", "fl. oz", "fluid ounce", "fluid ounces",
    "gallon", "gallons", "gal", "liter", "liters", "l", "ml",
    "milliliter", "milliliters", "quart", "quarts", "qt",
    "pint", "pints", "pt", "cup", "cups",
}
COUNT_UNITS = {"sheets", "pages", "cups", "trays"}
SEATING_UNITS = {"person", "persons", "people", "seat", "seats", "guest", "guests", "adult", "adults", "children"}


def classify_capacity_type(unit: str, attr_name: str = "") -> str:
    unit_lower = unit.lower().strip()
    attr_lower = attr_name.lower().strip()
    # Seating/person capacity
    if any(kw in attr_lower for kw in ["seat capacity", "seating capacity", "person"]):
        return "seating_capacity"
    if unit_lower in SEATING_UNITS:
        return "seating_capacity"
    # Weight/load capacity
    if any(kw in attr_lower for kw in ["weight capacity", "load capacity", "weight limit", "max load", "capacity (lbs", "table capacity", "chair capacity", "step stool", "ladder"]):
        return "weight_capacity"
    if any(kw in attr_lower for kw in ["liquid", "volume", "tank", "water", "gallon", "bottle", "fl oz"]):
        return "volume_capacity"
    if any(kw in attr_lower for kw in ["sheet", "paper", "tray"]):
        return "count_capacity"
    if unit_lower in WEIGHT_UNITS:
        return "weight_capacity"
    if unit_lower in VOLUME_UNITS:
        return "volume_capacity"
    if unit_lower in COUNT_UNITS:
        return "count_capacity"
    return "weight_capacity"


# ---------------------------------------------------------------------------
# Text regex patterns (ordered by priority)
# ---------------------------------------------------------------------------
CAPACITY_REGEX_PATTERNS = [
    # --- Original patterns ---
    (r'(?:holds?|supports?|carries?)\s+(?:up\s+to\s+)?(\d+\.?\d*)\s*(lbs?|pounds?|kg|oz|gallons?|gal|liters?|L)', 1, 2),
    (r'(\d+\.?\d*)[-\s]*(lbs?|pounds?|kg|oz|gallons?|gal|liters?|L)\s*capacity', 1, 2),
    (r'capacity[:\s]+(?:of\s+)?(\d+\.?\d*)\s*(fl\.?\s*oz|oz|lbs?|pounds?|gallons?|gal|ml|mL|liters?|L|kg|qt|quarts?)', 1, 2),
    (r'weight\s+capacity[:\s]+(\d+\.?\d*)\s*(lbs?|pounds?|kg)', 1, 2),
    (r'max(?:imum)?\s+capacity[:\s]+(\d+\.?\d*)\s*(lbs?|pounds?|kg|oz|gallons?|gal|liters?|L|ml)', 1, 2),
    # --- NEW: Furniture & Chairs patterns (from deep-dive analysis) ---
    # "500 lb. Weight Capacity" / "250-lb. capacity" / "880 lb. Weight Capacity"
    (r'(\d+\.?\d*)\s*[-]?\s*lb\.?\s*(?:weight\s+)?capacity', 1, None),
    # "Rated for up to 300 lbs" / "Rated to 500 lbs."
    (r'[Rr]ated\s+(?:for\s+|to\s+|at\s+)?(?:up\s+to\s+)?(\d+\.?\d*)\s*(lbs?\.?|pounds?|kg)', 1, 2),
    # "weight capacity: up to 275 lbs" / "Weight rating: 250 lbs"
    (r'[Ww]eight\s+(?:capacity|rating)[:\s]+(?:up\s+to\s+)?(\d+\.?\d*)\s*(lbs?\.?|pounds?|kg)', 1, 2),
    # "up to 250 lbs" (standalone)
    (r'(?:up\s+to\s+)(\d+\.?\d*)\s*(lbs?\.?|pounds?|kg)', 1, 2),
    # "accommodates up to 300 LBS" / "withstands 250 lbs"
    (r'(?:accommodat\w*|withstand\w*)\s+(?:up\s+to\s+)?(\d+\.?\d*)\s*(lbs?\.?|pounds?|kg)', 1, 2),
    # "X lbs per shelf" / "75 lb per shelf"
    (r'(\d+\.?\d*)\s*(lbs?\.?|pounds?)\s*(?:per|each)\s*shelf', 1, 2),
    # "Seats up to 8 People" / "seats 4"
    (r'[Ss]eats?\s+(?:up\s+to\s+)?(\d+)\s*(people|person|adults?|children|guests?)?', 1, 2),
    # "max load 250 lbs" / "maximum load: 500 lbs"
    (r'max(?:imum)?\s+(?:load|weight)\s*[:\s]+(\d+\.?\d*)\s*(lbs?\.?|pounds?|kg)?', 1, 2),
]

FALLBACK_UNIT_PATTERNS = [
    (r'(\d+\.?\d*)\s*(fl\.?\s*oz\.?)', 1, 2),
    (r'(\d+\.?\d*)\s*(gallons?|gal)', 1, 2),
]


def _infer_unit_from_attr_name(attr_name: str) -> str:
    lower = attr_name.lower()

    if any(x in lower for x in ["sheet", "paper", "tray"]):
        return "sheets"

    if any(x in lower for x in ["lbs", "lb", "pound"]):
        return "lbs"

    if any(x in lower for x in ["gallons", "gallon", "gal"]):
        return "gallons"

    if any(x in lower for x in ["fl oz", "fluid ounce", "(oz)", " oz"]):
        return "oz"

    if "seat capacity" in lower or "seating capacity" in lower:
        return "seats"

    return "lbs"


_UNIT_PATTERN = re.compile(
    r"(?<![A-Za-z])"
    r"(fl\.?\s*oz|fluid\s+ounces?|fluid\s+ounce|"
    r"gallons?|gal|liters?|litres?|ml|milliliters?|millilitres?|"
    r"quarts?|qt|pints?|pt|cups?|"
    r"pounds?|lbs?\.?|kilograms?|kgs?|kg|grams?|g|"
    r"sheets?|pages?|trays?|"
    r"people|persons?|seats?|guests?|adults?|children|"
    r"kilowatts?|kw|megawatts?|mw|watts?|w)"
    r"(?![A-Za-z])",
    re.IGNORECASE,
)


def _extract_unit(value_text: str, attr_name: str) -> str:
    match = _UNIT_PATTERN.search(value_text)
    if not match:
        return _infer_unit_from_attr_name(attr_name)

    unit = re.sub(r"\s+", " ", match.group(1).strip().lower()).rstrip(".")
    aliases = {
        "pound": "lbs", "pounds": "lbs", "lb": "lbs", "lbs": "lbs",
        "kilogram": "kg", "kilograms": "kg", "kgs": "kg",
        "gram": "g", "grams": "g",
        "kilowatt": "kw", "kilowatts": "kw",
        "megawatt": "mw", "megawatts": "mw",
        "watt": "w", "watts": "w",
        "gallon": "gallons", "liter": "liters", "litre": "liters",
        "litres": "liters", "milliliter": "ml", "milliliters": "ml",
        "millilitre": "ml", "millilitres": "ml",
    }
    return aliases.get(unit, unit)


def _capacity_result(value: str, unit: str, attr_name: str, attr_value: str) -> Dict[str, str]:
    return {
        "capacity_value": value,
        "capacity_unit": unit,
        "capacity_type": classify_capacity_type(unit, attr_name),
        "capacity_raw_text": f"{attr_name}: {attr_value}",
        "capacity_source": "spec_json",
    }


def extract_capacity_from_spec(specs: Any) -> Optional[Dict[str, str]]:
    if not specs:
        return None
    if isinstance(specs, str):
        try:
            specs_list = json.loads(specs)
        except (json.JSONDecodeError, TypeError):
            return None
    else:
        specs_list = specs

    for row in specs_list:
        item = row.asDict() if hasattr(row, 'asDict') else row
        if not isinstance(item, dict):
            continue
        attr_nm = (item.get("attribute_nm") or "").strip()
        attr_val = (item.get("attribute_value_txt") or "").strip()
        if not attr_nm or not attr_val:
            continue
        if attr_nm.lower() not in _CAPACITY_ATTRS_LOWER:
            continue
        
        # 1) Range
        # Examples:
        #   "20 - 29"
        #   "301 - 400 lbs."
        #   "401-500 lbs."
        #   "20–29 lb"
        m = re.match(
            r'^(\d+(?:\.\d+)?)\s*(?:[-\u2013\u2014]|to)\s*(\d+(?:\.\d+)?)\s*(.*)$',
            attr_val
        )

        if m:
            lower_bound = m.group(1)
            upper_bound = m.group(2)
            trailing_unit = m.group(3).strip().rstrip('.')

            # Preserve the complete range
            value = f"{lower_bound}-{upper_bound}"

            # Unit may be present after the range,
            # otherwise infer it from the attribute name.
            unit = _extract_unit(trailing_unit, attr_nm)
            return _capacity_result(value, unit, attr_nm, attr_val)

        # 2) "Up to 300 lbs."
        m = re.match(r'^[Uu]p\s+to\s+(\d+\.?\d*)\s*(.*)', attr_val)
        if m:
            value = m.group(1)
            unit = _extract_unit(m.group(2), attr_nm)
            return _capacity_result(value, unit, attr_nm, attr_val)
        
        # 3) "500+ lbs."
        m = re.match(r'^(\d+)\+\s*(.*)', attr_val)
        if m:
            value = m.group(1)
            unit = _extract_unit(m.group(2), attr_nm)
            return _capacity_result(value, unit, attr_nm, attr_val)
        # 4) "Under 100 lbs."
        m = re.match(r'^[Uu]nder\s+(\d+)\s*(.*)', attr_val)
        if m:
            value = m.group(1)
            unit = _extract_unit(m.group(2), attr_nm)
            return _capacity_result(value, unit, attr_nm, attr_val)
        # 5) Standard numeric: "350", "600 lbs"
        m = re.match(r'^(\d+(?:\.\d+)?(?:\s*/\s*\d+(?:\.\d+)?)?)\s*(.*)', attr_val)
        if m:
            value = m.group(1)
            unit = _extract_unit(m.group(2), attr_nm)
            return _capacity_result(value, unit, attr_nm, attr_val)
    return None


def extract_capacity_from_text(text: str, source_label: str) -> Optional[Dict[str, str]]:
    if not text:
        return None
    for pattern, val_group, unit_group in CAPACITY_REGEX_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value = match.group(val_group)
            # unit_group=None for patterns that infer unit (e.g. "500 lb. capacity")
            if unit_group is not None and match.lastindex >= unit_group and match.group(unit_group):
                unit = match.group(unit_group).strip().rstrip('.')
            else:
                unit = "lbs"
            cap_type = classify_capacity_type(unit)
            return {
                "capacity_value": value,
                "capacity_unit": unit.lower() if unit else None,
                "capacity_type": cap_type,
                "capacity_raw_text": match.group(0),
                "capacity_source": source_label,
            }
    for pattern, val_group, unit_group in FALLBACK_UNIT_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value = match.group(val_group)
            unit = match.group(unit_group).strip()
            cap_type = classify_capacity_type(unit)
            return {
                "capacity_value": value,
                "capacity_unit": unit.lower(),
                "capacity_type": cap_type,
                "capacity_raw_text": match.group(0),
                "capacity_source": source_label,
            }
    return None


def extract_capacity_logic(spec_json, title, description, bullets):
    result = extract_capacity_from_spec(spec_json)
    if result:
        return result
    result = extract_capacity_from_text(title, "title")
    if result:
        return result
    if bullets:
        for bullet in bullets:
            if bullet:
                result = extract_capacity_from_text(bullet, "bullets")
                if result:
                    return result
    result = extract_capacity_from_text(description, "description")
    if result:
        return result
    return None


# ---------------------------------------------------------------------------
# Extraction entrypoint
# ---------------------------------------------------------------------------

def extract_capacity_data(df: DataFrame) -> DataFrame:
    """
    Apply capacity extraction UDF to a product DataFrame.

    Args:
        df: DataFrame with columns: item_id, title, description, spec_json, bullets_json

    Returns:
        DataFrame with one row per input product and columns: item_id,
        capacity_value, capacity_unit, capacity_type, capacity_raw_text,
        capacity_source. Capacity columns are null when extraction fails.
    """
    @F.udf(CAPACITY_SCHEMA)
    def _extract_udf(spec_json, title, description, bullets):
        return extract_capacity_logic(spec_json, title, description, bullets)

    result_df = df.select(
        "item_id", "title", "description", "spec_json", "bullets_json"
    ).withColumn(
        "_cap",
        _extract_udf("spec_json", "title", "description", "bullets_json")
    ).select(
        "item_id",
        F.col("_cap.capacity_value").alias("capacity_value"),
        F.col("_cap.capacity_unit").alias("capacity_unit"),
        F.col("_cap.capacity_type").alias("capacity_type"),
        F.col("_cap.capacity_raw_text").alias("capacity_raw_text"),
        F.col("_cap.capacity_source").alias("capacity_source"),
    )

    return result_df


# ---------------------------------------------------------------------------
# Pipeline entrypoint
# ---------------------------------------------------------------------------

# Columns this task reads from its source table.
SOURCE_COLUMNS = ["item_id", "title", "description", "spec_json", "bullets_json"]


def run_capacity_indicator_pipeline(
    spark: DatabricksSession,
    source_table: str,
    output_table: str,
    output_catalog: str = None,
    output_schema: str = None,
    mode: str = "merge",
    delete_missing: bool = True,
    max_source_drop_rate: float = 0.50,
) -> DataFrame:
    """Run capacity extraction as a current-source snapshot.

    The output contains one row per source product; capacity fields are null
    when extraction finds no value. Merge with source-driven deletion keeps the
    target synchronized without rewriting the complete table.
    """
    _log_section("CAPACITY INDICATOR EXTRACTION PIPELINE", width=80)

    logger.info("1. Loading data from %s...", source_table)
    try:
        df = read_all_products(spark, source_table, SOURCE_COLUMNS)
        total_count = df.count()
        logger.info("Loaded %s rows", total_count)
    except Exception:
        logger.exception("Error loading table %s", source_table)
        raise

    null_key_count = df.where(F.col("item_id").isNull()).count()
    if null_key_count:
        raise ValueError(
            f"Capacity source contains {null_key_count} rows with null item_id; refusing to merge."
        )

    source_key_count = df.select("item_id").distinct().count()
    duplicate_key_count = total_count - source_key_count
    if duplicate_key_count:
        duplicate_ids = [
            row["item_id"]
            for row in df.groupBy("item_id").count()
            .where(F.col("count") > 1)
            .select("item_id")
            .limit(10)
            .collect()
        ]
        raise ValueError(
            f"Capacity source contains {duplicate_key_count} duplicate rows for item_id; "
            f"sample duplicate IDs: {duplicate_ids}"
        )

    if delete_missing and max_source_drop_rate is not None:
        if spark.catalog.tableExists(output_table):
            target_key_count = spark.table(output_table).select("item_id").distinct().count()
        else:
            target_key_count = None

        if target_key_count and source_key_count < target_key_count * (1 - max_source_drop_rate):
            drop_rate = 1 - (source_key_count / target_key_count)
            raise ValueError(
                f"Capacity source population dropped by {drop_rate:.2%} "
                f"({target_key_count} to {source_key_count}), exceeding the allowed "
                f"{max_source_drop_rate:.2%}; refusing source-driven deletion."
            )

    logger.info("2. Extracting capacity indicators...")
    result_df = extract_capacity_data(df)
    result_count = result_df.count()
    extracted_count = result_df.where(F.col("capacity_value").isNotNull()).count()
    result_key_count = result_df.where(F.col("capacity_value").isNotNull()).select("item_id").where(F.col("item_id").isNotNull()).distinct().count()

    logger.info(
        "Capacity extracted: %s / %s (%.1f%%)",
        extracted_count, source_key_count, (extracted_count / source_key_count * 100) if source_key_count > 0 else 0
    )
    logger.info(
        "Output rows: %s; distinct source keys: %s; distinct capacity keys: %s; duplicate output rows: %s",
        result_count, source_key_count, result_key_count, 0,
    )

    # Log breakdown by type
    type_counts = result_df.groupBy("capacity_type").count().collect()
    for row in type_counts:
        logger.info("  %s: %s", row["capacity_type"], row["count"])

    # Log breakdown by source
    source_counts = result_df.groupBy("capacity_source").count().collect()
    for row in source_counts:
        logger.info("  %s: %s", row["capacity_source"], row["count"])

    logger.info("3. Saving results to %s...", output_table)
    save_data(
        result_df,
        spark,
        catalog=output_catalog,
        schema=output_schema,
        table=output_table,
        mode=mode,
        delete_missing=delete_missing,
        min_row_count=0,
    )

    _log_section("PIPELINE COMPLETE", width=80)
    return result_df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    spark = get_spark_session()

    GENERAL_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
    _general_config = read_config(GENERAL_CONFIG_PATH)

    SOURCE_TABLE = _general_config["capacity_indicator"]["tables"]["source_table"]
    OUTPUT_TABLE = _general_config["capacity_indicator"]["tables"]["output_table"]

    logger.info("Running Capacity Indicator Pipeline with the following configuration:")
    logger.info("Source Table: %s", SOURCE_TABLE)
    logger.info("Output Table: %s", OUTPUT_TABLE)
    

    run_capacity_indicator_pipeline(spark, SOURCE_TABLE, OUTPUT_TABLE)
