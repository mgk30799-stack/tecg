import os
import json
import yaml
import uuid
import logging
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Dict, List, NamedTuple, Optional

from databricks.connect import DatabricksSession
from pyspark.sql import Column, DataFrame, SparkSession
from pyspark.sql.window import Window
from pyspark.sql.types import (
    ArrayType, MapType, NullType, StringType, StructField, StructType, TimestampType,
)
import pyspark.sql.functions as F

logger = logging.getLogger(__name__)


UNIT_TAG_SCHEMA = StructType([
    StructField("unit_id", StringType(), False),
    StructField("item_id", StringType(), False),
    StructField("source", StringType(), False),
    StructField("source_id", StringType(), True),
    StructField("source_text", StringType(), True),
    StructField("issues_json", StringType(), True),
    StructField("faq_json", StringType(), True),
    StructField("created_at_ts", TimestampType(), True),
    StructField("last_updated_ts", TimestampType(), True),
])
UNIT_TAG_COLUMNS = UNIT_TAG_SCHEMA.fieldNames()
_JSON_OPTIONS = {
    "ignoreNullFields": "false",
    "timestampFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX",
}


def _with_unit_id(rows: DataFrame, fallback_column: str) -> DataFrame:
    return rows.withColumn(
        "unit_id",
        F.sha2(F.to_json(F.struct(
            "item_id", "source", "source_id",
            F.when(F.col("source_id").isNull(), F.col(fallback_column)).alias("fallback"),
        )), 256),
    )


def faq_unit_rows(tags: DataFrame) -> DataFrame:
    rows = tags.select(
        F.col("item_id").cast("string").alias("item_id"),
        "tag_id",
        F.lit("qa").alias("source"),
        F.col("question_id").cast("string").alias("source_id"),
        F.col("question").alias("source_text"),
        F.to_json(F.struct(*tags.columns), options=_JSON_OPTIONS).alias("faq_json"),
        "created_at_ts", "last_updated_ts",
    )
    return (
        _with_unit_id(rows, "tag_id")
        .withColumn("issues_json", F.lit(None).cast("string"))
        .select(*UNIT_TAG_COLUMNS)
        .dropDuplicates(["unit_id"])
    )


def issue_unit_rows(tags: DataFrame) -> DataFrame:
    rows = _with_unit_id(tags, "source_text")
    return (
        rows.groupBy("unit_id", "item_id", "source", "source_id")
        .agg(
            F.first("source_text", ignorenulls=True).alias("source_text"),
            F.to_json(
                F.sort_array(F.collect_set(F.struct(*tags.columns))),
                options=_JSON_OPTIONS,
            ).alias("issues_json"),
            F.min("created_at_ts").alias("created_at_ts"),
            F.max("last_updated_ts").alias("last_updated_ts"),
        )
        .withColumn("faq_json", F.lit(None).cast("string"))
        .select(*UNIT_TAG_COLUMNS)
    )


def write_unit_tags(
    spark: SparkSession, rows: DataFrame, output_table: str, payload_column: str,
) -> None:
    """Upsert one half without clearing the other half or the unit's creation time."""
    if payload_column not in ("issues_json", "faq_json"):
        raise ValueError(f"Unsupported unit-tag payload: {payload_column}")
    other_payload = "faq_json" if payload_column == "issues_json" else "issues_json"
    if spark.catalog.tableExists(output_table):
        # strict is safe here: UNIT_TAG_SCHEMA is a declared constant, not a
        # per-run df.schema, so a column missing from it really was retired.
        incremental_save_data(
            rows, spark, table=output_table, id_col="unit_id",
            schema_mode="strict", expected_schema=UNIT_TAG_SCHEMA,
            update_fields={
                column: f"updates.{column}"
                for column in UNIT_TAG_COLUMNS
                if column not in ("unit_id", "created_at_ts", other_payload)
            },
        )
    else:
        save_data(
            rows, spark, table=output_table, id_col="unit_id",
            required_columns=["unit_id", "item_id", "source"],
        )


def read_faq_tags(
    spark: SparkSession, output_table: str, faq_schema: StructType,
) -> DataFrame:
    return (
        spark.table(output_table)
        .filter(F.col("faq_json").isNotNull())
        .select(F.from_json("faq_json", faq_schema, options=_JSON_OPTIONS).alias("_faq"))
        .select("_faq.*")
    )


def question_id_expr(item_id: Column, position: Column) -> Column:
    """
    Build `tag_id`: "{item_id}_{position+1}", e.g. "108616_1".

    A surrogate key (position in q_and_a, which is not order-stable across runs);
    never write it to `question_id`. question_id_str is the pure-Python counterpart.
    """
    return F.concat(item_id, F.lit("_"), (position + F.lit(1)).cast("string"))


def question_id_str(item_id, position: int) -> str:
    """
    Pure-Python counterpart to question_id_expr; must produce the same "{item_id}_{n}" tag_id.
    `position` is 0-based. Never assign the result to `question_id`.
    """
    return f"{item_id}_{position + 1}"


# The site whose questions the loader actually writes into q_and_a. MUST match
# discovery_data_loader.py's answers_per_question CTE (WHERE q.site_id =
# 'STAPLESUS').
#
# This is load-bearing, not cosmetic. resolve_question_keys keeps the LATEST
# source row per (product, question text). Scanning a wider set than the loader
# wrote lets a row from another site — one the loader never sourced this
# question from — win that dedupe on a newer SUBMISSION_TMS and hand the
# pipeline its QUESTION_ID and its timestamp. The result looks entirely normal:
# the field is populated, just with the wrong row's values.
#
# Deliberately NOT applied to the answers table: the loader does not filter
# answers either, and that join is already constrained by QUESTION_ID.
QUESTION_SITE_ID = "STAPLESUS"
# The same for q_and_a_contract in product_discovery_data_all: the loader takes Staples Business
# questions from this site (discovery_data_loader.py CONTRACT_SITE_ID).
CONTRACT_QUESTION_SITE_ID = "STAPLESADVANTAGE"


def resolve_question_keys(
    spark,
    df: DataFrame,
    questions_table: str,
    answers_table: Optional[str] = None,
    site_id: str = QUESTION_SITE_ID,
) -> Optional[DataFrame]:
    """
    Resolve q_and_a questions (and optionally answers) to their Snowflake source rows
    by text, site-filtered and deduped to the latest submission.

    Returns one row per item with _question_meta_map (and _answer_meta_map when
    answers_table is given), keyed by tag_id; or None when keys cannot be resolved
    (callers emit NULL ids). Duplicate question text on one product resolves to one id.

    Args:
        spark:           Active SparkSession.
        df:              Frame with item_id and the raw q_and_a array.
        questions_table: Fully qualified product_web_question.
        answers_table:   Fully qualified product_web_answer, or None for question ids only.
        site_id:         Site to narrow the questions table to.
    """
    try:
        # Aliased scans with columns renamed at selection time: no bare
        # QUESTION_ID or PRODUCT_ID survives into the join scope, so
        # AMBIGUOUS_REFERENCE has nothing to attach to if these tables ever
        # resolve to the same view.
        w_q = Window.partitionBy("q_product_id", "q_text_for_match").orderBy(
            F.col("q_submission_ts").desc_nulls_last()
        )

        # Narrow to the loader's site BEFORE the dedupe, so a foreign-site row
        # cannot win latest-per-text and attach its QUESTION_ID/SUBMISSION_TMS
        # to a question the loader sourced from a different row entirely.
        # See QUESTION_SITE_ID.
        #
        # Existence-checked rather than assumed, the same way ANSWER_ID is
        # below: .columns is metadata only, no job runs. A renamed column costs
        # precision — we fall back to scanning every site, which is the older
        # behaviour — instead of raising and blanking every id downstream.
        question_scan = spark.table(questions_table).alias("qts")
        question_cols = {c.upper() for c in question_scan.columns}

        # Fail EXPLICITLY on a table that cannot support the match at all.
        # Without this the missing column surfaces as an AnalysisException from
        # deep inside the plan, the except at the bottom swallows it, and the
        # only evidence is one warning naming a Spark internal — while every
        # question_id silently comes out NULL. Name the columns instead.
        required = {
            "PRODUCT_ID", "QUESTION_ID", "QUESTION_DETAILS_TXT", "SUBMISSION_TMS",
        }
        absent = sorted(required - question_cols)
        if absent:
            logger.warning(
                "%s is missing required column(s) %s — question ids cannot be "
                "resolved and will all be NULL. Point QUESTIONS_TABLE at a "
                "table with the product_web_question shape.",
                questions_table, absent,
            )
            return None

        if "SITE_ID" in question_cols:
            question_scan = question_scan.filter(
                F.col("qts.SITE_ID") == F.lit(site_id)
            )
        else:
            logger.warning(
                "%s has no SITE_ID column — cannot narrow to '%s' the way "
                "discovery_data_loader does, so a question answered on another "
                "site may supply the QUESTION_ID and submission_date",
                questions_table, site_id,
            )

        # Match nvl(details, summary) like the loader; QUESTION_SUMMARY_TXT is optional.
        if "QUESTION_SUMMARY_TXT" in question_cols:
            question_text_col = F.coalesce(
                F.col("qts.QUESTION_DETAILS_TXT"),
                F.col("qts.QUESTION_SUMMARY_TXT"),
            )
        else:
            logger.warning(
                "%s has no QUESTION_SUMMARY_TXT column — matching on "
                "QUESTION_DETAILS_TXT alone. Any question the loader sourced "
                "from the summary text will not resolve.", questions_table,
            )
            question_text_col = F.col("qts.QUESTION_DETAILS_TXT")

        wq = (
            question_scan
            .select(
                F.col("qts.PRODUCT_ID").cast("string").alias("q_product_id"),
                F.col("qts.QUESTION_ID").cast("string").alias("q_question_id"),
                question_text_col.alias("q_text_for_match"),
                F.col("qts.SUBMISSION_TMS").cast("string").alias("q_submission_ts"),
            )
            .withColumn("_rn", F.row_number().over(w_q))
        )

        # Duplicate (product, question text) means two source questions collapse
        # onto one QUESTION_ID here — see the KNOWN LIMIT in the docstring.
        # Counted before the _rn filter discards the losers, so the collapse is
        # measurable rather than silent. Behaviour is unchanged.
        try:
            collapsed = wq.filter(F.col("_rn") > 1).count()
            if collapsed:
                logger.warning(
                    "%d source question(s) share a (product, question text) with "
                    "another and were dropped by the latest-wins dedupe. Those "
                    "q_and_a entries will carry the SURVIVING question's "
                    "QUESTION_ID and submission_date, not their own — q_and_a "
                    "carries no id to tell them apart.", collapsed,
                )
        except Exception as e:
            logger.warning("Could not count duplicate question text (%s)", e)

        wq = wq.filter(F.col("_rn") == 1).drop("_rn")

        # q_idx from posexplode IS the question's position in the raw q_and_a
        # array, which is what the positional key is built from — the same
        # position review_mining captures inside its own loop before ranking
        # reorders the candidates.
        exploded = (
            df
            .select(
                F.col("item_id").cast("string").alias("item_id"),
                F.col("q_and_a"),
            )
            .filter(F.col("q_and_a").isNotNull())
            .select(
                "item_id",
                F.posexplode("q_and_a").alias("q_idx", "qa_item"),
            )
            .select(
                "item_id",
                "q_idx",
                F.col("qa_item.q").alias("question_text"),
                F.col("qa_item.a").alias("answer_texts"),
            )
        )

        q_matched = exploded.join(
            wq,
            (exploded["item_id"] == wq["q_product_id"])
            & (exploded["question_text"] == wq["q_text_for_match"]),
            "inner",
        )

        # One row per (item, question) either way. The groupBy below IS the key
        # dedupe, so tag_id is unique per item by construction and
        # map_from_entries cannot raise.
        per_question_src = q_matched
        answer_aggs = []

        if answers_table:
            # ANSWER_ID is the one column here nothing else in this repo reads,
            # so its presence is confirmed against the live schema rather than
            # assumed. .columns is metadata only — no job runs. A differently
            # named key costs the answer ids and nothing else; timestamps still
            # resolve.
            answer_cols = {c.upper() for c in spark.table(answers_table).columns}
            answer_id_col = (
                F.col("ats.ANSWER_ID").cast("string") if "ANSWER_ID" in answer_cols
                else F.lit(None).cast("string")
            )
            if "ANSWER_ID" not in answer_cols:
                logger.warning(
                    "%s has no ANSWER_ID column — faq_json.answer_ids will be empty",
                    answers_table,
                )

            w_a = Window.partitionBy("a_question_id", "a_text_for_match").orderBy(
                F.col("a_submission_ts").desc_nulls_last()
            )
            wa = (
                spark.table(answers_table).alias("ats")
                .select(
                    F.col("ats.QUESTION_ID").cast("string").alias("a_question_id"),
                    answer_id_col.alias("a_answer_id"),
                    F.col("ats.ANSWER_TXT").alias("a_text_for_match"),
                    F.col("ats.SUBMISSION_TMS").cast("string").alias("a_submission_ts"),
                )
                .withColumn("_rn", F.row_number().over(w_a))
                .filter(F.col("_rn") == 1)
                .drop("_rn")
            )

            # posexplode_outer + left join: a question with no answers, or whose
            # answers match nothing, must keep its row or it loses its own
            # timestamp too. a_pos is the answer's index in the RAW `a` array.
            per_question_src = q_matched.select(
                "item_id", "q_idx", "q_question_id", "q_submission_ts",
                F.posexplode_outer("answer_texts").alias("a_pos", "answer_text"),
            ).join(
                wa,
                (F.col("q_question_id") == wa["a_question_id"])
                & (F.col("answer_text") == wa["a_text_for_match"]),
                "left",
            )

            answer_aggs = [
                # collect_list drops the NULLs that F.when yields, so unmatched
                # or absent answers simply leave no entry. Element ORDER is not
                # guaranteed and does not matter: every element carries its own
                # `position` and the UDF looks up by that, never by index.
                F.collect_list(
                    F.when(
                        F.col("a_answer_id").isNotNull()
                        | F.col("a_submission_ts").isNotNull(),
                        F.struct(
                            F.col("a_pos").cast("int").alias("position"),
                            F.col("a_answer_id").alias("answer_id"),
                            F.col("a_submission_ts").alias("submission_tms"),
                        ),
                    )
                ).alias("answers"),
            ]

        per_question = (
            per_question_src
            .groupBy("item_id", "q_idx")
            .agg(
                F.first("q_question_id", ignorenulls=True).alias("question_id"),
                F.first("q_submission_ts", ignorenulls=True).alias("submission_tms"),
                *answer_aggs,
            )
            .withColumn(
                "tag_id", question_id_expr(F.col("item_id"), F.col("q_idx")),
            )
        )

        map_aggs = [
            F.map_from_entries(
                F.collect_list(
                    F.struct(
                        F.col("tag_id"),
                        F.struct(
                            F.col("question_id").alias("question_id"),
                            F.col("submission_tms").alias("submission_tms"),
                        ).alias("q_meta"),
                    )
                )
            ).alias("_question_meta_map"),
        ]
        if answers_table:
            map_aggs.append(
                F.map_from_entries(
                    F.collect_list(F.struct(F.col("tag_id"), F.col("answers")))
                ).alias("_answer_meta_map")
            )

        return per_question.groupBy("item_id").agg(*map_aggs)
    except Exception as e:
        logger.warning(
            "Failed to resolve FAQ question keys (%s) — question_id will be "
            "NULL and submission_date empty", e,
        )
        return None


# ---------------------------------------------------------------------------
# product_discovery_data_all column names
# ---------------------------------------------------------------------------
# The loader writes product_discovery_data_all (every product on Staples.com or Staples Business)
# with these lists, and read_all_products gives its Staples.com columns back their
# product_discovery_data names for the tasks that read it.

# Columns about the product itself. They keep their product_discovery_data names. A product in
# product_discovery_data carries exactly its values; a product only on Staples Business gets them
# from the same expressions as load_product_master.
ALL_BU_PRODUCT_COLUMNS = [
    "upc", "corp_class_id", "corp_class_nm", "corp_department_id", "corp_department_nm",
    "corp_division_id", "corp_division_nm", "ean", "gtin", "mpn", "brand", "own_brand_ind",
    "manufacturer", "model_number", "title", "description", "dimensions", "length", "width",
    "height", "weight", "dimension_unit", "weight_unit", "sell_unit_dimensions", "sell_unit_length",
    "sell_unit_width", "sell_unit_height", "sell_unit_weight", "spec_json", "bullets_json", "image_url",
    "additional_image_urls", "product_create_date", "review_count", "star_rating",
    "eco_feature_ind", "eco_energy_star_certified_ind", "eco_recycled_ind", "bopis_eligible",
    "ship_from_store_ind", "auto_restock_ind", "is_eligible_search", "is_eligible_checkout",
    "web_headliner_statement_txt",
]
# Product columns that only product_discovery_data computes (from Staples.com data, or over its
# own population). Empty for a product only on Staples Business.
ALL_BU_DOTCOM_ONLY_COLUMNS = ["review_aspects", "review_overall_summary", "size_category"]
# Staples.com columns, renamed so that every per-site column ends in _dotcom or _contract
# (product_discovery_data name -> product_discovery_data_all name). Empty for a product only on
# Staples Business.
ALL_BU_DOTCOM_COLUMNS = {
    "url": "url_dotcom",
    "pm_price": "price_dotcom",
    "web_first_published_date": "web_first_published_date_dotcom",
    "group_id": "group_id_dotcom",
    "listing_has_variations": "listing_has_variations_dotcom",
    "store_name": "store_name_dotcom",
    "seller_url": "seller_url_dotcom",
    "seller_privacy_policy": "seller_privacy_policy_dotcom",
    "seller_tos": "seller_tos_dotcom",
    "return_policy": "return_policy_dotcom",
    "return_window": "return_window_dotcom",
    "store_country": "store_country_dotcom",
    "support_channel_json": "support_channel_json_dotcom",
    "store_review_count": "review_count_dotcom",
    "store_star_rating": "star_rating_dotcom",
    "q_and_a": "q_and_a_dotcom",
    "reviews": "reviews_dotcom",
    "related_product_id": "related_product_id_dotcom",
    "similar_item_ids": "similar_item_ids_dotcom",
    "relationship_type": "relationship_type_dotcom",
    "dropship_dotcom_ind": "dropship_ind_dotcom",
    "sales_velocity": "sales_velocity_dotcom",
    "sales_amt_lt_30days": "sales_amt_lt_30days_dotcom",
}
# Hierarchy levels. The Staples.com hierarchy (web_*_dotcom) is filled for products only on
# Staples Business too, because the SB tagger classifies against it.
ALL_BU_HIERARCHY_LEVELS = ["class_id", "class_nm", "department_id", "department_nm",
                           "category_id", "category_nm", "supercategory_id", "supercategory_nm"]


def dotcom_names_in_all_bu() -> Dict[str, str]:
    """Every product_discovery_data column name, mapped to its name in product_discovery_data_all."""
    names = {c: c for c in ALL_BU_PRODUCT_COLUMNS + ALL_BU_DOTCOM_ONLY_COLUMNS}
    names.update({"web_" + lv: "web_" + lv + "_dotcom" for lv in ALL_BU_HIERARCHY_LEVELS})
    names.update(ALL_BU_DOTCOM_COLUMNS)
    return names


def read_all_products(spark: SparkSession, table: str, columns: List[str]) -> DataFrame:
    """Every product of product_discovery_data_all, with its Staples.com columns under their
    product_discovery_data names, so a task written for product_discovery_data reads it as before.
    The site flags and the _contract columns keep their names.

    Reads one version of the table, so the whole task sees the same copy, and raises if any of
    `columns` is missing instead of letting the task fill it with NULL.
    """
    version = spark.sql(f"DESCRIBE HISTORY {table} LIMIT 1").first()["version"]
    df = spark.read.option("versionAsOf", version).table(table)
    renames = {all_bu: name for name, all_bu in dotcom_names_in_all_bu().items()
               if all_bu != name and all_bu in df.columns}
    clashes = sorted(set(renames.values()) & set(df.columns))
    if clashes:
        raise ValueError(f"{table} already has column(s) {', '.join(clashes)}")
    df = df.select(*[F.col(c).alias(renames.get(c, c)) for c in df.columns])
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"{table} has no column(s) {', '.join(missing)}")
    logger.info("Reading %s version %s", table, version)
    return df


# The hazard table's yes/no flags and codes; its other columns are free text.
HAZARD_FLAG_COLUMNS = frozenset({
    "PROP_65_IND", "WERCS_P651_IND", "HAZMAT_CD", "SDS_REQUIRED_IND",
    "BATTERY_CONTAINING_PRODUCT_IND", "WERCS_BATT_IND", "AEROSOL_INDICATOR_CD",
})
# Values that say nothing: a blank, a flag's N or U, or a placeholder the warning and age rules
# skip ("y" is one too for free text).
_HAZARD_NO_INFO = ["", "n", "u", "no", "n/a", "na", "none", "null", "blank", "-", "--",
                   "unknown", "see sds", "nan"]


def read_hazard_by_product(spark: SparkSession, table: str, columns: List[str]) -> DataFrame:
    """One row per PRODUCT_ID of the hazard table, with `columns`.

    The table has a row per product per source system (PRODUCT_SOURCE_CD), and the sources do not
    always agree. A flag is Y when any source says Y, and every column takes a value that says
    something (a code or real text) over an N, a U, a blank or a placeholder. Ties go to the first
    source code alphabetically. A product with one row keeps that row's values.
    """

    def pick(column: str) -> Column:
        value = F.col(column)
        text = F.lower(F.trim(value.cast("string")))
        is_flag = column in HAZARD_FLAG_COLUMNS
        no_info = _HAZARD_NO_INFO if is_flag else _HAZARD_NO_INFO + ["y"]
        tier = (F.when(F.lit(is_flag) & (text == "y"), 0)
                .when(~text.isin(*no_info), 1)
                .otherwise(2))
        # Rows without a value are skipped, and the value itself breaks any tie left, so the pick
        # never depends on the order the rows arrive in.
        order = F.when(value.isNotNull(),
                       F.struct(tier, F.col("PRODUCT_SOURCE_CD"), value.cast("string")))
        return F.min_by(value, order).alias(column)

    return spark.table(table).groupBy("PRODUCT_ID").agg(*[pick(c) for c in columns])


def get_spark_session() -> DatabricksSession:
    """
    Dynamically create a Spark session.
    - Uses native Spark context if running on a Databricks cluster (e.g., Job).
    - Uses Databricks Connect with .env credentials if running locally.
    """
    # Databricks clusters always have this environment variable defined
    if os.getenv("DATABRICKS_RUNTIME_VERSION"):
        print("Running on Databricks cluster. Using native Spark session.")
        return DatabricksSession.builder.getOrCreate()
    else:
        print("Running locally. Using Databricks Connect.")
        from dotenv import load_dotenv
        load_dotenv()
        
        databricks_host = os.getenv('DATABRICKS_HOST', '').rstrip('/')
        databricks_token = os.getenv('DATABRICKS_TOKEN', '')
        cluster_id = os.getenv('DATABRICKS_CLUSTER_ID', '')
        
        if not databricks_host or not databricks_token:
            raise ValueError("DATABRICKS_HOST and DATABRICKS_TOKEN must be set in .env for local development.")
            
        return (DatabricksSession.builder
            .remote(host=databricks_host, token=databricks_token, cluster_id=cluster_id if cluster_id else None)
            .getOrCreate())

def replace_env_placeholders(obj, env_val):
    """Recursively replaces {env} placeholders in any string in the config object."""
    if isinstance(obj, dict):
        return {k: replace_env_placeholders(v, env_val) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [replace_env_placeholders(i, env_val) for i in obj]
    elif isinstance(obj, str):
        return obj.replace('{env}', env_val)
    else:
        return obj
    
ENVS = {
    'dev': 'de',
    'qa': 'qe',
    'prod': 'pe'
}
CATALOG = {
    'dev': 'mld01_ml_de',
    'qa': 'mld01_ml_qe',
    'prod': 'mld01_ml_pe'
}
CATALOG_TO_RUN_MODE = {v: k for k, v in CATALOG.items()}

def get_run_mode(catalog: str = None) -> str:
    """
    Determine the runtime environment (dev/qa/prod): reverse-lookup `catalog` if
    given, else read the sf_env environment variable.

    Args:
        catalog: Optional catalog name (e.g., 'mld01_ml_qe')

    Returns:
        str: 'dev', 'qa', or 'prod'

    Raises:
        ValueError: If the environment cannot be determined outside local dev.
    """
    if catalog:
        run_mode = CATALOG_TO_RUN_MODE.get(catalog, None)
        if run_mode is None:
            raise ValueError(
                f"Unknown catalog '{catalog}'. Expected one of: {list(CATALOG.values())}"
            )
        return run_mode

    sf_env = os.environ.get("sf_env", "").strip()

    if 'prod' in sf_env.lower():
        return 'prod'
    elif 'qa' in sf_env.lower():
        return 'qa'
    elif 'dev' in sf_env.lower():
        return 'dev'

    # Only allow implicit 'dev' in local development (DATABRICKS_RUNTIME_VERSION not set)
    if not os.getenv("DATABRICKS_RUNTIME_VERSION"):
        print("WARNING: Running locally without sf_env set. Defaulting to 'dev'.")
        return 'dev'

    # In Databricks cluster, sf_env must be explicitly set
    raise ValueError(
        "Environment cannot be determined. "
        "sf_env environment variable is not set in Databricks cluster. "
        "Ensure spark_env_vars sets sf_env in the DAB job configuration, "
        "OR pass catalog parameter from dbutils.widgets in notebooks."
    )

def read_config(config_path: str, env_val: str = None, run_mode: str = None) -> dict:
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    if env_val is None:
        if run_mode is None:
            run_mode = get_run_mode()
        env_val = ENVS[run_mode]
    config = replace_env_placeholders(config, env_val)
    return config

def validate_dataframe_schema(
    df: DataFrame,
    required_columns: list = None,
    min_row_count: int = 1,
    max_null_rate: float = 0.05,
    key_columns: list = None
) -> None:
    """
    Validate DataFrame schema and data quality before writing.

    Args:
        df: DataFrame to validate
        required_columns: List of columns that must be present (None = skip check)
        min_row_count: Minimum number of rows required (default 1)
        max_null_rate: Maximum allowed null rate for key columns (default 5%)
        key_columns: Columns to check null rate on (None = use required_columns)

    Raises:
        ValueError: If validation fails
    """
    # Check row count
    row_count = df.count()
    if row_count < min_row_count:
        raise ValueError(
            f"DataFrame validation failed: row count {row_count} is below minimum {min_row_count}"
        )

    # Check required columns
    if required_columns:
        df_columns = set(df.columns)
        missing_cols = set(required_columns) - df_columns
        if missing_cols:
            raise ValueError(
                f"DataFrame validation failed: missing required columns {sorted(missing_cols)}"
            )

    # Check null rates on key columns
    if key_columns or required_columns:
        check_cols = key_columns if key_columns else required_columns
        for col in check_cols:
            if col in df.columns:
                null_count = df.filter(df[col].isNull()).count()
                null_rate = null_count / row_count if row_count > 0 else 0
                if null_rate > max_null_rate:
                    raise ValueError(
                        f"DataFrame validation failed: column '{col}' has null rate {null_rate:.2%} "
                        f"which exceeds maximum {max_null_rate:.2%} ({null_count}/{row_count} nulls)"
                    )

    logger.info(
        f"✓ DataFrame validation passed: {row_count} rows, "
        f"{len(df.columns)} columns"
    )

# =============================================================================
# SCHEMA ALIGNMENT
# =============================================================================

class SchemaDriftError(RuntimeError):
    """A target table's schema no longer matches what the pipeline produces."""


_SCHEMA_MODES = ("strict", "evolve", "overlap")
_GENERAL_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "config", "general.yml",
)
_schema_align_switch: dict = {}


_TRUE_WORDS = ("true", "yes", "on", "1")
_FALSE_WORDS = ("false", "no", "off", "0")


def _parse_bool(value):
    """
    A YAML boolean, or None when `value` is not one.

    bool() is NOT used: bool("false") is True, so a quoted `"false"` would
    silently mean the opposite of what it says.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return {0: False, 1: True}.get(value)
    if isinstance(value, str):
        word = value.strip().lower()
        if word in _TRUE_WORDS:
            return True
        if word in _FALSE_WORDS:
            return False
    return None


def _parse_non_negative_number(value):
    """A number >= 0 (bools excluded), or None when `value` is not one."""
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number >= 0 else None


def _schema_align_setting(key: str, default, parse=_parse_bool):
    """
    A `schema_align.<key>` setting from general.yml, read once per process.

    Read straight from the YAML rather than through read_config: the settings
    are not environment-specific, so there is no {env} to substitute and no
    reason to depend on sf_env being set. A missing file or key means
    `default`; so does an unreadable file, invalid YAML, or a value `parse`
    rejects — each with a warning, never a crash.
    """
    if key not in _schema_align_switch:
        value = default
        try:
            with open(_GENERAL_CONFIG_PATH, "r") as f:
                cfg = yaml.safe_load(f) or {}
            block = cfg.get("schema_align") if isinstance(cfg, dict) else None
            raw = block.get(key, default) if isinstance(block, dict) else default
            parsed = parse(raw)
            if parsed is None:
                logger.warning(
                    "schema_align.%s in %s is %r, which is not valid — using %r",
                    key, _GENERAL_CONFIG_PATH, raw, default,
                )
            else:
                value = parsed
        except (OSError, yaml.YAMLError) as e:
            logger.warning(
                "Could not read %s (%s) — schema_align.%s defaults to %r",
                _GENERAL_CONFIG_PATH, e, key, default,
            )
        _schema_align_switch[key] = value
    return _schema_align_switch[key]


def schema_align_enabled() -> bool:
    """schema_align.enabled — missing means true, the default every caller used
    before this reader existed."""
    return _schema_align_setting("enabled", True)


def schema_align_complex_dtype_only() -> bool:
    """schema_align.complex_dtype_only — missing means false: every dtype change,
    scalar or complex, is migrated."""
    return _schema_align_setting("complex_dtype_only", False)


def schema_align_retype_cooldown_hours() -> float:
    """schema_align.retype_cooldown_hours — how long after a column is retyped
    SVL refuses to retype it again. Missing means 24; 0 turns the guard off."""
    return _schema_align_setting(
        "retype_cooldown_hours", 24.0, parse=_parse_non_negative_number,
    )


class SchemaValidation(NamedTuple):
    """
    Result of validate_table_schema — step 1 of the schema validation layer.

    status:  "PASS"      the table already matches for this mode
             "NEW_TABLE" the table does not exist yet; the write creates it
             "MISMATCH"  step 2 (align_table_schema) has something to change
    retyped: [(name, table_type, code_type)] columns whose type differs
    added:   columns the code produces that the table lacks
    removed: columns the migration would DROP (strict mode only)
    kept:    columns only the table has, which this mode keeps (evolve mode)
    """
    table: str
    mode: str
    status: str
    retyped: tuple = ()
    added: tuple = ()
    removed: tuple = ()
    kept: tuple = ()

    @property
    def detail(self) -> str:
        return "; ".join(
            [f"{n}: {old} -> {new}" for n, old, new in self.retyped]
            + [f"+{n}" for n in self.added]
            + [f"-{n}" for n in self.removed]
        )


def _schema_drift(existing, target, mode: str, complex_dtype_only: bool = False):
    """
    Compare two schemas by name and type, returning (retyped, added, removed).

    simpleString() is deliberately the comparison key. It carries struct field
    ORDER — which coalesce, and every struct comparison Delta makes, care about
    — but NOT nullability, which Delta rewrites freely and which would
    otherwise report drift on every single run.

    `removed` is every column only the table has (empty in overlap mode).
    validate_table_schema decides whether the mode drops them (strict) or
    keeps them (evolve).
    """
    ex = {f.name: f.dataType for f in existing.fields}
    tg = {f.name: f.dataType for f in target.fields}

    retyped = [
        (n, ex[n].simpleString(), tg[n].simpleString())
        for n in tg
        if n in ex and ex[n].simpleString() != tg[n].simpleString()
        and not (complex_dtype_only
                 and not isinstance(tg[n], (StructType, ArrayType, MapType)))
    ]
    added = [n for n in tg if n not in ex]
    removed = [n for n in ex if n not in tg]

    if mode == "overlap":
        # The producer is a known subset of the target — the master merge's
        # enrichment_staged view against product_master_enriched_t. A column on
        # one side only is expected there, and MERGE WITH SCHEMA EVOLUTION
        # already handles additions. Only a TYPE change is drift.
        added, removed = [], []

    return retyped, added, removed


def _conform_columns(df: DataFrame, final_fields: list) -> DataFrame:
    """
    Project `df` onto `final_fields` (list of (name, DataType) in final order).

    Scalars use try_cast; nested types round-trip through to_json/from_json (fields
    matched by name); complex -> string serialises, complex -> other scalar is NULL.
    """
    complex_types = (StructType, ArrayType, MapType)
    existing = {f.name: f.dataType for f in df.schema.fields}
    cols = []
    for name, dtype in final_fields:
        if name not in existing:
            cols.append(F.lit(None).cast(dtype).alias(name))
            continue
        old = existing[name]
        if old.simpleString() == dtype.simpleString():
            col = F.col(name)
        elif isinstance(dtype, complex_types) and isinstance(old, complex_types):
            col = F.from_json(
                F.to_json(F.col(name), _ROUNDTRIP_JSON_OPTIONS), dtype, _ROUNDTRIP_JSON_OPTIONS,
            )
        elif isinstance(dtype, complex_types):
            col = F.from_json(F.col(name).cast("string"), dtype)
        elif isinstance(old, complex_types) and isinstance(dtype, StringType):
            col = F.to_json(F.col(name))
        elif isinstance(old, complex_types):
            col = F.lit(None).cast(dtype)
        else:
            col = F.expr(f"try_cast({_quote_ident(name)} AS {_ddl_type(dtype)})")
        cols.append(col.alias(name))
    return df.select(*cols)


# The complex -> complex rewrite serialises with these and parses them back,
# so both sides agree on a microsecond format for timestamp and timestamp_ntz.
_ROUNDTRIP_JSON_OPTIONS = {
    **_JSON_OPTIONS,
    "timestampNTZFormat": "yyyy-MM-dd'T'HH:mm:ss.SSSSSS",
}


def _without_void(new, old):
    """
    `new` with every NullType (void) replaced by the type `old` has at the
    same path, or None when nothing at all can be kept.

    A bare F.lit(None) types its column `void`. That is the absence of a
    type, not a decision to change one — univ_attributes' get_col() returns
    one whenever a facet column is missing that run. Taken literally, the
    rewrite would cast the table's values to void (wiping them) or fail, as
    Delta rejects void inside a struct. So void keeps the table's type, and a
    void field the table does not have yet is left out until the code
    produces a real type for it.
    """
    if isinstance(new, NullType):
        return old
    if isinstance(new, StructType):
        old_fields = _fields_by_lower_name(old) if isinstance(old, StructType) else {}
        fields = []
        for f in new.fields:
            # Struct field names are case-insensitive in Delta too: match the
            # table's field and keep the table's spelling (see _resolve_against_table).
            old_field = old_fields.get(f.name.lower())
            dtype = _without_void(f.dataType, old_field.dataType if old_field else None)
            if dtype is not None:
                name = old_field.name if old_field else f.name
                fields.append(StructField(name, dtype, f.nullable, f.metadata))
        return StructType(fields) if fields else old
    if isinstance(new, ArrayType):
        element = _without_void(
            new.elementType, old.elementType if isinstance(old, ArrayType) else None,
        )
        return ArrayType(element, new.containsNull) if element is not None else old
    if isinstance(new, MapType):
        is_map = isinstance(old, MapType)
        key = _without_void(new.keyType, old.keyType if is_map else None)
        value = _without_void(new.valueType, old.valueType if is_map else None)
        if key is None or value is None:
            return old
        return MapType(key, value, new.valueContainsNull)
    return new


def _fields_by_lower_name(struct) -> dict:
    return {f.name.lower(): f for f in struct.fields}


def _contains_void(dtype) -> bool:
    if isinstance(dtype, NullType):
        return True
    if isinstance(dtype, StructType):
        return any(_contains_void(f.dataType) for f in dtype.fields)
    if isinstance(dtype, ArrayType):
        return _contains_void(dtype.elementType)
    if isinstance(dtype, MapType):
        return _contains_void(dtype.keyType) or _contains_void(dtype.valueType)
    return False


def _resolve_against_table(target, existing):
    """
    `target` as the rest of the layer should compare it with `existing`:

      * NAMES take the table's spelling when they match case-insensitively,
        at the top level and inside structs. Delta resolves names that way,
        so code writing `Item_ID` to a table with `item_id` is the same
        column — compared by exact name it was an addition plus a kept
        column, and the rewrite failed on a duplicate column every run.
      * VOID is resolved against the table's type (see _without_void). A
        top-level void column the table does not have is dropped.

    Returns (schema, names of the columns that carried a void).
    """
    existing_fields = _fields_by_lower_name(existing)
    fields, void_columns = [], []
    for f in target.fields:
        old_field = existing_fields.get(f.name.lower())
        name = old_field.name if old_field else f.name
        if _contains_void(f.dataType):
            void_columns.append(name)
        dtype = _without_void(f.dataType, old_field.dataType if old_field else None)
        if dtype is not None:
            fields.append(StructField(name, dtype, f.nullable, f.metadata))
    return StructType(fields), void_columns


def _count_values(df: DataFrame, columns: list) -> tuple:
    """
    (row count, {column: non-NULL count}) in one pass over `df`.

    The rewrite compares these before and after the conversion: the row count
    proves no row was lost, the per-column counts prove no VALUE was — a cast
    the new type cannot hold (bigint -> int overflow, "abc" -> int) leaves the
    row in place and NULLs the value, which a row count never sees.
    """
    row = df.agg(
        F.count(F.lit(1)),
        *[F.count(F.col(_quote_ident(c))) for c in columns],
    ).first()
    return row[0], {c: row[i + 1] for i, c in enumerate(columns)}


_JSON_PARTIAL_RESULTS = "spark.sql.json.enablePartialResults"


@contextmanager
def _json_partial_results(spark):
    """
    Turn on JSON partial results for the duration of the rewrite.

    Without it, from_json NULLs a WHOLE struct when a single field fails to
    parse, so one bad value in a retyped nested field would take every other
    field of that row down with it. With it, only the failing field is NULL.
    The session's previous setting is restored afterwards.
    """
    previous, changed = None, False
    try:
        previous = spark.conf.get(_JSON_PARTIAL_RESULTS, None)
        spark.conf.set(_JSON_PARTIAL_RESULTS, "true")
        changed = True
    except Exception as e:
        logger.warning(
            "Could not set %s (%s) — a struct with one unparseable field may be "
            "NULLed whole by the rewrite", _JSON_PARTIAL_RESULTS, e,
        )
    try:
        yield
    finally:
        if changed:
            try:
                if previous is None:
                    spark.conf.unset(_JSON_PARTIAL_RESULTS)
                else:
                    spark.conf.set(_JSON_PARTIAL_RESULTS, previous)
            except Exception as e:
                logger.warning("Could not restore %s (%s)", _JSON_PARTIAL_RESULTS, e)


# Table property holding {column: {"at": ISO-8601 UTC, "from": type, "to": type}}
# for the last time SVL retyped each column. It lives on the table, so every
# job that writes the table sees the same history.
_RETYPE_HISTORY_PROPERTY = "schema_align.retyped_at"


def _read_retype_history(spark, table: str) -> dict:
    """The table's retype history, or {} if it has none or cannot be read."""
    try:
        for row in spark.sql(f"SHOW TBLPROPERTIES {table}").collect():
            if row["key"] == _RETYPE_HISTORY_PROPERTY:
                history = json.loads(row["value"])
                return history if isinstance(history, dict) else {}
    except Exception as e:
        logger.warning(
            "Could not read %s on %s (%s) — the rewrite-loop guard is off for this run",
            _RETYPE_HISTORY_PROPERTY, table, e,
        )
    return {}


def _held_by_retype_cooldown(table: str, retyped, history: dict) -> list:
    """
    The retyped columns SVL must NOT retype this run: ones it already retyped
    within schema_align.retype_cooldown_hours.

    Two writers that disagree on a column's type — or one producer whose
    output type varies from run to run or batch to batch — would otherwise
    retype the table back and forth on every write, each time a full rewrite
    plus a full change-feed push to the index syncs. Holding the column at
    the table's current type stops the loop; the write then casts implicitly,
    as it did before scalar types were migrated. After the cooldown the
    column is retyped normally, so a deliberate revert still lands.
    """
    hours = schema_align_retype_cooldown_hours()
    if not hours or not retyped:
        return []
    now = datetime.now(timezone.utc)
    held = []
    for name, table_type, code_type in retyped:
        entry = history.get(name)
        try:
            last = datetime.fromisoformat(entry["at"]) if entry else None
        except (TypeError, KeyError, ValueError):
            last = None
        if last is None or now - last >= timedelta(hours=hours):
            continue
        held.append(name)
        logger.warning(
            "SCHEMA DRIFT on %s: %s was already retyped %s -> %s at %s. Retyping it "
            "again (%s -> %s) within %g h looks like writers disagreeing on its type "
            "(a rewrite loop) — keeping %s this run. Make every writer produce one "
            "type, or set schema_align.retype_cooldown_hours: 0 to turn this off.",
            table, name, entry.get("from"), entry.get("to"), entry["at"],
            table_type, code_type, hours, table_type,
        )
    return held


def _record_retypes(spark, table: str, history: dict, retypes: dict) -> None:
    """
    Add `retypes` ({column: (from, to)}) to the table's retype history.

    A metadata-only commit. Failing to record never fails the pipeline — the
    rewrite already succeeded; it only means the loop guard cannot see this
    retype.
    """
    if not retypes:
        return
    at = datetime.now(timezone.utc).isoformat()
    updated = dict(history)
    for column, (old, new) in retypes.items():
        updated[column] = {"at": at, "from": old, "to": new}
    value = json.dumps(updated, sort_keys=True).replace("\\", "\\\\").replace("'", "\\'")
    try:
        spark.sql(
            f"ALTER TABLE {table} SET TBLPROPERTIES "
            f"('{_RETYPE_HISTORY_PROPERTY}' = '{value}')"
        )
    except Exception as e:
        logger.warning(
            "Could not record the retype of %s on %s (%s) — the rewrite-loop guard "
            "will not see it", ", ".join(retypes), table, e,
        )


def validate_table_schema(
    spark,
    table: str,
    target_schema,
    mode: str = "evolve",
    complex_dtype_only: bool = False,
) -> SchemaValidation:
    """
    Read-only compare of `table` with `target_schema`; logs one SCHEMA VALIDATION line.

    mode: strict (retyped, added and table-only columns count), evolve (table-only
    columns kept, not a mismatch), overlap (only retyped shared columns count).
    """
    if mode not in _SCHEMA_MODES:
        raise ValueError(f"Unknown schema mode {mode!r}; expected one of {_SCHEMA_MODES}")

    if not spark.catalog.tableExists(table):
        logger.info("SCHEMA VALIDATION %s: NEW_TABLE — the write will create it", table)
        return SchemaValidation(table, mode, "NEW_TABLE")

    existing_schema = spark.table(table).schema
    target_schema, void_columns = _resolve_against_table(target_schema, existing_schema)
    if void_columns:
        logger.warning(
            "SCHEMA VALIDATION %s: void (untyped NULL) in %s — keeping the table's "
            "type there instead of migrating to void", table, ", ".join(void_columns),
        )
    retyped, added, removed = _schema_drift(existing_schema, target_schema, mode, complex_dtype_only)
    if complex_dtype_only:
        # Scalar type differences are not migrated (the MERGE casts them), but
        # they are still a difference between code and table — log them.
        scalar = [
            r for r in _schema_drift(existing_schema, target_schema, mode)[0]
            if r not in retyped
        ]
        if scalar:
            logger.warning(
                "SCHEMA VALIDATION %s: scalar type differences left to the write's "
                "implicit cast: %s", table,
                "; ".join(f"{n}: {old} -> {new}" for n, old, new in scalar),
            )
    kept = []
    if mode == "evolve":
        # A column the code did not produce THIS run is not proof it was
        # retired: review_mining's keyword-only run omits four scalars that
        # the LLM run writes. Dropping them would wipe the good values.
        kept, removed = removed, []

    status = "MISMATCH" if (retyped or added or removed) else "PASS"
    result = SchemaValidation(
        table, mode, status,
        tuple(retyped), tuple(added), tuple(removed), tuple(kept),
    )
    if status == "PASS":
        logger.info("SCHEMA VALIDATION %s: PASS (%s)", table, mode)
    else:
        logger.warning("SCHEMA VALIDATION %s: MISMATCH (%s) — %s", table, mode, result.detail)
    if kept:
        logger.info(
            "SCHEMA VALIDATION %s: keeping %d column(s) this run did not produce: %s",
            table, len(kept), ", ".join(kept),
        )
    return result


def _quote_ident(name: str) -> str:
    return "`" + name.replace("`", "``") + "`"


def _ddl_type(dtype) -> str:
    """Spark SQL DDL for a DataType, with every struct field name quoted."""
    if isinstance(dtype, StructType):
        return "STRUCT<" + ", ".join(
            f"{_quote_ident(f.name)}: {_ddl_type(f.dataType)}" for f in dtype.fields
        ) + ">"
    if isinstance(dtype, ArrayType):
        return f"ARRAY<{_ddl_type(dtype.elementType)}>"
    if isinstance(dtype, MapType):
        return f"MAP<{_ddl_type(dtype.keyType)}, {_ddl_type(dtype.valueType)}>"
    return dtype.simpleString()


def _nested_additions(path: list, old, new) -> Optional[list]:
    """
    The struct fields `new` adds to `old`, as (path, field, after) triples —
    or None if the change is anything other than pure additions.

    Additions are allowed at any depth through structs and array elements.
    Everything else returns None and is left to the rewrite: a removed field,
    any type change (including int -> bigint), a reorder of existing fields,
    and anything inside a map.
    """
    if old.simpleString() == new.simpleString():
        return []
    if isinstance(old, ArrayType) and isinstance(new, ArrayType):
        return _nested_additions(path + ["element"], old.elementType, new.elementType)
    if not (isinstance(old, StructType) and isinstance(new, StructType)):
        return None

    old_types = {f.name: f.dataType for f in old.fields}
    new_names = [f.name for f in new.fields]
    # Existing fields must all survive, in their existing relative order. ADD
    # COLUMNS can only insert; it cannot remove or move a field.
    if [n for n in new_names if n in old_types] != [f.name for f in old.fields]:
        return None

    additions, previous = [], None
    for field in new.fields:
        if field.name in old_types:
            inner = _nested_additions(path + [field.name], old_types[field.name], field.dataType)
            if inner is None:
                return None
            additions.extend(inner)
        else:
            additions.append((path, field, previous))
        previous = field.name
    return additions


def _additive_alter_statements(table: str, existing, target, validation) -> Optional[list]:
    """
    ALTER TABLE ... ADD COLUMNS statements that bring `existing` to `target`
    when every difference in `validation` is an addition. None otherwise.

    One statement per column, in the code's order: a field placed AFTER
    another new field needs that field to exist first. Nested fields are
    placed with FIRST/AFTER so the struct's field order matches the code —
    the comparison key includes struct order, so an appended field would
    report a mismatch on every run. Top-level columns are appended; column
    order is not part of the comparison.
    """
    if validation.removed:
        return None
    existing_types = {f.name: f.dataType for f in existing.fields}
    target_types = {f.name: f.dataType for f in target.fields}

    statements = []
    for name, _, _ in validation.retyped:
        additions = _nested_additions([name], existing_types[name], target_types[name])
        if not additions:
            return None
        for path, field, after in additions:
            column = ".".join(_quote_ident(p) for p in path + [field.name])
            position = f"AFTER {_quote_ident(after)}" if after else "FIRST"
            statements.append(
                f"ALTER TABLE {table} ADD COLUMNS "
                f"({column} {_ddl_type(field.dataType)} {position})"
            )
    for name in validation.added:
        statements.append(
            f"ALTER TABLE {table} ADD COLUMNS "
            f"({_quote_ident(name)} {_ddl_type(target_types[name])})"
        )
    return statements


def align_table_schema(
    spark,
    table: str,
    target_schema,
    mode: str = "evolve",
    enabled: Optional[bool] = None,
    complex_dtype_only: Optional[bool] = None,
) -> bool:
    """
    Bring `table` in line with `target_schema` when they differ.

    Pure additions use ALTER TABLE ADD COLUMNS; anything else rewrites the existing
    table rows (never the caller's batch), keeping table id, grants and history.

    Args:
        spark:         Active SparkSession.
        table:         Fully qualified target table. Missing table -> no-op.
        target_schema: StructType the pipeline produces.
        mode:          "evolve" (add/retype, keep table-only columns), "strict"
                       (exactly target_schema; declared schemas only) or "overlap"
                       (retype shared columns only).
        enabled:       False raises SchemaDriftError instead; None follows schema_align.enabled.
        complex_dtype_only: Only struct/array/map changes count as drift; None
                       follows schema_align.complex_dtype_only.

    Returns:
        True if the table was changed, False if the schemas already agreed.
    """
    if complex_dtype_only is None:
        complex_dtype_only = schema_align_complex_dtype_only()
    validation = validate_table_schema(spark, table, target_schema, mode, complex_dtype_only)
    if validation.status != "MISMATCH":
        return False

    detail = validation.detail
    if enabled is None:
        enabled = schema_align_enabled()

    if not enabled:
        raise SchemaDriftError(
            f"{table} no longer matches what the pipeline produces ({detail}). "
            f"Set schema_align.enabled=true in general.yml to let the pipeline "
            f"rewrite it, or migrate the table by hand."
        )

    # The same name and void resolution validate_table_schema compared
    # against, so the ALTER and the rewrite below see the same columns and
    # never migrate one to void.
    table_schema = spark.table(table).schema
    target_schema, _ = _resolve_against_table(target_schema, table_schema)

    # Rewrite-loop guard: a column retyped again within the cooldown keeps the
    # table's type this run (see _held_by_retype_cooldown).
    retype_history = _read_retype_history(spark, table)
    held = _held_by_retype_cooldown(table, validation.retyped, retype_history)
    if held:
        table_types = {f.name: f.dataType for f in table_schema.fields}
        target_schema = StructType([
            StructField(f.name, table_types[f.name], f.nullable, f.metadata)
            if f.name in held else f
            for f in target_schema.fields
        ])
        validation = validate_table_schema(spark, table, target_schema, mode, complex_dtype_only)
        if validation.status != "MISMATCH":
            return False
        detail = validation.detail

    statements = _additive_alter_statements(
        table, spark.table(table).schema, target_schema, validation,
    )
    if statements:
        logger.warning(
            "SCHEMA DRIFT on %s is additions only — adding them in place "
            "(metadata only, no data rewritten): %s", table, detail,
        )
        try:
            for statement in statements:
                logger.info("  %s", statement)
                spark.sql(statement)
        except Exception as e:
            logger.warning("ALTER on %s failed (%s) — rewriting the table instead", table, e)
        validation = validate_table_schema(spark, table, target_schema, mode, complex_dtype_only)
        if validation.status != "MISMATCH":
            logger.warning("Schema align: %s now matches — no rewrite needed", table)
            return True
        detail = validation.detail
        logger.warning("%s still differs after ALTER (%s) — rewriting the table", table, detail)

    logger.warning(
        "SCHEMA DRIFT on %s — rewriting the whole table to match the code. "
        "Changes: %s. Fields the new schema does not carry are DROPPED.",
        table, detail,
    )

    existing_df = spark.table(table)
    existing_types = {f.name: f.dataType for f in existing_df.schema.fields}

    def final_type(name, code_type):
        # complex_dtype_only: a scalar column keeps the table's type through the
        # rewrite, so a struct change elsewhere never casts its old values.
        if (complex_dtype_only and name in existing_types
                and not isinstance(code_type, (StructType, ArrayType, MapType))):
            return existing_types[name]
        return code_type

    if mode == "strict":
        final_fields = [(f.name, final_type(f.name, f.dataType)) for f in target_schema.fields]
    elif mode == "evolve":
        # The code's columns in the code's order, then every column only the
        # table has, untouched.
        kept = set(validation.kept)
        final_fields = [(f.name, final_type(f.name, f.dataType)) for f in target_schema.fields] + [
            (f.name, f.dataType) for f in existing_df.schema.fields if f.name in kept
        ]
    else:
        tg = {f.name: f.dataType for f in target_schema.fields}
        final_fields = [
            (f.name, final_type(f.name, tg.get(f.name, f.dataType)))
            for f in existing_df.schema.fields
        ]

    # Columns whose values go through a conversion — the only ones a cast can
    # NULL. Counted before and after, in the same pass as the row count.
    converted = [
        name for name, dtype in final_fields
        if name in existing_types
        and existing_types[name].simpleString() != dtype.simpleString()
    ]
    before, values_before = _count_values(existing_df, converted)
    conformed = _conform_columns(existing_df, final_fields)

    # The staging hop is mandatory. Overwriting a table from a DataFrame that
    # reads that same table is undefined behaviour in Spark, and it also leaves
    # the target intact until the conformed copy is fully materialised — so a
    # failure half way through costs nothing. from_json runs here, so partial
    # results are on for this write only.
    staging = f"{table}__schema_align_stg"
    with _json_partial_results(spark):
        (
            conformed.write.format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .saveAsTable(staging)
        )

    staged = spark.table(staging)
    staged_count, values_after = _count_values(staged, converted)
    if staged_count != before:
        raise SchemaDriftError(
            f"Refusing to rewrite {table}: the conformed copy has "
            f"{staged_count} rows but the source had {before}. "
            f"{staging} is retained for inspection."
        )

    # Not a failure — the code is the source of truth for the type, and the
    # pipeline must not stop on a schema change — but never silent.
    lost = {c: values_before[c] - values_after[c] for c in converted
            if values_after[c] < values_before[c]}
    if lost:
        logger.warning(
            "SCHEMA DRIFT on %s: values the new type cannot hold became NULL — %s",
            table, "; ".join(
                f"{c}: {n} of {values_before[c]} non-NULL values lost"
                for c, n in lost.items()
            ),
        )

    try:
        (
            staged.write.format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .saveAsTable(table)
        )
    except Exception:
        logger.error(
            "Rewrite of %s FAILED — %s is retained and holds the migrated "
            "data; the target is unchanged", table, staging,
        )
        raise

    spark.sql(f"DROP TABLE IF EXISTS {staging}")
    final_types = dict(final_fields)
    _record_retypes(spark, table, retype_history, {
        c: (existing_types[c].simpleString(), final_types[c].simpleString())
        for c in converted
    })
    logger.warning(
        "Schema align: %s rewritten to the pipeline schema, %d rows preserved",
        table, before,
    )
    return True


_WRITE_SCHEMA_MODES = _SCHEMA_MODES + ("validate-only",)


def validate_before_write(
    spark,
    table: str,
    schema,
    schema_mode: str = "evolve",
    complex_dtype_only: Optional[bool] = None,
) -> None:
    """
    Schema validation layer every writer calls before writing.

    schema_mode "evolve" / "strict" / "overlap" migrates the table on mismatch;
    "validate-only" (overwrites) only logs, compared strictly.
    complex_dtype_only None follows schema_align.complex_dtype_only in general.yml.
    """
    if schema_mode not in _WRITE_SCHEMA_MODES:
        raise ValueError(
            f"Unknown schema_mode {schema_mode!r}; expected one of {_WRITE_SCHEMA_MODES}"
        )
    if schema_mode == "validate-only":
        validate_table_schema(spark, table, schema, "strict")
    else:
        align_table_schema(spark, table, schema, mode=schema_mode, complex_dtype_only=complex_dtype_only)


def resolve_output_table(table: str, catalog: str = None, schema: str = None) -> tuple:
    """Resolve (catalog, schema, table_name, full_table_name) the way save_data does."""
    # If table is already fully qualified (catalog.schema.table), parse it out.
    parts = table.split(".")
    if len(parts) == 3:
        output_catalog, output_schema, table_name = parts
    elif len(parts) == 2:
        # No hardcoded fallback - fail explicitly if catalog not provided
        if not catalog:
            catalog_env = os.getenv('UNITY_CATALOG_OUTPUT_CATALOG')
            if not catalog_env:
                raise ValueError(
                    "Catalog must be provided when table is not fully qualified. "
                    "Either pass 'catalog' parameter or set UNITY_CATALOG_OUTPUT_CATALOG environment variable. "
                    "Table format: schema.table requires catalog parameter."
                )
            output_catalog = catalog_env
        else:
            output_catalog = catalog
        output_schema = parts[0]
        table_name = parts[1]
    else:
        # No hardcoded fallback - fail explicitly if catalog/schema not provided
        if not catalog:
            catalog_env = os.getenv('UNITY_CATALOG_OUTPUT_CATALOG')
            if not catalog_env:
                raise ValueError(
                    "Catalog must be provided when table is not fully qualified. "
                    "Either pass 'catalog' parameter or set UNITY_CATALOG_OUTPUT_CATALOG environment variable. "
                    f"Table: '{table}' requires catalog.schema.table format or catalog parameter."
                )
            output_catalog = catalog_env
        else:
            output_catalog = catalog

        if not schema:
            schema_env = os.getenv('UNITY_CATALOG_OUTPUT_SCHEMA')
            if not schema_env:
                raise ValueError(
                    "Schema must be provided when table is not fully qualified. "
                    "Either pass 'schema' parameter or set UNITY_CATALOG_OUTPUT_SCHEMA environment variable. "
                    f"Table: '{table}' requires catalog.schema.table format or schema parameter."
                )
            output_schema = schema_env
        else:
            output_schema = schema
        table_name = table

    full_table_name = f"{output_catalog}.{output_schema}.{table_name}"
    return output_catalog, output_schema, table_name, full_table_name


def _merge_counts(spark: SparkSession, full_table_name: str) -> str:
    """Rows updated, inserted and deleted by the table's latest MERGE, from the Delta log."""
    try:
        last = (
            spark.sql(f"DESCRIBE HISTORY {full_table_name} LIMIT 10")
            .filter(F.col("operation") == "MERGE")
            .orderBy(F.col("version").desc())
            .first()
        )
    except Exception as e:
        # Logging only: the MERGE has already committed, so this must not fail the task.
        return f"counts unavailable ({e})"
    if last is None:
        return "no MERGE in the last 10 versions"
    metrics = last["operationMetrics"] or {}
    return (
        f"{metrics.get('numTargetRowsUpdated')} updated, "
        f"{metrics.get('numTargetRowsInserted')} inserted, "
        f"{metrics.get('numTargetRowsDeleted')} deleted (version {last['version']})"
    )


def save_data(
    df: DataFrame,
    spark: DatabricksSession,
    catalog: str = None,
    schema: str = None,
    table: str = None,
    mode: str = "merge",
    id_col: str = "item_id",
    delete_missing: bool = False,
    validate_schema: bool = True,
    required_columns: list = None,
    min_row_count: int = 1,
    schema_mode: str = "evolve",
    expected_schema=None,
) -> None:
    """
    Save data to Unity Catalog (Delta), validating the target schema first.

    Args:
        df: DataFrame to save
        spark: Spark session
        catalog: Catalog name (optional if table is fully qualified)
        schema: Schema name (optional if table is fully qualified)
        table: Table name (can be fully qualified: catalog.schema.table)
        mode: Write mode - "merge", "overwrite", or "append"
        id_col: Column to use for merge operations
        delete_missing: In merge mode, delete target rows absent from the source
        validate_schema: Whether to validate before writing
        required_columns: Required columns for validation (None = skip)
        min_row_count: Minimum row count for validation
        schema_mode: "evolve", "strict", "overlap" or "validate-only"
        expected_schema: Declared schema to validate against; defaults to df.schema
    """
    if not table:
        raise ValueError("Output table name must be provided.")

    # Validate DataFrame before writing
    if validate_schema:
        validate_dataframe_schema(
            df,
            required_columns=required_columns,
            min_row_count=min_row_count,
            key_columns=[id_col] if id_col in df.columns else None
        )

    output_catalog, output_schema, table_name, full_table_name = resolve_output_table(
        table, catalog, schema
    )
    
    print(f"Saving to {full_table_name}...")
    
    try:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {output_catalog}.{output_schema}")
    except Exception as e:
        print(f"Warning creating schema: {e}")

    validate_before_write(
        spark, full_table_name,
        expected_schema if expected_schema is not None else df.schema,
        "validate-only" if mode == "overwrite" else schema_mode,
    )

    try:
        table_exists = spark.sql(
            f"SHOW TABLES IN {output_catalog}.{output_schema} LIKE '{table_name}'"
        ).count() > 0
        
        if table_exists and mode == "merge":
            print(f"Table {full_table_name} exists. Merging data on {id_col}...")
            temp_view_name = f"updates_temp_{uuid.uuid4().hex[:8]}"
            df.createOrReplaceTempView(temp_view_name)
            
            # Warn on schema drift — columns in target but missing from source
            target_cols = set(spark.table(full_table_name).columns)
            source_cols = set(df.columns)
            missing_cols = target_cols - source_cols - {id_col}
            
            if missing_cols:
                logger.warning(
                    f"Schema drift detected on {full_table_name}: "
                    f"target has columns not in source: {sorted(missing_cols)}. "
                    f"These columns will retain existing values on update and be NULL on insert. "
                    f"If removal is intended, run ALTER TABLE ... DROP COLUMN explicitly."
                )
            
            delete_clause = "WHEN NOT MATCHED BY SOURCE THEN DELETE" if delete_missing else ""
            merge_sql = f"""
                MERGE WITH SCHEMA EVOLUTION INTO {full_table_name} target
                USING {temp_view_name} source
                ON target.{id_col} = source.{id_col}
                WHEN MATCHED THEN UPDATE SET *
                WHEN NOT MATCHED THEN INSERT *
                {delete_clause}
            """
            spark.sql(merge_sql)
            # Counts from the Delta log: df.count() would replay the whole plan.
            print(f"✓ Merged into {full_table_name}: {_merge_counts(spark, full_table_name)}")
        else:
            writer = df.write.format("delta")
            if mode == "overwrite":
                writer = writer.mode("overwrite").option("overwriteSchema", "true")
            else:
                writer = writer.mode("append").option("mergeSchema", "true")
            writer.saveAsTable(full_table_name)
            # Count from the written table: df.count() would replay the whole plan.
            saved_rows = (spark.table(full_table_name).count()
                          if mode == "overwrite" else df.count())
            print(f"✓ Saved {saved_rows} rows to {full_table_name}")
    except Exception as e:
        print(f"✗ Failed to save to {full_table_name}: {e}")
        raise  # Re-raise to fail the job instead of silently continuing


def incremental_save_data(
    df: DataFrame,
    spark: DatabricksSession,
    table: str,
    update_fields: dict,
    id_col: str = "item_id",
    catalog: str = None,
    schema: str = None,
    schema_mode: str = "evolve",
    expected_schema=None,
) -> None:
    """
    Validate the target schema, then MERGE: matched rows update only `update_fields`
    (created_at_ts preserved), new rows insert all columns. Target table must exist.

    Args:
        df:              Enriched DataFrame to upsert.
        spark:           Active SparkSession.
        table:           Output table name (fully qualified or partial).
        update_fields:   { target_col: "updates.col_name" }; must not include created_at_ts.
        id_col:          Merge key column name.
        catalog:         Optional catalog override.
        schema:          Optional schema override.
        schema_mode:     "evolve", "strict", "overlap" or "validate-only".
        expected_schema: Declared schema to validate against; defaults to df.schema.
    """
    if not table:
        raise ValueError("Output table name must be provided.")

    # Parse fully qualified table name
    parts = table.split(".")
    if len(parts) == 3:
        output_catalog, output_schema, table_name = parts
    elif len(parts) == 2:
        output_catalog = catalog or os.getenv('UNITY_CATALOG_OUTPUT_CATALOG', 'mld01_ml_de')
        output_schema = parts[0]
        table_name = parts[1]
    else:
        output_catalog = catalog or os.getenv('UNITY_CATALOG_OUTPUT_CATALOG', 'mld01_ml_de')
        output_schema = schema or os.getenv('UNITY_CATALOG_OUTPUT_SCHEMA', 'product')
        table_name = table

    full_table_name = f"{output_catalog}.{output_schema}.{table_name}"

    print(f"Incremental MERGE into {full_table_name}...")

    try:
        # Ensure schema exists
        try:
            spark.sql(f"CREATE SCHEMA IF NOT EXISTS {output_catalog}.{output_schema}")
        except Exception as e:
            print(f"Warning creating schema: {e}")

        validate_before_write(
            spark, full_table_name,
            expected_schema if expected_schema is not None else df.schema,
            schema_mode,
        )

        # Auto-merge so new columns and nested struct fields are added by the MERGE
        spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

        from delta.tables import DeltaTable

        delta_tbl = DeltaTable.forName(spark, full_table_name)

        (
            delta_tbl.alias("existing")
            .merge(
                df.alias("updates"),
                f"existing.{id_col} = updates.{id_col}",
            )
            .whenMatchedUpdate(set=update_fields)
            .whenNotMatchedInsertAll()
            .execute()
        )

        # Counts from the Delta log: df.count() would replay the whole plan.
        print(f"✓ Merged into {full_table_name}: {_merge_counts(spark, full_table_name)}")
        print("  • Matched rows: fields in update_fields + last_updated_ts updated")
        print("  • New rows: all columns inserted (including created_at_ts)")

    except Exception as e:
        print(f"✗ Incremental MERGE failed: {e}")
        raise
        raise