import os
import yaml
import uuid
from databricks.connect import DatabricksSession
from pyspark.sql import DataFrame

# One schema validation layer for both save_data copies. Re-exported here so
# the modules that import from data_pipeline.utils can validate their direct
# writes too.
from .enrichment.utils import validate_before_write  # noqa: F401
# One reading of the hazard table for the lifecycle warnings and the tagger's age_restriction.
from .enrichment.utils import read_hazard_by_product  # noqa: F401

def get_spark_session() -> DatabricksSession:
    """
    Dynamically create a Spark session.
    - Uses native Spark context if running on a Databricks cluster (e.g., Job).
    - Uses Databricks Connect with .env credentials if running locally.
    """
    # Databricks clusters always have this environment variable defined
    if os.getenv("DATABRICKS_RUNTIME_VERSION"):
        print("Running on Databricks cluster. Using native Spark session.")
        return DatabricksSession.builder.getOrCreate()
    else:
        print("Running locally. Using Databricks Connect.")
        from dotenv import load_dotenv
        load_dotenv()
        
        databricks_host = os.getenv('DATABRICKS_HOST', '').rstrip('/')
        databricks_token = os.getenv('DATABRICKS_TOKEN', '')
        cluster_id = os.getenv('DATABRICKS_CLUSTER_ID', '')
        
        if not databricks_host or not databricks_token:
            raise ValueError("DATABRICKS_HOST and DATABRICKS_TOKEN must be set in .env for local development.")
            
        return (DatabricksSession.builder
            .remote(host=databricks_host, token=databricks_token, cluster_id=cluster_id if cluster_id else None)
            .getOrCreate())

def replace_env_placeholders(obj, env_val):
    """Recursively replaces {env} placeholders in any string in the config object."""
    if isinstance(obj, dict):
        return {k: replace_env_placeholders(v, env_val) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [replace_env_placeholders(i, env_val) for i in obj]
    elif isinstance(obj, str):
        return obj.replace('{env}', env_val)
    else:
        return obj
    
ENVS = {
    'dev': 'de',
    'qa': 'qe',
    'prod': 'pe'
}
CATALOG = {
    'dev': 'mld01_ml_de',
    'qa': 'mld01_ml_qe',
    'prod': 'mld01_ml_pe'
}
CATALOG_TO_RUN_MODE = {v: k for k, v in CATALOG.items()}

def get_run_mode(catalog: str = None) -> str:
    if catalog:
        return CATALOG_TO_RUN_MODE.get(catalog, 'dev')

    user = os.environ.get("sf_env", "")
    if 'prod' in user:
        return 'prod'
    elif 'qa' in user:
        return 'qa'
    return 'dev'

def read_config(config_path: str, env_val: str = None, run_mode: str = None) -> dict:
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    if env_val is None:
        if run_mode is None:
            run_mode = get_run_mode()
        env_val = ENVS[run_mode]
    config = replace_env_placeholders(config, env_val)
    return config
 
def save_data(
    df: DataFrame,
    spark: DatabricksSession,
    catalog: str = None,
    schema: str = None,
    table: str = None,
    mode: str = "merge",
    id_col: str = "item_id"
) -> None:
    """Save extracted data to Unity Catalog with Delta Lake merge support."""
    if not table:
        raise ValueError("Output table name must be provided.")

    # If table is already fully qualified (catalog.schema.table), parse it out.
    parts = table.split(".")
    if len(parts) == 3:
        output_catalog, output_schema, table_name = parts
    elif len(parts) == 2:
        output_catalog = catalog or os.getenv('UNITY_CATALOG_OUTPUT_CATALOG', 'mld01_ml_de')
        output_schema = parts[0]
        table_name = parts[1]
    else:
        output_catalog = catalog or os.getenv('UNITY_CATALOG_OUTPUT_CATALOG', 'mld01_ml_de')
        output_schema = schema or os.getenv('UNITY_CATALOG_OUTPUT_SCHEMA', 'product')
        table_name = table

    full_table_name = f"{output_catalog}.{output_schema}.{table_name}"
    
    print(f"Saving to {full_table_name}...")
    
    try:
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {output_catalog}.{output_schema}")
    except Exception as e:
        print(f"Warning creating schema: {e}")

    # Validate/evolve the target schema before any write; evolve never drops columns.
    validate_before_write(
        spark, full_table_name, df.schema,
        "validate-only" if mode == "overwrite" else "evolve",
    )

    try:
        table_exists = spark.sql(
            f"SHOW TABLES IN {output_catalog}.{output_schema} LIKE '{table_name}'"
        ).count() > 0

        if table_exists and mode == "merge":
            print(f"Table {full_table_name} exists. Merging data on {id_col}...")
            temp_view_name = f"updates_temp_{uuid.uuid4().hex[:8]}"
            df.createOrReplaceTempView(temp_view_name)

            spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
            
            merge_sql = f"""
                MERGE INTO {full_table_name} target
                USING {temp_view_name} source
                ON target.{id_col} = source.{id_col}
                WHEN MATCHED THEN UPDATE SET *
                WHEN NOT MATCHED THEN INSERT *
            """
            spark.sql(merge_sql)
            print(f"✓ Merged {df.count()} rows into {full_table_name}")
        else:
            writer = df.write.format("delta")
            if mode == "overwrite":
                writer = writer.mode("overwrite").option("overwriteSchema", "true")
            else:
                writer = writer.mode("append").option("mergeSchema", "true")
            writer.saveAsTable(full_table_name)
            print(f"✓ Saved {df.count()} rows to {full_table_name}")
    except Exception as e:
        print(f"✗ Failed to save: {e}")
        raise
