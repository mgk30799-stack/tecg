"""ETL pipeline that loads product data from Unity Catalog for product discovery."""

# Try to import Unity Catalog loader if databricks-connect is available
try:
    from data_pipeline.discovery_data_loader import UnityCatalogLoader
    UNITY_CATALOG_AVAILABLE = True
except (ImportError, ModuleNotFoundError):
    UnityCatalogLoader = None
    UNITY_CATALOG_AVAILABLE = False

__all__ = [
    'UnityCatalogLoader',
    'UNITY_CATALOG_AVAILABLE',
]
