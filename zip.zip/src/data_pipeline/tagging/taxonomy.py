from __future__ import annotations

import functools
import json
import os
import sys
from typing import Dict, List, Optional, Tuple

import yaml

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
    _REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(_HERE)))
except NameError:
    _HERE = os.getcwd()
    _REPO_ROOT = _HERE if os.path.exists(os.path.join(_HERE, "config")) else os.path.abspath(
        os.path.join(_HERE, "..", "..", ".."))

_PROMPT_STORE_DIR = os.path.join(_REPO_ROOT, "src", "data_pipeline", "prompts")
if _PROMPT_STORE_DIR not in sys.path:
    sys.path.insert(0, _PROMPT_STORE_DIR)

import prompt_store  # noqa: E402

CONFIG_DIR = os.path.join(_REPO_ROOT, "config")
TAGS_CONFIG_DIR = os.path.join(CONFIG_DIR, "tags")

ENGINE: Dict[str, str] = {
    "quality_grade": "D",
    "value_proposition_segment": "D",
    "gender": "D",
    "age_restriction": "D",
    "seasonality": "H",
    "body_parts": "H",
    "weather_condition": "H",
    "events": "H",
    "age_group": "L",
    "room_context": "L",
    "use_cases": "L",
    "audience_tags": "L",
}
FAMILIES: List[str] = list(ENGINE)
MODEL_FAMILIES: List[str] = [f for f in FAMILIES if ENGINE[f] != "D"]

ALWAYS_APPLICABLE: List[str] = ["room_context", "use_cases", "audience_tags"]
PROFILE_FAMILIES: List[str] = [f for f in MODEL_FAMILIES if f not in ALWAYS_APPLICABLE]

# Families the approved taxonomy defines as ONE value per product.
SINGLE_VALUE = frozenset(
    {"age_group", "gender", "age_restriction", "quality_grade", "value_proposition_segment"}
)
QUALITY_TIERS = ["Entry", "Reliable", "Superior", "Commercial"]
VALUE_TIERS = ["Budget", "Standard", "Premium", "Enterprise"]
AGE_GROUP_VALUES = ["newborn", "infant", "toddler", "kids", "adult"]
GENDER_VALUES = ["female", "male", "unisex"]
AGE_RESTRICTION_VALUES = ["18", "21"]

_TAXONOMY_FILES = {
    "seasonality": "seasonality_taxonomy.yaml",
    "weather_condition": "weather_taxonomy.yaml",
    "body_parts": "body_parts_taxonomy.yaml",
    "events": "event_taxonomy.yaml",
}

# room_context, use_cases and audience_tags are NOT given taxonomy files of their own.
COSMOS_CONFIG = os.environ.get("TAGGING_COSMOS_CONFIG") or os.path.join(
    CONFIG_DIR, "cosmos_taxonomy_config.json")
_COSMOS_FAMILIES = ("room_context", "use_cases", "audience_tags")

REGISTRY_CONFIG = os.path.join(CONFIG_DIR, "tagging_registry.yaml")
_REGISTRY_ALIASES = {"event": "events", "weather": "weather_condition"}


def _load(name: str):
    if name in _COSMOS_FAMILIES:
        return _cosmos(name)
    path = os.path.join(CONFIG_DIR, _TAXONOMY_FILES[name])
    if not os.path.exists(path):
        raise FileNotFoundError(
            "{}: taxonomy not found at {}. That file is the approved list of values for the "
            "family; without it the tag cannot be produced. Regenerate the workbook-derived "
            "ones with: python scripts/sync_taxonomy_from_workbook.py --write".format(name, path)
        )
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


@functools.lru_cache(maxsize=1)
def _cosmos_config() -> Dict:
    if not os.path.exists(COSMOS_CONFIG):
        raise FileNotFoundError(
            "cosmos taxonomy config not found at {}. It holds the approved values for {}; point "
            "TAGGING_COSMOS_CONFIG at it if it has moved.".format(
                COSMOS_CONFIG, ", ".join(_COSMOS_FAMILIES))
        )
    with open(COSMOS_CONFIG, encoding="utf-8") as fh:
        return json.load(fh)


def _cosmos(name: str):
    """One family's values out of the Cosmos taxonomy config.
    """
    config = _cosmos_config()
    if name not in config:
        raise KeyError(
            "{fam!r} is not defined in {path}. Add it there rather than creating a separate "
            "taxonomy file - one approved list per family, in one place.".format(
                fam=name, path=COSMOS_CONFIG)
        )
    raw = config[name]
    if name == "use_cases" and isinstance(raw, dict):  # grouped by supercategory
        return {str(k): [str(v) for v in vals] for k, vals in raw.items()}
    if isinstance(raw, dict):  # grouped, and the group is not a value
        return [str(v) for vals in raw.values() for v in vals]
    return [str(v) for v in raw]


@functools.lru_cache(maxsize=1)
def events() -> Tuple[List[str], List[str], Dict[str, str], Dict[str, List[str]]]:
    """Return ``(parents, sub_labels, sub_to_parent, ambiguous)``.
    """
    groups: Dict[str, List[str]] = _load("events")
    parents = sorted(groups)
    sub_to_parent: Dict[str, str] = {}
    ambiguous: Dict[str, List[str]] = {}
    for parent in parents:
        for raw in groups[parent]:
            sub = str(raw).strip()
            if sub in sub_to_parent:
                ambiguous.setdefault(sub, [sub_to_parent[sub]]).append(parent)
            else:
                sub_to_parent[sub] = parent
    return parents, sorted(sub_to_parent), sub_to_parent, ambiguous

USE_CASE_FALLBACK = [
    "Daily Office Operations", "Desk Organization", "Filing & Storage", "Bulk Replenishment",
    "Facility Maintenance", "Workplace Safety", "Device Protection", "Long-Tail Selection",
    "Specialty Needs",
]


@functools.lru_cache(maxsize=1)
def use_cases_by_supercategory() -> Dict[str, List[str]]:
    """Return ``supercategory -> labels`` when the Cosmos config groups use cases that way.

    Empty when the config holds one flat list, as the approved list from
    dotcom_enriched_data_schema.xlsx does: then every product is offered all of it.
    """
    loaded = _load("use_cases")
    return dict(loaded) if isinstance(loaded, dict) else {}


@functools.lru_cache(maxsize=1)
def use_case_values() -> List[str]:
    """Every approved use case, grouped or not."""
    loaded = _load("use_cases")
    if isinstance(loaded, dict):
        return sorted({v for vals in loaded.values() for v in vals})
    return list(loaded)


@functools.lru_cache(maxsize=1)
def body_parts_matrix() -> Dict[str, Dict[str, List[str]]]:
    """The hand-built body_parts category matrix from ``config/tags/body_parts_config.yml``."""
    path = family_config_files()["body_parts"]
    with open(path, encoding="utf-8") as fh:
        return (yaml.safe_load(fh) or {}).get("body_parts_category_matrix", {}) or {}


@functools.lru_cache(maxsize=1)
def enums() -> Dict[str, List[str]]:
    """The allowed values per family, in the form the taxonomy gate uses."""
    parents, subs, _, _ = events()
    return {
        "events": subs + parents,
        "seasonality": [l for l in _load("seasonality") if l != "Year-Round / All-Season"],
        "weather_condition": list(_load("weather_condition")),
        "body_parts": list(_load("body_parts")),
        "room_context": list(_load("room_context")),
        "audience_tags": list(_load("audience_tags")),
        "use_cases": use_case_values(),
        "quality_grade": QUALITY_TIERS,
        "value_proposition_segment": VALUE_TIERS,
        "age_group": AGE_GROUP_VALUES,
        "gender": GENDER_VALUES,
        "age_restriction": AGE_RESTRICTION_VALUES,
    }


def candidates_for(family: str, supercategory: Optional[str] = None) -> List[str]:
    """Allowed values for a product that has no class shortlist.
    """
    if family != "use_cases":
        return enums()[family]
    by_supercategory = use_cases_by_supercategory()
    if not by_supercategory:
        return enums()["use_cases"]
    return by_supercategory.get(str(supercategory or "").strip(), USE_CASE_FALLBACK)


# ---------------------------------------------------------------------------
# Per-family settings — caps, thresholds and (from config/prompts) authored guidance
# ---------------------------------------------------------------------------

@functools.lru_cache(maxsize=1)
def base_defaults() -> Dict:
    """``defaults`` from ``config/tagging_base_config.yaml`` - the shared caps and thresholds.
    """
    path = os.path.join(CONFIG_DIR, "tagging_base_config.yaml")
    if not os.path.exists(path):
        raise FileNotFoundError(
            "tagging base config not found at {}. It holds the shared max_labels and "
            "confidence_threshold that every family inherits.".format(path)
        )
    with open(path, encoding="utf-8") as fh:
        defaults = (yaml.safe_load(fh) or {}).get("defaults", {}) or {}
    return {
        "max_labels": int(defaults["max_labels"]),
        "confidence_threshold": float(defaults["confidence_threshold"]),
    }


@functools.lru_cache(maxsize=1)
def family_config_files() -> Dict[str, str]:
    """``family -> absolute config path``, from the registry that declares them."""
    if not os.path.exists(REGISTRY_CONFIG):
        raise FileNotFoundError(
            "tagging registry not found at {}. It declares which config file belongs to which "
            "tag family.".format(REGISTRY_CONFIG)
        )
    with open(REGISTRY_CONFIG, encoding="utf-8") as fh:
        registry = yaml.safe_load(fh) or {}
    out = {}
    for entry in registry.get("tags", []) or []:
        name = str(entry.get("name", "")).strip()
        family = _REGISTRY_ALIASES.get(name, name)
        path = str(entry.get("config_path", "")).strip()
        if family and path:
            out[family] = os.path.normpath(os.path.join(CONFIG_DIR, path))
    return out


def _family_guidance(family: str) -> Optional[str]:
    """The authored guidance for one family, from ``config/prompts/product_tagging.yaml``.

    Prompt text is centralised there; the per-family ``config/tags/*.yml`` files keep only the
    caps, thresholds and taxonomy that belong to the family.
    """
    return prompt_store.get("product_tagging", "family_guidance").get(family)


@functools.lru_cache(maxsize=1)
def family_settings() -> Dict[str, Dict]:
    """Every family's settings: the base defaults, overridden by its own config file.
    """
    base = base_defaults()
    files = family_config_files()
    out: Dict[str, Dict] = {}
    for family in FAMILIES:
        if family not in files:
            out[family] = dict(base, source="tagging_base_config.yaml",
                               prompt_template=_family_guidance(family))
            continue
        path = files[family]
        if not os.path.exists(path):
            raise FileNotFoundError(
                "{}: the registry points at {} and it is not there. That file holds this "
                "family's max_labels and its confidence_threshold.".format(
                    family, path)
            )
        with open(path, encoding="utf-8") as fh:
            raw = yaml.safe_load(fh) or {}
        defaults = raw.get("defaults", {}) or {}
        out[family] = {
            "max_labels": int(defaults.get("max_labels", base["max_labels"])),
            "confidence_threshold": float(
                defaults.get("confidence_threshold", base["confidence_threshold"])),
            "prompt_template": _family_guidance(family),
            "source": path,
        }
    return out


def cap(family: str) -> int:
    return int(family_settings()[family]["max_labels"])


def threshold(family: str) -> float:
    return float(family_settings()[family]["confidence_threshold"])


def prompt_template(family: str) -> Optional[str]:
    return family_settings()[family]["prompt_template"]


def caps() -> Dict[str, int]:
    return {f: cap(f) for f in MODEL_FAMILIES}


def thresholds() -> Dict[str, float]:
    return {f: threshold(f) for f in MODEL_FAMILIES}


def settings_summary() -> str:
    lines = ["family settings"]
    for family in MODEL_FAMILIES:
        cfg = family_settings()[family]
        lines.append("  {:<20} max_labels={}  threshold={}  prompt={}".format(
            family, cfg["max_labels"], cfg["confidence_threshold"],
            "authored" if cfg["prompt_template"] else "generic"))
    return "\n".join(lines)
