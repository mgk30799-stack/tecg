from __future__ import annotations

import json
import logging
import re
from typing import List, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StringType, StructField, StructType
from pyspark.sql.window import Window

import taxonomy

logger = logging.getLogger(__name__)

HIER = ["web_supercategory_nm", "web_department_nm", "web_category_nm", "web_class_nm"]

MIN_PER_CLASS = 30       # a class needs this many populated rows before it may be banded
RATING_PRIOR = 10        # shrinkage strength toward the class mean
LEGAL_AGES = [18, 21]    # the only two values age_restriction may take

# Price tier and quality grade are ranked per site; gender and age restriction are one value per
# product. A site maps the suffix of its tag columns to the columns its ranking reads and to the
# flag of the products that count on it (None: every row). The default is the one-site run on
# the master table.
SITE_FAMILIES = ("quality_grade", "value_proposition_segment")
PRODUCT_FAMILIES = ("gender", "age_restriction")
DEFAULT_SITES = {"": {"price": "pm_price", "star_rating": "star_rating",
                      "review_count": "review_count", "live": None}}

# --- gender ------------------------------------------------------------------
GENDER_SUPERCATEGORIES = frozenset({
    "workwear", "healthcare supplies", "safety supplies", "expanded assortment", "education",
    "bags, backpacks & luggage", "restaurant & foodservice supplies",
})
_G_FEMALE = {"women", "female", "woman", "girl", "girls", "female/girl", "girl/female",
             "girl (child)"}
_G_MALE = {"men", "male", "man", "boy", "boys", "male/boy", "boy/male", "boy (child)"}
_G_UNISEX = {"unisex", "unisex (child)"}
_GENDER_FEMALE_RE = re.compile(r"\b(women|woman|ladies|lady|female|girls?)\b", re.IGNORECASE)
_GENDER_MALE_RE = re.compile(r"\b(men|man|mens|male|gents?|boys?)\b", re.IGNORECASE)

GENDER_SCHEMA = StructType([
    StructField("value", StringType()),
    StructField("evidence", StringType()),
    StructField("source", StringType()),
])

# --- age_restriction ---------------------------------------------------------
_NOT_A_TIME_UNIT = r"(?!\s*(?:month|mos?\b|week|wk|day))"
_NOT_A_MEASUREMENT = (
    r"(?!\s*(?:[\"'°]|(?:in(?:ch(?:es)?)?|ft|feet|cm|mm|m|gauge|ga|awg|mil|"
    r"volts?|v|amps?|a|watts?|w|oz|lbs?|kg|g|qt|gal|pt|ml|l|"
    r"count|ct|pack|pk|pcs?|degrees?|deg)\b))")
_END_OF_FIELD = r"\s*[.,;:!\"'\)]*\s*(?:\(\w+\))?\s*[.,;:!\"'\)]*\s*$"
_NOT_A_COMPARATIVE = r"(?!-?\s*(?:sized?|\d))"

AGE_STATEMENT_PATTERNS = [
    re.compile(r"(?i)\bmust\s+be\s+(18|21)\b" + _NOT_A_TIME_UNIT + _NOT_A_MEASUREMENT),
    re.compile(r"(?i)\bages?\s+(18|21)\s*\+" + _NOT_A_TIME_UNIT + r"(?!\d)" + _END_OF_FIELD),
    re.compile(r"(?i)\b(18|21)\s*\+\s*(?:only|required|to\s+purchase)"),
    re.compile(r"(?i)\b(18|21)\s+years?\s+(?:of\s+age\s+)?or\s+older"),
    re.compile(r"(?i)\b(18|21)\s+and\s+(?:over|older)\b" + _NOT_A_TIME_UNIT
               + _NOT_A_COMPARATIVE),
]
AGE_STATEMENT_IMPLIED = [
    (re.compile(r"(?i)\bnot\s+for\s+sale\s+to\s+minors\b"), 18),
    (re.compile(r"(?i)\bage[-\s]restricted\s+(?:item|product)\b"), 18),
    (re.compile(r"(?i)\badult\s+signature\s+required\b"), 18),
]

# An audience age may be written as a word, and may be in months or weeks
_WORD_NUM = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
             "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
             "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
             "eighteen": 18, "nineteen": 19, "twenty": 20, "twenty-one": 21, "twentyone": 21}
_NUM = r"(?:\d{1,2}|" + "|".join(sorted(_WORD_NUM, key=len, reverse=True)) + r")"
_SUBYEAR = r"(?:month|mo|week|wk|day)"
AUDIENCE_AGE_PATTERNS = [
    re.compile(r"(?i)\bages?\s*:?\s*(" + _NUM + r")\s*(?:(" + _SUBYEAR + r")s?\b)?\s*"
               r"(?:years?|yrs?)?\s*(?:\+|(?:and|or|&)\s*(?:up|over|older|above))"),
    re.compile(r"(?i)\b(" + _NUM + r")\s*()(?:years?|yrs?)\s*(?:of\s+age\s*)?"
               r"(?:and|or|&)\s*(?:up|over|older|above)"),
    re.compile(r"(?i)\b(" + _NUM + r")\s*(" + _SUBYEAR + r")s?\s*"
               r"(?:and|or|&)\s*(?:up|over|older|above)"),
]

NEVER_RESTRICTED_SUPERCATEGORIES = frozenset({
    "furniture", "bags, backpacks & luggage", "office supplies", "paper", "arts & crafts",
    "office decor, homewares & appliances", "party supplies",
    "shipping, packing & mailing supplies", "gift shop", "gift cards", "wearable technology",
    "audio", "hard drives & data storage", "education",
})

# Which spec attributes say what a product IS, rather than how much of something it contains.
IDENTITY_ATTR_EXACT = frozenset({"drug type", "beverage type"})
IDENTITY_ATTR_CONTAINS = ("active ingredient", "product type")
IDENTITY_ATTR_QUANTITY_RE = re.compile(r"(?i)(^%|\bmilligrams?\b|\bmg\b|^\s*%\s*of\b)")

_OTC_DRUG_RE = re.compile(r"(?i)\b(?:pseudoephedrine|dextromethorphan)\b")
AEROSOL_SELF_EVIDENT_RE = re.compile(
    r"(?i)(?:"
    r"\b(?:spray\s+paints?|spray\s+primers?|marking\s+paints?|air\s+dusters?|"
    r"canned\s+air|compressed\s+gas\s+dusters?|aerosol\s+(?:paint|primer|sealer))\b"
    r"|\b(?:paint|primer|sealer)\b(?=.{0,40}\baerosol\b))")
POWERED_DEVICE_RE = re.compile(
    r"(?i)\b(?:electric(?:al)?|cordless|wireless|rechargeable|battery[-\s]powered|"
    r"rpm|motorized|motorised)\b")
REPRESENTATION_RE = re.compile(
    r"(?i)\b(?:print|poster|canvas|wall\s+art|artwork|mural|decal|sticker|sign|signage|label|"
    r"puzzle|mug|t-?shirt|magnet|postcard|calendar|framed|photo|ornament|greeting\s+card|"
    r"receptacle|holder|cooler|coaster)\b")

# Two constructions where a representation word is NOT the product: a colour or finish name
# ("Spray Paint, Gloss Photo Black") and an included accessory ("Compressed Gas Duster with Holder").
_REPRESENTATION_NOT_HEAD_RE = re.compile(
    r"(?i)(?:\b(?:gloss|matte|satin|flat|metallic|gloss[y]?|semi-?gloss|"
    r"pearl|neon|fluorescent|clear|tinted)\s+"
    r"|\b(?:with|w/|and|plus|includes?|featuring)\s+(?:\w+\s+){0,2})$")

# A noun an aerosol and a non-aerosol share (a feather duster): tags only when the hazard record
# confirms an aerosol.
AEROSOL_AMBIGUOUS_RE = re.compile(r"(?i)\b(?:duster|paint|primer|sealer)\b")

# AEROSOL_INDICATOR_CD is not a Y/N flag: it also holds "1", "2" and "3", which are genuine
# aerosols. CONFIRM-ONLY - absence means the record is silent, never that the item is not one.
AEROSOL_CODES = frozenset({"Y", "1", "2", "3"})

# Placeholder values seen in merchant free-text columns.
_RESTRICTION_JUNK = frozenset({
    "n", "y", "n/a", "na", "none", "no", "null", "blank", "-", "--", "u", "unknown", "see sds",
})

AGE_SCHEMA = StructType([
    StructField("value", IntegerType()),
    StructField("evidence", StringType()),
    StructField("source", StringType()),
])


def _s(value) -> str:
    """String, with the pandas 'nan' spelling treated as absent."""
    if value is None:
        return ""
    text = str(value)
    return "" if text.lower() == "nan" else text


def _spec_values(spec_json) -> List[Tuple[str, str]]:
    """``(attribute_nm, attribute_value_txt)`` pairs.

    Accepts the real ``array<struct>`` column, a Spark Row, and a JSON string. ``json.loads`` on
    the real column raises, and a bare except once silently killed three tiers in production.
    """
    if spec_json is None:
        return []
    if isinstance(spec_json, str):
        if not spec_json.strip():
            return []
        try:
            spec_json = json.loads(spec_json)
        except Exception:
            return []
    if isinstance(spec_json, dict) or not isinstance(spec_json, (list, tuple)):
        try:
            spec_json = list(spec_json)
        except TypeError:
            return []
    out = []
    for sp in spec_json:
        if isinstance(sp, dict):
            name, val = sp.get("attribute_nm"), sp.get("attribute_value_txt")
        elif hasattr(sp, "asDict"):
            d = sp.asDict()
            name, val = d.get("attribute_nm"), d.get("attribute_value_txt")
        elif hasattr(sp, "attribute_nm"):
            name, val = sp.attribute_nm, getattr(sp, "attribute_value_txt", None)
        else:
            continue
        out.append((_s(name).strip(), _s(val).strip()))
    return out


def _bullet_values(bullets_json) -> List[str]:
    if bullets_json is None:
        return []
    if isinstance(bullets_json, str):
        if not bullets_json.strip():
            return []
        try:
            bullets_json = json.loads(bullets_json)
        except Exception:
            return []
    if not isinstance(bullets_json, (list, tuple)):
        try:
            bullets_json = list(bullets_json)
        except TypeError:
            return []
    return [_s(b) for b in bullets_json if b is not None]


def resolve_gender(web_supercategory_nm, spec_json, title):
    """First match wins: supercategory gate -> spec attribute -> title pattern -> NULL."""
    supercat = _s(web_supercategory_nm).strip().lower()
    if supercat not in GENDER_SUPERCATEGORIES:
        return (None, None, "gated_out")
    for name, val in _spec_values(spec_json):
        if "gender" in name.lower():
            low = val.lower()
            if low in _G_FEMALE:
                return ("female", "{}: {}".format(name, val), "spec")
            if low in _G_MALE:
                return ("male", "{}: {}".format(name, val), "spec")
            if low in _G_UNISEX:
                return ("unisex", "{}: {}".format(name, val), "spec")
    text = _s(title).lower()
    match = _GENDER_FEMALE_RE.search(text)
    if match:
        return ("female", match.group(0), "title_regex")
    match = _GENDER_MALE_RE.search(text)
    if match:
        return ("male", match.group(0), "title_regex")
    return (None, None, "no_evidence")


def _match_age_statement(text):
    if not text:
        return None
    for pattern in AGE_STATEMENT_PATTERNS:
        match = pattern.search(text)
        if match:
            return int(match.group(1)), match.group(0).strip()
    for pattern, age in AGE_STATEMENT_IMPLIED:
        match = pattern.search(text)
        if match:
            return age, match.group(0).strip()
    return None


def _audience_age(text):
    """The LOWEST stated audience age in the text, with a sub-year unit counting as 0.

    Every match is considered, not just the first: a description naming both "ages 3 and up" and
    "18 and over" is a product sold to children, and the lowest age is the one that decides.
    """
    if not text:
        return None
    best = None
    for pattern in AUDIENCE_AGE_PATTERNS:
        for match in pattern.finditer(text):
            raw, unit = match.group(1), match.group(2)
            age = int(raw) if raw.isdigit() else _WORD_NUM.get(raw.lower())
            if age is None:
                continue
            if unit:
                age = 0
            if best is None or age < best[0]:
                best = (age, match.group(0).strip())
    return best


def _is_identity_attr(name) -> bool:
    text = _s(name).strip().lower()
    if not text or IDENTITY_ATTR_QUANTITY_RE.search(text):
        return False
    return text in IDENTITY_ATTR_EXACT or any(k in text for k in IDENTITY_ATTR_CONTAINS)


def _has_real_text(value) -> bool:
    """True when a merchant free-text field carries content, not a placeholder."""
    text = _s(value).strip()
    return bool(text) and text.lower() not in _RESTRICTION_JUNK


def _is_representation(title: str) -> bool:
    """True when the title's own subject is a depiction or accessory, not the regulated product.

    Veto-only: it can suppress a class match, never create one, so a miss costs at most one tag.
    """
    for match in REPRESENTATION_RE.finditer(title or ""):
        if not _REPRESENTATION_NOT_HEAD_RE.search(title[:match.start()]):
            return True
    return False


def classify_age_restriction(title, description, bullets_json, spec_json, web_supercategory_nm,
                             hazard_other_restrictions_txt=None, hazard_aerosol_ind=None):
    """Hazard statement -> statement -> audience-age veto -> never-restricted veto -> regulated class.

    The hazard columns come from the hazard record and are NULL when it has none for the product;
    the hazard tier then simply does not fire.
    """
    title_s, desc_s = _s(title), _s(description)
    candidates = [title_s, desc_s] + _bullet_values(bullets_json)

    if _has_real_text(hazard_other_restrictions_txt):
        hit = _match_age_statement(_s(hazard_other_restrictions_txt))
        if hit and hit[0] in LEGAL_AGES and hit[1]:
            return (hit[0], hit[1], "hazard_restriction_txt")

    for text in candidates:
        hit = _match_age_statement(text)
        if hit and hit[0] in LEGAL_AGES and hit[1]:
            return (hit[0], hit[1], "explicit_statement")

    for text in candidates:
        stated = _audience_age(text)
        if stated and stated[0] < 18:
            return (None, None, "audience_age_under_18")

    specs = _spec_values(spec_json)
    supercat = _s(web_supercategory_nm).strip().lower()
    if supercat in NEVER_RESTRICTED_SUPERCATEGORIES or _is_representation(title_s):
        return (None, None, "vetoed")

    class_text = " ".join(
        filter(None, [title_s] + [v for nm, v in specs if _is_identity_attr(nm)]))
    if not class_text:
        return (None, None, "no_evidence")

    match = _OTC_DRUG_RE.search(class_text)
    if match:
        return (18, match.group(0), "regulated_class:restricted_otc_drug")
    if not POWERED_DEVICE_RE.search(class_text):
        match = AEROSOL_SELF_EVIDENT_RE.search(class_text)
        if match:
            return (18, match.group(0), "regulated_class:aerosol_inhalant")
        if _s(hazard_aerosol_ind).strip().upper() in AEROSOL_CODES:
            match = AEROSOL_AMBIGUOUS_RE.search(class_text)
            if match:
                return (18, match.group(0), "regulated_class:aerosol_inhalant")
    return (None, None, "no_evidence")


# The hazard record's columns the hazard tier of age_restriction reads.
HAZARD_COLUMNS = ["OTHER_RESTRICTIONS_COMMENT_TXT", "AEROSOL_INDICATOR_CD"]


def _with_hazard(base: DataFrame, hazard) -> DataFrame:
    """Attach the hazard record's merchant restriction text and aerosol code (NULL if absent).

    hazard has one row per PRODUCT_ID with HAZARD_COLUMNS, or is None without a hazard table.
    """
    if hazard is not None:
        hazard = hazard.select(
            F.col("PRODUCT_ID").cast("string").alias("_hazard_id"),
            F.col("OTHER_RESTRICTIONS_COMMENT_TXT").cast("string")
            .alias("hazard_other_restrictions_txt"),
            F.col("AEROSOL_INDICATOR_CD").cast("string").alias("hazard_aerosol_ind"))
        return base.join(hazard, base["item_id"] == hazard["_hazard_id"], "left").drop("_hazard_id")
    logger.info("no hazard table - the hazard tier of age_restriction will not fire")
    return (base.withColumn("hazard_other_restrictions_txt", F.lit(None).cast("string"))
            .withColumn("hazard_aerosol_ind", F.lit(None).cast("string")))


def rule_columns(sites=None) -> List[str]:
    """The tag columns run() returns for these sites; each comes with a <column>_confidence."""
    sites = DEFAULT_SITES if sites is None else sites
    return [family + sfx for sfx in sites for family in SITE_FAMILIES] + list(PRODUCT_FAMILIES)


def run(spark: SparkSession, source_table: str, hazard=None, sites=None) -> DataFrame:
    """Compute all four families for every product. Returns a cached DataFrame.

    hazard: the hazard record, one row per PRODUCT_ID with HAZARD_COLUMNS, or None.

    Price tier and quality grade are ranked within each class, with ties broken by item_id, so a
    product's band does not depend on row order. Without `sites`, they are read from pm_price,
    star_rating and review_count, and a missing column counts as NULL. With `sites` (see
    DEFAULT_SITES) they are computed once per site, among the products that count on that site,
    from columns that must exist.
    """
    have = set(spark.table(source_table).columns)
    per_site = sites is not None
    sites = sites if per_site else DEFAULT_SITES
    if per_site:
        missing = sorted({c for cols in sites.values() for c in cols.values() if c} - have)
        if missing:
            raise ValueError("{} has no column {}".format(source_table, ", ".join(missing)))

    def col_or_null(name, typ="string"):
        return F.col(name) if name in have else F.lit(None).cast(typ)

    def on_site(value, live):
        """The value for the products that count on the site, NULL for the rest."""
        return F.when(F.col(live), value) if live else value

    site_inputs = []
    for sfx, cols in sites.items():
        site_inputs += [
            on_site(col_or_null(cols["price"]), cols.get("live")).alias("price_raw" + sfx),
            on_site(col_or_null(cols["star_rating"], "double").cast("double"),
                    cols.get("live")).alias("star_rating" + sfx),
            on_site(col_or_null(cols["review_count"], "double").cast("double"),
                    cols.get("live")).alias("review_count" + sfx),
        ]
    base = spark.table(source_table).select(
        F.col("item_id").cast("string").alias("item_id"),
        col_or_null("title").alias("title"),
        col_or_null("description").alias("description"),
        col_or_null("bullets_json").alias("bullets_json"),
        col_or_null("spec_json").alias("spec_json"),
        *[col_or_null(c).alias(c) for c in HIER],
        *site_inputs,
    )

    base = _with_hazard(base, hazard)

    cls = Window.partitionBy("web_class_nm")

    def quartile_within_class(value_col, population_col):
        ranked = F.when(
            value_col.isNotNull(),
            F.row_number().over(cls.orderBy(value_col.asc_nulls_last(), F.col("item_id"))),
        )
        return F.when(
            (population_col >= MIN_PER_CLASS) & ranked.isNotNull(),
            F.least(F.lit(4), F.greatest(F.lit(1),
                                         F.ceil(ranked * F.lit(4.0) / population_col))),
        )

    def band(quartile_col, tiers):
        value = F.lit(None).cast("string")
        for i, tier in enumerate(tiers, start=1):
            value = F.when(quartile_col == i, F.lit(tier)).otherwise(value)
        return value

    for sfx in sites:
        price, currency = F.col("price" + sfx), F.col("currency" + sfx)
        rating = F.col("star_rating" + sfx)
        reviews = F.coalesce(F.col("review_count" + sfx), F.lit(0.0))
        base = (
            base
            .withColumn("price" + sfx, F.regexp_extract(F.col("price_raw" + sfx),
                                                        r"([0-9]+\.?[0-9]*)", 1).cast("double"))
            .withColumn("currency" + sfx, F.upper(F.trim(
                F.regexp_extract(F.col("price_raw" + sfx), r"([A-Za-z]{3})\s*$", 1))))
            .withColumn("bandable_price" + sfx,
                        F.when((currency.isin("USD", "")) & (price > 0), price))
            .withColumn("_cls_priced" + sfx, F.count("bandable_price" + sfx).over(cls))
            .withColumn("_q_price" + sfx, quartile_within_class(F.col("bandable_price" + sfx),
                                                                F.col("_cls_priced" + sfx)))
            .withColumn("value_proposition_segment" + sfx,
                        band(F.col("_q_price" + sfx), taxonomy.VALUE_TIERS))
            .withColumn("_cls_mean" + sfx, F.avg("star_rating" + sfx).over(cls))
            .withColumn(
                "_shrunk" + sfx,
                F.when(rating.isNotNull(),
                       (reviews * rating + F.lit(RATING_PRIOR) * F.col("_cls_mean" + sfx))
                       / (reviews + F.lit(RATING_PRIOR))),
            )
            .withColumn("_cls_rated" + sfx, F.count("_shrunk" + sfx).over(cls))
            .withColumn("_q_rating" + sfx, quartile_within_class(F.col("_shrunk" + sfx),
                                                                 F.col("_cls_rated" + sfx)))
            .withColumn("quality_grade" + sfx,
                        band(F.col("_q_rating" + sfx), taxonomy.QUALITY_TIERS))
        )

    gender_udf = F.udf(resolve_gender, GENDER_SCHEMA)
    age_udf = F.udf(classify_age_restriction, AGE_SCHEMA)
    base = (
        base
        .withColumn("_g", gender_udf(F.col("web_supercategory_nm"), F.col("spec_json"),
                                     F.col("title")))
        .withColumn("_a", age_udf(F.col("title"), F.col("description"), F.col("bullets_json"),
                                  F.col("spec_json"), F.col("web_supercategory_nm"),
                                  F.col("hazard_other_restrictions_txt"),
                                  F.col("hazard_aerosol_ind")))
    )

    def band_confidence(quartile_col, population_col):
        """Computed from how much evidence stood behind the band, not asked of a model."""
        return F.when(quartile_col.isNull(), None).otherwise(
            F.round(
                F.least(
                    F.lit(0.95),
                    F.greatest(
                        F.lit(0.35),
                        F.lit(0.5) + F.least(F.lit(1.0), population_col / F.lit(200.0))
                        * F.lit(0.45),
                    ),
                ),
                2,
            )
        )

    site_outputs = []
    for sfx in sites:
        site_outputs += [
            F.col("quality_grade" + sfx),
            band_confidence(F.col("_q_rating" + sfx), F.col("_cls_rated" + sfx))
            .alias("quality_grade{}_confidence".format(sfx)),
            F.col("value_proposition_segment" + sfx),
            band_confidence(F.col("_q_price" + sfx), F.col("_cls_priced" + sfx))
            .alias("value_proposition_segment{}_confidence".format(sfx)),
        ]
    result = base.select(
        "item_id", "title", *HIER,
        *site_outputs,
        F.col("_g.value").alias("gender"),
        F.when(F.col("_g.source") == "spec", F.lit(0.9))
         .when(F.col("_g.source") == "title_regex", F.lit(0.7))
         .otherwise(F.lit(None).cast("double")).alias("gender_confidence"),
        F.col("_a.value").cast("string").alias("age_restriction"),
        F.when(F.col("_a.source").isin("explicit_statement", "hazard_restriction_txt"),
               F.lit(0.95))
         .when(F.col("_a.source").startswith("regulated_class"), F.lit(0.7))
         .otherwise(F.lit(None).cast("double")).alias("age_restriction_confidence"),
    ).cache()

    total = result.count()
    logger.info("deterministic families computed for %s products", format(total, ","))
    for family in rule_columns(sites):
        tagged = result.filter(F.col(family).isNotNull()).count()
        logger.info("  %-28s %9s  %5.2f%%", family, format(tagged, ","),
                    100.0 * tagged / max(total, 1))
    return result
