"""Tag every product live on Staples.com or Staples Business (SB) into one tags table.

Runs the steps of product_tagging.py on the all-sites product list and shares its saved AI
answers and class profiles, so a product is asked about once whichever site it is on. Price tier
and quality grade are ranked per site (_dotcom among Staples.com products, _contract among SB
products); every other tag is one value per product. Every product is tagged with its
Staples.com category, because the class profiles and the gates are built on those names.
"""
from __future__ import annotations

import logging
import os
import sys
from functools import reduce
from typing import Dict, List

try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:  # Databricks jobs run the file without __file__
    _HERE = os.getcwd()
    if os.path.exists(os.path.join(_HERE, "config")):
        _HERE = os.path.join(_HERE, "src", "data_pipeline", "tagging")
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

import deterministic
import product_tagging as pt  # sets up the import path, config and prompts the tagger needs
import taxonomy
from src.data_pipeline.utils import get_spark_session, read_config

logger = logging.getLogger(__name__)

_config = read_config(pt.CONFIG_PATH)["tagging_all"]
SOURCE_TABLE = _config["tables"]["source_table"]
TAGS_TABLE = _config["tables"]["tags_table"]
DETAIL_TABLE = _config["tables"]["detail_table"]
SITES = _config["sites"]
EXCLUDE_CORP_DIVISIONS = _config["exclude_corp_divisions"]

INPUT_VIEW = "tagging_all_input"
TEXT_COLUMNS = ["item_id", "title", "description", "bullets_json", "spec_json"]
CATEGORY_COLUMNS = {h: h + "_dotcom" for h in pt.HIER}


def build_input(spark: SparkSession, source_table: str, sites: Dict,
                exclude_divisions: List[str], view: str = INPUT_VIEW) -> str:
    """The products to tag, as a temporary view over one version of the source table, so a long
    run reads one copy. Every Staples.com product, plus each SB-only product that has a
    Staples.com category and is not custom print. Columns are named as the tagger reads them.
    """
    version = spark.sql("DESCRIBE HISTORY {} LIMIT 1".format(source_table)).first()["version"]
    source = spark.read.option("versionAsOf", version).table(source_table)
    site_columns = sorted({c for cols in sites.values() for c in cols.values() if c})
    needed = (TEXT_COLUMNS + list(CATEGORY_COLUMNS.values()) + site_columns
              + ["corp_division_nm", "in_product_discovery_data", "is_live_contract"])
    missing = sorted(set(needed) - set(source.columns))
    if missing:
        raise ValueError("{} has no column {}".format(source_table, ", ".join(missing)))

    has_category = reduce(lambda a, b: a & b, [
        F.coalesce(F.trim(F.col(c)), F.lit("")) != "" for c in CATEGORY_COLUMNS.values()])
    custom_print = F.coalesce(F.upper(F.trim(F.col("corp_division_nm")))
                              .isin([d.upper() for d in exclude_divisions]), F.lit(False))
    keep = F.col("in_product_discovery_data") | (
        F.col("is_live_contract") & has_category & ~custom_print)
    products = source.filter(keep).select(
        *TEXT_COLUMNS,
        *[F.col(c).alias(h) for h, c in CATEGORY_COLUMNS.items()],
        *[c for c in site_columns if c not in TEXT_COLUMNS],
        *[c for c in ("in_product_discovery_data", "is_live_contract") if c not in site_columns],
    )

    repeated = products.groupBy("item_id").count().filter(F.col("count") > 1).count()
    if repeated:
        raise ValueError("{} has {:,} item_id(s) more than once".format(source_table, repeated))
    products.createOrReplaceTempView(view)

    site = (F.when(~F.col("is_live_contract"), "Staples.com only")
            .when(F.col("in_product_discovery_data"), "both sites").otherwise("SB only"))
    counts = {r["site"]: r["count"] for r in products.groupBy(site.alias("site")).count().collect()}
    logger.info("input: %s version %s | %s", source_table, version,
                ", ".join("{} {:,}".format(k, v) for k, v in sorted(counts.items())))
    return view


def site_report(spark: SparkSession, result: DataFrame, view: str, sites: Dict) -> None:
    """Coverage per site: of the products that count on a site, how many have each tag."""
    flags = sorted({cols["live"] for cols in sites.values() if cols.get("live")})
    joined = result.join(spark.table(view).select("item_id", *flags), "item_id")
    for sfx, cols in sites.items():
        on_site = joined.filter(F.col(cols["live"])) if cols.get("live") else joined
        tags = ([f + sfx for f in deterministic.SITE_FAMILIES]
                + list(deterministic.PRODUCT_FAMILIES) + taxonomy.MODEL_FAMILIES)
        row = on_site.agg(
            F.count("*").alias("products"),
            *[F.count(F.when(F.trim(F.col(t).cast("string")) != "", True)).alias(t)
              for t in tags]).first()
        logger.info("coverage on %s: %s products", sfx.lstrip("_") or "the site",
                    format(row["products"], ","))
        for t in tags:
            logger.info("  %-36s %9s  %6.2f%%", t, format(row[t], ","),
                        100.0 * row[t] / max(row["products"], 1))


def run(spark: SparkSession, source_table: str, tags_table: str, detail_table: str,
        profile_table: str, cache_table: str, llm_cfg: Dict, sites: Dict,
        exclude_divisions: List[str]) -> DataFrame:
    """Tag the input and write the tags and detail tables. Safe to re-run: products already
    answered in the cache are not asked again."""
    view = build_input(spark, source_table, sites, exclude_divisions)
    result, gated = pt.compute_tags(spark, view, profile_table, cache_table, llm_cfg, sites)
    site_report(spark, result, view, sites)
    pt.publish_tags_table(spark, result, tags_table, pt.tag_single_columns(sites))
    pt.publish_detail(pt.build_detail(result, gated, sites), detail_table)
    return result


if __name__ == "__main__":
    spark = get_spark_session()

    logger.info("Running Product Tagging (all sites) with the following configuration:")
    logger.info("Source Table:  %s", SOURCE_TABLE)
    logger.info("Tags Table:    %s (tags are written here)", TAGS_TABLE)
    logger.info("Detail Table:  %s", DETAIL_TABLE)
    logger.info("Profile Table: %s (shared with product_tagging)", pt.PROFILE_TABLE)
    logger.info("Cache Table:   %s (shared with product_tagging)", pt.CACHE_TABLE)

    run(spark, SOURCE_TABLE, TAGS_TABLE, DETAIL_TABLE, pt.PROFILE_TABLE, pt.CACHE_TABLE,
        pt.LLM_CONFIG, SITES, EXCLUDE_CORP_DIVISIONS)
