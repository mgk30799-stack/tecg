from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

try:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))
except NameError:
    CURRENT_DIR = os.getcwd()
    if os.path.exists(os.path.join(CURRENT_DIR, "config")):
        PROJECT_ROOT = CURRENT_DIR
    else:
        PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", "..", ".."))

for _path in (PROJECT_ROOT, CURRENT_DIR,
              os.path.join(PROJECT_ROOT, "src", "data_pipeline", "prompts")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (ArrayType, BooleanType, DoubleType, IntegerType, StringType,
                               StructField, StructType, TimestampType)
from pyspark.sql.window import Window

import deterministic
import gates
import llm
import prompt_store
import taxonomy
from src.data_pipeline.utils import (get_spark_session, read_config, read_hazard_by_product,
                                     validate_before_write)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "general.yml")
_general_config = read_config(CONFIG_PATH)
_config = _general_config["tagging"]
# The hazard record feeds the hazard tier of age_restriction (deterministic.classify_age_restriction).
HAZARD_TABLE = _general_config["lifecycle"]["tables"]["HAZARD_TABLE"]
SOURCE_TABLE = _config["tables"]["source_table"]
PROFILE_TABLE = _config["tables"]["class_profile_table"]
CACHE_TABLE = _config["tables"]["cache_table"]
DETAIL_TABLE = _config["tables"]["detail_table"]
LLM_CONFIG = _config["llm"]


def truncate(value, limit: int) -> str:
    """Exactly what the notebook sent: stripped, and an ellipsis when it was cut.
    """
    text = (value or "").strip()
    return text if len(text) <= limit else text[:limit].rstrip() + "..."


def _log_section(title: str, width: int = 60) -> None:
    logger.info("")
    logger.info("=" * width)
    logger.info(title)
    logger.info("=" * width)


# ---------------------------------------------------------------------------
# Constants and schemas
# ---------------------------------------------------------------------------

HIER = ["web_supercategory_nm", "web_department_nm", "web_category_nm", "web_class_nm"]
VERDICTS = ("not_applicable", "class_determined", "varies")

SAMPLE_TITLES = 15
MAX_CANDIDATES = 6
MAX_CANDIDATES_BY_FAMILY = {"events": 12}

PROFILE_SCHEMA = StructType(
    [StructField(h, StringType()) for h in HIER]
    + [
        StructField("family", StringType()),
        StructField("product_count", IntegerType()),
        StructField("verdict", StringType()),
        StructField("labels", ArrayType(StringType())),
        StructField("candidates", ArrayType(StringType())),
        StructField("confidence", DoubleType()),
        StructField("reason", StringType()),
        StructField("forced_reason", StringType()),
        StructField("reviewer_verdict", StringType()),
        StructField("reviewer_labels", StringType()),
        StructField("reviewer_note", StringType()),
        StructField("reviewed_by", StringType()),
        StructField("reviewed_at", StringType()),
        StructField("run_id", StringType()),
        StructField("profiled_at", StringType()),
    ]
)

CACHE_SCHEMA = StructType([
    StructField("item_id", StringType()),
    StructField("family", StringType()),
    StructField("labels", ArrayType(StringType())),
    StructField("confidences", ArrayType(DoubleType())),
    StructField("evidence", StringType()),
    StructField("none_fit", BooleanType()),
    StructField("model_id", StringType()),
    StructField("cached_at", StringType()),
])

GATE_SCHEMA = StructType([
    StructField("labels", ArrayType(StringType())),
    StructField("confidences", ArrayType(DoubleType())),
    StructField("parents", ArrayType(StringType())),
    StructField("dropped", ArrayType(StringType())),
    StructField("state", StringType()),
])


# ---------------------------------------------------------------------------
# Prompts — all text lives in config/prompts/product_tagging.yaml
# ---------------------------------------------------------------------------

_PROMPTS = prompt_store.load("product_tagging")

CLASS_SCOPE = _PROMPTS["class_scope"]
PRODUCT_SCOPE = _PROMPTS["product_scope"]

_CLASS_PROMPT = _PROMPTS["class_prompt"]
_PRODUCT_PROMPT = _PROMPTS["product_prompt"]

_CLASS_INTRO = prompt_store.check_placeholders(
    _CLASS_PROMPT["intro"],
    {"family", "meaning", "class_name", "hierarchy", "product_count", "titles",
     "n_allowed", "allowed_labels"},
    "product_tagging.yaml class_prompt.intro",
)
_CLASS_PRIOR = prompt_store.check_placeholders(
    _CLASS_PROMPT["prior_note"], {"labels"}, "product_tagging.yaml class_prompt.prior_note")
_PRODUCT_HEAD = prompt_store.check_placeholders(
    _PRODUCT_PROMPT["head"], {"family", "meaning"}, "product_tagging.yaml product_prompt.head")
_PRODUCT_GUIDANCE = prompt_store.check_placeholders(
    _PRODUCT_PROMPT["guidance"], {"guidance"}, "product_tagging.yaml product_prompt.guidance")
_PRODUCT_BODY = prompt_store.check_placeholders(
    _PRODUCT_PROMPT["body"],
    {"title", "hierarchy", "description", "n_candidates", "candidates"},
    "product_tagging.yaml product_prompt.body",
)

# Every family needs a meaning in both steps, or the prompt silently says "Meaning: <family>".
_missing_scope = [f for f in taxonomy.PROFILE_FAMILIES if f not in CLASS_SCOPE] + [
    f for f in taxonomy.MODEL_FAMILIES if f not in PRODUCT_SCOPE]
if _missing_scope:
    raise prompt_store.PromptConfigError(
        "product_tagging.yaml has no class_scope/product_scope entry for: {}".format(
            sorted(set(_missing_scope))))

# {max_candidates} is filled by plain replace (the text contains JSON braces).
PROFILE_RULES = _CLASS_PROMPT["rules"]
if "{max_candidates}" not in PROFILE_RULES:
    raise prompt_store.PromptConfigError(
        "product_tagging.yaml class_prompt.rules must contain {max_candidates}")
PRODUCT_RULES = _PRODUCT_PROMPT["rules"]
# room_context, use_cases and audience_tags apply to every product, so their rules ask for the
# closest labels instead of saying an empty answer is usually right.
ALWAYS_APPLICABLE_RULES = _PRODUCT_PROMPT["always_applicable_rules"]
SINGLE_RULE = _PRODUCT_PROMPT["single_value_rule"]


# ---------------------------------------------------------------------------
# Step 1 — class profiling
# ---------------------------------------------------------------------------

def max_candidates_for(family: str) -> int:
    """Shortlist size, derived from the family's configured ``max_labels``.

    A shortlist should be somewhat wider than the cap on labels a product may carry, but not
    unbounded.
    """
    if family in MAX_CANDIDATES_BY_FAMILY:
        return MAX_CANDIDATES_BY_FAMILY[family]
    return max(MAX_CANDIDATES, taxonomy.cap(family) * 2)


def build_class_inventory(spark: SparkSession, source_table: str) -> DataFrame:
    """One row per class with a stratified title sample.

    Titles are stratified, not random: random sampling misses the rare variants that make a
    class heterogeneous, which is exactly what this step has to detect. Longest two, shortest
    two, and a deterministic spread for the rest.
    """
    src = spark.table(source_table).select(
        F.col("item_id").cast("string").alias("item_id"),
        F.col("title").cast("string").alias("title"),
        *[F.col(c).cast("string").alias(c) for c in HIER],
    ).filter(F.col("web_class_nm").isNotNull() & (F.trim("web_class_nm") != ""))

    by_length = Window.partitionBy(*HIER).orderBy(F.length("title").desc())
    by_hash = Window.partitionBy(*HIER).orderBy(F.abs(F.hash("item_id")))
    sampled = (
        src.withColumn("_by_len", F.row_number().over(by_length))
        .withColumn("_by_rnd", F.row_number().over(by_hash))
        .withColumn("_n", F.count("*").over(Window.partitionBy(*HIER)))
        .filter(
            (F.col("_by_len") <= 2)
            | (F.col("_by_len") > F.col("_n") - 2)
            | (F.col("_by_rnd") <= SAMPLE_TITLES - 4)
        )
    )

    classes = sampled.groupBy(*HIER).agg(
        F.first("_n").alias("product_count"),
        F.slice(F.collect_list("title"), 1, SAMPLE_TITLES).alias("sample_titles"),
    )
    return classes.orderBy(F.desc("product_count"))


def _format_labels(family: str, allowed: List[str]) -> str:
    """Flat for most families; grouped under parents for events.

    A pipe-joined line of 338 labels is unreadable and hides the structure the model is
    choosing within. Grouping also makes the parent-fallback rule obvious.
    """
    if family != "events":
        return "  " + " | ".join(allowed)
    groups: Dict[str, List[str]] = {}
    _parents, _subs, sub_to_parent, _amb = taxonomy.events()
    for sub, parent in sub_to_parent.items():
        groups.setdefault(parent, []).append(sub)
    out = []
    for parent in sorted(groups):
        out.append("  {}  (parent - use only if no sub-category below fits)".format(parent))
        line = "      "
        for label in sorted(groups[parent]):
            if len(line) + len(label) > 104:
                out.append(line.rstrip().rstrip(","))
                line = "      "
            line += label + ", "
        if line.strip():
            out.append(line.rstrip().rstrip(","))
    return "\n".join(out)


def prior_labels(family: str, row: Dict) -> List[str]:
    """Zones the hand-built body_parts matrix already assigns to this class.

    body_parts is the one family with existing hand-built work. Passing it as a prior means the
    model confirms or extends it instead of re-deriving it, and disagreement with the matrix is
    itself a signal worth reviewing. Read from config/tags/body_parts_config.yml.
    """
    if family != "body_parts":
        return []
    out = []
    for zone, scope in taxonomy.body_parts_matrix().items():
        for level, key in (("web_supercategories", "web_supercategory_nm"),
                           ("web_departments", "web_department_nm"),
                           ("web_classes", "web_class_nm")):
            values = scope.get(level) or []
            if row.get(key) and any(
                    gates.norm_label(v) == gates.norm_label(row[key]) for v in values):
                out.append(zone)
                break
    return sorted(set(out))


def build_class_prompt(family: str, row: Dict, max_candidates: int) -> str:
    allowed = taxonomy.enums()[family]
    titles = "\n".join(
        "  - {}".format(truncate(t, 110))
        for t in (row.get("sample_titles") or [])[:SAMPLE_TITLES]
    )
    parts = [
        _CLASS_INTRO.format(
            family=family,
            meaning=CLASS_SCOPE.get(family, family),
            class_name=row["web_class_nm"],
            hierarchy=" > ".join(str(row[h]) for h in HIER),
            product_count="{:,}".format(row["product_count"]),
            titles=titles,
            n_allowed=len(allowed),
            allowed_labels=_format_labels(family, allowed),
        ),
    ]
    prior = prior_labels(family, row)
    if prior:
        parts += ["", _CLASS_PRIOR.format(labels=" | ".join(prior))]
    parts += ["", PROFILE_RULES.replace("{max_candidates}", str(max_candidates))]
    return "\n".join(parts)


def profile_one(client, family: str, row: Dict, max_candidates: int, retries: int) -> Dict:
    allowed = taxonomy.enums()[family]
    allowed_map = {gates.norm_label(a): a for a in allowed}
    base = {
        "family": family,
        "product_count": row["product_count"],
        **{h: row[h] for h in HIER},
    }

    data, error = llm.ask_json(client, build_class_prompt(family, row, max_candidates), retries)
    if data is None:
        return dict(base, verdict=None, labels=[], candidates=[], confidence=None,
                    reason=None, forced_reason=None, ok=False, error=error)

    verdict = str(data.get("verdict", "")).strip().lower().replace(" ", "_")
    if verdict not in VERDICTS:
        return dict(base, verdict=None, labels=[], candidates=[], confidence=None, reason=None,
                    forced_reason=None, ok=False,
                    error="unparseable verdict {!r}".format(str(data.get("verdict"))[:60]))

    def clean(values):
        out = []
        for value in values or []:
            key = gates.norm_label(value)
            if key in allowed_map and allowed_map[key] not in out:
                out.append(allowed_map[key])
        return out

    labels = clean(data.get("labels"))
    candidates = clean(data.get("candidates"))[:max_candidates]
    try:
        confidence = max(0.0, min(1.0, float(data.get("confidence"))))
    except (TypeError, ValueError):
        confidence = None

    forced = None
    if verdict == "class_determined":
        verdict, forced = "varies", "class_determined treated as varies"

    if verdict == "varies":

        if not candidates and labels:
            candidates = list(labels)
            forced = (forced + "; " if forced else "") + "candidates taken from labels"
        if not candidates:
            candidates = list(allowed)
            forced = (forced + "; " if forced else "") + "no candidates given, full enum used"
    if verdict == "not_applicable":
        labels, candidates = [], []

    return dict(base, verdict=verdict, labels=labels, candidates=candidates,
                confidence=confidence, reason=str(data.get("reason") or "")[:200],
                forced_reason=forced, ok=True, error=None)


def _profile_jobs(spark: SparkSession, source_table: str, profile_table: str,
                  families: List[str]) -> Tuple[List[Dict], List[Tuple[str, Dict]]]:
    """(all classes, the (family, class) pairs not profiled yet).

    A pair is profiled once and kept, which is what lets this run on every pipeline pass without
    re-spending the calls - and what keeps a reviewer's correction from being superseded by a
    fresh row for the same class. To re-profile after a taxonomy change, delete the rows.
    """
    rows = [r.asDict() for r in build_class_inventory(spark, source_table).collect()]
    done = set()
    try:
        for r in spark.table(profile_table).select(*HIER, "family").distinct().collect():
            done.add(tuple(r[h] for h in HIER) + (r["family"],))
    except Exception:
        logger.info("no profile table yet - every class will be profiled")
    jobs = [(f, row) for row in rows for f in families
            if tuple(row[h] for h in HIER) + (f,) not in done]
    return rows, jobs


def profile_classes(spark: SparkSession, source_table: str, profile_table: str, llm_cfg: Dict,
                    families: Optional[List[str]] = None) -> int:
    """Profile the (class, family) pairs that have not been profiled yet. Returns how many."""
    _log_section("STEP 1 OF 3: CLASS PROFILING", width=80)
    families = families or taxonomy.PROFILE_FAMILIES
    logger.info(taxonomy.settings_summary())
    logger.info("profiling %d families: %s", len(families), ", ".join(families))
    logger.info("  %s apply to every product, so there is nothing to gate for them",
                ", ".join(taxonomy.ALWAYS_APPLICABLE))

    caps = {f: max_candidates_for(f) for f in families}
    class_rows, jobs = _profile_jobs(spark, source_table, profile_table, families)
    logger.info("%s classes | %s (class, family) pairs to profile",
                format(len(class_rows), ","), format(len(jobs), ","))
    if not jobs:
        logger.info("every class is already profiled - nothing to do")
        return 0

    client, settings = llm.build_client(llm_cfg)
    results = llm.run_pool(
        jobs,
        lambda job: profile_one(client, job[0], job[1], caps[job[0]], settings["retries"]),
        workers=settings["workers"], chunk=settings["chunk"], label="profiles",
        timeout_s=settings["timeout_s"], retries=settings["retries"],
    )
    ok = [r for r in results if r.get("ok")]
    logger.info("%s profiled, %s failed", format(len(ok), ","),
                format(len(results) - len(ok), ","))
    _profile_report(ok, class_rows, families)
    if not ok:
        return 0

    run_id = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    now = datetime.now(timezone.utc).isoformat()
    rows = [
        tuple([r[h] for h in HIER]
              + [r["family"], int(r["product_count"]), r["verdict"],
                 r["labels"], r["candidates"],
                 float(r["confidence"]) if r["confidence"] is not None else None,
                 r["reason"], r.get("forced_reason"),
                 None, None, None, None, None, run_id, now])
        for r in ok
    ]
    validate_before_write(spark, profile_table, PROFILE_SCHEMA)
    (spark.createDataFrame(rows, schema=PROFILE_SCHEMA)
     .write.format("delta").mode("append").option("mergeSchema", "true")
     .saveAsTable(profile_table))
    logger.info("written: %s   run_id = %s", profile_table, run_id)
    logger.info("Review the largest classes in that table - one corrected verdict is worth "
                "hundreds of per-product corrections. Fill reviewer_verdict / reviewer_labels "
                "and the next run honours them without re-profiling.")
    return len(ok)


def _profile_report(ok: List[Dict], class_rows: List[Dict], families: List[str]) -> None:
    if not ok:
        return
    logger.info("verdict mix per family")
    total_asked = 0
    for family in families:
        rows = [r for r in ok if r["family"] == family]
        if not rows:
            continue
        counts = {v: sum(1 for r in rows if r["verdict"] == v) for v in VERDICTS}
        asked = sum(r["product_count"] for r in rows if r["verdict"] == "varies")
        total_asked += asked
        logger.info("  %-20s not_applicable=%-7s varies=%-7s products_asked=%s",
                    family, format(counts["not_applicable"], ","),
                    format(counts["varies"], ","), format(asked, ","))

    naive = sum(r["product_count"] for r in class_rows) * len(families)
    logger.info("  pairs if nothing were gated : %s", format(naive, ","))
    logger.info("  pairs the product step calls: %s  (%.1f%%)", format(total_asked, ","),
                100.0 * total_asked / max(naive, 1))
    if total_asked > naive * 0.45:
        logger.warning("  gating removed less than planned - review the `varies` verdicts on "
                       "the largest classes before classifying")

    forced = [r for r in ok if r.get("forced_reason")]
    if forced:
        logger.info("  %s verdicts adjusted", format(len(forced), ","))
        for reason in sorted({r["forced_reason"] for r in forced}):
            logger.info("      %6s  %s",
                        format(sum(1 for r in forced if r["forced_reason"] == reason), ","),
                        reason)


# ---------------------------------------------------------------------------
# Step 2 — product classification
# ---------------------------------------------------------------------------

def build_product_prompt(job: Dict) -> str:
    family = job["family"]
    template = taxonomy.prompt_template(family)
    candidates = job["eff_candidates"] or taxonomy.candidates_for(
        family, job.get("web_supercategory_nm"))
    parts = [_PRODUCT_HEAD.format(family=family, meaning=PRODUCT_SCOPE.get(family, family))]
    if template:
        parts += ["", _PRODUCT_GUIDANCE.format(guidance=truncate(str(template), 900))]
    parts += [
        "",
        _PRODUCT_BODY.format(
            title=truncate(job.get("title"), 220),
            hierarchy=" > ".join(str(job.get(h)) for h in HIER),
            description=truncate(job.get("description"), 600),
            n_candidates=len(candidates),
            candidates=" | ".join(candidates),
        ),
        "",
        (ALWAYS_APPLICABLE_RULES if family in taxonomy.ALWAYS_APPLICABLE else PRODUCT_RULES)
        + (SINGLE_RULE if family in taxonomy.SINGLE_VALUE else ""),
    ]
    return "\n".join(parts)


def classify_one(client, job: Dict, retries: int) -> Dict:
    family = job["family"]
    out = {"item_id": job["item_id"], "family": family, "ok": False, "labels": [],
           "confidences": [], "evidence": None, "none_fit": False, "reason": None}

    data, error = llm.ask_json(client, build_product_prompt(job), retries)
    if data is None:
        out["reason"] = error
        return out

    candidates = job["eff_candidates"] or taxonomy.candidates_for(
        family, job.get("web_supercategory_nm"))
    allowed = {gates.norm_label(c): c for c in candidates}

    raw = data.get("labels")
    if isinstance(raw, str):
        raw = [raw]
    labels, confidences = [], []
    for item in raw or []:
        if isinstance(item, str):
            label, conf = item, None
        elif isinstance(item, dict):
            label, conf = item.get("label"), item.get("confidence")
        else:
            continue
        key = gates.norm_label(label)
        if key in allowed and allowed[key] not in labels:
            labels.append(allowed[key])
            try:
                confidences.append(max(0.0, min(1.0, float(conf))))
            except (TypeError, ValueError):
                confidences.append(None)

    evidence = data.get("evidence")
    if isinstance(evidence, (list, tuple)):
        evidence = next((e for e in evidence if e), None)
    out.update(
        ok=True, labels=labels, confidences=confidences,
        evidence=(str(evidence)[:400] if evidence else None),
        none_fit=bool(data.get("none_fit_but_something_does")), reason="accepted",
    )
    return out


def _effective_profiles(spark: SparkSession, profile_table: str) -> DataFrame:
    """One row per (class, family), with a reviewer's correction winning over the model.
    """
    newest = Window.partitionBy(*HIER, "family").orderBy(F.col("profiled_at").desc_nulls_last())
    return (
        spark.table(profile_table)
        .withColumn("_r", F.row_number().over(newest)).filter(F.col("_r") == 1).drop("_r")
        .withColumn("eff_verdict", F.coalesce(F.col("reviewer_verdict"), F.col("verdict")))
        .withColumn(
            "eff_candidates",
            F.when(
                F.col("reviewer_labels").isNotNull() & (F.trim("reviewer_labels") != ""),
                F.split(F.col("reviewer_labels"), r"\s*\|\s*"),
            ).otherwise(F.col("candidates")),
        )
    )


def _work_to_do(spark: SparkSession, source_table: str, profile_table: str,
                cache_table: str) -> DataFrame:
    profiles = _effective_profiles(spark, profile_table)

    varies = profiles.filter(F.col("eff_verdict") == "varies").select(
        *HIER, "family", "eff_candidates")

    source = spark.table(source_table).select(
        F.col("item_id").cast("string").alias("item_id"),
        F.col("title").cast("string").alias("title"),
        F.col("description").cast("string").alias("description"),
        *[F.col(c).cast("string").alias(c) for c in HIER],
    )
    work = source.join(varies, HIER, "inner")

    profiled = {r["family"] for r in profiles.select("family").distinct().collect()}
    unprofiled = [f for f in taxonomy.MODEL_FAMILIES if f not in profiled]
    if unprofiled:
        logger.info("classified against their own enum: %s", ", ".join(unprofiled))
        classes = source.select(*HIER).distinct()
        for family in unprofiled:
            work = work.unionByName(
                source.join(
                    classes.withColumn("family", F.lit(family))
                    .withColumn("eff_candidates", F.lit(None).cast("array<string>")),
                    HIER, "inner",
                )
            )

    try:
        done = spark.table(cache_table).select("item_id", "family")
        work = work.join(done, ["item_id", "family"], "left_anti")
    except Exception:
        logger.info("no cache yet - classifying everything in scope")
    return work


def classify_products(spark: SparkSession, source_table: str, profile_table: str,
                      cache_table: str, llm_cfg: Dict) -> int:
    """Classify every (product, family) pair the class profile left open. Returns how many."""
    _log_section("STEP 2 OF 3: PRODUCT CLASSIFICATION", width=80)

    work = _work_to_do(spark, source_table, profile_table, cache_table)
    jobs = [r.asDict() for r in work.collect()]
    logger.info("%s (product, family) pairs to classify", format(len(jobs), ","))
    if not jobs:
        logger.info("the cache already covers every pair in scope - nothing to do")
        return 0

    client, settings = llm.build_client(llm_cfg)
    tally = {"ok": 0, "failed": 0}

    def persist(chunk_results: List[Dict]) -> None:
        """Write one chunk, then let it go.

        Only successful answers are written: a cached failure is indistinguishable from a cached
        answer on the next run's anti-join, so one timeout would become a permanent gap for that
        product. Leaving failures out means the next run retries exactly them.

        Writing per chunk rather than at the end is not optional either - the first full run
        held 365,000 results in driver memory with nothing written, and a kill would have cost
        27 hours.
        """
        good = [r for r in chunk_results if r.get("ok")]
        tally["ok"] += len(good)
        tally["failed"] += len(chunk_results) - len(good)
        if not good:
            return
        now = datetime.now(timezone.utc).isoformat()
        rows = [
            (r["item_id"], r["family"], r["labels"], r["confidences"], r["evidence"],
             r["none_fit"], settings["model"], now)
            for r in good
        ]
        # Runs per checkpointed chunk; after the first chunk it is one
        # metadata read that logs PASS.
        validate_before_write(spark, cache_table, CACHE_SCHEMA)
        (spark.createDataFrame(rows, schema=CACHE_SCHEMA)
         .write.format("delta").mode("append").option("mergeSchema", "true")
         .saveAsTable(cache_table))
        logger.info("      checkpointed %s | %s cached so far",
                    format(len(good), ","), format(tally["ok"], ","))

    llm.run_pool(
        jobs,
        lambda job: classify_one(client, job, settings["retries"]),
        workers=settings["workers"], chunk=settings["chunk"], label="classifications",
        timeout_s=settings["timeout_s"], retries=settings["retries"], on_chunk=persist,
    )

    if getattr(client, "served", None):
        logger.info("answered by endpoint: %s", client.served)
    logger.info("%s answered and cached, %s failed",
                format(tally["ok"], ","), format(tally["failed"], ","))
    if tally["failed"]:
        logger.info("failures are NOT cached - run again and only those are retried")
    return tally["ok"]


# ---------------------------------------------------------------------------
# Step 3 — gates and output
# ---------------------------------------------------------------------------

def _dedupe_cache(cache: DataFrame) -> DataFrame:
    """Keep one row per (item_id, family), preferring the richer answer.

    A cache written before the hierarchy-join fix can hold two rows for one pair, because a
    class NAME under two department paths produced two profile rows. Keeping the answer with
    more labels (then the most recent) lets an already-paid-for cache be used without
    re-classifying hundreds of thousands of products.
    """
    before = cache.count()
    window = Window.partitionBy("item_id", "family").orderBy(
        F.size(F.coalesce(F.col("labels"), F.array())).desc(), F.col("cached_at").desc()
    )
    deduped = (cache.withColumn("_r", F.row_number().over(window))
               .filter(F.col("_r") == 1).drop("_r").cache())
    after = deduped.count()
    if before != after:
        logger.warning("de-duplicated cache: %s -> %s (%s duplicate pairs, kept the richer "
                       "answer)", format(before, ","), format(after, ","),
                       format(before - after, ","))
    return deduped


def _grounding_blob(spark: SparkSession, source_table: str) -> DataFrame:
    """Everything the prompt showed the model, lowercased.

    The category goes in twice: level by level, and as the one "A > B > C > D" line the prompt
    shows, so a quote copied from that line is found.
    """
    levels = [F.coalesce(F.col(h).cast("string"), F.lit("")) for h in HIER]
    return spark.table(source_table).select(
        F.col("item_id").cast("string").alias("item_id"),
        F.lower(
            F.concat_ws(
                " ",
                F.coalesce(F.col("title").cast("string"), F.lit("")),
                F.coalesce(F.col("description").cast("string"), F.lit("")),
                *levels,
                F.concat_ws(" > ", *levels),
            )
        ).alias("blob"),
    )


DETAIL_COLUMNS = ["item_id", "family", "label", "confidence", "accepted", "reason", "evidence",
                  "parent_label", "engine", "model_id", "prompt_version", "run_id", "tagged_at"]


def build_detail(out: DataFrame, gated: DataFrame, sites: Optional[Dict] = None) -> DataFrame:
    """The proof behind every master value: one row per (product, family, label).

    `accepted` rows are the labels that reached the master table. Rejected rows carry the gate
    that removed them in `reason` (below_<threshold>, no_evidence, not_grounded, not_in_enum,
    superseded, ambiguous, over_cap) together with the model's own confidence, so a threshold
    can be re-tuned without calling the model again. Computed families have no evidence; their
    reason is `rules`, and a per-site one is named with its site (quality_grade_contract, see
    deterministic.run). A family the model answered with no labels has no row: the raw "none" is
    in the cache table.
    """
    run_id = out.select("run_id").first()["run_id"]
    prompt_version = str(_PROMPTS.get("version", ""))

    exploded = gated.select(
        "item_id", "family", "evidence", "state", "model_id", "labels", "dropped", "parents",
        "raw_confidences", F.posexplode("raw_labels").alias("pos", "label"),
    )
    reason_entry = ("try_element_at(filter(dropped, d -> substring(d, 1, length(label) + 1) "
                    "= concat(label, ':')), 1)")
    llm_rows = exploded.select(
        "item_id", "family", "label",
        F.expr("try_element_at(raw_confidences, pos + 1)").cast("double").alias("confidence"),
        F.coalesce(F.expr("array_contains(labels, label)"), F.lit(False)).alias("accepted"),
        F.expr("coalesce(substring({e}, length(label) + 2), "
               "CASE WHEN array_contains(labels, label) THEN 'accepted' END, state)"
               .format(e=reason_entry)).alias("reason"),
        F.col("evidence").cast("string").alias("evidence"),
        F.expr("CASE WHEN array_contains(labels, label) AND parents IS NOT NULL "
               "THEN try_element_at(parents, CAST(array_position(labels, label) AS INT)) END"
               ).cast("string").alias("parent_label"),
        F.lit("llm").alias("engine"),
        F.col("model_id").cast("string").alias("model_id"),
    )
    llm_rows = llm_rows.withColumn(
        "reason", F.when(F.col("accepted"), F.lit("accepted")).otherwise(F.col("reason")))

    rule_rows = None
    for family in deterministic.rule_columns(sites):
        rows = out.filter(F.trim(F.coalesce(F.col(family).cast("string"), F.lit(""))) != "").select(
            "item_id",
            F.lit(family).alias("family"),
            F.col(family).cast("string").alias("label"),
            F.col("{}_confidence".format(family)).cast("double").alias("confidence"),
            F.lit(True).alias("accepted"),
            F.lit("rules").alias("reason"),
            F.lit(None).cast("string").alias("evidence"),
            F.lit(None).cast("string").alias("parent_label"),
            F.lit("rules").alias("engine"),
            F.lit(None).cast("string").alias("model_id"),
        )
        rule_rows = rows if rule_rows is None else rule_rows.unionByName(rows)

    detail = llm_rows if rule_rows is None else llm_rows.unionByName(rule_rows)
    return (detail.withColumn("prompt_version", F.lit(prompt_version))
            .withColumn("run_id", F.lit(run_id))
            .withColumn("tagged_at", F.current_timestamp())
            .select(*DETAIL_COLUMNS))


def gate_cache(spark: SparkSession, source_table: str, cache_table: str) -> DataFrame:
    """Run the cached model answers for the source's products through the gates: one row per
    (product, family).

    The cache is shared with other runs, so it also holds answers for products this source does
    not have (another site's, or products that left). Those are skipped, so they never reach this
    run's detail table as not_grounded rows.
    """
    thresholds = taxonomy.thresholds()
    caps = taxonomy.caps()
    in_source = spark.table(source_table).select(F.col("item_id").cast("string").alias("item_id"))
    cache = _dedupe_cache(spark.table(cache_table).join(in_source, "item_id", "left_semi"))
    enums = taxonomy.enums()

    def gate(family, labels, confidences, evidence, blob):
        out = gates.apply_gates(
            family=family, labels=labels, confidences=confidences, evidence=evidence,
            blob=blob, allowed=enums.get(family, []),
            threshold=thresholds.get(family), cap=caps.get(family),
        )
        return (out["labels"], out["confidences"], out["parents"], out["dropped"], out["state"])

    gate_udf = F.udf(gate, GATE_SCHEMA)

    gated = (
        cache.join(_grounding_blob(spark, source_table), "item_id", "left")
        .withColumn("_g", gate_udf(F.col("family"), F.col("labels"), F.col("confidences"),
                                   F.col("evidence"), F.col("blob")))
        .select(
            "item_id", "family", "evidence", "none_fit", "model_id",
            F.col("labels").alias("raw_labels"),
            F.col("confidences").alias("raw_confidences"),
            F.col("_g.labels").alias("labels"),
            F.col("_g.confidences").alias("confidences"),
            F.col("_g.parents").alias("parents"),
            F.col("_g.dropped").alias("dropped"),
            F.col("_g.state").alias("state"),
        )
        .cache()
    )

    logger.info("gate outcomes")
    for row in gated.groupBy("state").count().orderBy(F.desc("count")).collect():
        logger.info("  %-40s %9s", str(row["state"])[:40], format(row["count"], ","))
    return gated


def assemble_values(spark: SparkSession, source_table: str, cache_table: str,
                    gated: Optional[DataFrame] = None, sites: Optional[Dict] = None) -> DataFrame:
    """Gate the cached answers and join the computed families, one row per product.

    sites: price tier and quality grade per site (see deterministic.run); None is one site.
    """
    _log_section("STEP 3 OF 3: GATES AND OUTPUT", width=80)
    enums = taxonomy.enums()
    hazard = (read_hazard_by_product(spark, HAZARD_TABLE, deterministic.HAZARD_COLUMNS)
              if spark.catalog.tableExists(HAZARD_TABLE) else None)
    det = deterministic.run(spark, source_table, hazard, sites)
    if gated is None:
        gated = gate_cache(spark, source_table, cache_table)

    out = det
    for family in taxonomy.MODEL_FAMILIES:
        per_family = gated.filter(F.col("family") == family).select(
            "item_id",
            F.array_join("labels", " | ").alias(family),
            F.array_max("confidences").alias("{}_confidence".format(family)),
            F.array_join(F.transform(F.col("confidences"), lambda c: F.round(c, 2)),
                         " | ", "").alias("{}_confidences".format(family)),
            F.col("evidence").alias("{}_evidence".format(family)),
            F.col("state").alias("{}_state".format(family)),
            F.array_join("dropped", " | ").alias("{}_dropped".format(family)),
            F.col("none_fit").alias("{}_shortlist_gap".format(family)),
        )
        if family == "events":
            per_family = per_family.join(
                gated.filter(F.col("family") == "events").select(
                    "item_id", F.array_join("parents", " | ").alias("events_parent")),
                "item_id", "left",
            )
        out = out.join(per_family, "item_id", "left")

    run_id = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    out = out.withColumn("run_id", F.lit(run_id)).cache()

    _output_report(out, det, run_id, deterministic.rule_columns(sites) + taxonomy.MODEL_FAMILIES)
    _assert_taxonomy(out, enums)
    return out


# The master table (product_master_enriched_t) holds only the tag values that passed the gates,
# as flat columns; anything rejected (low confidence, no evidence, ...) is NULL there. The proof
# for every value, accepted or rejected, is in the detail table (see build_detail).
#   tags_updated_at timestamp of the last time any tag for the product changed
MASTER_ARRAY_COLUMNS = {
    "seasonality": "seasonality_tags",
    "body_parts": "body_part_tags",
    "weather_condition": "weather_tags",
    "events": "event_tags",
    "room_context": "room_context_tags",
    "use_cases": "use_case_tags",
    "audience_tags": "audience_tags",
}
MASTER_SINGLE_COLUMNS = {
    "gender": "gender", "age_group": "age_group", "age_restriction": "age_restriction",
    "quality_grade": "quality_grade", "value_proposition_segment": "value_proposition_segment",
}
MASTER_TYPE_OVERRIDES = {"age_restriction": "int"}


def _master_updates(out: DataFrame,
                    single_columns: Optional[Dict[str, str]] = None) -> DataFrame:
    """Reshape the tagging output into the master table's column names and types.
    Empty answers become NULL (not an empty array)."""
    def values(family):
        joined = F.col(family).cast("string")
        parts = F.filter(F.transform(F.split(joined, r"\s*\|\s*"), lambda v: F.trim(v)),
                         lambda v: v != "")
        return F.when(F.size(parts) > 0, parts)

    columns = [F.col("item_id").cast("string").alias("item_id")]
    for family, column in MASTER_ARRAY_COLUMNS.items():
        columns.append(values(family).alias(column))
    for family, column in (single_columns or MASTER_SINGLE_COLUMNS).items():
        columns.append(values(family).getItem(0)
                       .cast(MASTER_TYPE_OVERRIDES.get(family, "string")).alias(column))
    return out.select(*columns)


def tag_single_columns(sites: Dict) -> Dict[str, str]:
    """MASTER_SINGLE_COLUMNS with price tier and quality grade as one column per site."""
    columns = {family: column for family, column in MASTER_SINGLE_COLUMNS.items()
               if family not in deterministic.SITE_FAMILIES}
    columns.update({family + sfx: family + sfx
                    for sfx in sites for family in deterministic.SITE_FAMILIES})
    return columns


def publish_detail(detail: DataFrame, detail_table: str) -> None:
    """Replace the detail table with this run's rows (it is derived from the cache, so a full
    rewrite is always consistent with the master columns)."""
    _log_section("PUBLISHING TAG DETAIL", width=80)
    (detail.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .saveAsTable(detail_table))
    logger.info("wrote %s", detail_table)


def publish_to_master(spark: SparkSession, out: DataFrame, master_table: str) -> None:
    """Merge the tags into the master table, touching only rows whose tags changed."""
    _log_section("PUBLISHING TO MASTER TABLE", width=80)
    updates = _master_updates(out)

    columns = [(f.name, f.dataType.simpleString()) for f in updates.schema.fields
               if f.name != "item_id"] + [("tags_updated_at", "timestamp")]
    existing = {f.name for f in spark.table(master_table).schema.fields}
    for name, ddl in columns:
        if name not in existing:
            logger.info("adding column %s to %s", name, master_table)
            spark.sql("ALTER TABLE {} ADD COLUMNS ({} {})".format(master_table, name, ddl))

    targets = [name for name, _ in columns if name != "tags_updated_at"]
    changed = " OR ".join("NOT (t.{0} <=> s.{0})".format(c) for c in targets)
    assignments = ", ".join(["t.{0} = s.{0}".format(c) for c in targets]
                            + ["t.tags_updated_at = current_timestamp()"])
    updates.createOrReplaceTempView("tagging_master_updates")
    spark.sql(
        "MERGE INTO {table} t USING tagging_master_updates s ON t.item_id = s.item_id "
        "WHEN MATCHED AND ({changed}) THEN UPDATE SET {assignments}".format(
            table=master_table, changed=changed, assignments=assignments)
    )
    logger.info("published %s to %s", ", ".join(targets), master_table)


def publish_tags_table(spark: SparkSession, out: DataFrame, tags_table: str,
                       single_columns: Dict[str, str], max_drop: float = 0.5) -> None:
    """Make the tags table hold this run's products, one row each: new products are added,
    products whose tags changed are updated, and products no longer in the run are removed.

    tags_updated_at moves only when a product's tags change. A run that has lost more than
    max_drop of the table's products is refused: that points at a broken input, not at products
    leaving.
    """
    _log_section("PUBLISHING TAGS TABLE", width=80)
    updates = _master_updates(out, single_columns)
    targets = [f.name for f in updates.schema.fields if f.name != "item_id"]

    if not spark.catalog.tableExists(tags_table):
        schema = StructType([StructField(f.name, f.dataType) for f in updates.schema.fields]
                            + [StructField("tags_updated_at", TimestampType())])
        spark.createDataFrame([], schema).write.format("delta").saveAsTable(tags_table)
        logger.info("created %s", tags_table)
    existing = {f.name for f in spark.table(tags_table).schema.fields}
    for field in updates.schema.fields:
        if field.name not in existing:
            logger.info("adding column %s to %s", field.name, tags_table)
            spark.sql("ALTER TABLE {} ADD COLUMNS ({} {})".format(
                tags_table, field.name, field.dataType.simpleString()))

    products, before = updates.count(), spark.table(tags_table).count()
    if before and products < before * (1 - max_drop):
        raise RuntimeError("{:,} products to publish against {:,} in {}: refusing to remove that "
                           "many, check the input".format(products, before, tags_table))

    changed = " OR ".join("NOT (t.{0} <=> s.{0})".format(c) for c in targets)
    assignments = ", ".join(["t.{0} = s.{0}".format(c) for c in targets]
                            + ["t.tags_updated_at = current_timestamp()"])
    columns = ", ".join(["item_id"] + targets + ["tags_updated_at"])
    values = ", ".join(["s.{}".format(c) for c in ["item_id"] + targets]
                       + ["current_timestamp()"])
    updates.createOrReplaceTempView("tagging_tags_updates")
    merged = spark.sql(
        "MERGE INTO {table} t USING tagging_tags_updates s ON t.item_id = s.item_id "
        "WHEN MATCHED AND ({changed}) THEN UPDATE SET {assignments} "
        "WHEN NOT MATCHED THEN INSERT ({columns}) VALUES ({values}) "
        "WHEN NOT MATCHED BY SOURCE THEN DELETE".format(
            table=tags_table, changed=changed, assignments=assignments,
            columns=columns, values=values)
    ).first()
    logger.info("%s: %s products | %s added, %s updated, %s removed", tags_table,
                format(products, ","), format(merged["num_inserted_rows"], ","),
                format(merged["num_updated_rows"], ","), format(merged["num_deleted_rows"], ","))


def _output_report(out: DataFrame, det: DataFrame, run_id: str, families: List[str]) -> None:
    total, base = out.count(), det.count()
    logger.info("%s products x %s columns (run_id %s)",
                format(total, ","), len(out.columns), run_id)
    if total != base:
        logger.error("%+d against the %s computed rows - the join is fanning out. "
                     "Investigate before shipping.", total - base, format(base, ","))
    else:
        logger.info("  matches the computed row count exactly - no duplication")

    logger.info("coverage (over products that reached the model for that family)")
    for family in families:
        if family not in out.columns:
            continue
        tagged = out.filter(F.col(family).isNotNull()
                            & (F.trim(F.col(family)) != "")).count()
        state_col = "{}_state".format(family)
        scored = (out.filter(F.col(state_col).isNotNull()).count()
                  if state_col in out.columns else total)
        logger.info("  %-28s %9s tagged of %9s scored  %6.2f%%", family, format(tagged, ","),
                    format(scored, ","), 100.0 * tagged / max(scored, 1))

    for family in taxonomy.ALWAYS_APPLICABLE:
        col = "{}_shortlist_gap".format(family)
        if col in out.columns:
            gaps = out.filter(F.col(col)).count()
            if gaps:
                logger.info("  %s products flagged `none_fit_but_something_does` for %s - "
                            "their class shortlist is probably wrong",
                            format(gaps, ","), family)


def _assert_taxonomy(out: DataFrame, enums: Dict[str, List[str]]) -> None:
    """Every emitted value must be in its approved list. This has never failed; it stays
    because the day it does is the day something silently started inventing labels."""
    offenders = 0
    for family in taxonomy.MODEL_FAMILIES:
        if family not in out.columns:
            continue
        allowed = set(enums[family])
        values = (out.filter(F.col(family).isNotNull())
                  .select(F.explode(F.split(F.col(family), r"\s*\|\s*")).alias("v"))
                  .distinct().collect())
        off = [r["v"] for r in values if r["v"] and r["v"] not in allowed]
        if off:
            offenders += len(off)
            logger.error("%s: %d value(s) outside the approved list: %s",
                         family, len(off), off[:5])
    logger.info("taxonomy gate: %s", "PASS" if not offenders else "FAIL")
    if offenders:
        raise RuntimeError("taxonomy gate failed - {} off-list value(s)".format(offenders))


# ---------------------------------------------------------------------------
# Pipeline entrypoint
# ---------------------------------------------------------------------------

def compute_tags(spark: SparkSession, source_table: str, profile_table: str, cache_table: str,
                 llm_cfg: Dict, sites: Optional[Dict] = None) -> Tuple[DataFrame, DataFrame]:
    """Profile classes, classify products, gate the answers and add the computed families.

    Returns (one row per product, the gated answers that build_detail needs).
    """
    profile_classes(spark, source_table, profile_table, llm_cfg)
    classify_products(spark, source_table, profile_table, cache_table, llm_cfg)
    gated = gate_cache(spark, source_table, cache_table)
    return assemble_values(spark, source_table, cache_table, gated=gated, sites=sites), gated


def run_tagging_pipeline(spark: SparkSession, source_table: str, profile_table: str,
                         cache_table: str, llm_cfg: Dict,
                         detail_table: str = DETAIL_TABLE) -> DataFrame:
    """Profile classes, classify products, then gate and write. Safe to re-run.

    detail_table is a parameter like the others, so a run on test tables cannot overwrite the
    real detail table.
    """
    _log_section("PRODUCT TAGGING PIPELINE", width=80)
    result, gated = compute_tags(spark, source_table, profile_table, cache_table, llm_cfg)
    publish_to_master(spark, result, source_table)
    publish_detail(build_detail(result, gated), detail_table)
    _log_section("PIPELINE COMPLETE", width=80)
    return result


if __name__ == "__main__":
    spark = get_spark_session()

    logger.info("Running Product Tagging Pipeline with the following configuration:")
    logger.info("Master Table:  %s (tags are written here)", SOURCE_TABLE)
    logger.info("Profile Table: %s", PROFILE_TABLE)
    logger.info("Cache Table:   %s", CACHE_TABLE)
    logger.info("Detail Table:  %s", DETAIL_TABLE)

    run_tagging_pipeline(spark, SOURCE_TABLE, PROFILE_TABLE, CACHE_TABLE, LLM_CONFIG)
