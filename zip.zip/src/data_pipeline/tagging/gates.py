from __future__ import annotations

import re
from typing import Dict, List, Optional, Sequence, Tuple

import taxonomy

SPECIFIC_HOLIDAY_LABELS = [
    "Christmas", "Easter", "Halloween", "New Year", "Thanksgiving",
    "Valentine's Day", "Mother's Day", "Father's Day",
]
SUPERSEDED_BY: Dict[str, Dict[str, List[str]]] = {
    "seasonality": {"Specific Holidays": SPECIFIC_HOLIDAY_LABELS},
    "weather_condition": {"Specific Holidays": SPECIFIC_HOLIDAY_LABELS},
}


def norm_label(value) -> str:
    """Canonical form for comparing labels across sources.

    Case, whitespace, punctuation, ``&``/``and``, ``/`` and ``-`` all normalised, so
    ``Men's & Women's`` and ``mens and womens`` compare equal.
    """
    text = str(value or "").strip().lower()
    text = text.replace("&", " and ").replace("/", " ").replace("-", " ")
    text = re.sub(r"[^a-z0-9 ]", "", text)
    return re.sub(r"\s+", " ", text).strip()


# The field names the product prompt puts before each part of the text ("Category: ...").
_PROMPT_FIELD_RE = re.compile(r"^(product|title|category|description)\s*:\s*")


def _squash(text) -> str:
    """Lowercase, with every run of whitespace (line breaks included) as one space."""
    return re.sub(r"\s+", " ", str(text or "")).strip().lower()


def is_grounded(evidence, blob) -> bool:
    """True when the quote is really in the product text.

    The quote is compared word for word, ignoring case and whitespace. A quote the model
    shortened with "..." passes when every piece is in the text, and the prompt's own field name
    ("Category:") is not part of the product text.
    """
    text = _squash(blob)
    pieces = [_PROMPT_FIELD_RE.sub("", p.strip())
              for p in re.split(r"\.\.\.|…", _squash(evidence))]
    pieces = [p.strip() for p in pieces if p.strip()]
    return bool(pieces) and all(p in text for p in pieces)


def prefer_specific(family: str, labels: Sequence[str]) -> Tuple[List[str], List[str]]:
    """Drop a generic bucket when a label it covers is also present.
    """
    rules = SUPERSEDED_BY.get(family)
    if not rules or not labels:
        return list(labels or []), []
    kept, dropped = [], []
    for label in labels:
        covered = rules.get(label)
        if covered and any(c in labels for c in covered):
            dropped.append(label)
        else:
            kept.append(label)
    return kept, dropped


def events_parent_of(sub: str) -> Tuple[Optional[str], Optional[str]]:
    """Parent category for an events label. Returns ``(parent, note)``.
    """
    parents, _subs, sub_to_parent, ambiguous = taxonomy.events()
    if sub in ambiguous:
        return None, "sub {!r} exists under {} - parent undecidable".format(
            sub, ambiguous[sub])
    if sub in sub_to_parent:
        return sub_to_parent[sub], None
    if sub in parents:
        return sub, None
    return None, None


def apply_gates(
    family: str,
    labels: Sequence[str],
    confidences: Sequence[Optional[float]],
    evidence: Optional[str],
    blob: Optional[str],
    allowed: Sequence[str],
    threshold: Optional[float],
    cap: Optional[int],
) -> Dict[str, object]:
    """Run the full chain over one product's answer for one family.
    """
    labels = list(labels or [])
    confidences = list(confidences or [])
    confidences += [None] * max(0, len(labels) - len(confidences))
    allowed_set = set(allowed or [])
    dropped: List[str] = []
    note: Optional[str] = None

    def result(state, labs=None, confs=None, parents=None):
        return {
            "labels": labs or None,
            "confidences": confs or None,
            "parents": parents,
            "dropped": dropped or None,
            "state": state,
        }

    # 1. taxonomy - a label outside this product's allowed set never becomes a value
    kept, kept_conf = [], []
    for label, conf in zip(labels, confidences):
        if label in allowed_set:
            kept.append(label)
            kept_conf.append(conf)
        else:
            dropped.append("{}:not_in_enum".format(label))
    labels, confidences = kept, kept_conf

    # 2. grounding - proves the model READ the text, not that it reasoned correctly. A product
    #    that legitimately mentions a concept will ground a wrong tag perfectly, which is why
    #    the prompt's scope statement carries that distinction instead.
    if labels:
        if not evidence:
            dropped.extend("{}:no_evidence".format(l) for l in labels)
            return result("no_evidence")
        if not is_grounded(evidence, blob):
            dropped.extend("{}:not_grounded".format(l) for l in labels)
            return result("evidence_not_grounded")

    # 3. prefer the specific label over the generic bucket it covers
    kept, superseded = prefer_specific(family, labels)
    if superseded:
        pairs = [(l, c) for l, c in zip(labels, confidences) if l in kept]
        labels = [p[0] for p in pairs]
        confidences = [p[1] for p in pairs]
        dropped.extend("{}:superseded".format(l) for l in superseded)

    # 4. confidence threshold, PER LABEL, from the family's own config.
    #    A label the model returned without a score is kept: we do not impute a number to test
    #    it against, and discarding it would penalise the product for the model's omission.
    if threshold is not None:
        pairs = []
        for label, conf in zip(labels, confidences):
            if conf is not None and conf < threshold:
                dropped.append("{}:below_{}".format(label, threshold))
            else:
                pairs.append((label, conf))
        labels = [p[0] for p in pairs]
        confidences = [p[1] for p in pairs]

    # 5. cardinality - a single-value family takes one label or none. More than one is
    #    ambiguity, not a second tag, and the model's answer is preserved upstream for review.
    if family in taxonomy.SINGLE_VALUE and len(labels) > 1:
        dropped.extend("{}:ambiguous".format(l) for l in labels)
        return result("ambiguous")

    # 6. cap, keeping the highest confidence
    if cap and len(labels) > cap:
        order = sorted(
            range(len(labels)),
            key=lambda i: confidences[i] if confidences[i] is not None else -1.0,
            reverse=True,
        )
        cut = set(order[cap:])
        dropped.extend("{}:over_cap".format(labels[i]) for i in sorted(cut))
        labels = [l for i, l in enumerate(labels) if i not in cut]
        confidences = [c for i, c in enumerate(confidences) if i not in cut]

    parents = None
    if family == "events" and labels:
        parents = []
        for label in labels:
            parent, why = events_parent_of(label)
            parents.append(parent)
            if why and not note:
                note = why

    return result(note or ("accepted" if labels else "empty"), labels, confidences, parents)
