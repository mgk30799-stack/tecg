from __future__ import annotations

import base64
import json
import logging
import os
import random
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from typing import Callable, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)

os.environ.setdefault("MLFLOW_TRACING_ENABLED", "false")
os.environ.setdefault("MLFLOW_ENABLE_ASYNC_TRACE_LOGGING", "false")


def disable_mlflow_tracing() -> None:
    """Belt and braces on top of the env vars - Databricks enables this from several places."""
    try:
        import mlflow

        mlflow.autolog(disable=True, silent=True)
        for flavour in ("langchain", "openai", "anthropic", "gemini"):
            try:
                getattr(mlflow, flavour).autolog(disable=True, silent=True)
            except Exception:
                pass
        try:
            mlflow.tracing.disable()
        except Exception:
            pass
    except Exception as exc:
        logger.warning(
            "could not disable mlflow tracing (%s) - if throughput decays and the log shows "
            "'maximum allowed traces', that is why", type(exc).__name__
        )


REQUIRED_LLM_KEYS = (
    "model", "project", "region", "secret_scope", "secret_key", "temperature",
    "workers", "chunk", "timeout_s", "retries", "max_output_tokens",
)

TRANSIENT = (
    "ratelimit", "rate limit", "429", "resourceexhausted", "quota", "deadline", "timeout",
    "unavailable", "503", "internal", "500", "connection", "reset", "temporarily",
)


def is_transient(exc: BaseException) -> bool:
    text = "{} {}".format(type(exc).__name__, exc).lower()
    return any(t in text for t in TRANSIENT)


GCP_SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]
DEDICATED_KEYS = ("endpoint_id", "dns", "project_number", "region", "model")

# The dedicated endpoint scales to zero when idle, and refuses calls with one of these messages
# while it starts again - 5.4 minutes when measured on 2026-10-16.
COLD_START = ("not yet ready", "scale-up from zero", "scaling from zero",
              "not ready for inference")


class _Reply:
    """The one attribute ask_json reads from a LangChain reply."""

    def __init__(self, content: str):
        self.content = content


class DedicatedGemma:
    """Gemma on the dedicated Vertex endpoint (`tagging.llm.dedicated`), via its OpenAI-style
    chat route.

    Only some compute can reach `*.prediction.vertexai.goog`: serverless can, while the classic
    job clusters fail the TLS handshake. wait_until_ready tells those cases apart, so a run that
    cannot reach the endpoint falls back to MaaS after one probe instead of failing every call.
    """

    def __init__(self, cfg: Dict, credentials, max_tokens: int, temperature: float,
                 timeout_s: int):
        self.url = ("https://{dns}/v1beta1/projects/{project}/locations/{region}/endpoints/"
                    "{endpoint}/chat/completions").format(
            dns=cfg["dns"], project=cfg["project_number"], region=cfg["region"],
            endpoint=cfg["endpoint_id"])
        self._model = cfg["model"]
        self._credentials = credentials
        self._max_tokens, self._temperature, self._timeout_s = max_tokens, temperature, timeout_s
        self._lock = threading.Lock()
        self._local = threading.local()

    def _bearer(self) -> str:
        from google.auth.transport.requests import Request

        with self._lock:
            if not self._credentials.valid:  # also False a few minutes before the hour expires
                self._credentials.refresh(Request())
            return self._credentials.token

    def invoke(self, prompt: str) -> _Reply:
        import requests

        session = getattr(self._local, "session", None)
        if session is None:
            session = self._local.session = requests.Session()
        response = session.post(
            self.url, timeout=self._timeout_s,
            headers={"Authorization": "Bearer " + self._bearer()},
            json={"model": self._model, "temperature": self._temperature,
                  "max_tokens": self._max_tokens,
                  "messages": [{"role": "user", "content": prompt}]},
        )
        if response.status_code != 200:
            raise RuntimeError("dedicated endpoint HTTP {}: {}".format(
                response.status_code, response.text[:200]))
        message = response.json()["choices"][0].get("message") or {}
        return _Reply(message.get("content") or "")

    def wait_until_ready(self, timeout_s: int) -> bool:
        """True once the endpoint answers. False when this compute cannot reach it, when it keeps
        failing for some other reason, or when it is still waking up after timeout_s."""
        import requests

        started, other_failures = time.time(), 0
        while True:
            waited = time.time() - started
            try:
                self.invoke("Reply with the word OK.")
                logger.info("dedicated endpoint ready (waited %.0fs)", waited)
                return True
            except requests.exceptions.RequestException as exc:
                logger.warning("dedicated endpoint not reachable from this compute (%s)",
                               type(exc).__name__)
                return False
            except Exception as exc:
                if any(m in str(exc).lower() for m in COLD_START):
                    if waited > timeout_s:
                        logger.warning("dedicated endpoint still waking up after %.0fs", waited)
                        return False
                    logger.info("dedicated endpoint waking up (%.0fs so far)", waited)
                    time.sleep(30)
                    continue
                other_failures += 1
                if other_failures >= 3:
                    logger.warning("dedicated endpoint keeps failing: %s", str(exc)[:200])
                    return False
                time.sleep(10)


class FallbackClient:
    """The dedicated endpoint first; the MaaS client answers any call it fails.

    `served` counts who answered, so a run that quietly fell back to MaaS shows it in the log.
    """

    def __init__(self, primary: DedicatedGemma, backup):
        self._primary, self._backup = primary, backup
        self._lock = threading.Lock()
        self.served = {"dedicated": 0, "maas": 0}

    def invoke(self, prompt: str):
        try:
            reply, source = self._primary.invoke(prompt), "dedicated"
        except Exception:
            reply, source = self._backup.invoke(prompt), "maas"
        with self._lock:
            self.served[source] += 1
        return reply


def build_client(cfg: Dict):
    """Construct the Gemma client from the `tagging.llm` block of config/general.yml.

    With `dedicated.enabled`, calls go to the dedicated endpoint, and the MaaS client below only
    answers the calls it fails. If the dedicated endpoint cannot be reached from this compute, or
    does not wake up in time, the whole run uses MaaS as before.
    """
    from databricks.sdk import WorkspaceClient
    from google.oauth2 import service_account
    from langchain_google_genai import ChatGoogleGenerativeAI

    settings = dict(cfg or {})
    missing = [k for k in REQUIRED_LLM_KEYS if k not in settings]
    if missing:
        raise KeyError("config/general.yml is missing tagging.llm: {}".format(
            ", ".join(missing)))
    dedicated_cfg = settings.get("dedicated") or {}
    if dedicated_cfg.get("enabled"):
        missing = [k for k in DEDICATED_KEYS if not dedicated_cfg.get(k)]
        if missing:
            raise KeyError("config/general.yml is missing tagging.llm.dedicated: {}".format(
                ", ".join(missing)))
    disable_mlflow_tracing()

    secret = WorkspaceClient().secrets.get_secret(
        scope=settings["secret_scope"], key=settings["secret_key"]
    )
    info = json.loads(base64.b64decode(secret.value).decode("utf-8"))
    credentials = service_account.Credentials.from_service_account_info(info, scopes=GCP_SCOPES)

    client = ChatGoogleGenerativeAI(
        model=settings["model"],
        vertexai=True,
        project=settings["project"],
        location=settings["region"],
        credentials=credentials,
        temperature=settings["temperature"],
        max_output_tokens=settings["max_output_tokens"],
        timeout=settings["timeout_s"],
    )

    stray = set(getattr(client, "model_kwargs", {}) or {}) & {
        "vertexai", "project", "location", "max_output_tokens", "timeout"
    }
    if stray:
        raise RuntimeError(
            "langchain_google_genai moved {} into model_kwargs, which means an older version is "
            "loaded and the client is pointed at the wrong backend. Pin google-genai==2.12.1 "
            "and langchain_google_genai in the job's libraries.".format(sorted(stray))
        )
    if not dedicated_cfg.get("enabled"):
        return client, settings

    # Its own credentials object, so its token refresh never races the MaaS client's.
    dedicated = DedicatedGemma(
        dedicated_cfg,
        service_account.Credentials.from_service_account_info(info, scopes=GCP_SCOPES),
        max_tokens=int(settings["max_output_tokens"]),
        temperature=float(settings["temperature"]),
        timeout_s=int(settings["timeout_s"]),
    )
    if not dedicated.wait_until_ready(int(dedicated_cfg.get("wake_timeout_s", 900))):
        logger.warning("this run uses the MaaS endpoint only")
        return client, settings
    logger.info("calls go to the dedicated endpoint; MaaS answers any call it fails")
    return FallbackClient(dedicated, client), settings


def extract_json(text: Optional[str]) -> Optional[dict]:
    """Pull the outermost JSON object out of a text reply.
    """
    if not text:
        return None
    body = str(text).strip()

    if "```" in body:
        for part in body.split("```"):
            part = part.strip()
            if part.startswith("json"):
                part = part[4:].strip()
            if part.startswith("{") or part.startswith("["):
                body = part
                break

    lead = body.lstrip()
    if lead.startswith("["):
        try:
            arr = json.loads(lead)
        except json.JSONDecodeError:
            return None
        if isinstance(arr, list) and len(arr) == 1 and isinstance(arr[0], dict):
            return arr[0]
        return None

    start = body.find("{")
    if start < 0:
        return None
    depth, in_string, escaped = 0, False, False
    for i in range(start, len(body)):
        ch = body[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(body[start:i + 1])
                except json.JSONDecodeError:
                    return None
    return None


def ask_json(client, prompt: str, retries: int = 3):
    """One prompt -> ``(parsed dict, None)`` or ``(None, reason)``. Never raises.
    """
    last: Optional[BaseException] = None
    for attempt in range(retries + 1):
        try:
            response = client.invoke(prompt)
        except Exception as exc:
            last = exc
            if attempt < retries and is_transient(exc):
                time.sleep(min(2 ** attempt, 16) * (1.0 + random.random()))
                continue
            return None, "llm_error: {}: {}".format(type(exc).__name__, str(exc)[:160])

        content = response.content
        text = content if isinstance(content, str) else str(content)
        data = extract_json(text)
        if isinstance(data, dict):
            return data, None

        last = RuntimeError("unparseable reply ({} chars)".format(len(text)))
        if attempt < retries:
            time.sleep(min(2 ** attempt, 16) * (1.0 + random.random()))
    return None, "no_json: {}".format(str(last)[:160])


def run_pool(
    items: Sequence,
    fn: Callable,
    workers: int,
    chunk: int,
    timeout_s: int,
    retries: int,
    label: str = "items",
    on_chunk: Optional[Callable[[List], None]] = None,
) -> List:
    """Run ``fn`` over ``items`` with a bounded pool, reporting as results land.

    submit/as-completed rather than ``map``: ``map`` blocks until the whole batch finishes, so a
    long batch printed nothing and a hung request stalled it silently.

    ``on_chunk`` is how a caller persists as it goes, and results are dropped from memory once
    handed over. It exists because of an expensive mistake: the first full classification run
    accumulated 365,000 results in driver memory with nothing written, because the write sat
    after the entire pool completed. A kill at that point would have cost 27 hours.
    """
    collected: List = []
    started = time.time()

    for offset in range(0, len(items), chunk):
        batch = list(items[offset:offset + chunk])
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(fn, item): item for item in batch}
            pending = set(futures)
            done_count, last_reported = 0, -1
            chunk_started = time.time()
            budget = timeout_s * (retries + 1) * max(len(batch) / max(workers, 1), 1)

            while pending:
                if time.time() - chunk_started > budget:
                    for future in pending:
                        future.cancel()
                    logger.warning("chunk budget %.0fs exceeded, %d abandoned",
                                   budget, len(pending))
                    break
                done, pending = wait(pending, timeout=30, return_when=FIRST_COMPLETED)
                for future in done:
                    try:
                        collected.append(future.result())
                    except Exception as exc:
                        collected.append(
                            {"ok": False,
                             "reason": "{}: {}".format(type(exc).__name__, exc)}
                        )
                    done_count += 1
                if done_count != last_reported:
                    elapsed = max(time.time() - chunk_started, 1e-9)
                    print("      {:,}/{:,} | {:.0f}s | {:.2f}/s".format(
                        done_count, len(batch), elapsed, done_count / elapsed), flush=True)
                    last_reported = done_count

        print("    {:,}/{:,} {} | {:.0f} min".format(
            min(offset + chunk, len(items)), len(items), label,
            (time.time() - started) / 60))

        if on_chunk is not None:
            on_chunk(collected)
            collected = []

    return collected
