# Compatibility Mention Detection Logic

## Overview
This document outlines the logic used in `enrichment_pipeline_compatibility.py` to detect whether a product description, title, or specification mentions compatibility with another product, brand, or model.

Unlike strict EAV parsing, this pipeline uses Natural Language Processing (NLP) and regular expressions to extract compatibility intent from unstructured and semi-structured fields.

## Input Data
**Source Table:** `product_discovery_data`

Key columns used:
*   `item_id`: Unique product identifier.
*   `brand`: Source of truth for building the dynamic Brand Dictionary.
*   `title`: Product title / display name.
*   `bullets_json`: JSON array of bullet strings from the product page.
*   `spec_json`: JSON array of specifications.
*   `description`: Long-form product description.

## End Goal
To enrich product records with an accurate flag indicating if the product is a compatible accessory or consumable, backed by the raw evidence and the extracted target brand/model for downstream vector searching.

**Output Fields:**
*   `compatibility_mentioned`: String flag (`"yes"` or `"no"`).
*   `evidence`: JSON array containing the detailed mentions. Each entry includes:
    *   `source_field`: Where the text came from (e.g., `bullets_json`, `title`).
    *   `matched_keyword`: The trigger phrase found (e.g., "compatible with").
    *   `detection_method`: How the entity was confirmed (`brand_dictionary`, `ner:<TYPE>`, or `pos_nnp`).
    *   `matched_entity`: The extracted brand or model name.
    *   `search_query`: Cleaned representation of the matched entity for vector search.
    *   `raw_text`: A snippet of the surrounding original text.
    *   `window`: The exact window of text evaluated after the keyword.

## The Process

The extraction logic employs a multi-stage funnel to maximize accuracy and avoid false positives:

### 1. Brand Dictionary Building
At runtime, the pipeline builds a target brand dictionary dynamically from the catalog's real `brand` column. 
- It excludes generic terms like "fit", "pro", "all", "none", or "generic".
- It enforces a minimum length threshold to ensure high-quality brand names are used for exact keyword matching.

### 2. Stage 1: Trigger Keyword Matching (Regex)
The pipeline scans the textual input fields (`title`, `description`, `bullets_json`, `spec_json`) for predefined regex trigger phrases.
Currently active trigger phrases:
*   `compatible with`
*   `works with`
*   `use with`
*   `made for`

**Window Extraction:** If a trigger phrase is found, the system captures the next 12 consecutive words. It clips this window at the first sentence boundary (`.` `,` `;` `?` `!`) to ensure the entity belongs to the same clause.

### 3. Stage 2: Entity Confirmation Pipeline
Once a trigger phrase establishes *intent*, the pipeline seeks to confirm the *target* (the brand or model) using one of three fallback checks:

#### A. Brand Dictionary (Highest Precision)
*   **Action:** The system checks if any brand from the dynamic catalog dictionary exists inside the text window.
*   **Result:** If a match is found, extraction is confirmed with method `brand_dictionary`.

#### B. spaCy Named Entity Recognition (NER)
*   **Action:** If no dictionary brand is found and the keyword allows "NER fallback" (e.g., "compatible with"), the system passes the window to the spaCy `en_core_web_sm` NLP model.
*   **Result:** If the NLP model identifies an entity of type `ORG` (organization), `PRODUCT`, `GPE` (GeoPolitical Entity), or `FAC` (Facility), extraction is confirmed with method `ner:<LABEL>`. This helps catch new models or unseen competitor brands.

#### C. Part-of-Speech Proper Noun (POS-NNP) Fallback
*   **Action:** If NER fails, the system runs a grammatical structure check. It determines if the tokens immediately following the keyword are formatted as Proper Nouns (NNP or NNPS in spaCy).
*   **Result:** Extracts the consecutive string of capitalized Proper Nouns (e.g., "Samsung DC97"). If it finds them, it confirms the extraction with method `pos_nnp`.

### 4. Search Query Generation
For confirmed entities, the pipeline generates a cleaned `search_query` targeting vector similarity searches down the line. It strips articles ("the", "an", "all"), prepositional logic ("for", "with", "or"), and trailing punctuation from the window.

### 5. Aggregation
All unique instances of compatibility evidence across the different analyzed fields are deduplicated and bundled into a final JSON string under the `evidence` column for the `item_id`.

## Sample Output Rows (JSON Evidence)
```json
{
  "compatibility_mentioned": "yes",
  "evidence": [
    {
      "source_field": "bullets_json",
      "matched_keyword": "compatible with",
      "detection_method": "brand_dictionary",
      "matched_entity": "HP",
      "search_query": "HP LaserJet Pro M501",
      "raw_text": "...toner cartridge is compatible with HP LaserJet Pro M501 series...",
      "window": "compatible with HP LaserJet Pro M501"
    },
    {
      "source_field": "title",
      "matched_keyword": "works with",
      "detection_method": "ner:ORG",
      "matched_entity": "Keurig",
      "search_query": "Keurig brewers",
      "raw_text": "Reusable Coffee Pods works with Keurig brewers...",
      "window": "works with Keurig brewers"
    }
  ]
}
```