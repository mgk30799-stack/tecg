# `enrichment_pipeline_univ.py` — Column Reference

**Output table:** `mld01_ml_de.product.product_univ_attributes`  
**Source file:** `src/data_pipeline/enrichment/enrichment_pipeline_univ.py`  
**Source table:** `mld01_ml_de.product.product_discovery_data`

---

## Output Columns

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| `item_id` | `string` | No | Primary key. Unique product identifier inherited from source table. |
| `target_category` | `string` | Yes | Product category label (e.g. `Chairs`, `Printers`, `Breakroom`). Passed through from source. |
| `material` | `array<string>` | Yes | List of normalised material values extracted from relevant spec attributes (e.g. `["mesh", "aluminum"]`). Lowercased. Drawn from ~30 material-specific attribute names across all categories. |
| `pattern` | `array<string>` | Yes | List of bucketed pattern values for style-relevant categories (`Chairs`, `Luggage`, `Breakroom`). Values are normalised into buckets: `solid`, `textured`, `striped`, `checkered`, `multi-patterned`, `print`. |
| `color` | `array<string>` | Yes | List of normalised, atomic color values. Compound values like `"Red/White"` or `"Red and White"` are split into individual tokens (e.g. `["red", "white"]`). Lowercased. |
| `collection_name` | `string` | Yes | Product series or collection name. Sourced from `series_or_collection` attribute with fallback to `collection`. Applies to all categories. |
| `warranty_json` | `map<string, string>` | Yes | Warranty raw text keyed by the originating spec attribute name. Since `warranty_information` (non-printers) and `printer_warranty` (printers) are mutually exclusive, the map carries exactly one entry. Example: `{"warranty_information": "1 Year Limited Warranty"}` or `{"printer_warranty": "90 Day Limited"}`. Duplicate attribute rows are deduplicated before map construction (first non-null value wins). |
| `warranty_type` | `string` | Yes | Classified warranty type derived from the raw warranty text. Possible values: `limited_lifetime`, `lifetime`, `limited`, `extended`, `onsite`, `unspecified`. Evaluated in priority order (most specific first). |
| `support_warranty_duration_months` | `integer` | Yes | Warranty duration normalised to months. Years and days are converted (`years × 12`, `days ÷ 30` rounded). Lifetime warranties are represented as `9999` (sentinel value). `null` if duration cannot be parsed from text. |
| `compliance_tags_json` | `array<struct<name:string, source:string, confidence:int>>` | Yes | List of detected compliance certifications and standards. Each entry contains: `name` (normalised tag, e.g. `"Energy Star"`, `"GREENGUARD Gold"`, `"RoHS"`), `source` (`"spec_json"` or `"bullets_json"`), and `confidence` (always `1`). Detected via both indicator attributes (e.g. `eco_energy_star_certified_ind = Y`) and free-text scanning across spec values and bullet points. |

---

## Computed-but-not-output Columns

These columns are computed internally during the pipeline run but are **not included** in the final output table (excluded from `final_cols`):

| Column | Description |
|--------|-------------|
| `true_color` | Single canonical color string from the `true_color` spec attribute. Excluded from output — `color` array supersedes it. |
| `style_facets_json` | Detailed facet JSON (pattern, material, color entries with evidence) for style categories only (`Chairs`, `Luggage`, `Breakroom`). Currently excluded from final output. |
| `room_context_json` | Placeholder column (`null`). Reserved for future room context extraction (currently sourced by a separate pipeline). |

---

## Source Attribute Mapping

### Material (`material`)
Drawn from ~30 spec attribute names including `material`, `seat_material`, `luggage_material`, `backpack_material`, `pot_or_pan_base_material`, `filament_material`, etc.

### Pattern (`pattern`)
Drawn from category-specific pattern attributes: `pattern`, `luggage_pattern`, `backpack_pattern`, `design_and_pattern`, `floor_mat_pattern`, etc.

### Color (`color`)
Drawn from: `color`, `true_color`, `furnishing_color`, `base_color`, `toaster_color`, `dinnerware_color`, `appliance_color`, and a few other appliance-specific color attrs.

### Warranty (`warranty_json`, `warranty_type`, `support_warranty_duration_months`)
Drawn from: `warranty_information` (all non-printer categories), `printer_warranty` (Printers only). Mutually exclusive per product.

### Compliance (`compliance_tags_json`)
Tags detected across all spec attribute values and `bullets_json`. Indicator boolean attributes (e.g. `eco_energy_star_certified_ind`, `greenguard_certified_ind`, `bpa_free_ind`) are checked directly. Additional tags scanned via regex across free text.

**Supported tags (normalised names):**
`Energy Star`, `GREENGUARD`, `GREENGUARD Gold`, `BIFMA`, `ANSI/BIFMA`, `EPA Safer Choice`, `Green Seal`, `DfE`, `NSF`, `BPA-Free`, `EPEAT`, `EPEAT Gold`, `EPEAT Silver`, `EPEAT Bronze`, `Blue Angel`, `SCS Indoor Advantage`, `SCS Indoor Advantage Gold`, `RoHS`, `REACH`, `TB 117`, `CAL 133`, `FCC`, `CE`, `UL`, `ISO <N>`

---

## Warranty Type Classification Logic

| Detected condition | `warranty_type` value |
|---|---|
| Text contains both "lifetime" AND "limited" | `limited_lifetime` |
| Text contains "lifetime" only | `lifetime` |
| Text contains "limited" only | `limited` |
| Text contains "extended" | `extended` |
| Text contains "on-site" or "onsite" | `onsite` |
| Numeric duration found but no qualifier | `limited` (assumed) |
| None of the above | `unspecified` |

---

## Duration Normalisation Logic

| Unit in text | Conversion |
|---|---|
| `year` / `years` | value × 12 |
| `month` / `months` | value (as-is) |
| `day` / `days` | round(value ÷ 30) |
| `lifetime` | `9999` (sentinel) |
| Not parseable | `null` |
