# EAV Parsing Logic for Claims Extraction

## Overview
This document outlines the logic for extracting performance claims and key features from product descriptions. The primary goal is to identify quantifiable, verifiable statements made about a product's performance, quality, or features and structure them for AI consumption.

This process is designed to be a lightweight, regex-based extraction focusing on high-signal text, primarily from product bullet points.

## Data Sources
The claims extraction pipeline primarily targets unstructured text fields from the `product_discovery` table, including:
*   `bullet_txt`: The main source for concise, feature-rich statements.
*   `PRODUCT_WEB_DSCR`: The long description, as a secondary source.

## Extraction Logic

### 1. Regex-Based Claim Detection
The core of the extraction relies on a set of predefined regular expression patterns to identify common claim formats. This approach is fast and provides high-confidence extractions for specific types of claims.

**Claim Patterns (`CLAIM_PATTERNS`):**
```python
CLAIM_PATTERNS = {
    "performance_multiplier": {
        "pattern": r'(\d+(?:\.\d+)?)\s*x\s+(more|faster|better|stronger|longer)',
        "claim_type": "performance",
        "example": "3x faster than competitors"
    },
    "percentage_improvement": {
        "pattern": r'(\d+(?:\.\d+)?)\s*%\s+(more|less|faster|effective|reduction)',
        "claim_type": "performance",
        "example": "50% more effective"
    },
    "duration": {
        "pattern": r'(?:lasts?|lasting)\s+(\d+)\s*(day|days|hour|hours|week|weeks|month|months|year|years)',
        "claim_type": "durability",
        "example": "Lasts 30 days"
    },
    "coverage": {
        "pattern": r'(?:covers?|covering)\s+(\d+)\s*(sq\s*ft|square\s*feet|pages?|uses?)',
        "claim_type": "capacity",
        "example": "Covers 800 sq ft"
    },
    "time_savings": {
        "pattern": r'save(?:s)?\s+(?:up\s+to\s+)?(\d+)\s*(minute|minutes|hour|hours)',
        "claim_type": "efficiency",
        "example": "Saves up to 30 minutes"
    },
    "warranty": {
        "pattern": r'(\d+)\s*-?\s*(year|month)\s+(warranty|guarantee)',
        "claim_type": "warranty",
        "example": "5-year warranty"
    },
    "certification": {
        "pattern": r'(EPA|BIFMA|GREENGUARD|Energy\s*Star|UL|CE|FCC)\s*(?:certified|approved|compliant)',
        "claim_type": "certification",
        "example": "EPA certified"
    },
    "safety_free_from": {
        "pattern": r'(BPA|toxic|paraben|phthalate|latex|lead|mercury|acid)\s*[-]?\s*free',
        "claim_type": "safety",
        "example": "BPA free"
    },
    "ease_of_use": {
        "pattern": r'easy\s+to\s+(use|install|clean|assemble|operate|maintain|setup)',
        "claim_type": "usability",
        "example": "Easy to install"
    },
    "eco_friendly": {
        "pattern": r'(recyclable|biodegradable|compostable|sustainable|eco-friendly|recycled|post-consumer)',
        "claim_type": "sustainability",
        "example": "100% recyclable"
    },
    "resistance": {
        "pattern": r'(water|stain|scratch|fade|rust|corrosion|weather|heat|tear|puncture)\s*[-]?\s*(resistant|proof|repellent)',
        "claim_type": "durability",
        "example": "Water resistant"
    },
    "origin": {
        "pattern": r'made\s+in\s+(USA|America|Germany|China|Japan|Italy|France|UK|Canada)',
        "claim_type": "origin",
        "example": "Made in USA"
    }
}
```

### 2. Key Feature Identification
A bullet point or feature is considered "key" if it contains one or more of the extracted claims or matches a predefined list of important keywords (e.g., "ergonomic", "adjustable", "heavy-duty").

## Output Fields

*   `extracted_claims_json`: A JSON array containing all claims found in the product text. Each claim object includes details about the type, value, and source.
*   `key_features_json`: A JSON array listing the bullet points or sentences identified as key features, along with a count of the claims they contain.

## Example Output

### Example 1: `extracted_claims_json`
```json
[
  {
    "claim_type": "certification",
    "confidence": 0.9,
    "pattern": "certification",
    "source_bullet_index": 8,
    "source_text": "ANSI/BIFMA Certified",
    "text": "BIFMA Certified",
    "unit": null,
    "value": "BIFMA"
  }
]
```

### `key_features_json`
```json
[{"bullet_index": 0, "claim_count": 0, "feature": "Vinyl Adjustable Height Barstools"}, {"bullet_index": 8, "claim_count": 1, "feature": "ANSI/BIFMA Certified"}, {"bullet_index": 10, "claim_count": 0, "feature": "Set of 2 Contemporary Adjustable Height Stools with Pedestal Base"}, {"bullet_index": 15, "claim_count": 0, "feature": "Height Adjustable Seat with Gas Lift adjusts from bar to counter height"}]
```

## Extraction Performance Report

### Summary
* **Total Products Processed:** 32,997
* **Products with Bullets (Source):** 32,964 (99.90%)
* **Extraction Success Rate (Claims / Bullets):** 24.51%
* **Products with Extracted Claims:** 8,080 (24.49%)
* **Products with Key Features:** 16,339 (49.52%)
* **Products with Any Enrichment:** 16,339 (49.52%)

---

### Claim Type Distribution
| Claim Type | Count |
| :--- | :--- |
| sustainability | 3,353 |
| durability | 3,127 |
| safety | 1,557 |
| usability | 1,271 |
| performance | 535 |
| certification | 534 |
| warranty | 438 |
| origin | 291 |

---

### Pattern Distribution
| Pattern | Count |
| :--- | :--- |
| eco_friendly | 3,353 |
| resistance | 3,048 |
| safety_free_from | 1,557 |
| ease_of_use | 1,271 |
| certification | 534 |
| warranty | 438 |
| percentage_improvement | 337 |
| origin | 291 |
| performance_multiplier | 198 |
| duration | 79 |

---

### Key Feature Keyword Distribution
| Keyword | Count |
| :--- | :--- |
| designed | 4,314 |
| durable | 3,824 |
| certified | 2,991 |
| adjustable | 2,893 |
| ergonomic | 1,483 |
| premium | 964 |
| professional | 906 |
| reliable | 632 |
| patented | 541 |
| advanced | 510 |
| innovative | 191 |
| award | 48 |