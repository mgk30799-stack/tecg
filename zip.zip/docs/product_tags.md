# Product tags in `product_master_enriched_t`

Tags live in the master table itself. There is no separate tag table. `product_tagging` is the
only writer; the enrichment merge never touches these columns.

## Columns

| Column | Type | Meaning |
|---|---|---|
| `product_tags` | struct | The full answer: one field per family (below). |
| `tags_updated_at` | timestamp | Last time any tag for the product changed. |
| `room_context_tags`, `use_case_tags`, `audience_tags` | array&lt;string&gt; | Flat labels, derived from `product_tags`. Read by the sync notebooks. |
| `gender`, `age_group` | string | Single value, derived from `product_tags`. |
| `age_restriction` | int | 18 or 21, derived from `product_tags`. |

The flat columns are written in the same MERGE as `product_tags`, so they cannot disagree with it.

## `product_tags.<family>`

Families: `quality_grade`, `value_proposition_segment`, `gender`, `age_restriction`, `seasonality`,
`body_parts`, `weather_condition`, `events`, `age_group`, `room_context`, `use_cases`, `audience_tags`.

Every family has the same shape:

| Field | Type | Meaning |
|---|---|---|
| `labels` | array&lt;string&gt; | Approved values, in order. |
| `confidences` | array&lt;double&gt; | `confidences[i]` belongs to `labels[i]`. |
| `evidence` | string | The model's quoted support (model families only). |
| `state` | string | Gate outcome: `accepted`, `empty`, `no_evidence`, `evidence_not_grounded`, `ambiguous`, or a gate note (model families only). |
| `dropped` | array&lt;string&gt; | Labels the gates removed, as `label:reason`; reasons are `not_in_enum`, `no_evidence`, `not_grounded`, `superseded`, `below_<threshold>`, `ambiguous`, `over_cap` (model families only). |
| `parents` | array&lt;string&gt; | Parent labels (used by `events`). |
| `shortlist_gap` | boolean | Model said nothing fit but something might (model families only). |

Computed families (`quality_grade`, `value_proposition_segment`, `gender`, `age_restriction`) fill only
`labels` and `confidences`; the other fields are NULL.

## Reading them

```sql
-- labels with their confidences
SELECT item_id, l AS label, product_tags.use_cases.confidences[i] AS confidence
FROM product_master_enriched_t
LATERAL VIEW posexplode(product_tags.use_cases.labels) t AS i, l;

-- products tagged for a room
SELECT item_id FROM product_master_enriched_t
WHERE array_contains(room_context_tags, 'Home Office');

-- why a tag was dropped
SELECT item_id, product_tags.events.dropped, product_tags.events.state
FROM product_master_enriched_t WHERE size(product_tags.events.dropped) > 0;

-- products tagged this week
SELECT count(*) FROM product_master_enriched_t WHERE tags_updated_at >= date_sub(current_date(), 7);
```

## Working tables

`product_tag_class_profile` and `product_tag_cache_v2` are working state for the tagging job (class
profiles and per-product model answers, so reruns do not re-spend LLM calls). They are not outputs.
