#Migration Checklist — Agentic Commerce

**Scope:** Deep clone tables (grouped by pipeline), enable CDF at version 0, copy documents, set up new workspace artifacts.
**Convention:** `{src}` = `mld01_ml_de`, `{tgt}` = `mld01_ml_qe` (swap if direction differs).

> **Why deep clone at all?** The pipelines would work fine in QE even starting from empty tables — the daily job would just backfill everything from scratch on first run. Deep cloning is purely a **cost/time optimization**: it seeds QE with DE's existing state so the daily job only computes deltas for new inserts/updates going forward, instead of recomputing embeddings, taxonomy tags, and enrichment joins for all 177K SKUs on day one.

---

## 1. Product Master Enriched (`product_master_enriched_t`)

`product_master_enriched_t` is built by joining `product_discovery_data` against these enrichment tables — clone all of them first, then clone the final joined table.

```sql
-- reference: join structure product_master_enriched_t is built from
    LEFT JOIN {claims_table} claims ON disc.item_id = claims.item_id
    LEFT JOIN {lifecycle_table} lcd ON disc.item_id = lcd.item_id
    LEFT JOIN {universal_attributes_table} univ ON disc.item_id = univ.item_id
    LEFT JOIN {compatibility_table} comp ON disc.item_id = comp.item_id
    LEFT JOIN {review_mining_table} faq ON disc.item_id = faq.item_id
    LEFT JOIN {cosmos_table} cosmos ON disc.item_id = cosmos.item_id
    LEFT JOIN {product_cache_table} cache_data ON disc.item_id = cache_data.item_id
```

| # | Table (from `general.yml`) | Feeds join alias |
|---|---|---|
| ☐ | `product_discovery_data` | `disc` (base) |
| ☐ | `product_claims` | `claims_table` |
| ☐ | `product_lifecycle_enriched_data` | `lifecycle_table` |
| ☐ | `product_univ_attributes` | `universal_attributes_table` |
| ☐ | `product_enrichment_compatibility` | `compatibility_table` |
| ☐ | `product_reviews_faq_enriched_data` | `review_mining_table` |

```sql
-- repeat per table above
CREATE TABLE IF NOT EXISTS {tgt}.product.<table_name>
DEEP CLONE {src}.product.<table_name>;
```

```sql
-- all_cat_cosmos_taxonomy uses OR REPLACE, not IF NOT EXISTS
CREATE OR REPLACE TABLE mld01_ml_qe.product.all_cat_cosmos_taxonomy
DEEP CLONE mld01_ml_de.product.all_cat_cosmos_taxonomy;
```

### Final table + CDF

| # | Step |
|---|---|
| ☐ | Deep clone `product_master_enriched_t` |
| ☐ | Enable CDF at version 0 immediately after |

```sql
CREATE TABLE IF NOT EXISTS {tgt}.product.product_master_enriched_t
DEEP CLONE {src}.product.product_master_enriched_t;

ALTER TABLE {tgt}.product.product_master_enriched_t
SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- sanity check: CDF should start at version 0, no prior writes
DESCRIBE HISTORY {tgt}.product.product_master_enriched_t;
```

---

## 2. Unstructured Data (`product_unstructured_t`)

From `general.yml` → `unstructured_data.tables`:

| # | Table | Notes |
|---|---|---|
| ☐ | `product_document_url_data` | URLs extracted from product data (`url_data`) |
| ☐ | `product_unstructured_t` | Parsed document content — **+ CDF at v0** |

```sql
CREATE TABLE IF NOT EXISTS {tgt}.product.product_document_url_data
DEEP CLONE {src}.product.product_document_url_data;

CREATE TABLE IF NOT EXISTS {tgt}.product.product_unstructured_t
DEEP CLONE {src}.product.product_unstructured_t;

ALTER TABLE {tgt}.product.product_unstructured_t
SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

DESCRIBE HISTORY {tgt}.product.product_unstructured_t;
```

### Copy raw PDFs (no re-download)

The actual downloaded PDFs live in the UC Volume, not just the table — copy the files directly so the parsing pipeline doesn't re-hit the source URLs.

| # | Step |
|---|---|
| ☐ | Copy `documents/` volume contents from `{src}` workspace to `{tgt}` workspace |
| ☐ | Verify file count matches between source and target |
| ☐ | Confirm `download_status` table (`url_download_status`) is cloned too, so change-detection hashes stay intact and nothing re-downloads |

```python
# run in QE workspace (cross-workspace volume copy — adjust to your actual cross-workspace access method,
# e.g. Volume-to-Volume via dbutils.fs.cp if both mounted, or an external copy/sync job if not)
dbutils.fs.cp(
    "/Volumes/mld01_ml_de/product/documents/",
    "/Volumes/mld01_ml_qe/product/documents/",
    recurse=True
)
```

```sql
-- also clone this so parsed/download history travels with the files (avoids re-parsing too)
CREATE TABLE IF NOT EXISTS {tgt}.product.url_download_status
DEEP CLONE {src}.product.url_download_status;
```

---

## 3. Index Source / Embedding Tables

Purpose: avoids recomputing embeddings in QE.

| # | Table | Source | Target |
|---|---|---|---|
| ☐ | `product_discovery_index_source` | `{src}.product.product_discovery_index_source` | `{tgt}.product.product_discovery_index_source` |
| ☐ | `product_documents_index_source` | `{src}.product.product_documents_index_source` | `{tgt}.product.product_documents_index_source` |
| ☐ | `product_detail_index_embedding` | `{src}.product.product_detail_index_embedding` | `{tgt}.product.product_detail_index_embedding` |
| ☐ | `product_title_index_source` | `{src}.product.product_title_index_source` | `{tgt}.product.product_title_index_source` |
| ☐ | `product_lookup` | `{src}.product.product_lookup` | `{tgt}.product.product_lookup` |

All five get CDF enabled at version 0.

```sql
-- deep clone (repeat per table)
CREATE TABLE IF NOT EXISTS {tgt}.product.<table_name>
DEEP CLONE {src}.product.<table_name>;

-- enable CDF right after, pinned at version 0
ALTER TABLE {tgt}.product.<table_name>
SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

DESCRIBE HISTORY {tgt}.product.<table_name>;
```

> After cloning, point `sync_*` configs' `vs_index_source_table` entries at `{tgt}` and re-sync the vector search index metadata (not full re-embedding) so the index binds to the cloned source.

---

## 4. New Workspace Setup — Volume Folder Structure

Target volume: `/Volumes/mld01_ml_qe/product/`

| # | Folder | Purpose |
|---|---|---|
| ☐ | `documents/` | Downloaded PDFs for unstructured pipeline (populated via copy in §2, not fresh download) |
| ☐ | `checkpoints/` | Streaming checkpoints for sync notebooks |
| ☐ | `ml_artifacts/` | Model wheels, tokenizer files, label configs |

```python
import os

base = "/Volumes/mld01_ml_qe/product"
for folder in ["documents", "checkpoints", "ml_artifacts"]:
    os.makedirs(f"{base}/{folder}", exist_ok=True)

print("Created:", sorted(os.listdir(base)))
```

---

## 5. spaCy Wheel

| # | Step |
|---|---|
| ☐ | Confirm target volume exists: `/Volumes/mld01_ml_qe/product/ml_artifacts/wheels` |
| ☐ | Run download script below in the **QE workspace** |
| ☐ | Verify wheel file present via `os.listdir` output |
| ☐ | Update cluster/job library config to `%pip install` from the volume path |

```python
import os
import urllib.request

target_dir = "/Volumes/mld01_ml_qe/product/ml_artifacts/wheels"
os.makedirs(target_dir, exist_ok=True)

wheel_url = "https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl"
target_file = f"{target_dir}/en_core_web_sm-3.8.0-py3-none-any.whl"

urllib.request.urlretrieve(wheel_url, target_file)

print("Downloaded:", target_file)
print("Files in folder:", sorted(os.listdir(target_dir)))
```

---

## 6. Post-Migration Validation

| # | Check |
|---|---|
| ☐ | Row counts match between `{src}` and `{tgt}` for all cloned tables |
| ☐ | `DESCRIBE HISTORY` confirms CDF enabled at version 0 (no writes before the property set) |
| ☐ | PDF file counts match between `{src}` and `{tgt}` volumes (no re-download occurred) |
| ☐ | `config.yml` / `general.yml` `{env}` placeholder resolves correctly to `qe` in new workspace |
| ☐ | Vector search endpoint (`product_discovery_endpoint`) re-registered against cloned index-source tables |
| ☐ | Neo4j `qe` URI (`acm02-neo4jdb-de-01...`) confirmed reachable from new workspace |
| ☐ | spaCy wheel installs cleanly on a test cluster |
| ☐ | Checkpoint paths (`/Volumes/mld01_ml_qe/product/checkpoints`) are clean/fresh for QE streams (not reused from DE) |

---

## Notes / Gotchas

- Deep clone is a **new physical copy** — cost/storage doubles until old DE artifacts are decommissioned.
- CDF "at version 0" only holds if no writes land on the target between `CREATE TABLE` and the `ALTER TABLE` — don't let a scheduled job sneak in between.
- Index-source clones save embedding recompute cost, but the **Vector Search index itself** still needs to be re-pointed/re-synced to the new source table — cloning the Delta table doesn't move the VS index.
- Copying `documents/` volume + `url_download_status` together avoids both re-downloading files and re-triggering SHA-256 change-detection re-parses.