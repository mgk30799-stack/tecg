
# Feasibility: Filtering by `confidence_score` / `conflict_flag` Before Notebook Vector Index Embedding

> **Status**: Temporary analysis report. No production code, config, schema, or tests were changed while producing this.
> **Scope**: `review_mining` pipeline → `notebooks/sync_product_detail_index.py` (the notebook vector index job).

---

## 1. Executive Summary

The request asks whether **reviews** can be filtered by `confidence_score` and `conflict_flag` before embedding, to improve vector index quality.

The codebase does not have those two fields at the review grain, so the request as literally scoped cannot be implemented without inventing new fields and a new LLM call path. What actually exists:

| Field asked about | What exists instead | Grain |
|---|---|---|
| `confidence_score` | `confidence` (DOUBLE, 0–1) on **issue signals** — one row per *detected issue*, not per review | per issue mention |
| `conflict_flag` | `conflict_flag` (BOOLEAN) on **issue_summary** (per product × issue_key) and **faq_summary** (per product × question) | aggregated across many reviews/answers |

Raw review text itself (`detail_type="review"` in the vector index source — just `review.title` + `review.content`) carries **neither** field today. Both fields live only on *derived, already-aggregated* structures that sit downstream of the raw review text in the same index.

Two filtering mechanisms **already exist** in this codebase and are relevant prior art:
1. **Confidence filtering is already enforced upstream**, before an issue signal is ever created (`issues_tagging.py`, `MIN_CONFIDENCE = 0.5`, configurable via `config/general.yml: review_mining.llm.min_confidence`).
2. **Score-based filtering at the embedding/index layer already exists** for FAQ answers (`notebooks/sync_product_detail_index.py`, `_MIN_INDEXED_ANSWER_SCORE = 4`), which is the correct template to follow for any new index-time filter.

`conflict_flag` is a weaker candidate for hard filtering than it first appears: a prior validation effort on this same field found it **misses most real conflicts** (low recall) — see [§8](#8-open-questions--assumptions) and the team's own retained finding on this. Hard-excluding `conflict_flag = true` rows would not meaningfully clean the index (most true conflicts aren't flagged anyway) while discarding content that is flagged.

**Recommendation**: do not add review-level filtering (the fields don't exist there). Do not hard-filter on `conflict_flag` anywhere, given its known recall gap. An optional, low-priority index-time confidence floor on `issue_summary`/`issue_signal` rows is feasible and cheap to add, following the existing FAQ-answer-score pattern, but is largely redundant with the extraction-time floor that already exists. See [§5](#5-recommended-approach) for the detailed rationale.

---

## 2. Current Implementation & Data Flow

```
reviews / Q&A (product_master_enriched_t)
        │
        ▼
issues_tagging.py  ──LLM (Gemma/Vertex) per review/QA text──▶  per-issue records
        │   - confidence (0-1), confidence_band, severity, sentiment_score, ...
        │   - MIN_CONFIDENCE floor already applied HERE (entries below 0.5 dropped)
        │
        ▼ (second LLM pass, grouped by product × issue_key)
issues_tagging.py  ──conflict detection──▶  conflict_flag (BOOLEAN, nullable)
        │   - falls back to a sentiment heuristic if the LLM pass is off/fails
        │
        ▼
review_mining.py  ──pure aggregation, no LLM calls──▶
        issue_signals_json   (one entry per detected mention; carries `confidence`)
        issue_summary_json   (one entry per issue_key per product; carries `conflict_flag`)
        │
        ▼ (separately, faq_tagging.py produces faq_summary_json.conflict_flag
        │  per question per product, using answer_score, not confidence)
        │
        ▼
product_master_enriched_t  (one row per product_id, with reviews, issue_signals_json,
                             issue_summary_json, faq_summary_json, etc.)
        │
        ▼
notebooks/sync_product_detail_index.py  ──build_product_detail_projection()──▶
        one row per (product_id, detail_type, detail_text):
          detail_type ∈ {spec, bullet, review, faq, claim, highlight,
                          issue_signal, issue_overview, issue_summary, faq_summary}
        │
        ▼ build_upsert_frame() → write to vs_index_source_table
   mld01_ml_{env}.product.product_detail_index_embedding   (detail_text_emb = NULL)
        │
        ▼ shared.backfill_embeddings() — real ai_query() calls, batched
   detail_text_emb populated
        │
        ▼ Databricks Vector Search (create_delta_sync_index_and_wait, TRIGGERED pipeline)
   mld01_ml_{env}.product.product_detail_index   ← the notebook vector index
```

Key files/functions:
- [`src/data_pipeline/enrichment/issues_tagging.py`](../src/data_pipeline/enrichment/issues_tagging.py) — produces `confidence` (line ~39) and enforces `MIN_CONFIDENCE` (lines ~783, 818–822); produces `conflict_flag` via a second LLM pass with a sentiment-heuristic fallback (lines ~235, 1901, 2004–2326).
- [`src/data_pipeline/enrichment/review_mining.py`](../src/data_pipeline/enrichment/review_mining.py) — aggregates per-issue records into `issue_signals_json`/`issue_summary_json` (function starting ~line 1420); explicitly documents that `conflict_flag` "is the one field that is NOT derived here" (line ~1438), it only fills gaps from `issues_tagging`'s verdict.
- [`src/data_pipeline/enrichment/faq_tagging.py`](../src/data_pipeline/enrichment/faq_tagging.py) — produces `conflict_flag` per question (lines ~572–583, requires ≥2 answers); has **no confidence field at all**, uses `answer_score` (0–10 usefulness ranking) instead.
- [`notebooks/sync_product_detail_index.py`](../notebooks/sync_product_detail_index.py) — the notebook vector index job: `build_product_detail_projection()` (line ~180) builds `detail_text` per detail type; `build_upsert_frame()` (line ~592) adds the `detail_text_emb` slot and timestamps; the streaming `process_batch()` (line ~640) upserts into the index source table; embeddings are computed later by `shared.backfill_embeddings()`.
- [`notebooks/common/shared.py`](../notebooks/common/shared.py) — `backfill_embeddings()` (line ~356) is where real embedding compute (`ai_query()`) happens, against whatever rows already landed in the source table with `detail_text_emb IS NULL`.

---

## 3. Existing Usage of `confidence_score` and `conflict_flag`

### 3.1 `confidence` (not `confidence_score` — that exact name does not exist anywhere in the repo)

- Defined on **issue signals only**: `StructField("confidence", DoubleType())`, LLM self-reported, clamped to `[0,1]` (`issues_tagging.py` docstring, line 39; schema at lines 284, 336, 2857).
- **Already filtered at the source**: `issues_tagging.py` line ~818–822 drops any detected issue entry whose `confidence < min_confidence` *before* it is ever written to `issue_signals_json`. `min_confidence` defaults to `0.5` (`DEFAULT_MIN_CONFIDENCE`) and is configurable via `config/general.yml` → `review_mining: llm: min_confidence: 0.5` (line 129).
- In the vector index job, `issue_signal.confidence` is read only to be **serialized as literal text** (`"confidence=0.82"`) inside `detail_text` (`sync_product_detail_index.py` lines 296–299). It is never used to include/exclude a row.
- `issue_summary_json` (the per-product × issue_key aggregate) does **not** carry a `confidence` field at all — only `issue_signals_json` (the per-mention records) does.
- There is no confidence field anywhere on raw reviews, FAQ answers, or FAQ summaries.
- `avg_confidence_score` appears once, in `config/tagging_registry.yaml` line 317, as an entry in a generic `monitoring.metrics` list (metrics prefix `staples_tagging_`). It is a metric *name string* in what looks like a separate/generic tagging-registry config, not a field produced or consumed anywhere in `review_mining`, `issues_tagging`, or the index notebooks found by this search. Treat this as unrelated unless the team confirms otherwise — it was not traced to a producer.

### 3.2 `conflict_flag`

- **Two distinct, aggregate-level instances**, neither at the review grain:
  1. `issue_summary_json.issues[].conflict_flag` — per product × issue_key, derived from a second LLM pass over *all* mentions of that issue for that product (`issues_tagging.py` lines ~1901–2326). Falls back to a sentiment-divergence heuristic (`sentiment_conflict_fallback`) when the LLM conflict pass is disabled or fails (line 235, 2653–2680).
  2. `faq_summary_json.conflict_flag` — per product × question, true only when ≥2 answers exist and the LLM judges them contradictory (`faq_tagging.py` lines 572–583). Never NULL by contract — defaults to `False` when there's no verdict.
- In the vector index job, both are read only to be **serialized as literal text** (`"conflict_flag=true"` / `"conflict_flag=false"`) inside `detail_text` for `issue_summary` and `faq_summary` detail rows (`sync_product_detail_index.py` lines 414–417, 550–559). Never used to include/exclude a row.
- Raw review rows (`detail_type="review"`, built from `review.title`/`review.content` alone — lines 225–235) and raw FAQ rows (`detail_type="faq"`, lines 236–242) carry **no** `conflict_flag` at all; it is not a property of an individual review or an individual Q&A pair in this schema.
- **Known reliability gap (carried over from prior validation work on this field, not re-verified in this pass)**: the issue-level `conflict_flag` was previously found to miss most real conflicts (low recall) relative to human-labeled ground truth. This is a standing caution against treating `conflict_flag = true/false` as a trustworthy exclusion signal — it's directional at best, not currently validated.

### 3.3 Existing filtering precedent at the index layer

`sync_product_detail_index.py` lines 68–73, 456–463 already filters FAQ answers by a quality score (`answer_score >= _MIN_INDEXED_ANSWER_SCORE = 4`) before they're folded into `faq_summary`'s `detail_text`, with a deliberate `coalesce(...)` so that a degraded/disabled tagging run (all `answer_score` NULL) keeps every answer rather than silently emptying the index. **This is the direct precedent to follow** for any new filter introduced at this layer — both the mechanism (`F.filter` over the exploded array before string-building) and the safety pattern (coalesce-to-keep on missing data) should be reused rather than redesigned.

---

## 4. Feasibility of Each Filtering Strategy

| Strategy | Feasible as literally scoped (on *reviews*)? | Feasible on the fields that actually exist? | Notes |
|---|---|---|---|
| **Confidence-only filtering** | No — reviews have no confidence field | Partially — only on `issue_signal` rows (per-mention `confidence`) | Already enforced upstream at extraction time (`MIN_CONFIDENCE`); an index-time floor would be a second, redundant gate unless intentionally stricter for retrieval vs. extraction purposes |
| **Conflict-only filtering** | No — reviews have no conflict field | Yes, mechanically — on `issue_summary`/`faq_summary` rows | Not recommended: known low recall on `issue_summary.conflict_flag` means hard-exclusion gives a false sense of cleanup while discarding content that may still be useful for retrieval nuance |
| **Combined (confidence + conflict), configurable rules** | No | Yes, mechanically, same caveats as above | Combining doesn't resolve the recall gap in conflict_flag; would mainly add complexity |
| **Retain all, track filtering metrics for comparison** | N/A (nothing to filter on at review grain) | Yes — straightforward | Lowest risk; consistent with current design where `confidence`/`conflict_flag` are surfaced as *inline text* for the embedding model/retriever to see, not as a hard gate |

---

## 5. Recommended Approach

1. **Do not filter raw reviews by confidence_score or conflict_flag.** Those fields don't exist at that grain. Building them would require a new per-review LLM scoring pass, duplicating work `issues_tagging.py` already does at the issue-mention grain, at added cost and latency, for a benefit that isn't established.
2. **Do not hard-filter `conflict_flag` anywhere in the index**, including on `issue_summary`/`faq_summary` rows. Given the documented low-recall finding on this exact field, exclusion would remove some legitimately flagged content without reliably removing the much larger set of unflagged-but-actually-conflicting content — i.e., it wouldn't achieve the stated goal of cleaner embeddings, and the current design (surfacing `conflict_flag=true/false` as inline text the embedding/retriever can read) already uses the signal more honestly than a hard gate would. The FAQ `conflict_flag` carries no recall data point from prior validation either way; absent that evidence, the same caution applies by default.
3. **An index-time confidence floor on `issue_signal`/`issue_summary` rows is feasible but low-value**, since `MIN_CONFIDENCE` already removes sub-0.5 detections before they're ever aggregated. If retrieval quality still looks poor at the current 0.5 floor, the cheaper fix is raising `review_mining.llm.min_confidence` in `config/general.yml` (affects extraction, not just indexing, and avoids maintaining two thresholds), not adding a second, notebook-local constant.
4. **If stakeholders still want an index-time guard** (e.g. to decouple "what gets tagged" from "what gets embedded" without touching the extraction threshold), the lowest-risk way to add one is to mirror `_MIN_INDEXED_ANSWER_SCORE` exactly: a module-level constant (or, better, a config value under `sync_product_detail_index` in `general.yml`) checked with `F.filter(...)` / a `.where(...)` on the exploded `issue_signal`/`issue_summary` frame inside `build_product_detail_projection()`, before `build_upsert_frame()`. It must `coalesce()` to "keep" on NULL, exactly as the FAQ pattern does, so a disabled/degraded tagging run doesn't silently empty the index.
5. **Track, don't gate, initially.** Whatever is decided, start by adding `confidence`/`conflict_flag` distribution metrics to the existing index-vs-source reconciliation check (`sync_product_detail_index.py` lines ~731–749 already counts expected vs. actual products) rather than shipping a hard filter blind. This lets the team see what volume a given threshold would actually remove before committing to it.

---

## 6. Suggested Configurable Thresholds/Rules (if pursued)

These do not exist today and are **proposals only**:

- `sync_product_detail_index.filtering.min_issue_confidence` (float, optional, default unset/disabled) — analogous to `_MIN_INDEXED_ANSWER_SCORE`, applied only to `issue_signal`/`issue_summary` detail rows.
- No `exclude_conflicting` flag is recommended given the recall caveat in §3.2/§8; if added anyway, it should default to `false` (retain-all) and be presented as experimental.
- Any new config key should be read with `.get(key, default)` so existing deployments that don't declare it behave exactly as today — consistent with this pipeline's existing "evolve, don't break" pattern for schema and config changes.

---

## 7. Expected Benefits, Risks, Performance Implications

**Benefits (if a confidence floor is added at index time)**
- Marginal: most of the benefit is already captured by `MIN_CONFIDENCE` at extraction. The incremental gain from a second, index-level floor is unproven without the metrics step in §5.4.

**Benefits (if conflict filtering is added despite the recommendation against it)**
- None demonstrated; the known recall gap means it would not reliably remove conflicting content, only some of it, while discarding potentially useful flagged content.

**Risks**
- **Retroactive application requires a full refresh.** The vector index source table is maintained by an incremental CDC stream (`start_stream_with_cdc_recovery` / `process_batch`, lines ~640–719): a product's detail rows are only re-evaluated when that product's row in `product_master_enriched_t` changes. Introducing or tightening a filter does **not** retroactively remove now-disqualified rows for products that haven't otherwise changed — per the existing `full_refresh` widget/flow (lines 91–121), a full refresh would be needed to apply a new/changed threshold across the whole catalog, exactly as it is for any other schema/logic change to this notebook.
- **Embedding cost is real, not just a Vector Search abstraction.** `backfill_embeddings()` (`shared.py` line 356) issues actual `ai_query()` calls, batched and rate-limited, against every row with `detail_text_emb IS NULL` in the source table. Any filtering must happen in `build_product_detail_projection()`/before `saveAsTable`/MERGE — i.e., before a row ever reaches the source table — to actually avoid embedding spend. Filtering after the fact (e.g., at retrieval time) does not save embedding cost.
- **Schema/compatibility**: the vector index's `columns_to_sync` (`detail_id, product_id, detail_type, detail_text, detail_text_emb`) is fixed; a row-count-reducing filter changes no schema and is backward compatible with the index definition itself.
- **Backward compatibility of thresholds**: `config/general.yml`'s `min_confidence` is shared infrastructure for `issues_tagging.py`; do not repurpose it for indexing — a separate, independently tunable knob (§6) avoids coupling extraction behavior to indexing behavior.

---

## 8. Open Questions / Assumptions Requiring Clarification

- **Assumption**: "review data" in the task request was intended loosely to mean "content derived from reviews" (i.e. issue signals/summaries), not literally the raw `review.title`/`review.content` text. This report evaluates both readings; under the literal reading, the feasibility answer is "not applicable — the fields don't exist there."
- **Carried-over, not re-verified in this pass**: the claim that `issue_summary.conflict_flag` has low recall against human-labeled ground truth comes from this team's own prior validation work on that field, not from analysis performed for this report. If that validation is stale or was scoped differently than assumed here, the recommendation in §5.2 should be revisited — it would help to pull the original validation note/dataset and confirm it's still representative of the current `issues_tagging.py` conflict-detection logic before treating this as settled.
- **Unresolved**: `avg_confidence_score` in `config/tagging_registry.yaml` (§3.1) — unclear whether `tagging_registry.yaml` belongs to `review_mining` at all, or is a generic/legacy config for a different tagging framework in this repo. Needs a maintainer to confirm; this report did not find a producer for it.
- **Unquantified**: no data was pulled in this pass on what fraction of `issue_signal`/`issue_summary`/`faq_summary` rows would actually be removed by any candidate threshold, or what the measured impact on retrieval quality would be. §5.5's recommendation to instrument before gating is meant to close this gap before any implementation decision is made.
- **Scope check**: confirm whether "notebook vector index" in the task refers specifically to `sync_product_detail_index.py` (assumed here, since it is the only one of the four `sync_product_*_index.py` notebooks whose source data includes `issue_signals_json`/`issue_summary_json`/`faq_summary_json`) as opposed to `sync_product_discovery_index.py`, `sync_product_documents_index.py`, or `sync_product_title_index.py`, which were not examined in depth for this report.

---

## 9. Suggested Implementation Plan & Validation Strategy (if the team proceeds past tracking-only)

1. Add distribution metrics (counts/percentiles of `confidence`, `conflict_flag` true-rate) to the existing reconciliation/validation cell in `sync_product_detail_index.py` — no behavior change, just visibility.
2. Run against a full catalog snapshot; have someone with domain context review whether the distribution suggests a confidence floor would remove true noise vs. legitimate low-but-valid signals.
3. If a confidence floor is adopted, implement it as a config-driven `F.filter`/`.where()` in `build_product_detail_projection()`, modeled exactly on the FAQ-answer-score pattern (coalesce-to-keep on NULL), covered by a unit test analogous to whatever currently covers `_MIN_INDEXED_ANSWER_SCORE` behavior (if one exists — not located in this pass; check `tests/`).
4. Roll out behind the optional config key, defaulted to "disabled" (§6), so existing deployments are unaffected until explicitly opted in.
5. Apply via `full_refresh=true` on a non-prod environment first, compare before/after row counts and a sample of excluded `detail_text` values for sanity, before running against prod.
6. Do not implement conflict-based exclusion without first re-validating the recall claim in §8 against current data.
