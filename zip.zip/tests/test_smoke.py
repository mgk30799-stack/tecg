# Placeholder kept so the tests/ directory always has a collectable module.
#
# Was previously written as UTF-16, which pytest cannot parse ("source code
# string cannot contain null bytes") — that error aborted collection for the
# WHOLE suite, so every other test file in here was silently never run.
# Re-saved as UTF-8; do not re-encode it.
