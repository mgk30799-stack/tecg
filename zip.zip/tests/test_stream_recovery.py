"""
notebooks/common/shared.py — the stream restart after a source schema change
(R3) and the embedding-preserving upsert (R2).

delta-spark is not installed locally, so `delta.tables` is stubbed before
shared.py is imported; nothing here touches a real DeltaTable. Streams and
the MERGE builder are fakes that record what was asked of them.
"""

import os
import sys
import types

import pytest

if "delta.tables" not in sys.modules:
    _delta = types.ModuleType("delta")
    _tables = types.ModuleType("delta.tables")
    _tables.DeltaTable = object
    _delta.tables = _tables
    sys.modules.setdefault("delta", _delta)
    sys.modules["delta.tables"] = _tables

_COMMON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "notebooks", "common")
if _COMMON not in sys.path:
    sys.path.insert(0, _COMMON)

import shared  # noqa: E402

SCHEMA_STOP = Exception(
    "[DELTA_STREAMING_METADATA_EVOLUTION] The schema, table configuration or protocol "
    "of your Delta table has changed during streaming."
)
CDC_STALE = Exception("[DELTA_INVALID_CDC_RANGE] CDC range from start 5 to end 9 was invalid")


class FakeStream:
    def __init__(self, outcome):
        self.outcome = outcome
        self.stopped = False

    def awaitTermination(self, _timeout):
        if isinstance(self.outcome, Exception):
            raise self.outcome
        return self.outcome

    def stop(self):
        self.stopped = True


class FakeReader:
    """spark.readStream ... .start() — records options, returns the next stream."""

    def __init__(self, spark):
        self.spark, self.options = spark, {}

    def option(self, key, value):
        self.options[key] = value
        return self

    def table(self, _):
        return self

    @property
    def writeStream(self):
        return self

    def foreachBatch(self, _):
        return self

    def trigger(self, **_):
        return self

    def start(self):
        self.spark.started.append(dict(self.options))
        return FakeStream(self.spark.outcomes.pop(0))


class FakeSpark:
    def __init__(self, outcomes):
        self.outcomes, self.started = list(outcomes), []
        self.streams = types.SimpleNamespace(resetTerminated=lambda: None)

    @property
    def readStream(self):
        return FakeReader(self)


class FakeDbutils:
    def __init__(self):
        self.removed = []
        self.fs = types.SimpleNamespace(rm=lambda path, recurse: self.removed.append(path))


def run(outcomes, **kwargs):
    spark, dbutils = FakeSpark(outcomes), FakeDbutils()
    shared.start_stream_with_cdc_recovery(
        spark, dbutils, "cat.sch.src", "/chk", process_batch_fn=None, **kwargs,
    )
    return spark, dbutils


# --- R3: restart after a source schema change ------------------------------

def test_clean_run_starts_once():
    spark, dbutils = run([True])
    assert len(spark.started) == 1 and dbutils.removed == []


def test_schema_change_restarts_keeping_the_checkpoint():
    spark, dbutils = run([SCHEMA_STOP, SCHEMA_STOP, True])
    assert len(spark.started) == 3
    assert dbutils.removed == []  # checkpoint kept


def test_schema_restarts_are_capped():
    with pytest.raises(Exception, match="DELTA_STREAMING_METADATA_EVOLUTION"):
        run([SCHEMA_STOP] * 3, max_schema_restarts=2)


def test_stale_cdc_checkpoint_still_reset_once():
    spark, dbutils = run([CDC_STALE, True])
    assert dbutils.removed == ["/chk"] and len(spark.started) == 2


def test_stale_cdc_twice_raises():
    with pytest.raises(Exception, match="DELTA_INVALID_CDC_RANGE"):
        run([CDC_STALE, CDC_STALE])


def test_schema_change_after_checkpoint_reset_still_restarts():
    spark, dbutils = run([CDC_STALE, SCHEMA_STOP, True])
    assert dbutils.removed == ["/chk"] and len(spark.started) == 3


def test_unrelated_error_is_raised():
    with pytest.raises(ValueError):
        run([ValueError("boom")])


def test_timeout_is_raised():
    with pytest.raises(TimeoutError):
        run([False])


def test_reader_options():
    spark, _ = run([True], allow_source_column_drop=True, allow_source_column_type_change=True)
    opts = spark.started[0]
    assert opts["allowSourceColumnDrop"] == "always"
    assert opts["allowSourceColumnTypeChange"] == "always"
    assert opts["schemaTrackingLocation"] == "/chk/_schema_tracking"


def test_type_change_option_off_by_default():
    spark, _ = run([True])
    assert "allowSourceColumnTypeChange" not in spark.started[0]


# --- R2: keep embeddings whose text is unchanged ---------------------------

class FakeMerge:
    def __init__(self, log):
        self.log = log

    def whenMatchedUpdate(self, condition=None, set=None):
        self.log.append(("matched_update", condition, set))
        return self

    def whenMatchedUpdateAll(self, condition=None):
        self.log.append(("matched_update_all", condition))
        return self

    def whenNotMatchedInsertAll(self, condition=None):
        self.log.append(("insert_all", condition))
        return self

    def execute(self):
        self.log.append(("execute",))


class FakeTarget:
    def __init__(self):
        self.log = []

    def alias(self, _):
        return self

    def merge(self, _source, condition):
        self.log.append(("merge", condition))
        return FakeMerge(self.log)


class FakeUpsert:
    columns = ["detail_id", "product_id", "detail_text", "detail_text_emb", "created_at", "updated_at"]

    def alias(self, _):
        return self


def test_upsert_keeps_embedding_when_text_unchanged():
    target = FakeTarget()
    shared.upsert_preserving_embeddings(
        target, FakeUpsert(), "t.detail_id = s.detail_id",
        text_col="detail_text", emb_col="detail_text_emb",
    )
    merge, keep, update_all, insert, execute = target.log
    assert merge == ("merge", "t.detail_id = s.detail_id")

    _, condition, set_ = keep
    assert condition == "t.`detail_text` <=> s.`detail_text` AND t.`detail_text_emb` IS NOT NULL"
    assert "detail_text_emb" not in set_
    assert set_["detail_text"] == "s.`detail_text`"
    assert len(set_) == len(FakeUpsert.columns) - 1

    # Text changed (or no embedding yet): today's behaviour — update all,
    # embedding becomes NULL and is re-computed by backfill_embeddings.
    assert update_all == ("matched_update_all", None)
    assert insert == ("insert_all", None)
    assert execute == ("execute",)
