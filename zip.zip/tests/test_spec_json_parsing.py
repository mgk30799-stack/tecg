"""
Regression tests for spec_json / bullets_json parsing in the lifecycle pipeline.

Background
----------
In product_discovery_data these columns are NOT JSON strings:

    spec_json     array<struct<attribute_group_nm, attribute_nm, attribute_value_txt>>
    bullets_json  array<string>

A Python UDF therefore receives real Python lists (of Row objects, and of str).
Six call sites nevertheless called json.loads() on them and swallowed the
resulting TypeError in a bare `except`, so every spec- and bullet-driven branch
returned "nothing found" for every row in production:

    _extract_age_from_spec_py   -> age_group  fell through to title/category guesses
    get_multipack_udf           -> multipack  ran on the title regex alone
    _extract_warning_bullets    -> warning    bullet scanning did nothing
    _resolve_warning            -> warning    Prop 65 / flammable spec branch dead
    _resolve_gender             -> gender     682 items tagged, 4,121 had a gender spec

Parsing is now centralised in `_spec_values` and `_bullet_values`, which accept
BOTH shapes. Every test below runs each case twice — once as the real array
shape, once as a JSON string — because both must behave identically and the
array shape is the one that actually reaches production.
"""

import json
import os
import sys

import pytest

_ENRICHMENT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "src", "data_pipeline", "enrichment",
)
if _ENRICHMENT_DIR not in sys.path:
    sys.path.insert(0, _ENRICHMENT_DIR)

from enriched_lifecycle_data_loader import (  # noqa: E402
    _bullet_values,
    _extract_warning_bullets,
    _resolve_warning,
    _spec_values,
    get_multipack_udf,
    get_warning_url_udf,
)


class Row:
    """Stands in for a pyspark Row, which exposes asDict()."""

    def __init__(self, **kw):
        self._d = kw

    def asDict(self):
        return dict(self._d)


def spec(nm, val, group="G"):
    return {"attribute_group_nm": group, "attribute_nm": nm, "attribute_value_txt": val}


def both_shapes(specs):
    """The same spec list as (array<struct> equivalent, JSON string)."""
    return [
        specs,                                                  # list of dict
        [Row(**s) for s in specs],                              # list of Row
        json.dumps(specs),                                      # JSON string
    ]


# ---------------------------------------------------------------------------
# The normalisers
# ---------------------------------------------------------------------------

def test_spec_values_all_shapes_agree():
    specs = [spec("Selling Quantity", "12"), spec("Color Family", "Cognac")]
    expected = [("Selling Quantity", "12"), ("Color Family", "Cognac")]
    for shape in both_shapes(specs):
        assert _spec_values(shape) == expected, f"shape {type(shape).__name__} disagreed"


@pytest.mark.parametrize("junk", [
    None, "", "   ", "{not json", "null", '"a string"', 42, {"a": 1}, [1, 2, 3],
])
def test_spec_values_junk_is_empty_not_an_exception(junk):
    assert _spec_values(junk) == []


def test_spec_values_skips_unusable_entries_but_keeps_the_rest():
    assert _spec_values([spec("Pack Qty", "6"), 42, None, {"no_attrs": 1}]) == [
        ("Pack Qty", "6"), ("", ""),
    ]


def test_bullet_values_all_shapes_agree():
    bullets = ["12 rolls per case", "Made in USA"]
    assert _bullet_values(bullets) == bullets
    assert _bullet_values(json.dumps(bullets)) == bullets


@pytest.mark.parametrize("junk", [None, "", "   ", "{not json", 42, {"a": 1}])
def test_bullet_values_junk_is_empty(junk):
    assert _bullet_values(junk) == []


def test_bullet_values_drops_nulls():
    assert _bullet_values(["a", None, "b"]) == ["a", "b"]


# ---------------------------------------------------------------------------
# multipack — get_multipack_udf
# ---------------------------------------------------------------------------

def test_multipack_from_quantity_spec():
    for shape in both_shapes([spec("Selling Quantity", "12")]):
        assert get_multipack_udf("Plain Item", None, shape) is True


def test_multipack_from_uom_spec():
    for shape in both_shapes([spec("Selling Quantity (UOM)", "Carton")]):
        assert get_multipack_udf("Plain Item", None, shape) is True


def test_multipack_quantity_of_one_is_not_a_multipack():
    for shape in both_shapes([spec("Selling Quantity", "1")]):
        assert get_multipack_udf("Plain Item", None, shape) is False


def test_multipack_quantity_above_range_is_not_matched_by_the_spec_branch():
    """The spec branch caps at 24 to avoid single-item counts; 5000 must not match."""
    for shape in both_shapes([spec("Selling Quantity", "5000")]):
        assert get_multipack_udf("Plain Item", None, shape) is False


def test_multipack_from_bullets_both_shapes():
    bullets = ["Includes 6 pack of refills", "Made in USA"]
    assert get_multipack_udf("Plain Item", bullets, None) is True
    assert get_multipack_udf("Plain Item", json.dumps(bullets), None) is True


def test_multipack_title_branch_still_works():
    assert get_multipack_udf("Medline Gauze, 150/Box", None, None) is True
    assert get_multipack_udf("Single Desk Lamp", None, None) is False


def test_multipack_never_raises_on_junk():
    for junk in (None, "", "{not json", 42, [1, 2, 3]):
        assert get_multipack_udf("Item", junk, junk) in (True, False)


# ---------------------------------------------------------------------------
# warning — _extract_warning_bullets
# ---------------------------------------------------------------------------

def test_warning_bullets_are_found_in_both_shapes():
    bullets = ["Ergonomic grip", "WARNING: Contains small parts", "Prop 65 compliant"]
    for shape in (bullets, json.dumps(bullets)):
        out = _extract_warning_bullets(shape)
        assert out is not None
        assert "WARNING: Contains small parts" in out
        assert "Prop 65 compliant" in out
        assert "Ergonomic grip" not in out


def test_warning_bullets_none_when_nothing_matches():
    for shape in (["Blue", "Lightweight"], json.dumps(["Blue", "Lightweight"])):
        assert _extract_warning_bullets(shape) is None


@pytest.mark.parametrize("junk", [None, "", "{not json", 42])
def test_warning_bullets_junk_is_none(junk):
    assert _extract_warning_bullets(junk) is None


def test_warning_bullets_skip_flame_words():
    bullets = ["Flame resistant for life of garment", "Non-flammable", "FR certified"]
    assert _extract_warning_bullets(bullets) is None


# ---------------------------------------------------------------------------
# warning — _resolve_warning
# ---------------------------------------------------------------------------

def resolve(supercategory="Safety Supplies", specs=None, bullets=None, **hazard):
    """_resolve_warning with no hazard data unless given."""
    fields = dict.fromkeys([
        "prop_65_ind", "wercs_p65_warning_txt", "wercs_p65_chem_txt", "wercs_p651_ind",
        "hazmat_cd", "proper_shipping_nm", "web_category_nm", "sds_document_url",
        "hazard_primary_label_txt", "other_restrictions_txt",
        "battery_ind", "wercs_batt_ind", "aerosol_ind", "sds_required_ind",
    ])
    fields.update(hazard)
    return _resolve_warning(supercategory, None, bullets, specs, **fields)


@pytest.mark.parametrize("supercategory", [None, "Decor"])
def test_hazard_data_warns_in_any_category(supercategory):
    assert resolve(supercategory, hazmat_cd="Y", proper_shipping_nm="Lighters") == (
        "Hazmat Warning", "HAZMAT WARNING: Lighters")


def test_aerosol_flag_gives_the_flammable_label():
    assert resolve(aerosol_ind="Y")[0] == "Flammable / Aerosol Warning"


@pytest.mark.parametrize("nm, val", [
    ("Flame Resistant", "Flame Resistant"), ("Flame Retardant", "Yes"), ("Flammability", "Non-Flammable"),
])
def test_flame_specs_are_not_a_warning(nm, val):
    for shape in both_shapes([spec(nm, val)]):
        assert resolve(specs=shape) == (None, None)


def test_prop_65_spec_still_warns():
    for shape in both_shapes([spec("Prop 65", "Yes"), spec("Flame Resistant", "Yes")]):
        assert resolve(specs=shape) == ("Prop 65 - Chemical Warning", "Prop 65: Yes")


def test_written_flammable_warning_keeps_its_text():
    bullets = ["Flame resistant fabric", "WARNING: Flammable. Keep away from heat."]
    assert resolve(bullets=bullets) == (
        "Product Safety Warning", "WARNING: Flammable. Keep away from heat.")


def test_text_rules_still_need_a_listed_category():
    assert resolve("Decor", bullets=["WARNING: Contains small parts"]) == (None, None)


@pytest.mark.parametrize("supercategory", [None, "Decor", "Safety Supplies"])
def test_sds_link_in_any_category(supercategory):
    url = get_warning_url_udf(supercategory, None, None, None, None, None, " https://example.com/sds.pdf ")
    assert url == "https://example.com/sds.pdf"


# ---------------------------------------------------------------------------
# gender — _resolve_gender is defined inside add_lifecycle_features, so exercise
# the parsing contract it depends on directly.
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("value,expected", [
    ("Women", "female"), ("Female", "female"), ("Girl (child)", "female"),
    ("Men", "male"), ("Male", "male"), ("Boy (child)", "male"),
    ("Unisex", None),
])
def test_gender_spec_values_are_reachable(value, expected):
    """
    _resolve_gender lowercases the value and matches these exact sets. The bug
    was never the matching — it was that _spec_values returned [] so the loop
    never ran. Pin that the attribute is now visible in every shape.
    """
    female = {"women", "female", "woman", "girl", "girls", "female/girl",
              "girl/female", "girl (child)"}
    male = {"men", "male", "man", "boy", "boys", "male/boy", "boy/male", "boy (child)"}

    for shape in both_shapes([spec("Gender", value)]):
        parsed = _spec_values(shape)
        assert parsed, "gender attribute must be visible to _resolve_gender"
        nm, val = parsed[0]
        assert "gender" in nm.lower()
        val = val.lower()
        resolved = "female" if val in female else "male" if val in male else None
        assert resolved == expected
