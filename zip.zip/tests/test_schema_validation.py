"""
Schema validation layer — validate_table_schema (step 1) and the decisions
align_table_schema (step 2) makes on top of it.

Spark cannot start locally (pyspark 3.5 vs Python 3.14), so the session is a
fake that only answers what these functions ask of it: does the table exist,
what is its schema, and what got written where. The rewrite's column
projection (_conform_columns) needs a JVM, so it is replaced by a recorder and
the tests assert on the column list it was given — which is exactly the
decision under test.
"""

import json
import re
from datetime import datetime, timedelta, timezone

import pytest
from pyspark.sql.types import (
    ArrayType, BooleanType, IntegerType, LongType, MapType, NullType, StringType,
    StructField, StructType,
)

import utils
from utils import (
    SchemaDriftError, align_table_schema, schema_align_enabled,
    validate_table_schema,
)

TABLE = "cat.sch.product_reviews_faq_enriched_data"

FAQ_V1 = StructType([StructField("q", StringType()), StructField("a", StringType()),
                     StructField("legacy", StringType())])
FAQ_V2 = StructType([StructField("q", StringType()), StructField("a", StringType())])


def schema(*fields):
    return StructType([StructField(n, t) for n, t in fields])


LLM_RUN = schema(
    ("item_id", StringType()), ("faq_json", FAQ_V2),
    ("has_high_severity_issue", BooleanType()), ("top_issue_keys", ArrayType(StringType())),
)
KEYWORD_ONLY_RUN = schema(("item_id", StringType()), ("faq_json", FAQ_V2))


class _Writer:
    def __init__(self, spark, df):
        self.spark, self.df = spark, df

    def format(self, _):
        return self

    def mode(self, _):
        return self

    def option(self, *_):
        return self

    def saveAsTable(self, name):
        self.spark.writes.append(name)
        self.spark.write_confs.append(dict(self.spark.conf.values))
        self.spark.tables[name] = _FakeDF(self.spark, self.df.schema, self.df.rows)


class _FakeDF:
    def __init__(self, spark, schema_, rows):
        self.spark, self.schema, self.rows = spark, schema_, rows

    def count(self):
        return self.rows

    @property
    def write(self):
        return _Writer(self.spark, self)


class _Catalog:
    def __init__(self, spark):
        self.spark = spark

    def tableExists(self, name):
        return name in self.spark.tables


class _Rows:
    def __init__(self, rows):
        self.rows = rows

    def collect(self):
        return self.rows


class _Conf:
    def __init__(self):
        self.values = {}

    def get(self, key, default=None):
        return self.values.get(key, default)

    def set(self, key, value):
        self.values[key] = value

    def unset(self, key):
        self.values.pop(key, None)


class FakeSpark:
    """
    ALTER statements are recorded, not parsed. `schema_after_alter` is the
    schema the table should have once they have run (None leaves it as it
    was, simulating an ALTER that did not achieve a match); `alter_error`
    makes the first ALTER raise.
    """

    def __init__(self, tables=None, rows=184_000, schema_after_alter=None, alter_error=None):
        self.tables = {n: _FakeDF(self, s, rows) for n, s in (tables or {}).items()}
        self.writes, self.sql_calls, self.write_confs = [], [], []
        self.catalog = _Catalog(self)
        self.conf = _Conf()
        self.properties = {}
        self.schema_after_alter, self.alter_error = schema_after_alter, alter_error

    def table(self, name):
        return self.tables[name]

    @property
    def alters(self):
        return [s for s in self.sql_calls if s.startswith("ALTER TABLE") and "ADD COLUMNS" in s]

    def sql(self, stmt):
        self.sql_calls.append(stmt)
        if stmt.startswith("DROP TABLE IF EXISTS "):
            self.tables.pop(stmt.split()[-1], None)
        if stmt.startswith("SHOW TBLPROPERTIES "):
            props = self.properties.get(stmt.split()[-1], {})
            return _Rows([{"key": k, "value": v} for k, v in props.items()])
        if stmt.startswith("ALTER TABLE") and "SET TBLPROPERTIES" in stmt:
            key, value = re.search(r"\('([^']*)' = '(.*)'\)$", stmt).groups()
            self.properties.setdefault(stmt.split()[2], {})[key] = value.replace("\\'", "'")
            return None
        if stmt.startswith("ALTER TABLE"):
            if self.alter_error:
                raise self.alter_error
            if self.schema_after_alter is not None:
                self.tables[stmt.split()[2]].schema = self.schema_after_alter


@pytest.fixture
def conform_calls(monkeypatch):
    """Replace the JVM-bound projection and value counts; record the final column list."""
    calls = []

    def fake_conform(df, final_fields):
        calls.append(final_fields)
        return _FakeDF(df.spark, StructType([StructField(n, t) for n, t in final_fields]), df.rows)

    monkeypatch.setattr(utils, "_conform_columns", fake_conform)
    monkeypatch.setattr(utils, "_count_values", lambda df, cols: (df.rows, {c: df.rows for c in cols}))
    return calls


# --- step 1: validate_table_schema -----------------------------------------

def test_validate_pass_is_read_only():
    spark = FakeSpark({TABLE: LLM_RUN})
    result = validate_table_schema(spark, TABLE, LLM_RUN)
    assert result.status == "PASS"
    assert spark.writes == [] and spark.sql_calls == []


def test_validate_new_table():
    spark = FakeSpark()
    assert validate_table_schema(spark, TABLE, LLM_RUN).status == "NEW_TABLE"


def test_validate_reports_struct_change_as_retype():
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("faq_json", FAQ_V1))})
    result = validate_table_schema(spark, TABLE, KEYWORD_ONLY_RUN)
    assert result.status == "MISMATCH"
    assert [n for n, _, _ in result.retyped] == ["faq_json"]
    assert spark.writes == []


def test_validate_ignores_nullability():
    nullable = StructType([StructField("item_id", StringType(), True)])
    required = StructType([StructField("item_id", StringType(), False)])
    spark = FakeSpark({TABLE: nullable})
    assert validate_table_schema(spark, TABLE, required).status == "PASS"


def test_evolve_keeps_columns_the_run_did_not_produce():
    # R1: a keyword-only run omits the issue scalars. That is not a mismatch
    # in evolve mode — the columns are reported as kept.
    spark = FakeSpark({TABLE: LLM_RUN})
    result = validate_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, mode="evolve")
    assert result.status == "PASS"
    assert set(result.kept) == {"has_high_severity_issue", "top_issue_keys"}
    assert result.removed == ()


def test_strict_reports_missing_columns_as_removed():
    spark = FakeSpark({TABLE: LLM_RUN})
    result = validate_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, mode="strict")
    assert result.status == "MISMATCH"
    assert set(result.removed) == {"has_high_severity_issue", "top_issue_keys"}


def test_overlap_counts_only_retypes():
    master = schema(("item_id", StringType()), ("faq_json", FAQ_V1), ("other", LongType()))
    staged = schema(("item_id", StringType()), ("faq_json", FAQ_V1), ("new_col", LongType()))
    spark = FakeSpark({TABLE: master})
    assert validate_table_schema(spark, TABLE, staged, mode="overlap").status == "PASS"


def test_unknown_mode_rejected():
    with pytest.raises(ValueError):
        validate_table_schema(FakeSpark({TABLE: LLM_RUN}), TABLE, LLM_RUN, mode="loose")


# --- step 2: align_table_schema decisions ----------------------------------

def test_align_does_nothing_on_pass(conform_calls):
    spark = FakeSpark({TABLE: LLM_RUN})
    assert align_table_schema(spark, TABLE, LLM_RUN, enabled=True) is False
    assert spark.writes == [] and conform_calls == []


def test_align_r1_keyword_only_run_drops_nothing(conform_calls):
    # The exact R1 scenario: before the fix (strict), this rewrote the table
    # without the scalars. Evolve must not touch it at all.
    spark = FakeSpark({TABLE: LLM_RUN})
    assert align_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, enabled=True) is False
    assert spark.writes == []


def test_align_evolve_rewrite_keeps_table_only_columns(conform_calls):
    # A real change (faq_json reshaped) on a keyword-only day: the table is
    # rewritten, and the scalars survive the rewrite.
    table_schema = schema(
        ("item_id", StringType()), ("faq_json", FAQ_V1),
        ("has_high_severity_issue", BooleanType()),
    )
    spark = FakeSpark({TABLE: table_schema})
    assert align_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, enabled=True) is True

    final_names = [n for n, _ in conform_calls[0]]
    assert final_names == ["item_id", "faq_json", "has_high_severity_issue"]
    assert spark.tables[TABLE].schema["faq_json"].dataType == FAQ_V2
    assert spark.writes == [f"{TABLE}__schema_align_stg", TABLE]
    assert f"{TABLE}__schema_align_stg" not in spark.tables


def test_align_strict_drops_columns(conform_calls):
    spark = FakeSpark({TABLE: LLM_RUN})
    assert align_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, mode="strict", enabled=True)
    assert [n for n, _ in conform_calls[0]] == ["item_id", "faq_json"]


def test_align_disabled_raises_without_writing(conform_calls):
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("faq_json", FAQ_V1))})
    with pytest.raises(SchemaDriftError, match="faq_json"):
        align_table_schema(spark, TABLE, KEYWORD_ONLY_RUN, enabled=False)
    assert spark.writes == [] and conform_calls == []


def test_align_default_follows_config_switch(monkeypatch, conform_calls):
    monkeypatch.setitem(utils._schema_align_switch, "enabled", False)
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("faq_json", FAQ_V1))})
    with pytest.raises(SchemaDriftError):
        align_table_schema(spark, TABLE, KEYWORD_ONLY_RUN)
    assert spark.writes == []


def test_align_new_table_is_noop(conform_calls):
    spark = FakeSpark()
    assert align_table_schema(spark, TABLE, LLM_RUN, enabled=True) is False
    assert spark.writes == []


# --- step 2: additions in place (metadata only) ----------------------------

FAQ_V2_PLUS = StructType([StructField("q", StringType()), StructField("a", StringType()),
                          StructField("source_url", StringType())])


def statements_for(existing, target, mode="evolve"):
    spark = FakeSpark({TABLE: existing})
    validation = validate_table_schema(spark, TABLE, target, mode=mode)
    return utils._additive_alter_statements(TABLE, existing, target, validation)


def test_alter_new_struct_field_placed_after_its_sibling():
    existing = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2_PLUS))
    assert statements_for(existing, target) == [
        f"ALTER TABLE {TABLE} ADD COLUMNS (`faq_json`.`source_url` string AFTER `a`)"
    ]


def test_alter_new_first_field_uses_first():
    target_struct = StructType([StructField("id", LongType())] + FAQ_V2.fields)
    statements = statements_for(schema(("faq_json", FAQ_V2)), schema(("faq_json", target_struct)))
    assert statements == [f"ALTER TABLE {TABLE} ADD COLUMNS (`faq_json`.`id` bigint FIRST)"]


def test_alter_field_inside_array_of_structs():
    existing = schema(("issues", ArrayType(FAQ_V2)))
    target = schema(("issues", ArrayType(FAQ_V2_PLUS)))
    assert statements_for(existing, target) == [
        f"ALTER TABLE {TABLE} ADD COLUMNS (`issues`.`element`.`source_url` string AFTER `a`)"
    ]


def test_alter_new_top_level_column_with_struct_type():
    existing = schema(("item_id", StringType()))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    assert statements_for(existing, target) == [
        f"ALTER TABLE {TABLE} ADD COLUMNS (`faq_json` STRUCT<`q`: string, `a`: string>)"
    ]


@pytest.mark.parametrize("existing, target", [
    # struct field removed (faq_json 13 -> 4 fields)
    (schema(("faq_json", FAQ_V1)), schema(("faq_json", FAQ_V2))),
    # a nested type change (string -> bigint) is not done in place
    (schema(("n", StringType()), ("c", StructType([StructField("x", StringType())]))),
     schema(("n", StringType()), ("c", StructType([StructField("x", LongType())])))),
    # existing fields reordered
    (schema(("faq_json", FAQ_V2)),
     schema(("faq_json", StructType([FAQ_V2.fields[1], FAQ_V2.fields[0]])))),
])
def test_non_additive_changes_get_no_alter(existing, target):
    assert statements_for(existing, target) is None


def test_strict_drop_gets_no_alter():
    assert statements_for(LLM_RUN, KEYWORD_ONLY_RUN, mode="strict") is None


def test_align_additions_alter_without_rewrite(conform_calls):
    existing = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2_PLUS), ("score", LongType()))
    spark = FakeSpark({TABLE: existing}, schema_after_alter=target)

    assert align_table_schema(spark, TABLE, target, enabled=True) is True
    assert len(spark.alters) == 2
    assert spark.writes == [] and conform_calls == []


def test_align_rewrites_when_alter_fails(conform_calls):
    existing = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2_PLUS))
    spark = FakeSpark({TABLE: existing}, alter_error=RuntimeError("DELTA_UNSUPPORTED"))

    assert align_table_schema(spark, TABLE, target, enabled=True) is True
    assert spark.writes == [f"{TABLE}__schema_align_stg", TABLE]


def test_align_rewrites_when_alter_leaves_a_mismatch(conform_calls):
    existing = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2_PLUS))
    spark = FakeSpark({TABLE: existing})  # ALTER "runs" but changes nothing

    assert align_table_schema(spark, TABLE, target, enabled=True) is True
    assert len(spark.alters) == 1
    assert spark.writes == [f"{TABLE}__schema_align_stg", TABLE]


def test_align_disabled_runs_no_alter(conform_calls):
    existing = schema(("item_id", StringType()), ("faq_json", FAQ_V2))
    target = schema(("item_id", StringType()), ("faq_json", FAQ_V2_PLUS))
    spark = FakeSpark({TABLE: existing}, schema_after_alter=target)
    with pytest.raises(SchemaDriftError):
        align_table_schema(spark, TABLE, target, enabled=False)
    assert spark.alters == [] and spark.writes == []


# --- void (untyped NULL) in the code's schema --------------------------------

FACETS = StructType([StructField("pattern", ArrayType(StringType())),
                     StructField("color", ArrayType(StringType()))])


def test_void_column_keeps_the_table_type():
    # A bare F.lit(None) column is "no type this run", not a change to void.
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("n", LongType()))})
    result = validate_table_schema(spark, TABLE, schema(("item_id", StringType()), ("n", NullType())))
    assert result.status == "PASS"


def test_void_nested_field_keeps_the_table_type():
    # univ_attributes' style_facets struct when a facet column is missing.
    code_facets = StructType([StructField("pattern", NullType()),
                              StructField("color", ArrayType(StringType()))])
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("style_facets", FACETS))})
    result = validate_table_schema(
        spark, TABLE, schema(("item_id", StringType()), ("style_facets", code_facets)),
    )
    assert result.status == "PASS"


def test_void_inside_array_and_map_keeps_the_table_type():
    table_schema = schema(("a", ArrayType(LongType())), ("m", MapType(StringType(), LongType())))
    code_schema = schema(("a", ArrayType(NullType())), ("m", MapType(StringType(), NullType())))
    spark = FakeSpark({TABLE: table_schema})
    assert validate_table_schema(spark, TABLE, code_schema).status == "PASS"


def test_new_void_column_is_not_added(conform_calls):
    spark = FakeSpark({TABLE: schema(("item_id", StringType()))})
    code_schema = schema(("item_id", StringType()), ("later", NullType()))
    assert align_table_schema(spark, TABLE, code_schema, enabled=True) is False
    assert spark.alters == [] and spark.writes == []


def test_new_void_struct_field_is_left_out_of_the_migration(conform_calls):
    code_facets = StructType(FACETS.fields + [StructField("finish", NullType())])
    spark = FakeSpark({TABLE: schema(("style_facets", FACETS))})
    assert align_table_schema(spark, TABLE, schema(("style_facets", code_facets)), enabled=True) is False
    assert spark.alters == [] and spark.writes == []


def test_void_does_not_mask_a_real_change(conform_calls):
    # A void field next to a real struct change: the change migrates, the
    # void field keeps its table type through the rewrite.
    table_facets = StructType(FACETS.fields + [StructField("legacy", StringType())])
    code_facets = StructType([StructField("pattern", NullType()),
                              StructField("color", ArrayType(StringType()))])
    spark = FakeSpark({TABLE: schema(("style_facets", table_facets))})
    assert align_table_schema(spark, TABLE, schema(("style_facets", code_facets)), enabled=True)
    assert dict(conform_calls[0])["style_facets"] == FACETS


# --- the rewrite: lost values and partial JSON results -----------------------

def test_rewrite_logs_values_the_new_type_cannot_hold(monkeypatch, conform_calls, caplog):
    counts = iter([(100, {"n": 100}), (100, {"n": 97})])
    monkeypatch.setattr(utils, "_count_values", lambda df, cols: next(counts))
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("n", StringType()))}, rows=100)
    with caplog.at_level("WARNING"):
        assert align_table_schema(
            spark, TABLE, schema(("item_id", StringType()), ("n", IntegerType())), enabled=True,
        )
    assert "n: 3 of 100 non-NULL values lost" in caplog.text
    # Logged, not fatal: the table was still rewritten.
    assert spark.writes == [f"{TABLE}__schema_align_stg", TABLE]


def test_rewrite_counts_only_converted_columns(monkeypatch, conform_calls):
    seen = []

    def fake_count(df, cols):
        seen.append(list(cols))
        return df.rows, {c: df.rows for c in cols}

    monkeypatch.setattr(utils, "_count_values", fake_count)
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("n", LongType()))})
    align_table_schema(spark, TABLE, schema(("item_id", StringType()), ("n", StringType())), enabled=True)
    assert seen == [["n"], ["n"]]


def test_partial_json_results_on_for_staging_write_only(conform_calls):
    spark = FakeSpark({TABLE: schema(("faq_json", FAQ_V1))})
    align_table_schema(spark, TABLE, schema(("faq_json", FAQ_V2)), enabled=True)
    staging_conf, final_conf = spark.write_confs
    assert staging_conf.get(utils._JSON_PARTIAL_RESULTS) == "true"
    assert utils._JSON_PARTIAL_RESULTS not in final_conf
    assert utils._JSON_PARTIAL_RESULTS not in spark.conf.values


def test_partial_json_results_restores_previous_setting(conform_calls):
    spark = FakeSpark({TABLE: schema(("faq_json", FAQ_V1))})
    spark.conf.set(utils._JSON_PARTIAL_RESULTS, "false")
    align_table_schema(spark, TABLE, schema(("faq_json", FAQ_V2)), enabled=True)
    assert spark.conf.get(utils._JSON_PARTIAL_RESULTS) == "false"


def test_roundtrip_json_options_keep_microseconds():
    opts = utils._ROUNDTRIP_JSON_OPTIONS
    assert opts["timestampFormat"].endswith("SSSSSSXXX")
    assert opts["timestampNTZFormat"].endswith("SSSSSS")


# --- column-name case ---------------------------------------------------------

def test_names_match_the_table_case_insensitively():
    # Delta resolves Item_ID and item_id to the same column.
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("score", LongType()))})
    code_schema = schema(("Item_ID", StringType()), ("SCORE", LongType()))
    assert validate_table_schema(spark, TABLE, code_schema).status == "PASS"


def test_case_difference_plus_retype_rewrites_under_the_table_spelling(conform_calls):
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("score", LongType()))})
    code_schema = schema(("Item_ID", StringType()), ("Score", StringType()))
    assert align_table_schema(spark, TABLE, code_schema, enabled=True)
    assert [n for n, _ in conform_calls[0]] == ["item_id", "score"]


def test_nested_field_names_match_case_insensitively():
    spark = FakeSpark({TABLE: schema(("faq_json", FAQ_V2))})
    code_struct = StructType([StructField("Q", StringType()), StructField("A", StringType())])
    assert validate_table_schema(spark, TABLE, schema(("faq_json", code_struct))).status == "PASS"


# --- rewrite-loop guard (retype cooldown) -----------------------------------------

LONG_TABLE = schema(("item_id", StringType()), ("n", LongType()))
STRING_CODE = schema(("item_id", StringType()), ("n", StringType()))


def history_at(spark, hours_ago, old="string", new="bigint"):
    at = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    spark.properties[TABLE] = {
        utils._RETYPE_HISTORY_PROPERTY: json.dumps({"n": {"at": at, "from": old, "to": new}}),
    }


@pytest.fixture
def cooldown(monkeypatch):
    monkeypatch.setitem(utils._schema_align_switch, "retype_cooldown_hours", 24.0)


def test_rewrite_records_the_retype(conform_calls, cooldown):
    spark = FakeSpark({TABLE: LONG_TABLE})
    align_table_schema(spark, TABLE, STRING_CODE, enabled=True)
    history = json.loads(spark.properties[TABLE][utils._RETYPE_HISTORY_PROPERTY])
    assert history["n"]["from"] == "bigint" and history["n"]["to"] == "string"


def test_retype_within_cooldown_is_held(conform_calls, cooldown, caplog):
    # Another writer retyped n string -> bigint an hour ago; this one wants it
    # back to string. That is the loop: keep bigint, no rewrite.
    spark = FakeSpark({TABLE: LONG_TABLE})
    history_at(spark, hours_ago=1)
    with caplog.at_level("WARNING"):
        assert align_table_schema(spark, TABLE, STRING_CODE, enabled=True) is False
    assert spark.writes == [] and conform_calls == []
    assert "rewrite loop" in caplog.text


def test_retype_after_cooldown_goes_ahead(conform_calls, cooldown):
    spark = FakeSpark({TABLE: LONG_TABLE})
    history_at(spark, hours_ago=25)
    assert align_table_schema(spark, TABLE, STRING_CODE, enabled=True) is True
    assert dict(conform_calls[0])["n"] == StringType()


def test_cooldown_zero_turns_the_guard_off(monkeypatch, conform_calls):
    monkeypatch.setitem(utils._schema_align_switch, "retype_cooldown_hours", 0.0)
    spark = FakeSpark({TABLE: LONG_TABLE})
    history_at(spark, hours_ago=1)
    assert align_table_schema(spark, TABLE, STRING_CODE, enabled=True) is True


def test_held_column_does_not_block_other_changes(conform_calls, cooldown):
    # n is held at bigint; the faq_json reshape still rewrites the table.
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("n", LongType()), ("faq_json", FAQ_V1))})
    history_at(spark, hours_ago=1)
    code_schema = schema(("item_id", StringType()), ("n", StringType()), ("faq_json", FAQ_V2))
    assert align_table_schema(spark, TABLE, code_schema, enabled=True) is True
    final = dict(conform_calls[0])
    assert final["n"] == LongType() and final["faq_json"] == FAQ_V2


def test_unreadable_history_does_not_block(conform_calls, cooldown):
    spark = FakeSpark({TABLE: LONG_TABLE})
    spark.properties[TABLE] = {utils._RETYPE_HISTORY_PROPERTY: "not json"}
    assert align_table_schema(spark, TABLE, STRING_CODE, enabled=True) is True


# --- config parsing -------------------------------------------------------------

def config_file(monkeypatch, tmp_path, text):
    cfg = tmp_path / "general.yml"
    cfg.write_text(text)
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    monkeypatch.setattr(utils, "_GENERAL_CONFIG_PATH", str(cfg))


@pytest.mark.parametrize("raw, expected", [
    ('"false"', False), ("'False'", False), ('"true"', True), ("no", False), ("1", True), ("0", False),
])
def test_quoted_and_word_booleans_mean_what_they_say(monkeypatch, tmp_path, raw, expected):
    config_file(monkeypatch, tmp_path, f"schema_align:\n  complex_dtype_only: {raw}\n")
    assert utils.schema_align_complex_dtype_only() is expected


def test_invalid_boolean_falls_back_to_default(monkeypatch, tmp_path, caplog):
    config_file(monkeypatch, tmp_path, "schema_align:\n  complex_dtype_only: maybe\n")
    with caplog.at_level("WARNING"):
        assert utils.schema_align_complex_dtype_only() is False
    assert "not valid" in caplog.text


def test_invalid_yaml_does_not_crash(monkeypatch, tmp_path):
    config_file(monkeypatch, tmp_path, "schema_align: [unclosed\n")
    assert schema_align_enabled() is True
    assert utils.schema_align_complex_dtype_only() is False


@pytest.mark.parametrize("raw, expected", [("12", 12.0), ("0", 0.0), ("-3", 24.0), ("soon", 24.0)])
def test_cooldown_hours_parsing(monkeypatch, tmp_path, raw, expected):
    config_file(monkeypatch, tmp_path, f"schema_align:\n  retype_cooldown_hours: {raw}\n")
    assert utils.schema_align_retype_cooldown_hours() == expected


def test_cooldown_hours_reads_general_yml(monkeypatch):
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    assert utils.schema_align_retype_cooldown_hours() == 24.0


# --- the switch ------------------------------------------------------------

def test_switch_reads_general_yml(monkeypatch):
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    # The repo's general.yml ships with schema_align.enabled: true.
    assert schema_align_enabled() is True


def test_switch_defaults_true_when_file_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    monkeypatch.setattr(utils, "_GENERAL_CONFIG_PATH", str(tmp_path / "missing.yml"))
    assert schema_align_enabled() is True


def test_complex_dtype_only_reads_general_yml(monkeypatch):
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    # The repo's general.yml ships with schema_align.complex_dtype_only: false.
    assert utils.schema_align_complex_dtype_only() is False


def test_complex_dtype_only_defaults_false_when_file_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    monkeypatch.setattr(utils, "_GENERAL_CONFIG_PATH", str(tmp_path / "missing.yml"))
    assert utils.schema_align_complex_dtype_only() is False


def test_complex_dtype_only_true_from_config_skips_scalar_migration(monkeypatch, conform_calls):
    monkeypatch.setitem(utils._schema_align_switch, "complex_dtype_only", True)
    table_schema = schema(("item_id", StringType()), ("n", LongType()))
    code_schema = schema(("item_id", StringType()), ("n", StringType()))
    spark = FakeSpark({TABLE: table_schema})
    utils.validate_before_write(spark, TABLE, code_schema)
    assert spark.writes == [] and conform_calls == []


def test_switch_false(monkeypatch, tmp_path):
    cfg = tmp_path / "general.yml"
    cfg.write_text("schema_align:\n  enabled: false\n")
    monkeypatch.setattr(utils, "_schema_align_switch", {})
    monkeypatch.setattr(utils, "_GENERAL_CONFIG_PATH", str(cfg))
    assert schema_align_enabled() is False


# --- Phase 1: the write helpers validate first ------------------------------

class _StopBeforeWrite(Exception):
    pass


@pytest.fixture
def check_calls(monkeypatch):
    """Record validate_before_write and stop there, so no write code runs."""
    calls = []

    def fake_check(spark, table, schema_, schema_mode="evolve", complex_dtype_only=None):
        calls.append((table, schema_, schema_mode))
        raise _StopBeforeWrite

    monkeypatch.setattr(utils, "validate_before_write", fake_check)
    return calls


class _DF:
    def __init__(self, schema_):
        self.schema = schema_
        self.columns = schema_.fieldNames()


@pytest.mark.parametrize("mode, expected", [
    ("merge", "evolve"), ("append", "evolve"), ("overwrite", "validate-only"),
])
def test_save_data_validates_first(check_calls, mode, expected):
    spark = FakeSpark()
    with pytest.raises(_StopBeforeWrite):
        utils.save_data(_DF(LLM_RUN), spark, table=TABLE, mode=mode, validate_schema=False)
    assert check_calls == [(TABLE, LLM_RUN, expected)]
    assert spark.writes == []


def test_save_data_declared_schema_and_mode(check_calls):
    with pytest.raises(_StopBeforeWrite):
        utils.save_data(_DF(KEYWORD_ONLY_RUN), FakeSpark(), table=TABLE, validate_schema=False,
                        schema_mode="strict", expected_schema=LLM_RUN)
    assert check_calls == [(TABLE, LLM_RUN, "strict")]


def test_incremental_save_data_validates_first(check_calls):
    with pytest.raises(_StopBeforeWrite):
        utils.incremental_save_data(_DF(LLM_RUN), FakeSpark(), table=TABLE, update_fields={})
    assert check_calls == [(TABLE, LLM_RUN, "evolve")]


def test_write_unit_tags_validates_strict_against_declared_schema(check_calls):
    spark = FakeSpark({TABLE: utils.UNIT_TAG_SCHEMA})
    with pytest.raises(_StopBeforeWrite):
        utils.write_unit_tags(spark, _DF(utils.UNIT_TAG_SCHEMA), TABLE, "faq_json")
    assert check_calls == [(TABLE, utils.UNIT_TAG_SCHEMA, "strict")]


def test_validate_before_write_rejects_unknown_mode():
    with pytest.raises(ValueError):
        utils.validate_before_write(FakeSpark({TABLE: LLM_RUN}), TABLE, LLM_RUN, "loose")


def test_validate_only_never_changes_the_table(conform_calls):
    spark = FakeSpark({TABLE: LLM_RUN}, schema_after_alter=KEYWORD_ONLY_RUN)
    utils.validate_before_write(spark, TABLE, KEYWORD_ONLY_RUN, "validate-only")
    assert spark.alters == [] and spark.writes == [] and conform_calls == []


def test_scalar_only_difference_is_migrated(conform_calls):
    # Any dtype change in the code is migrated: the table is rewritten with
    # the code's type, not left to the MERGE's implicit cast.
    table_schema = schema(("item_id", StringType()), ("n", LongType()))
    code_schema = schema(("item_id", StringType()), ("n", StringType()))
    spark = FakeSpark({TABLE: table_schema})
    utils.validate_before_write(spark, TABLE, code_schema)
    assert spark.alters == []
    assert spark.writes == [f"{TABLE}__schema_align_stg", TABLE]
    assert dict(conform_calls[0])["n"] == StringType()
    assert spark.tables[TABLE].schema["n"].dataType == StringType()


def test_rewrite_casts_scalars_and_structs_to_the_code(conform_calls):
    table_schema = schema(("n", LongType()), ("faq_json", FAQ_V1))
    code_schema = schema(("n", StringType()), ("faq_json", FAQ_V2))
    spark = FakeSpark({TABLE: table_schema})
    utils.validate_before_write(spark, TABLE, code_schema)
    final = dict(conform_calls[0])
    assert final["n"] == StringType() and final["faq_json"] == FAQ_V2


def test_complex_to_scalar_change_is_migrated(conform_calls):
    # A struct column the code now writes as a JSON string.
    spark = FakeSpark({TABLE: schema(("item_id", StringType()), ("faq_json", FAQ_V2))})
    utils.validate_before_write(spark, TABLE, schema(("item_id", StringType()), ("faq_json", StringType())))
    assert dict(conform_calls[0])["faq_json"] == StringType()


def test_rewrite_keeps_scalar_types_when_complex_dtype_only(conform_calls):
    # The opt-out still works for a caller that passes complex_dtype_only=True.
    table_schema = schema(("n", LongType()), ("faq_json", FAQ_V1))
    code_schema = schema(("n", StringType()), ("faq_json", FAQ_V2))
    spark = FakeSpark({TABLE: table_schema})
    utils.validate_before_write(spark, TABLE, code_schema, complex_dtype_only=True)
    final = dict(conform_calls[0])
    assert final["n"] == LongType() and final["faq_json"] == FAQ_V2


def test_retype_converges_so_the_next_run_passes(conform_calls):
    # After the rewrite the table matches the code: no rewrite on every run.
    table_schema = schema(("item_id", StringType()), ("n", LongType()))
    code_schema = schema(("item_id", StringType()), ("n", StringType()))
    spark = FakeSpark({TABLE: table_schema})
    utils.validate_before_write(spark, TABLE, code_schema)
    assert validate_table_schema(spark, TABLE, code_schema).status == "PASS"


# --- Phase 3: the second save_data copy (data_pipeline/utils.py) ------------

def _pipeline_utils():
    import os
    import sys
    src = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src")
    if src not in sys.path:
        sys.path.insert(0, src)
    import data_pipeline.utils as pipeline_utils
    return pipeline_utils


@pytest.mark.parametrize("mode, expected", [("merge", "evolve"), ("overwrite", "validate-only")])
def test_second_save_data_validates_first(monkeypatch, mode, expected):
    pipeline_utils = _pipeline_utils()
    calls = []

    def fake_check(spark, table, schema_, schema_mode="evolve", complex_dtype_only=None):
        calls.append((table, schema_, schema_mode))
        raise _StopBeforeWrite

    monkeypatch.setattr(pipeline_utils, "validate_before_write", fake_check)
    spark = FakeSpark({TABLE: LLM_RUN})
    with pytest.raises(_StopBeforeWrite):
        pipeline_utils.save_data(_DF(KEYWORD_ONLY_RUN), spark, table=TABLE, mode=mode)
    assert calls == [(TABLE, KEYWORD_ONLY_RUN, expected)]
    # The old ALTER TABLE DROP COLUMN loop is gone.
    assert not any("DROP COLUMN" in s for s in spark.sql_calls)
