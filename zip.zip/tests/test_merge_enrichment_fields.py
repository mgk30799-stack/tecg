"""The merge task's SQL plumbing: drift check trigger, new columns, history clean-up."""
import os
import re

import pytest
from pyspark.sql.types import IntegerType, StringType, StructField, StructType

import merge_product_enrichments as mpe
from utils import (ALL_BU_DOTCOM_COLUMNS, ALL_BU_DOTCOM_ONLY_COLUMNS, ALL_BU_HIERARCHY_LEVELS,
                   ALL_BU_PRODUCT_COLUMNS)

SQL_FILE = os.path.join(mpe.PROJECT_ROOT, "sql", "merge_product_enrichment_fields.sql")
INCLUSIVE_SQL_FILE = os.path.join(mpe.PROJECT_ROOT, "sql", "merge_product_enrichment_fields_inclusive.sql")


def _sql():
    with open(SQL_FILE) as f:
        return f.read()


class _Table:
    def __init__(self, schema):
        self.schema = schema
        self.columns = [f.name for f in schema.fields]


class _Result:
    def collect(self):
        return [{"num_inserted_rows": 0, "num_updated_rows": 0, "num_deleted_rows": 0,
                 "num_affected_rows": 0}]


class _Catalog:
    def tableExists(self, name):
        return True


class _Spark:
    """Enough of a SparkSession for the statement loop: tables by name, and every SQL run."""

    def __init__(self, tables, fail_on=None):
        self.tables, self.fail_on, self.statements = tables, fail_on, []
        self.catalog = _Catalog()

    def table(self, name):
        return _Table(self.tables[name])

    def sql(self, statement):
        self.statements.append(statement)
        if self.fail_on and self.fail_on in statement:
            raise RuntimeError("boom")
        return _Result()


def _schema(*names):
    return StructType([StructField(n, StringType()) for n in names])


def test_view_is_found_after_comment_lines():
    assert mpe._creates_view("-- Step 1: build\n-- more\nCREATE OR REPLACE TEMPORARY VIEW v AS SELECT 1")
    assert not mpe._creates_view("-- Step 2\nCREATE TABLE IF NOT EXISTS t AS SELECT 1")


def test_insert_list_is_the_update_list_plus_key_and_insert_time():
    sql = _sql()
    assert mpe._merge_insert_columns(sql) - mpe._merge_update_columns(sql) == {"item_id", "row_inserted_at"}
    assert mpe._merge_update_columns(sql) <= mpe._merge_insert_columns(sql)


def test_history_rows_carry_the_run_timestamp():
    sql = _sql()
    assert "__RUN_TS__ AS changed_at" in sql
    assert "CURRENT_TIMESTAMP() AS changed_at" not in sql
    assert re.fullmatch(r"timestamp_micros\(\d{16}\)", mpe.run_timestamp())


def test_new_columns_are_added_before_they_are_read():
    staged = StructType([StructField("item_id", StringType()), StructField("a", StringType()),
                         StructField("b", IntegerType())])
    spark = _Spark({"master": _schema("item_id", "a")})
    assert mpe.add_new_columns(spark, "master", staged, ["a", "b"]) == ["b"]
    assert spark.statements == ["ALTER TABLE master ADD COLUMNS (`b` int)"]
    spark.statements.clear()
    assert mpe.add_new_columns(spark, "master", staged, ["a"]) == []
    assert spark.statements == []


def test_failed_merge_removes_this_runs_history_rows(monkeypatch):
    monkeypatch.setattr(mpe, "assert_merge_covers_staged", lambda spark, sql: None)
    monkeypatch.setattr(mpe, "assert_one_row_per_item", lambda spark, view: None)
    monkeypatch.setattr(mpe, "align_table_schema", lambda *a, **k: False)
    sql = ("-- Step 1\nCREATE OR REPLACE TEMPORARY VIEW enrichment_staged AS SELECT 1;\n"
           "INSERT INTO hist SELECT __HISTORY_STACK__, __RUN_TS__ WHERE __CHANGED_ROWS_T_S__;\n"
           "MERGE INTO master AS target USING enrichment_staged AS source ON target.item_id = source.item_id\n"
           "WHEN MATCHED AND __CHANGED_ROWS_TARGET_SOURCE__ THEN UPDATE SET target.a = source.a\n"
           "WHEN NOT MATCHED THEN INSERT (item_id, a) VALUES (source.item_id, source.a);")
    schema = _schema("item_id", "a")
    spark = _Spark({"enrichment_staged": schema, "master": schema}, fail_on="MERGE INTO")
    with pytest.raises(RuntimeError):
        mpe.merge(spark, sql, "enrichment_staged", "master", "timestamp_micros(1)", assigned=["a"],
                  hist_table="hist", check_drift=True)
    assert spark.statements[1].startswith("INSERT INTO hist") and "timestamp_micros(1)" in spark.statements[1]
    assert spark.statements[-1] == "DELETE FROM hist WHERE changed_at = timestamp_micros(1)"


def _top_level_items(text):
    """Split a SELECT list on the commas that are not inside parentheses."""
    items, depth, current = [], 0, ""
    for ch in text:
        depth += {"(": 1, ")": -1}.get(ch, 0)
        if ch == "," and depth == 0:
            items.append(current.strip())
            current = ""
        else:
            current += ch
    return [i for i in items + [current.strip()] if i]


def _inclusive_columns():
    """The columns inclusive_staged has: product_discovery_data_all's, plus Step 1's own."""
    with open(INCLUSIVE_SQL_FILE) as f:
        sql = mpe._strip_sql_comments(f.read())
    body = sql[sql.index("SELECT") + len("SELECT"):sql.index("FROM {all_products_table}")]
    names = ({"item_id", "in_product_discovery_data"} | set(ALL_BU_PRODUCT_COLUMNS)
             | set(ALL_BU_DOTCOM_ONLY_COLUMNS) | set(ALL_BU_DOTCOM_COLUMNS.values())
             | {f"web_{level}_dotcom" for level in ALL_BU_HIERARCHY_LEVELS})
    for item in _top_level_items(body):
        if item.startswith("p.*"):
            continue
        alias = re.search(r"\bAS\s+(\w+)$", item, re.IGNORECASE)
        names.add((alias.group(1) if alias else item.split(".")[-1]).strip().lower())
    return names


def test_every_master_column_comes_from_the_inclusive_table():
    names = mpe.dotcom_names_in_inclusive()
    inclusive = _inclusive_columns()
    columns = [c for c in mpe._merge_insert_column_list(_sql()) if c not in mpe._MASTER_OWN_COLUMNS]
    assert [c for c in columns if names.get(c, c) not in inclusive] == []
    assert names["pm_price"] == "price_dotcom" and names["store_review_count"] == "review_count_dotcom"
    assert names["quality_grade"] == "quality_grade_dotcom" and names["title"] == "title"


def test_master_merge_writes_the_tags():
    sql = _sql()
    tags = {"seasonality_tags", "body_part_tags", "weather_tags", "event_tags", "room_context_tags",
            "use_case_tags", "audience_tags", "gender", "age_group", "age_restriction",
            "quality_grade", "value_proposition_segment", "tags_updated_at"}
    assert tags <= mpe._merge_update_columns(sql) and tags <= mpe._merge_insert_columns(sql)
    assert "FROM dotcom_slice;" in sql


SELL_UNIT_COLUMNS = ["sell_unit_dimensions", "sell_unit_length", "sell_unit_width", "sell_unit_height",
                     "sell_unit_weight"]


def test_sell_unit_columns_reach_the_master():
    """The package size under its sell_unit_ names: built for Staples.com and for SB-only products,
    carried by product_discovery_data_all, and written by the master's MERGE."""
    with open(os.path.join(mpe.PROJECT_ROOT, "src", "data_pipeline", "discovery_data_loader.py")) as f:
        loader = f.read()
    sql = _sql()
    for c in SELL_UNIT_COLUMNS:
        assert len(re.findall(rf"\bAS {c},", loader)) == 2, c
    assert set(SELL_UNIT_COLUMNS) <= set(ALL_BU_PRODUCT_COLUMNS)
    assert set(SELL_UNIT_COLUMNS) <= mpe._merge_update_columns(sql) & mpe._merge_insert_columns(sql)


def test_short_title_reaches_the_master():
    """short_title, joined into the inclusive table from product_short_titles, is written by the
    master's MERGE too."""
    sql = _sql()
    assert "short_title" in _inclusive_columns()
    assert "short_title" in mpe._merge_update_columns(sql) & mpe._merge_insert_columns(sql)


def test_generated_lists_assign_every_staged_column():
    schema = _schema("item_id", "a", "tags_updated_at")
    spark = _Spark({"staged": schema, "target": schema})
    generated = mpe.generated_sql(spark, "staged", "target", ["a", "tags_updated_at"], "timestamp_micros(1)")
    assert generated["__UPDATE_SET__"] == ("target.`a` = source.`a`,\n  target.`tags_updated_at` = "
                                           "source.`tags_updated_at`,\n  target.row_updated_at = CURRENT_TIMESTAMP()")
    assert generated["__INSERT__"] == (
        "(`item_id`, `a`, `tags_updated_at`, `row_inserted_at`, `row_updated_at`) VALUES "
        "(source.`item_id`, source.`a`, source.`tags_updated_at`, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())")
    # The tags' time moves with the tags, so on its own it never rewrites a row.
    assert "tags_updated_at" not in generated["__CHANGED_ROWS_TARGET_SOURCE__"]


def test_change_check_accepts_the_masters_own_update_list():
    # The master's UPDATE SET also sets row_updated_at, which the staged view does not have.
    schema = _schema("item_id", "a", "source_row_hash")
    spark = _Spark({"enrichment_staged": schema, "master": schema})
    assigned = sorted(mpe._merge_update_columns(
        "WHEN MATCHED THEN UPDATE SET target.a = source.a, target.source_row_hash = source.source_row_hash, "
        "target.row_updated_at = CURRENT_TIMESTAMP() WHEN NOT MATCHED THEN INSERT (item_id) VALUES (source.item_id)"))
    assert assigned == ["a", "row_updated_at", "source_row_hash"]
    generated = mpe.generated_sql(spark, "enrichment_staged", "master", assigned, "timestamp_micros(1)")
    assert "row_updated_at" not in generated["__CHANGED_ROWS_TARGET_SOURCE__"]
    assert spark.statements == []


@pytest.mark.parametrize("path", [SQL_FILE, INCLUSIVE_SQL_FILE])
def test_no_semicolon_inside_a_comment(path):
    # The task splits each file into statements at every semicolon, comments included.
    with open(path) as f:
        commented = [line for line in f if "--" in line and ";" in line.split("--", 1)[1]]
    assert commented == []
