"""The short-title check: what is cleaned, what is rejected, and the main prompt fingerprint.

The examples are real titles ai_extract returned in qa (product_short_titles, 2026-11-10).
"""
import pytest

import extract_product_short_titles as st


@pytest.mark.parametrize("raw, cleaned", [
    ('JAM Paper Shipping Labels, 8 1/2" x 11" (40 chars)', 'JAM Paper Shipping Labels, 8 1/2" x 11"'),
    ('Welcome Home IV Gallery-Wrapped Canvas, 35" x 35" (39 characters)',
     'Welcome Home IV Gallery-Wrapped Canvas, 35" x 35"'),
    ('Trademark Fine Art "Porto and Sherry Sandeman" Canvas 35 x 47" 57 characters',
     'Trademark Fine Art "Porto and Sherry Sandeman" Canvas 35 x 47"'),
    ('Barker Creek School Name Plates 12x3.5" (37 chars: "Barker Creek School Name Plates 12x3.5")',
     'Barker Creek School Name Plates 12x3.5"'),
    ('"Trademark Fine Art \'Dewy Pink Aster\' Wall Art" (25 characters)',
     "Trademark Fine Art 'Dewy Pink Aster' Wall Art"),
    ("  Coastwide   Paper Towels ", "Coastwide Paper Towels"),
])
def test_a_trailing_character_count_is_removed(raw, cleaned):
    assert st.clean_title(raw) == cleaned
    assert st.check_title(raw) == (cleaned, None)


@pytest.mark.parametrize("title", [
    "Garvey 22-77 Labeler Kit, 2-Line, 7 Characters/Line",
    'Stanley Powerlock Tape Rule 1/2" x 12ft',
    "Trademark Fine Art 'I Will III' Canvas",
    "Enchante I Can And I Will Canvas 16x20",
    'National Marker Walk-On Decal, Please Wait, 8", Red/White',
    'Xerox 008R13061 Toner Collection Unit',
    "Tarp",
])
def test_real_titles_are_kept_as_they_are(title):
    assert st.check_title(title) == (title, None)


@pytest.mark.parametrize("raw, issue", [
    ('Mailers 17 1/8 x 11 1/8 x 3"Literature is 10 chars, Mailers is 7 chars. 10+1+7+1+18=37? No. '
     "Let's recount carefully", "ai_notes"),
    ('Miguel Paredes Dancer I Canvas, 16x24" = 41 characters Actually, I need to strip the quote mark '
     "for consistency.", "ai_notes"),
    ('Staedtler Mars Triangular Architect Scale 12" "Preservation Rules: Remove size, dimensions, '
     "capacity, weight, volume", "ai_notes"),
    ("Canvas & & & & & & & & & & & &", "junk"),
    ("...", "no_words"),
    ("", "empty"),
    ("null", "empty"),
    (None, "empty"),
    ("Coastwide Professional Recycled Centerpull Paper Towels, 600 Sheets/Roll", "too_long"),
])
def test_unusable_titles_are_rejected_with_the_reason(raw, issue):
    assert st.check_title(raw) == (None, issue)


def test_the_limit_counts_characters():
    assert st.check_title("A" * 65) == ("A" * 65, None)
    assert st.check_title("A" * 66) == (None, "too_long")
    assert st.check_title("A" * 50, max_chars=40) == (None, "too_long")


def test_a_count_is_removed_before_the_length_is_checked():
    # 64 characters once ' (59 chars)' is removed.
    raw = 'Avery Laser/Inkjet Rectangle Multipurpose Labels, 2-1/4 x 7-3/4" (59 chars)'
    assert st.check_title(raw) == ('Avery Laser/Inkjet Rectangle Multipurpose Labels, 2-1/4 x 7-3/4"', None)


def test_the_repair_prompt_is_only_used_when_asked_for():
    assert st.INSTRUCTIONS_SQL in st.ai_extract_sql("c")
    repair = st.ai_extract_sql("c", st.REPAIR_SCHEMA_SQL, st.REPAIR_INSTRUCTIONS_SQL)
    assert st.REPAIR_INSTRUCTIONS_SQL in repair and st.INSTRUCTIONS_SQL not in repair


def test_the_main_prompt_is_unchanged():
    # The main prompt is part of every row's source_hash: changing it sends every product (about
    # 260,000 per environment) back to ai_extract. Change it only on purpose, then update this value.
    assert st.PROMPT_HASH == "380406fc81771bd357177f4eb5327878fe81a3dcc3c7af19d4dbfb4218be7139"
