"""
Shared test bootstrap for the enrichment modules.

Two jobs:

1. Put ``src/data_pipeline/enrichment`` on sys.path. Those modules import each
   other flatly (``from utils import ...``) because Databricks runs them as
   standalone scripts, not as a package — so tests have to use the same flat
   import style, and there is no importable package path to use instead.

2. Stub the heavy runtime-only dependencies when they are absent. The functions
   under test here are plain Python — they take strings, ints and dicts, and
   never touch Spark — but they live in modules whose import line pulls in
   pandas and databricks.connect. Without these stubs the whole suite is
   unrunnable anywhere except a Databricks cluster, which in practice means it
   never runs at all.

   The stubs are deliberately inert: they satisfy the import statement and
   nothing more. Any test that actually needed Spark or pandas behaviour would
   fail loudly on an AttributeError rather than pass against a fake.
"""

import os
import sys
import types

_ENRICHMENT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "src", "data_pipeline", "enrichment",
)
if _ENRICHMENT_DIR not in sys.path:
    sys.path.insert(0, _ENRICHMENT_DIR)


def _stub(name, **attrs):
    """Register an inert module under `name` only if it is not installed."""
    try:
        __import__(name)
        return
    except ImportError:
        pass

    module = types.ModuleType(name)
    for attr, value in attrs.items():
        setattr(module, attr, value)
    sys.modules[name] = module

    # A dotted name needs its parents registered too, and needs to be reachable
    # as an attribute of its parent, or `from a.b import C` still fails.
    parts = name.split(".")
    for depth in range(1, len(parts)):
        parent_name = ".".join(parts[:depth])
        if parent_name not in sys.modules:
            sys.modules[parent_name] = types.ModuleType(parent_name)
        setattr(sys.modules[parent_name], parts[depth], sys.modules[".".join(parts[:depth + 1])])


class _Missing:
    """Placeholder for a class that is imported by name but never instantiated."""


_stub("pandas", Series=_Missing, DataFrame=_Missing)
_stub("numpy", ndarray=_Missing)
_stub("databricks.connect", DatabricksSession=_Missing)
