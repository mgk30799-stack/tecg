# Tagging Configuration Architecture — Complete Setup Guide

## 📁 File Structure

```
config/
├── tagging_base_config.yml       # Shared infrastructure (inherited by all tags)
├── tagging_registry.yml          # Master registry (orchestrates all tags)
└── tags/
	├── event_config.yml          # Event/occasion tagging
	├── weather_config.yml        # Weather applicability tagging
	└── seasonality_config.yml    # Seasonal demand pattern tagging
```

---

## 🎯 Quick Reference

### Base Config (`tagging_base_config.yml`)
- **Purpose:** Single source of truth for shared defaults
- **Contains:** Error handling, match behavior, LLM config, output processing
- **Use:** All tag configs inherit from this via `extends: ../tagging_base_config.yml`
- **Maintenance:** Update here once, applies to all tags

| Setting | Value | Rationale |
|---------|-------|-----------|
| `applicable: false` (default) | Opt-in not opt-out | Prevent hallucination |
| `multi_label: true` (default) | Allow flexibility | Most tags benefit |
| `confidence_threshold: 0.6` (default) | Moderate bar | Balance safety/coverage |
| `validation_strict_mode: true` | Fail loudly | Catch config errors early |

---

### Event Config (`tags/event_config.yml`)
- **Purpose:** Tag products with occasion/event context
- **Applicable Products:** ~40% (catering, gifts, weddings, etc.)
- **Key Features:**
  - Event category matrix eliminates duplication
  - 3 rule types: non-eventable, multi-candidate, fixed-event
  - LLM prevents hallucination via narrow candidate sets
- **Confidence Threshold:** 0.6 (standard)
- **Typical Cost:** ~$0.06 per 1,000 products

**Example:**
```yaml
- match: { web_department_nm: "Plates, Cups & Cutlery" }
  applicable: true
  candidate_parent_events: [Parties & Social Gatherings, Weddings, ...]
```

---

### Weather Config (`tags/weather_config.yml`)
- **Purpose:** Identify weather-dependent products and conditions
- **Applicable Products:** ~30% (outdoor, garden, rain gear, etc.)
- **Key Features:**
  - Weather category matrix maps conditions → product types
  - 3 rule types: non-applicable, multi-candidate, fixed-weather
  - Higher confidence threshold (0.7) for safety
- **Confidence Threshold:** 0.7 (stricter than events)
- **Typical Cost:** ~$0.04 per 1,000 products
- **Update Frequency:** Monthly (patterns evolve with seasons)

**Example:**
```yaml
- match: { web_department_nm: "Outdoor Furniture" }
  applicable: true
  candidate_weather: [Outdoor, Heat & Summer, Cold & Winter, Rain]
```

---

### Seasonality Config (`tags/seasonality_config.yml`)
- **Purpose:** Predict seasonal demand peaks for inventory planning
- **Applicable Products:** ~45% (school supplies, holidays, weddings, etc.)
- **Key Features:**
  - 8 seasonal periods (Back to School, Holiday, Wedding Season, etc.)
  - Includes `demand_multiplier` (e.g., 3.5x normal demand)
  - Includes `inventory_recommendation` (stock strategy)
  - Integrates with weather tag via `seasonality_hints`
- **Confidence Threshold:** 0.65 (more interpretive)
- **Typical Cost:** ~$0.05 per 1,000 products
- **Output Schema:** Extends base with `demand_multiplier` and `inventory_recommendation`

**Example:**
```yaml
- match: { web_department_nm: "School Supplies" }
  applicable: true
  candidate_seasons: [Back to School (Aug-Sep), Spring Semester (Jan-Feb)]
  demand_multiplier: 3.5
```

---

### Registry (`tagging_registry.yml`)
- **Purpose:** Orchestrate all tags and manage system-wide behavior
- **Key Sections:**
  1. **Tag Registry:** Lists all tags, versions, owners, priorities
  2. **Tag Assignment:** Which tags run for which product categories
  3. **Execution Config:** Sequential/parallel, error handling, timeouts
  4. **Output Config:** Where results go (Database, S3, Elasticsearch)
  5. **Validation:** Quality checks and coverage monitoring
  6. **Monitoring:** Metrics, logging, alerts
  7. **Integrations:** Cross-system dependencies (weather→seasonality, seasonality→inventory)

**Tag Assignment Example:**
```yaml
"School Supplies":
  tags: ["event", "seasonality"]
  reason: "Strong seasonal patterns; events (graduations, holidays)"
```

---

## 🚀 How It Works

### Pipeline Execution Flow

```
1. Load tagging_registry.yml
   ↓
2. Cascade to tagging_base_config.yml (common defaults)
   ↓
3. Load tag-specific configs (event, weather, seasonality)
   ├─ Each inherits from base_config.yml
   ├─ Override defaults as needed (e.g., seasonality: confidence_threshold = 0.65)
   └─ Define tag-specific rules and category matrices
   ↓
4. For each product:
   a. Look up product category in tag_assignment
   b. Run assigned tags in priority order (event=100, seasonality=90, weather=80)
   c. Match product against rules (most specific wins)
   d. If applicable: call LLM with candidate labels
   e. Validate output, filter by confidence, post-process
   f. Store results in all backends (DB, S3, Elasticsearch)
   ↓
5. Monitor: track metrics, check quality, alert on issues
```

---

## ✅ Validation Checklist

Before running the pipeline:

- [ ] All event configs exist: `event_taxonomy.yaml`
- [ ] All weather configs exist: `weather_taxonomy.yaml`
- [ ] All seasonality configs exist: `seasonality_taxonomy.yaml`
- [ ] LLM API keys configured for gpt-4
- [ ] Test cases pass: `python validate_tagging_configs.py`

---

## 🔧 Common Tasks

### Add a New Tag
1. Create `config/tags/my_new_tag_config.yml`
2. Set `extends: ../tagging_base_config.yml`
3. Define tag-specific defaults, category matrix, rules
4. Add entry to `tags:` section in `tagging_registry.yml`
5. Add assignments to `tag_assignment:` for applicable product categories
6. Update `integrations:` if this tag feeds to other systems

### Change a Confidence Threshold
- For one tag: Edit the `defaults` section in that tag's config
- For all tags: Edit the `defaults` section in `tagging_base_config.yml`

### Add a New Product Category to Event Tagging
1. Update `event_category_matrix` in `tags/event_config.yml`
2. Add new rule if needed (or update existing rule's `candidate_parent_events`)
3. Update `tag_assignment` in `tagging_registry.yml`

### Monitor Tag Performance
- Check metrics in Prometheus at `http://prometheus:9090/targets`
- Alerts routed to: Email, Slack (#product-tagging-alerts), PagerDuty
- Dashboard: [Link to Grafana dashboard]

---

## 🔗 Integration Points

```
┌─────────────────────┐
│  Products Database  │
│  (Source)           │
└──────────┬──────────┘
		   │
		   ▼
┌──────────────────────────────┐
│  Tagging Pipeline            │
│  ├─ Event Tag                │
│  ├─ Weather Tag              │
│  └─ Seasonality Tag          │
└──────┬───────────┬────────┬───┘
	   │           │        │
	   ▼           ▼        ▼
   Database      S3      Elasticsearch
	   │           │        │
	   ├─→ Inventory Planning
	   ├─→ Marketing Automation (Events)
	   └─→ Search/Recommendations
```

---

## 📝 Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| `Tag config inherits correctly but overrides don't apply` | YAML syntax error (indentation) | Check `defaults:` section indentation matches base config |
| `LLM returns labels not in candidate set` | Invalid output | Config sets `invalid_label_action: drop_and_return_none_label` → check LLM prompt |
| `Coverage drops below 30%` | Too many non-applicable rules | Review rules, consider broadening candidate sets or adjusting thresholds |
| `Confidence scores always 1.0` | LLM not instructed to provide confidence | Verify `output_schema` requires `confidence` field |
| `Tags running in wrong order` | Priority misconfigured | Check `priority:` in `tagging_registry.yml` tags list |

---

## 📚 Related Files

- `event_taxonomy.yaml` — Event parent/child categories
- `weather_taxonomy.yaml` — Weather condition taxonomy
- `seasonality_taxonomy.yaml` — Seasonal period taxonomy

