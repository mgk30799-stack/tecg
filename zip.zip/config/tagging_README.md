# Tagging Configuration — Restructuring Summary

## 🎯 What Was Done

The tagging configuration has been **restructured into a scalable, multi-tag architecture** that supports events, weather, seasonality, and future tags.

### ✅ Completed Tasks

1. **Created Base Configuration** (`tagging_base_config.yml`)
   - Centralized defaults, error handling, LLM config
   - Shared across ALL tag types
   - Eliminates duplication

2. **Restructured Event Config** (`tags/event_config.yml`)
   - Now inherits from base config
   - Removed 100+ lines of duplicate code
   - Kept all event-specific logic (category matrix, rules, taxonomy)

3. **Created Weather Config Template** (`tags/weather_config.yml`)
   - 7 weather categories (Indoor, Outdoor, Rain, Snow, Heat, Cold, All Weather)
   - Confidence threshold: 0.7 (stricter for safety)
   - Ready to use or customize

4. **Created Seasonality Config Template** (`tags/seasonality_config.yml`)
   - 8 seasonal periods (Back to School, Holiday, Wedding, etc.)
   - Includes demand multiplier for inventory planning
   - Confidence threshold: 0.65 (more interpretive)
   - Integrates with weather tag

5. **Created Master Registry** (`tagging_registry.yml`)
   - Orchestrates all tags
   - Defines which tags apply to which product categories
   - Execution order: Event (priority 100), Seasonality (90), Weather (80)
   - Output configuration: Database, S3, Elasticsearch
   - Monitoring & alerts

6. **Created Documentation**
   - `TAGGING_SETUP_GUIDE.md` — Setup instructions and quick reference
   - `IMPLEMENTATION_CHECKLIST.md` — Step-by-step implementation plan

---

## 📁 New File Structure

```
config/
├── tagging_base_config.yml           ← Shared infrastructure (155 lines)
├── tagging_registry.yml              ← Master orchestrator (280 lines)
├── TAGGING_SETUP_GUIDE.md            ← Setup guide & quick reference
├── IMPLEMENTATION_CHECKLIST.md       ← Implementation plan & todos
└── tags/                             ← Tag-specific configs
	├── event_config.yml              ← Event tagging (350 lines)
	├── weather_config.yml            ← Weather tagging (250 lines)
	└── seasonality_config.yml        ← Seasonality tagging (300 lines)
```

---

## 🔑 Key Design Principles

### 1. **Inheritance Model**
```yaml
# Base config defines common behavior
tagging_base_config.yml
  ├─ defaults (multi_label, confidence_threshold, etc.)
  ├─ error_handling
  ├─ match_behavior
  ├─ output_processing
  └─ llm_config

# Each tag inherits and customizes
tags/event_config.yml
  extends: ../tagging_base_config.yml
  # Override confidence_threshold if needed
  # Add tag-specific rules, categories, taxonomy
```

### 2. **Category Matrix Pattern**
Instead of repeating candidate lists in every rule:
```yaml
# OLD (duplicate)
- match: { web_department_nm: "Balloons" }
  candidate_events: [Weddings, Parties, Life Events]
- match: { web_department_nm: "Wrapping Supplies" }
  candidate_events: [Weddings, Parties, Life Events, Gifting]

# NEW (centralized, single source of truth)
event_category_matrix:
  "Weddings":
	web_departments: [Balloons, Wrapping Supplies, ...]

# Rules just reference the matrix
- match: { web_department_nm: "Balloons" }
  candidate_parent_events: [Weddings, Parties, ...]
```

### 3. **Specificity-Based Rule Matching**
```
Priority: web_class_nm > web_department_nm > web_category_nm > web_supercategory_nm

Example: "Wedding Glassware"
├─ web_class_nm "Wedding Glassware" matches? ✓ YES
│  └─ fixed_sub_event: "Wedding Reception" (no LLM call needed)
└─ (department/category checks skipped; rule already matched)
```

### 4. **Fail-Safe Defaults**
```yaml
defaults:
  applicable: false    # Default = don't tag (opt-in, not opt-out)
  confidence_threshold: 0.6  # Moderate bar prevents over-tagging
```

---

## 🔀 How It Works (Simple Flow)

```
1. Product arrives (e.g., "Plates, Cups & Cutlery")
   ↓
2. Load tagging_registry.yml
   ↓
3. Look up product in tag_assignment → ["event", "weather", "seasonality"]
   ↓
4. For each tag:
   a. Load tag config (inherits from base)
   b. Match product against rules (most specific wins)
   c. If applicable: Call LLM with candidates
   d. Validate output, filter by confidence
   ↓
5. Store results in database/S3/Elasticsearch
   ↓
6. Done! Product now tagged with events, weather, seasonality
```

---

## ✨ Benefits of This Architecture

### ✅ **DRY (Don't Repeat Yourself)**
- Shared base config eliminates duplication
- Category matrices are single source of truth
- Maintenance cost: edit once, applies everywhere

### ✅ **Scalable**
- Adding new tags is trivial (create new config in `tags/`)
- No changes to existing configs needed
- Pipeline handles all tags uniformly

### ✅ **Maintainable**
- Clear ownership (each tag has owner team)
- Self-documenting (each rule has reason/notes)
- Versioned and audited (detailed changelog)

### ✅ **Flexible**
- Override defaults per tag (e.g., weather threshold=0.7 vs default 0.6)
- Override per rule (e.g., high-confidence rules use different threshold)
- Inheritance model allows cascading behavior

### ✅ **Observable**
- Monitoring & alerts built in
- Metrics tracked: products tagged, LLM costs, latency, errors
- Quality checks: coverage monitoring, confidence validation

### ✅ **Testable**
- Test cases in each config
- CI/CD can validate all configs before deployment
- Mock LLM responses for deterministic testing

---

## 🚀 Next Steps

### Immediate (Day 1)
1. Review the configs:
   - `config/tagging_base_config.yml` — Understand inheritance
   - `config/tags/event_config.yml` — Already formatted, ready to use
   - `config/tagging_registry.yml` — Understand orchestration

2. Review documentation:
   - `TAGGING_SETUP_GUIDE.md` — Quick reference

### Short Term (Week 1)
3. Create taxonomy files:
   - `event_taxonomy.yaml` — Event parent/child mappings
   - `weather_taxonomy.yaml` — Weather conditions
   - `seasonality_taxonomy.yaml` — Seasonal periods

4. Set up infrastructure:
   - Database table for tagged products

### Medium Term (Week 2-3)
5. Implement tagging pipeline:
   - Config loader
   - Rule matcher
   - LLM caller
   - Output validator & storage

6. Test & validate:
   - Unit tests for each module
   - Run test cases from configs
   - Staging environment testing

### Long Term (Week 4+)
7. Deploy to production:
   - Canary deployment (5% traffic, 24h monitoring)
   - Roll out to 100%
   - Monitor metrics

8. Handoff:
   - Document runbook
   - Train team
   - Set up support channels

---

## 📊 Config Size Comparison

| File | Lines | Sections | Purpose |
|------|-------|----------|---------|
| `tagging_base_config.yml` | 155 | 6 | Shared defaults |
| `tags/event_config.yml` | 350 | 11 | Event tagging |
| `tags/weather_config.yml` | 250 | 10 | Weather tagging |
| `tags/seasonality_config.yml` | 300 | 10 | Seasonality tagging |
| `tagging_registry.yml` | 280 | 7 | System orchestration |



---

## 🎓 Learning Resources

In the generated documentation:

- **`TAGGING_SETUP_GUIDE.md`** — Start here for quick understanding
  - File structure
  - Each tag's purpose & defaults
  - Integration points
  - Troubleshooting tips

- **`IMPLEMENTATION_CHECKLIST.md`** — Ready to implement?
  - Phase-by-phase breakdown
  - Concrete code examples
  - Timeline estimates
  - Success criteria

---

## ❓ Common Questions

**Q: Do I have to use all three tags?**
A: No. Enable/disable tags in `tagging_registry.yml`. Weather and seasonality are optional.

**Q: Can I customize the candidate lists per product category?**
A: Yes. Modify rules in each tag config's `rules:` section, or update the category matrices.

**Q: How do I add a new seasonal period?**
A: Add entry to `event_category_matrix` in `seasonality_config.yml`, then add rule that uses it.

**Q: What if I have a custom tag type?**
A: Create `tags/my_custom_tag_config.yml` with `extends: ../tagging_base_config.yml`. Add to `tagging_registry.yml`.

**Q: Can different product categories use different confidence thresholds?**
A: Yes. Set `confidence_threshold` per rule (override the global default).

---
**Configuration version: 1.1** | **Last updated: 2026-08-15** | **Status: Ready for Implementation**
