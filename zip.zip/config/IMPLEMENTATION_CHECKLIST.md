# Implementation Checklist

## ✅ Phase 1: Configuration Setup (COMPLETE)

- [x] Created `config/tagging_base_config.yml` — Shared infrastructure
- [x] Created `config/tags/event_config.yml` — Event-specific config
- [x] Created `config/tags/weather_config.yml` — Weather-specific config
- [x] Created `config/tags/seasonality_config.yml` — Seasonality-specific config
- [x] Created `config/tagging_registry.yml` — Master orchestrator
- [x] Created `config/TAGGING_SETUP_GUIDE.md` — Setup guide
- [x] Created `config/ARCHITECTURE_DIAGRAM.md` — Visual architecture
- [x] Created `config/event_taxonomy.yaml`
- [x] Created `config/weather_taxonomy.yaml`
- [x] Created `config/seasonality_taxonomy.yaml`

## 💻 Phase 2: Pipeline Implementation (TODO)

### [ ] Config Loader Module

**Responsibilities:**
- Load and parse YAML configs
- Validate schema and inheritance
- Merge base config with tag-specific overrides
- Return structured config objects

**Language:** Python / Go / Java (your choice)

**Key Functions:**
```python
def load_tagging_registry(path: str) -> RegistryConfig
def load_tag_config(tag_name: str) -> TagConfig
def validate_all_configs() -> bool
def get_effective_config(tag_name: str) -> TagConfig  # with inheritance applied
```

### [ ] Rule Matcher Module

**Responsibilities:**
- Match product against rules in priority order
- Implement specificity hierarchy (web_class > department > category > supercategory)
- Handle tiebreaker rules
- Return matching rule or default

**Key Functions:**
```python
def match_rule(product: Product, config: TagConfig) -> Rule
def is_applicable(product: Product, config: TagConfig) -> bool
def get_candidate_events(product: Product, config: TagConfig) -> List[str]
```

### [ ] LLM Caller Module

**Responsibilities:**
- Build LLM prompt using candidate labels
- Call GPT-4 API
- Validate JSON response
- Implement retry logic and caching
- Log token usage for cost tracking

**Key Functions:**
```python
def call_llm_for_labeling(product: Product, config: TagConfig, candidates: List[str]) -> LLMResponse
def validate_llm_output(response: dict, schema: dict) -> bool
def get_cached_response(product_id: str, tag_type: str) -> Optional[LLMResponse]
def cache_response(product_id: str, tag_type: str, response: LLMResponse) -> None
```

### [ ] Output Validator Module

**Responsibilities:**
- Filter labels by confidence threshold
- Validate labels exist in taxonomy
- Deduplication
- Case normalization
- Sorting

**Key Functions:**
```python
def validate_output(output: dict, config: TagConfig) -> bool
def post_process_output(output: dict, config: TagConfig) -> dict
def filter_by_confidence(labels: List[Label], threshold: float) -> List[Label]
```

### [ ] Storage & Output Module

**Responsibilities:**
- Store tagged products in database
- Archive to S3
- Index in Elasticsearch
- Handle batch operations
- Retry on failures

**Key Functions:**
```python
def store_tagged_product(product: Product, tags: Dict[str, List[str]]) -> bool
def batch_store_tagged_products(products: List[Product]) -> int  # returns count stored
def archive_to_s3(data: bytes, tag_type: str, date: str) -> str  # returns S3 path
def index_in_elasticsearch(product: Product, tags: dict) -> bool
```

### [ ] Monitoring & Metrics Module

**Responsibilities:**
- Track metrics (products tagged, LLM calls, costs, latency)
- Send to Prometheus
- Log errors
- Alert on issues

**Key Functions:**
```python
def record_metric(metric_name: str, value: float, labels: dict) -> None
def log_error(error_type: str, message: str, context: dict) -> None
def check_coverage_alert(products_tagged: int, total_products: int) -> None
```

---

## 🧪 Phase 3: Testing & Validation (TODO)

### [ ] Unit Tests

Create tests for each module:

```python
# test_config_loader.py
def test_load_tagging_base_config()
def test_load_event_config_with_inheritance()
def test_validate_config_schema()
def test_detect_missing_taxonomy_ref()

# test_rule_matcher.py
def test_match_web_class_priority()
def test_match_department_fallback()
def test_default_when_no_match()
def test_tiebreaker_error()

# test_llm_caller.py
def test_build_prompt_with_candidates()
def test_validate_llm_json_output()
def test_retry_on_invalid_json()
def test_cache_hit_on_identical_product()

# test_output_validator.py
def test_filter_by_confidence()
def test_deduplicate_labels()
def test_normalize_case()
def test_validate_against_taxonomy()

# test_integration.py
def test_end_to_end_event_tagging()
def test_end_to_end_weather_tagging()
def test_end_to_end_seasonality_tagging()
```

### [ ] Config Test Cases

Run test cases defined in each config:

```bash
python -m tagging.validate \
  --config config/tagging_registry.yml \
  --run-test-cases \
  --fail-on-error
```

**Expected output:**
```
Event Config:
  ✓ Wedding Glassware → Wedding Reception (fixed label)
  ✓ Plates, Cups & Cutlery → 6 candidate events (LLM)
  ✓ Seasonal Decor → 2 candidate events (LLM)
  ✓ Staples Gift Cards → No Event (non-applicable)

Weather Config:
  ✓ Winter Boots → Cold & Winter (fixed weather)
  ✓ Outdoor Furniture → 4 candidate weather (LLM)
  ✓ Office Supplies → 2 candidate weather (LLM)

Seasonality Config:
  ✓ Christmas Decorations → Holiday Season (fixed season)
  ✓ School Supplies → 2 candidate seasons (LLM)
  ✓ Office Supplies → 4 candidate seasons (LLM)

All 12 test cases PASSED ✓
```

### [ ] Staging Environment Test

- Load sample 10,000 products
- Run through tagging pipeline
- Verify all outputs in database
- Check S3 and Elasticsearch
- Monitor metrics

---

## 📊 Phase 4: Infrastructure Setup (TODO)

### [ ] Database Schema

Create a table or merge to existing table for tagged products:

```sql
CREATE TABLE products_tagged (
  product_id VARCHAR(50) PRIMARY KEY,
  event_labels JSONB,              -- {"labels": [...], "confidence": 0.X}
  weather_tags JSONB,
  seasonality_tags JSONB,
  tagged_at TIMESTAMP,
  updated_at TIMESTAMP,
  INDEX idx_product_id (product_id),
  INDEX idx_tagged_at (tagged_at)
);
```