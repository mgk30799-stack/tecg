from __future__ import annotations

import argparse
import difflib
import json
import sys
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
WORKBOOK = ROOT / "taxonomy_config_tags_APPROVED.xlsx"
CONFIG = ROOT / "config"


def _clean(values) -> list[str]:
    seen, out = set(), []
    for v in values:
        t = str(v).strip()
        if t and t.lower() != "nan" and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _scalar(value: str) -> str:
    """Plain, unless YAML would not read it back as the same string."""
    text = str(value)
    try:
        if yaml.safe_load("- " + text) == [text]:
            return text
    except yaml.YAMLError:
        pass
    return json.dumps(text)


def _flat_yaml(labels: list[str]) -> str:
    return "".join(f"- {_scalar(l)}\n" for l in labels)


def _nested_yaml(groups: dict[str, list[str]]) -> str:
    parts: list[str] = []
    for parent in sorted(groups):
        parts.append(f"{_scalar(parent)}:\n")
        parts += [f"  - {_scalar(s)}\n" for s in sorted(groups[parent])]
        parts.append("\n")
    return "".join(parts).rstrip("\n") + "\n"


def build() -> dict[Path, str]:
    """-> {path: desired content}. Pure; writes nothing."""
    xl = pd.ExcelFile(WORKBOOK)
    out: dict[Path, str] = {}

    # --- seasonality: 29 approved labels ---------------------------------
    se = _clean(xl.parse("seasonality_proposal")["lable"].dropna())
    out[CONFIG / "seasonality_taxonomy.yaml"] = _flat_yaml(se)

    # --- weather: 9 approved labels --------------------------------------
    we_df = xl.parse("weather_condition_proposal")
    we_col = next(c for c in we_df.columns if we_df[c].dtype == object)
    we = _clean(we_df[we_col].dropna())
    out[CONFIG / "weather_taxonomy.yaml"] = _flat_yaml(we)

    # --- events: sub-categories grouped under their parents ---------------
    ev = xl.parse("events_updated").dropna(subset=["parent_category", "sub_category"])
    groups: dict[str, list[str]] = {}
    for r in ev.itertuples():
        groups.setdefault(str(r.parent_category).strip(), []).append(str(r.sub_category).strip())
    groups = {p: _clean(v) for p, v in groups.items()}
    out[CONFIG / "event_taxonomy.yaml"] = _nested_yaml(groups)

    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true", help="regenerate the files")
    ap.add_argument("--check", action="store_true", help="verify only; non-zero if they differ")
    args = ap.parse_args()
    if not (args.write or args.check):
        ap.error("pass --write or --check")

    drift = 0
    for path, desired in build().items():
        current = path.read_text(encoding="utf-8") if path.exists() else ""
        if current == desired:
            print(f"  ok      {path.relative_to(ROOT)}")
            continue
        drift += 1
        if args.write:
            path.write_text(desired, encoding="utf-8")
            print(f"  WROTE   {path.relative_to(ROOT)}")
        else:
            print(f"  DRIFT   {path.relative_to(ROOT)}")
            for line in list(difflib.unified_diff(
                    current.splitlines(), desired.splitlines(),
                    "committed", "workbook", lineterm=""))[:14]:
                print(f"            {line}")

    if args.check and drift:
        print(f"\n{drift} taxonomy file(s) no longer match the approved workbook.")
        print("Run: python scripts/sync_taxonomy_from_workbook.py --write")
        return 1
    print(f"\n{'regenerated' if args.write else 'checked'} "
          f"{len(build())} taxonomy files against {WORKBOOK.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
