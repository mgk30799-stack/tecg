-- ============================================================
-- product_faq_tags — one-time backfill of question_id + question_submission_tms
-- ============================================================
--
-- WHY THIS EXISTS
--   Rows written before utils.resolve_question_keys became reachable from
--   faq_tagging carry question_id = NULL, and question_submission_tms did not
--   exist on the table at all. The pipeline resolves both natively now, but
--   only for rows it re-tags — and re-tagging exists rows costs a full LLM
--   pass. This does the same join in SQL for zero model cost.
--
--   Run it ONCE per environment, AFTER the pipeline has run at least once (that
--   is what adds the question_submission_tms column). New rows need nothing from here.
--
-- THE MATCH RULES ARE THE PIPELINE'S
--   The site filter, the nvl(details, summary) text and the latest-per-text
--   dedupe are utils.resolve_question_keys', expressed as SQL. If you change
--   one, change both — a rule that drifts between them produces two different
--   question_ids for one question and nothing errors.
--
-- IT JOINS ON (item_id, question), NOT ON tag_id VIA A FRESH EXPLODE.
--   tag_id is POSITIONAL ("{item_id}_{n}") and q_and_a's element order comes
--   from COLLECT_LIST with no ORDER BY (discovery_data_loader's f_a_q CTE), so
--   it is not guaranteed stable across reprocessing runs — see the STABILITY
--   CAVEAT on utils.question_id_expr. Re-exploding and joining on tag_id would
--   hand any drifted row ANOTHER question's QUESTION_ID: populated, plausible,
--   and wrong, with nothing to signal it.
--
--   product_faq_tags already stores the question TEXT, which does not drift.
--   Joining on it needs no explode and cannot be affected by reordering, so it
--   is correct whether or not the array was ever reshuffled. That is why
--   product_discovery_data does not appear in this file at all.
--
-- REPLACE mld01_ml_de WITH THE TARGET CATALOG: _de dev, _qe qa, _pe prod.
-- ============================================================


-- ------------------------------------------------------------
-- Step 1: resolve each tagged question back to its product_web_question row
-- ------------------------------------------------------------
CREATE OR REPLACE TEMPORARY VIEW faq_key_backfill AS
WITH wq_dedup AS (
    -- Latest source row per (product, question text).
    --
    -- REQUIRED, not an optimisation. Several source rows can share one
    -- (product, question text); without this the join fans out and the MERGE
    -- below fails with "multiple source rows matched". desc_nulls_last so a
    -- NULL-timestamp duplicate never outranks a real one.
    --
    -- KNOWN LIMIT: two source questions with identical text collapse onto the
    -- surviving row's QUESTION_ID and SUBMISSION_TMS. q_and_a has no id and its
    -- element order comes from COLLECT_LIST with no ORDER BY, so nothing can
    -- tell them apart. The pipeline logs how many rows this affects.
    SELECT
        CAST(product_id AS STRING)        AS product_id,
        CAST(question_id AS STRING)       AS question_id,
        question_text,
        CAST(submission_tms AS TIMESTAMP) AS question_submission_tms
    FROM (
        SELECT
            wq.product_id,
            wq.question_id,
            -- The loader writes nvl(details, summary) into q_and_a, so matching
            -- on question_details_txt alone loses every question that fell back
            -- to the summary text. Mirror it exactly.
            NVL(wq.question_details_txt, wq.question_summary_txt) AS question_text,
            wq.submission_tms,
            ROW_NUMBER() OVER (
                PARTITION BY wq.product_id,
                             NVL(wq.question_details_txt, wq.question_summary_txt)
                ORDER BY wq.submission_tms DESC NULLS LAST
            ) AS rn
        FROM snowflake_edh.product.product_web_question wq
        -- The same slice discovery_data_loader wrote into q_and_a. Scanning
        -- wider lets a row from another site win latest-per-text and supply a
        -- QUESTION_ID for a question it was never the source of — populated,
        -- plausible, and wrong.
        WHERE wq.site_id = 'STAPLESUS'
    )
    WHERE rn = 1
)
SELECT
    t.tag_id,
    t.item_id,
    t.question,
    w.question_id,
    w.question_submission_tms
FROM mld01_ml_de.product.product_faq_tags t
-- LEFT so an unmatched question keeps its row and is visible in step 2's match
-- rate. Nothing is substituted for a missing question_id — a "{item_id}_{n}"
-- string written there is indistinguishable from a real Snowflake id.
LEFT JOIN wq_dedup w
       ON t.item_id  = w.product_id
      AND t.question = w.question_text;


-- ------------------------------------------------------------
-- Step 2: check the match rate BEFORE writing anything
-- ------------------------------------------------------------
-- A pct_resolved near zero means the join is broken (site filter, text
-- expression, or item_id/product_id typing), not that the data is empty. Stop
-- and fix it rather than merging.
SELECT
    COUNT(*)                                        AS total_questions,
    COUNT(question_id)                              AS resolved,
    ROUND(100.0 * COUNT(question_id) / COUNT(*), 2) AS pct_resolved
FROM faq_key_backfill;


-- ------------------------------------------------------------
-- Step 3: MERGE into product_faq_tags
-- ------------------------------------------------------------
-- Only question_id and question_submission_tms are in the SET list.
-- question_tags, question_keyword, conflict_flag, answers_meta, model_endpoint
-- and created_at_ts are untouched, so no LLM output is disturbed.
--
-- WHERE question_id IS NOT NULL is on the MERGE SOURCE, not the target: no
-- product_faq_tags row is ever dropped. Unmatched rows simply keep NULL rather
-- than being rewritten with NULL, which also means re-running this can never
-- blank a value the pipeline resolved.
MERGE INTO mld01_ml_de.product.product_faq_tags AS t
USING (
    SELECT tag_id, question_id, question_submission_tms
    FROM faq_key_backfill
    WHERE question_id IS NOT NULL
) AS s
   ON t.tag_id = s.tag_id
WHEN MATCHED THEN UPDATE SET
    t.question_id             = s.question_id,
    t.question_submission_tms = s.question_submission_tms,
    t.last_updated_ts         = CURRENT_TIMESTAMP();


-- ------------------------------------------------------------
-- Step 4: confirm nothing else moved
-- ------------------------------------------------------------
-- with_qid and with_tms must be equal (both come from one resolved source row).
-- with_tags and oldest_created must match what they were before the merge.
SELECT
    COUNT(*)                       AS rows,
    COUNT(question_id)             AS with_qid,
    COUNT(question_submission_tms) AS with_tms,
    COUNT(question_tags)           AS with_tags,
    MIN(created_at_ts)             AS oldest_created
FROM mld01_ml_de.product.product_faq_tags;
