-- ============================================================
-- Inclusive Product Master Enriched: every product of both sites
-- ============================================================
-- product_discovery_data_all with the six enrichments, the short titles and the tags of product_tagging_all. A
-- column with a value per site ends in _dotcom or _contract. product_master_enriched is written
-- from this table as its Staples.com slice (sql/merge_product_enrichment_fields.sql).

-- Step 1: Join every product with its enrichments and tags
CREATE OR REPLACE TEMPORARY VIEW inclusive_staged AS
SELECT
  p.* EXCEPT (image_url, additional_image_urls),
  -- Image fallback: if the primary image is missing, promote the first additional image.
  COALESCE(NULLIF(TRIM(p.image_url), ''), NULLIF(TRIM(SPLIT(p.additional_image_urls, ',')[0]), '')) AS image_url,
  CASE
    WHEN NULLIF(TRIM(p.image_url), '') IS NULL
         AND NULLIF(TRIM(p.additional_image_urls), '') IS NOT NULL
    THEN
      CASE
        WHEN SIZE(SPLIT(p.additional_image_urls, ',')) <= 1 THEN ''
        ELSE ARRAY_JOIN(
               SLICE(
                 TRANSFORM(SPLIT(p.additional_image_urls, ','), x -> TRIM(x)),
                 2,
                 SIZE(SPLIT(p.additional_image_urls, ','))
               ),
               ', '
             )
      END
    ELSE p.additional_image_urls
  END AS additional_image_urls,

  -- Enrichment columns
  claims.extracted_claims_json, claims.claims, claims.elec_spec_json, claims.highlights_json,
  lcd.lifecycle_status AS lifecycle_status_dotcom, lcd.lifecycle_status_contract,
  lcd.multipack, lcd.warning, lcd.warning_url,
  univ.color, univ.material, univ.pattern, univ.finish, univ.collection_name,
  univ.warranty_json, univ.warranty_type, univ.support_warranty_duration_months,
  univ.compliance_tags_json,
  comp.compatible_item_ids AS compatible_item_ids_dotcom,
  comp.compatibility_json AS compatibility_json_dotcom,
  comp.compatible_item_ids_contract, comp.compatibility_json_contract,
  faq.issue_signals_json, faq.issue_summary_json,
  faq.faq_json AS faq_json_dotcom, faq.faq_summary_json AS faq_summary_json_dotcom,
  faq.faq_json_contract, faq.faq_summary_json_contract,

  -- Capacity Indicator (unified)
  to_json(named_struct(
    'value', cap.capacity_value,
    'unit', cap.capacity_unit,
    'type', cap.capacity_type,
    'raw_text', cap.capacity_raw_text,
    'source', cap.capacity_source
  )) AS capacity_info,

  -- Tags (product_tagging_all). Price tier and quality grade are ranked per site.
  tags.seasonality_tags, tags.body_part_tags, tags.weather_tags, tags.event_tags,
  tags.room_context_tags, tags.use_case_tags, tags.audience_tags,
  tags.gender, tags.age_group, tags.age_restriction,
  tags.quality_grade_dotcom, tags.value_proposition_segment_dotcom,
  tags.quality_grade_contract, tags.value_proposition_segment_contract,
  tags.tags_updated_at,
  st.short_title

FROM {all_products_table} p
LEFT JOIN {claims_table} claims ON p.item_id = claims.item_id
LEFT JOIN {lifecycle_table} lcd ON p.item_id = lcd.item_id
LEFT JOIN {universal_attributes_table} univ ON p.item_id = univ.item_id
LEFT JOIN {compatibility_table} comp ON p.item_id = comp.item_id
LEFT JOIN {review_mining_table} faq ON p.item_id = faq.item_id
LEFT JOIN {capacity_indicator_table} cap ON p.item_id = cap.item_id
LEFT JOIN {tags_table} tags ON p.item_id = tags.item_id
LEFT JOIN {short_titles_table} st ON p.item_id = st.item_id;


-- Step 2: Ensure the target table exists, with a change feed for the syncs
CREATE TABLE IF NOT EXISTS {product_master_enriched_inclusive}
TBLPROPERTIES (delta.enableChangeDataFeed = true)
AS SELECT *, CURRENT_TIMESTAMP() AS row_inserted_at, CURRENT_TIMESTAMP() AS row_updated_at
FROM inclusive_staged WHERE 1 = 0;


SET spark.databricks.delta.schema.autoMerge.enabled = true;

-- Step 3: Rewrite only rows where a column really changed (order of lists and maps ignored),
-- add new products and remove products that left. The column lists are generated from
-- inclusive_staged, so every column of Step 1 is written.
MERGE WITH SCHEMA EVOLUTION INTO {product_master_enriched_inclusive} AS target
USING inclusive_staged AS source
ON target.item_id = source.item_id
WHEN MATCHED AND __CHANGED_ROWS_TARGET_SOURCE__ THEN UPDATE SET __UPDATE_SET__
WHEN NOT MATCHED THEN INSERT __INSERT__
WHEN NOT MATCHED BY SOURCE THEN DELETE;
