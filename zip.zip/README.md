# Staples Agentic Commerce Data Platform

This repository contains the Databricks data and indexing layer for the Product Discovery Agentic Commerce B2B platform. It includes both the data pipeline infrastructure and the product enrichment system.

## Project Overview

This project is an agentic B2B e-commerce system focused on Staples.com product catalog enrichment. The system enriches product data to support AI agents in helping business customers with product discovery, procurement, and recommendations.

It is configured as a Databricks Asset Bundle named `staples_agentic_commerce_data` and currently deploys five notebook-driven jobs:

- Product discovery vector index sync (`notebooks/sync_product_discovery_index.py`)
- Product documents vector index sync (`notebooks/sync_product_documents_index.py`)
- Product details vector index sync (`notebooks/sync_product_detail_index.py`)
- Product graph streaming sync (`notebooks/sync_product_graph.py`)
- Product lookup streaming sync (`notebooks/sync_product_lookup.py`)

Future scope includes a graph curation ETL pipeline and enrichment pipelines as part of the broader intelligence layer.

## Prerequisites

- Python 3.12+
- Conda for environment management
- Databricks CLI v0.218.0 or newer (tested with v0.270.0)
- Access to the dev workspace: `https://adb-4144455588799812.12.azuredatabricks.net/`

## Getting Started

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd agentic_commerce
   ```

2. **Create and activate the Conda environment:**
   ```bash
   conda env create -f environment.yml
   conda activate dbconnect_312
   ```

3. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

### Configuration

#### Databricks CLI Authentication

1. Authenticate Databricks CLI:
   ```bash
   databricks auth login --host https://adb-4144455588799812.12.azuredatabricks.net/
   ```

2. Validate the bundle:
   ```bash
   databricks bundle validate -t dev
   ```

3. Deploy bundle resources:
   ```bash
   databricks bundle deploy -t dev
   ```

#### Environment Variables & Databricks Connection

This project can be run both locally and directly on Databricks, and the connection to the Spark cluster is managed automatically. The `src/utils/databricks_utils.py` file contains a `get_spark_session` function that handles this logic:

- **When running on a Databricks job cluster**, it uses the native Spark session available in the environment.
- **When running locally**, it uses Databricks Connect to connect to a remote cluster defined in your `.env` file.

1. **Create the `.env` file:**
   ```bash
   cp .env.example .env
   ```

2. **Fill in your credentials** for local development:
   ```env
   # Databricks
   DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
   DATABRICKS_TOKEN=your-personal-access-token
   DATABRICKS_CLUSTER_ID=your-cluster-id

   # OpenAI (for LLM enrichment)
   OPENAI_API_KEY=your-openai-key
   ```

#### Configuration Files (`.yml`)

The project uses `.yml` files for various configuration purposes:

- **`databricks.yml`**: Bundle definition, target configuration, and shared variables. Centralized location for all table names, schema/catalog, index names, model endpoints, and graph runtime settings.
- **`config/general.yml`**: The main configuration file for the pipelines. It defines the source and output tables used by discovery_data_loader and enrichment scripts.
- **`config/claims_config.yml`**: Contains specific rules and regex patterns for the `claims` enrichment pipeline, used to extract structured marketing claims from unstructured text.
- **`resources/agentic_commerce_data_pipeline.yml`**: Defines the Databricks Asset Bundle (DAB) configuration. This specifies the workflow orchestration, job clusters, and the sequence of enrichment tasks.

## Data Pipeline Architecture

The project uses a **medallion architecture** with three layers:

- **Bronze Layer**: Raw product data from Staples.com (scraped/API data)
- **Silver Layer**: Cleaned and standardized product data
- **Gold Layer**: Enriched product data with business context, ready for AI agents

### Database Schema

Uses **Databricks Unity Catalog** with the following structure:

```
Catalog: dev_agentic_commerce_catalog
├── bronze_schema: Raw scraped data
│   └── staples_products_raw
├── silver_schema: Cleaned data
│   └── staples_products_cleaned
└── gold_schema: Enriched data
	├── lifecycle_enriched
	├── room_context_enriched
	├── review_mining_enriched
	├── universal_attributes_enriched
	├── compatibility_enriched
	├── claims_enriched
	├── product_discovery_data_enriched
	└── product_enrichments_merged (final table)
```

## Project Structure

```
agentic_commerce/
├── requirements.txt                    # Python dependencies
├── README.md                           # Documentation
├── databricks.yml                      # Bundle definition
├── config/                             # Configuration files
│   ├── general.yml
│   └── claims_config.yml
├── resources/
│   ├── jobs.yml                        # Job resources
│   └── agentic_commerce_data_pipeline.yml
├── sql/                                # SQL queries
├── notebooks/                          # Notebook sources
│   ├── common/
│   │   └── shared.py                   # Shared utilities
│   ├── sync_product_discovery_index.py
│   ├── sync_product_documents_index.py
│   ├── sync_product_detail_index.py
│   ├── sync_product_graph.py
│   └── sync_product_lookup.py
├── src/                                # Source code
│   ├── data_pipeline/
│   │   ├── ingestion/                  # Data scraping/loading
│   │   │   └── staples_scraper.py
│   │   ├── enrichment/                 # Enrichment pipelines
│   │   │   ├── lifecycle_enrichment.py
│   │   │   ├── room_context_enrichment.py
│   │   │   ├── review_mining_enrichment.py
│   │   │   ├── universal_attributes_enrichment.py
│   │   │   ├── compatibility_enrichment.py
│   │   │   ├── claims_enrichment.py
│   │   │   ├── product_discovery_data_enrichment.py
│   │   │   └── merge_product_enrichments.py
│   │   ├── discovery_data_loader.py    # Data loading logic
│   │   └── validation/                 # Data quality checks
│   ├── agents/                         # AI agent logic (future)
│   ├── api/                            # REST API (future)
│   └── utils/                          # Shared utilities
│       └── databricks_utils.py
├── tests/                              # Unit and integration tests
├── docs/                               # Documentation
└── .env.example                        # Environment variables template
```

## Usage

### Run Jobs via Databricks CLI

Run product discovery index sync:
```bash
databricks bundle run -t dev sync_product_discovery_index
```

Run product documents index sync:
```bash
databricks bundle run -t dev sync_product_documents_index
```

Run product details index sync:
```bash
databricks bundle run -t dev sync_product_detail_index
```

Run graph streaming sync:
```bash
databricks bundle run -t dev sync_product_graph
```

Short titles run as the `enrichment_short_titles` task of the Agentic Commerce Data Pipeline (`src/data_pipeline/enrichment/extract_product_short_titles.py`). They are written to `product_short_titles` and joined into `product_master_enriched_inclusive_t` and its Staples.com slice `product_master_enriched_t` by `enrichment_fields`. Every title is checked before it is saved: a title over `max_title_chars` (65), with the model's notes in it, or without real words is saved as NULL with the reason in `short_title_issue`, and goes to a stricter repair prompt at most `max_repair_attempts` times. The main prompt is part of every row's `source_hash`, so changing it regenerates every title; `tests/test_short_titles.py` pins it.

Run lookup streaming sync:
```bash
databricks bundle run -t dev sync_product_lookup
```

### Run Data Pipelines as Python Scripts

The data pipelines can be executed as Python scripts. They will automatically connect to Databricks using the method described above.

#### Discovery Data Loader

Pivots product attributes to create category-specific tables:

```bash
python src/data_pipeline/discovery_data_loader.py
```

#### Enrichment Pipelines

Run specific enrichment pipelines:

```bash
# Claims enrichment
python src/data_pipeline/enrichment/claims_enrichment.py

# Lifecycle enrichment
python src/data_pipeline/enrichment/lifecycle_enrichment.py

# Room context enrichment
python src/data_pipeline/enrichment/room_context_enrichment.py

# Review mining enrichment
python src/data_pipeline/enrichment/review_mining_enrichment.py

# Universal attributes enrichment
python src/data_pipeline/enrichment/universal_attributes_enrichment.py

# Compatibility enrichment
python src/data_pipeline/enrichment/compatibility_enrichment.py

# Product discovery data enrichment
python src/data_pipeline/enrichment/product_discovery_data_enrichment.py

# Merge all enrichments
python src/data_pipeline/enrichment/merge_product_enrichments.py
```

## Data Components

### Implemented Enrichment Pipelines

Current enrichment pipelines enrich product data for the following categories:

1. **Chairs** - Office seating, ergonomic chairs
2. **Jan/San** - Janitorial and sanitation supplies
3. **Printers** - Office printers, MFPs, supplies
4. **Luggage** - Business travel bags
5. **Breakroom** - Coffee makers, kitchen supplies
6. **Hydration** - Water coolers, filtration systems

#### 1. Data Ingestion

- **`staples_scraper.py`**: Scrapes product data from Staples.com
  - Handles pagination and rate limiting
  - Extracts product details, specifications, reviews
  - Saves raw data to Bronze layer

#### 2. Data Enrichment

- **`lifecycle_enrichment.py`**: Product lifecycle stages (new, mature, end-of-life)
- **`room_context_enrichment.py`**: Room/space suitability (office, breakroom, warehouse)
- **`review_mining_enrichment.py`**: Extracts insights from customer reviews
- **`universal_attributes_enrichment.py`**: Standardizes common attributes across categories
- **`compatibility_enrichment.py`**: Product compatibility and integration data
- **`claims_enrichment.py`**: Marketing claims and certifications
- **`product_discovery_data_enrichment.py`**: Discovery-focused metadata
- **`merge_product_enrichments.py`**: Merges all enrichment tables into final Gold layer

### Data Exposure by System

This section documents what each downstream system is expected to expose from this repo:

```mermaid
flowchart LR
	A["Product Dim Table<br/>catalog.schema.product_dim_table_name"]
	B["Product VS Source Table<br/>product_vs_index_source_table_name"]
	C["Product Vector Search Index<br/>product_vs_index_name"]
	D["Documents VS Source Table<br/>documents_vs_index_source_table_name"]
	E["Documents Vector Search Index<br/>documents_vs_index_name"]
	X["Product details VS Source Table<br/>product_detail_vs_index_source_table_name"]
	Y["Product details Vector Search Index<br/>product_detail_vs_index_name"]
	F["Neo4j Graph"]
	G["Lookup Table<br/>product_lookup_table_name"]

	A -->|"sync_product_discovery_index.py"| B
	B -->|"delta sync"| C
	A -->|"sync_product_documents_index.py (via product docs source)"| D
	D -->|"delta sync"| E
	A -->|"sync_product_detail_index.py"| X
	X -->|"delta sync"| Y
	A -->|"sync_product_graph.py"| F
	A -->|"sync_product_lookup.py"| G

	F --- F1["Nodes: Product, Brand, Manufacturer, Category, Group"]
	F --- F2["Edges: IN_*, CHILD_OF, BRANDED_BY, MANUFACTURED_BY, IN_PRODUCT_GROUP, COMPATIBLE_WITH, SUBSTITUTE_OF, BOUGHT_WITH"]
```

#### Product Vector Search (product discovery)

Backed by `${catalog}.${schema}.${product_vs_index_source_table_name}` from `notebooks/sync_product_discovery_index.py`.

- **Primary key**: `product_id`
- **Embedding source column**: `discovery_profile`
- **Discovery profile NLP cleanup**:
  - Strips URLs/control chars and normalizes whitespace
  - Removes common filler/stopwords
  - Deduplicates repeated segments and repeated tokens (order-preserving)
- **Columns exposed**:
  - `product_id`
  - `brand`
  - `manufacturer`
  - `own_brand_ind`
  - `web_class_nm`
  - `web_department_nm`
  - `web_category_nm`
  - `web_supercategory_nm`
  - `list_price` (from source `cache_list_price`)
  - `sale_price` (from source `cache_sale_price`)
  - `lifecycle_status`
  - `eco_feature_ind`
  - `eco_energy_star_certified_ind`
  - `eco_recycled_ind`
  - `discovery_profile`

#### Product Details Vector Search

Backed by `${catalog}.${schema}.${product_detail_vs_index_source_table_name}` from `notebooks/sync_product_detail_index.py`.

- **Primary key**: `detail_id`
- **Embedding source column**: `detail_text`
- **Purpose**: Designed for detail retrieval by product context (filter by `product_id` and `detail_type`)
- **Columns exposed**:
  - `detail_id`
  - `product_id`
  - `detail_type` (`spec`, `bullet`, `review`, `faq`, `claim`, `highlight`, `issue_signal`, `known_issue`, `troubleshooting`, `issue_frequency`)
  - `detail_text`

#### Document Vector Search (document lookup)

Backed by `${catalog}.${schema}.${documents_vs_index_source_table_name}` from `notebooks/sync_product_documents_index.py`.

- **Primary key**: `chunk_id`
- **Embedding source column**: `chunk_text`
- **Columns exposed**:
  - `chunk_id`
  - `product_id`
  - `document_id`
  - `url`
  - `chunk_text`
  - `chunk_index`

#### Neo4j Graph (product knowledge graph)

Built by `notebooks/sync_product_graph.py`.

```mermaid
flowchart LR
	P["Product"]
	B["Brand"]
	M["Manufacturer"]
	C["Category"]
	G["Group"]
	RP["Product (related)"]
	BW["Product (bought with)"]
	CP["Category (parent)"]

	P -->|"BRANDED_BY"| B
	P -->|"MANUFACTURED_BY"| M
	P -->|"IN_PRODUCT_GROUP"| G

	P -->|"IN_SUPERCATEGORY"| C
	P -->|"IN_CATEGORY"| C
	P -->|"IN_DEPARTMENT"| C
	P -->|"IN_CLASS"| C
	C -->|"CHILD_OF"| CP

	P -->|"COMPATIBLE_WITH<br/>source, confidence, compatibility_json"| RP
	P -->|"SUBSTITUTE_OF<br/>source, confidence, compatibility_json"| RP
	P -->|"BOUGHT_WITH"| BW
```

**Node labels and properties**:
- `Product`: `product_id`, `brand`, `manufacturer`, `own_brand_ind`, `web_class_nm`, `web_department_nm`, `web_category_nm`, `web_supercategory_nm`, `list_price`, `sale_price`, `lifecycle_status`, `eco_feature_ind`, `eco_energy_star_certified_ind`, `eco_recycled_ind`
- `Brand`: `name`, `is_owned_brand`
- `Manufacturer`: `name`
- `Category`: `name`, `level`
- `Group`: `group_id`

**Relationship types and direction**:
- `(:Product)-[:IN_SUPERCATEGORY]->(:Category)`
- `(:Product)-[:IN_DEPARTMENT]->(:Category)`
- `(:Product)-[:IN_CATEGORY]->(:Category)`
- `(:Product)-[:IN_CLASS]->(:Category)`
- `(:Category)-[:CHILD_OF]->(:Category)`
- `(:Product)-[:BRANDED_BY]->(:Brand)`
- `(:Product)-[:MANUFACTURED_BY]->(:Manufacturer)`
- `(:Product)-[:IN_PRODUCT_GROUP]->(:Group)`
- `(:Product)-[:COMPATIBLE_WITH]->(:Product)` with edge properties: `source`, `confidence`, `compatibility_json`
- `(:Product)-[:SUBSTITUTE_OF]->(:Product)` with edge properties: `source`, `confidence`, `compatibility_json`
- `(:Product)-[:BOUGHT_WITH]->(:Product)`

#### Product Lookup Table

Built by `notebooks/sync_product_lookup.py` as `${catalog}.${schema}.${product_lookup_table_name}`.

**Columns exposed**:
- **Core product identity**:
  - `product_id` (from source `item_id`)
  - `upc`, `ean`, `gtin`, `mpn`, `model_number`
  - `title`, `description`, `url`
  - `image_url`, `additional_image_urls`
- **Physical packaging**:
  - `multipack`
  - `length`, `width`, `height`, `weight` (unit-concatenated display strings)
  - `sell_unit_length`, `sell_unit_width`, `sell_unit_height`, `sell_unit_weight`: the same package (sell unit) size, under the names that replace the four above
  - `color`, `material`, `pattern`, `collection_name`
- **Fulfillment**:
  - `store_name`, `target_countries`, `store_country`
  - `bopis_eligible`, `dropship_dotcom_ind`, `ship_from_store_ind`, `auto_restock_ind`
  - `return_window`, `lifecycle_status`
- **Audience**:
  - `gender`, `age_group`, `age_restriction`
  - `room_context_json` (normalized array of room names where `confidence > 0.8`)
- **Quality, maintenance, and support**:
  - `review_count`, `star_rating`
  - `review_overall_summary`
  - `issue_frequency_score_json`
  - `reliability_score`, `maintenance_burden_score`, `setup_difficulty_score`
  - `compliance_tags_json` (normalized array of tag names where `confidence > 0.8`)
  - `warranty`, `support_warranty_duration_months`, `warning`
  - `support` (normalized array of structs: `channel`, `availability`, `email`, `phone`)

## CI/CD Pipelines

Pipeline definitions live in `azure-pipelines/`:

- `azure-pipelines-dab-bundle-cicd-dev.yml`
- `azure-pipelines-dab-bundle-cicd-qa.yml`
- `azure-pipelines-dab-bundle-cicd-prod.yml`

### Dev (`develop`)

- PR to `develop`:
  - runs `UnitTests`
  - runs `DevBundleCI` (bundle validation)
- Merge/push to `develop`:
  - runs `DevBundleCD` only (no unit test stage)
  - validates bundle
  - deploys bundle
  - runs notebook jobs in parallel:
	- `sync_product_discovery_index`
	- `sync_product_documents_index`
	- `sync_product_detail_index`
	- `sync_product_graph`
	- `sync_product_lookup`

### QA (`qa`)

- PR to `qa`:
  - runs `QABundleCI` (bundle validation)
- Merge/push to `qa`:
  - runs `QABundleCD`
  - validates bundle
  - deploys bundle
  - runs notebook jobs in parallel:
	- `sync_product_discovery_index`
	- `sync_product_documents_index`
	- `sync_product_detail_index`
	- `sync_product_graph`
	- `sync_product_lookup`

### Prod (`main`)

- PR to `main`:
  - runs `ProdBundleCI` (bundle validation)
- Merge/push to `main`:
  - runs `ProdBundleCD`
  - validates bundle
  - deploys bundle
  - runs notebook jobs in parallel:
	- `sync_product_discovery_index`
	- `sync_product_documents_index`
	- `sync_product_detail_index`
	- `sync_product_graph`
	- `sync_product_lookup`

### Tests for Dev Pipeline

The dev unit test stage expects:

- `tests/requirements-test.txt`
- at least one pytest test under `tests/`
- optional `tests/test_data/` directory (present in this repo)

Only the `dev` pipeline includes `UnitTests`. The `qa` and `prod` pipelines do not run unit tests.

### Azure Repos PR Triggering

This repository is hosted in Azure Repos. YAML `trigger` controls branch push/merge CI, but PR validation runs are started by branch policies.

To run pipeline validation automatically on PR updates, configure build validation on each target branch:

- `develop` -> `product_discovery_data_cicd_dev`
- `qa` -> `product_discovery_data_cicd_qa`
- `main` -> `product_discovery_data_cicd_prod`

## Coding Guidelines

### When Adding New Enrichment Pipelines

1. **File Location**: `src/data_pipeline/enrichment/[enrichment_type]_enrichment.py`

2. **Required Structure**:
```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, lit
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from src.utils.databricks_utils import get_spark_session

def enrich_[type](df, spark):
	"""
	Enrich products with [type] data.

	Args:
		df: Input DataFrame from silver layer
		spark: SparkSession

	Returns:
		DataFrame with new columns for [type] enrichment
	"""
	# Enrichment logic here
	return enriched_df

if __name__ == "__main__":
	spark = get_spark_session()

	# Read from silver layer
	input_table = "dev_agentic_commerce_catalog.silver_schema.staples_products_cleaned"
	df = spark.read.table(input_table)

	# Enrich
	enriched_df = enrich_[type](df, spark)

	# Write to gold layer
	output_table = "dev_agentic_commerce_catalog.gold_schema.[type]_enriched"
	enriched_df.write.mode("overwrite").saveAsTable(output_table)
```

3. **Add to Merge Script**: Update `merge_product_enrichments.py`:
   - Add table reference in merge SQL template
   - Add LEFT JOIN for new enrichment table
   - Add column selections in final SELECT

### LLM Integration Guidelines

When using LLMs for enrichment (e.g., generating business descriptions):
- Use **batch processing** to minimize API calls
- Implement **retry logic** with exponential backoff
- **Cache results** to avoid re-processing
- Add **validation** for LLM outputs (length, format, content)
- Store raw LLM responses for debugging

Example pattern:
```python
from openai import OpenAI
import time

def enrich_with_llm(product_data, client):
	"""Generate business context using LLM."""
	prompt = f"""
	Generate a B2B-focused description for:
	Product: {product_data['name']}
	Category: {product_data['category']}
	Features: {product_data['features']}

	Focus on business value, ROI, and professional use cases.
	"""

	try:
		response = client.chat.completions.create(
			model="gpt-4",
			messages=[{"role": "user", "content": prompt}],
			max_tokens=200
		)
		return response.choices[0].message.content
	except Exception as e:
		print(f"LLM error: {e}")
		return None
```

### Data Quality Rules

All enrichment pipelines should:
- ✅ Handle **null values** gracefully (use `when().otherwise()`)
- ✅ Maintain **product_id** as primary key
- ✅ Add **enrichment_timestamp** column
- ✅ Include **confidence_score** where applicable (0.0-1.0)
- ✅ Validate output schema before writing
- ✅ Log enrichment statistics (coverage %, null rates)

### Spark Best Practices

- Use **broadcast joins** for small lookup tables
- Avoid **collect()** on large datasets
- Use **coalesce()** for output partitioning
- Cache DataFrames only when reused multiple times
- Use **partitionBy()** when writing large tables

### Testing Approach

When adding new features:
1. **Unit tests**: Test enrichment logic on sample data
2. **Integration tests**: Test end-to-end pipeline with small dataset
3. **Data quality tests**: Validate output completeness and accuracy
4. **Manual QA**: Review sample enriched records for quality

## B2B Enrichment Priorities

### High Priority (Immediate Impact)
- **Business use case tags**: Small office, enterprise, remote work
- **Certifications**: BIFMA, Energy Star, OSHA, ADA compliance
- **Bulk ordering info**: Case quantities, volume pricing
- **TCO/ROI indicators**: Warranty, lifespan, cost-per-use

### Medium Priority (Next Quarter)
- **Industry suitability**: Healthcare, education, corporate
- **Compatibility data**: Integration with existing systems
- **Scalability info**: Single user vs team vs enterprise
- **Sustainability metrics**: Recycled content, energy efficiency

### Low Priority (Future)
- **Social proof**: Usage statistics, testimonials
- **Trend analysis**: Growing/declining demand
- **Supplier diversity**: Minority-owned, local suppliers

## AI Agent Integration

### Expected Query Patterns

The enriched data should support queries like:
- "Find ergonomic chairs for a 50-person office under $300 each"
- "What printer has the lowest cost-per-page for 5000 pages/month?"
- "Recommend janitorial supplies for a healthcare facility"
- "Compare breakroom coffee solutions for 30 employees"

### API Endpoints (Planned)

```
GET /api/products?category={category}&use_case={use_case}
GET /api/products/{id}/business-context
GET /api/products/compare?ids={id1,id2,id3}&dimensions={dim1,dim2}
GET /api/products/recommend?company_size={size}&industry={industry}
```

## Graph Mapping Scope (Current)

The current graph sync intentionally loads only direct mappings from the product table (no enrichment or canonical normalization yet).

- **Included from table values**:
  - `Product`, `Category`, `Brand`, `Manufacturer`, `Group`
  - Product taxonomy edges, brand/manufacturer links, product-group membership, and product-to-product links (`COMPATIBLE_WITH`, `SUBSTITUTE_OF`, `BOUGHT_WITH`)
- **Not included yet**:
  - LLM-extracted semantic graph layers (feature/persona intent nodes)
  - Canonical normalization layers beyond source-table values

## Notes

- All jobs are configured for Databricks serverless compute (no cluster definitions in `resources/jobs.yml`).
- All table names, schema/catalog, index names, model endpoints, and graph runtime settings are centralized under `variables` in `databricks.yml`.
- Checkpoints are configured from one shared base variable in `databricks.yml`:
  - `checkpoints_base_path`
  - Each notebook derives its concrete location as `<base>/sync_product_discovery_index`, `<base>/sync_product_documents_index`, `<base>/sync_product_detail_index`, `<base>/sync_product_lookup`, and `<base>/sync_product_graph`
- The graph stream notebook reads Neo4j credentials from Databricks secrets:
  - scope: `agentic_commerce`
  - keys: `neo4j_username`, `neo4j_password`
- The graph stream notebook expects runtime widgets for:
  - `neo4j_uri`, `neo4j_database`
- Graph sync always reads with Delta Change Data Feed (CDF) enabled (`readChangeFeed=true`).
- Ensure the source table has CDF turned on before running:
  - `ALTER TABLE <catalog>.<schema>.<table> SET TBLPROPERTIES (delta.enableChangeDataFeed = true)`

## Future Scaling Notes (Graph Sync)

Current graph writes prioritize correctness and deterministic relationship refresh behavior.

- Keep a single logical writer path by default (the current `foreachBatch` driver flow).
- If throughput becomes a bottleneck, scale with controlled parallelism only:
  - Use executor-side writes with `foreachPartition`
  - Explicitly cap partition concurrency (for example, fixed low `N` partitions)
  - Keep retries/backoff for transient Neo4j write-routing or connection errors
- Keep Neo4j constraints enabled for all graph identity keys before increasing write parallelism.

**Recommended batching guardrails**:

- Keep Cypher payload chunking bounded (currently 200 rows/chunk in graph sync).
- Add a soft per-microbatch cap before write fan-out (for example, 5k-20k product rows depending on observed Neo4j throughput).
- If a microbatch exceeds the cap, process in bounded slices rather than opening more concurrent writers.

## Common Issues & Solutions

### Issue: Merge script fails with missing columns
**Solution**: Check that all enrichment tables have run successfully and contain expected columns. Run individual enrichment scripts first.

### Issue: Spark session connection errors
**Solution**: Ensure Databricks credentials are set in environment variables or `.env` file.

### Issue: LLM rate limiting
**Solution**: Implement exponential backoff and batch processing with delays between batches.

### Issue: Low enrichment coverage
**Solution**: Review source data quality. Add fallback logic for missing attributes.

## Success Metrics

Track these KPIs for each enrichment:
- **Coverage %**: Percentage of products with enriched data
- **Null rate**: Percentage of null values in enriched columns
- **Validation errors**: Count of data quality failures
- **Processing time**: Time to enrich full catalog
- **Agent query success**: Percentage of queries successfully answered with enriched data

## Development Workflow

1. **Add new enrichment**: Create `[type]_enrichment.py` in `enrichment/`
2. **Test locally**: Run with small sample of data
3. **Validate output**: Check schema, completeness, quality
4. **Update merge script**: Add new table to final merge
5. **Run full pipeline**: Execute all enrichment → merge
6. **QA review**: Manually review enriched products
7. **Document**: Update this file with new enrichment details

## Next Steps

### Immediate (This Sprint)
- [ ] Fix any remaining bugs in merge_product_enrichments.py
- [ ] Add data quality validation tests
- [ ] Implement logging across all enrichment scripts

### Short-term (Next Sprint)
- [ ] Add LLM-based business description generation
- [ ] Implement certification data enrichment (BIFMA, Energy Star, etc.)
- [ ] Build bulk ordering information enrichment

### Long-term (Next Quarter)
- [ ] Build AI agent query interface
- [ ] Implement product comparison API
- [ ] Add recommendation engine
- [ ] Create monitoring dashboard for data quality

## Workspace Configuration

- Dev host: `https://adb-4144455588799812.12.azuredatabricks.net/`
- Bundle target: `dev` (default)

---

**Recent Major Updates**: 
* DAB Setup
* Implemented Row Hashing (change detection) for final table merge

**Author**: Venkat Neelraj Nitta

**Last Updated**: April 28, 2026
